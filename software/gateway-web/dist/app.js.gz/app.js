var Vt=Object.create;var Qe=Object.defineProperty;var Bt=Object.getOwnPropertyDescriptor;var Gt=Object.getOwnPropertyNames;var Kt=Object.getPrototypeOf,Qt=Object.prototype.hasOwnProperty;var Jt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var zt=(e,t,n,s)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Gt(t))!Qt.call(e,o)&&o!==n&&Qe(e,o,{get:()=>t[o],enumerable:!(s=Bt(t,o))||s.enumerable});return e};var Xt=(e,t,n)=>(n=e!=null?Vt(Kt(e)):{},zt(t||!e||!e.__esModule?Qe(n,"default",{value:e,enumerable:!0}):n,e));var Tt=Jt(He=>{var St;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof He=="object"?e(He):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(St={}):e(St={})})(function(e){e.version="1.2.2";function t(){for(var f=0,N=new Array(256),m=0;m!=256;++m)f=m,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,N[m]=f;return typeof Int32Array<"u"?new Int32Array(N):N}var n=t();function s(f){var N=0,m=0,b=0,g=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(b=0;b!=256;++b)g[b]=f[b];for(b=0;b!=256;++b)for(m=f[b],N=256+b;N<4096;N+=256)m=g[N]=m>>>8^f[m&255];var R=[];for(b=1;b!=16;++b)R[b-1]=typeof Int32Array<"u"?g.subarray(b*256,b*256+256):g.slice(b*256,b*256+256);return R}var o=s(n),a=o[0],r=o[1],l=o[2],u=o[3],c=o[4],p=o[5],i=o[6],_=o[7],h=o[8],y=o[9],F=o[10],x=o[11],S=o[12],w=o[13],L=o[14];function P(f,N){for(var m=N^-1,b=0,g=f.length;b<g;)m=m>>>8^n[(m^f.charCodeAt(b++))&255];return~m}function B(f,N){for(var m=N^-1,b=f.length-15,g=0;g<b;)m=L[f[g++]^m&255]^w[f[g++]^m>>8&255]^S[f[g++]^m>>16&255]^x[f[g++]^m>>>24]^F[f[g++]]^y[f[g++]]^h[f[g++]]^_[f[g++]]^i[f[g++]]^p[f[g++]]^c[f[g++]]^u[f[g++]]^l[f[g++]]^r[f[g++]]^a[f[g++]]^n[f[g++]];for(b+=15;g<b;)m=m>>>8^n[(m^f[g++])&255];return~m}function W(f,N){for(var m=N^-1,b=0,g=f.length,R=0,Se=0;b<g;)R=f.charCodeAt(b++),R<128?m=m>>>8^n[(m^R)&255]:R<2048?(m=m>>>8^n[(m^(192|R>>6&31))&255],m=m>>>8^n[(m^(128|R&63))&255]):R>=55296&&R<57344?(R=(R&1023)+64,Se=f.charCodeAt(b++)&1023,m=m>>>8^n[(m^(240|R>>8&7))&255],m=m>>>8^n[(m^(128|R>>2&63))&255],m=m>>>8^n[(m^(128|Se>>6&15|(R&3)<<4))&255],m=m>>>8^n[(m^(128|Se&63))&255]):(m=m>>>8^n[(m^(224|R>>12&15))&255],m=m>>>8^n[(m^(128|R>>6&63))&255],m=m>>>8^n[(m^(128|R&63))&255]);return~m}e.table=n,e.bstr=P,e.buf=B,e.str=W})});var he,E,Ze,Yt,J,Je,et,tt,nt,xe,Te,Ce,Zt,re={},st=[],en=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,$e=Array.isArray;function G(e,t){for(var n in t)e[n]=t[n];return e}function Ee(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ie(e,t,n){var s,o,a,r={};for(a in t)a=="key"?s=t[a]:a=="ref"?o=t[a]:r[a]=t[a];if(arguments.length>2&&(r.children=arguments.length>3?he.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(a in e.defaultProps)r[a]===void 0&&(r[a]=e.defaultProps[a]);return _e(e,r,s,o,null)}function _e(e,t,n,s,o){var a={type:e,props:t,key:n,ref:s,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++Ze,__i:-1,__u:0};return o==null&&E.vnode!=null&&E.vnode(a),a}function ve(e){return e.children}function fe(e,t){this.props=e,this.context=t}function ne(e,t){if(t==null)return e.__?ne(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?ne(e):null}function at(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return at(e)}}function ze(e){(!e.__d&&(e.__d=!0)&&J.push(e)&&!me.__r++||Je!=E.debounceRendering)&&((Je=E.debounceRendering)||et)(me)}function me(){for(var e,t,n,s,o,a,r,l=1;J.length;)J.length>l&&J.sort(tt),e=J.shift(),l=J.length,e.__d&&(n=void 0,o=(s=(t=e).__v).__e,a=[],r=[],t.__P&&((n=G({},s)).__v=s.__v+1,E.vnode&&E.vnode(n),Re(t.__P,n,s,t.__n,t.__P.namespaceURI,32&s.__u?[o]:null,a,o??ne(s),!!(32&s.__u),r),n.__v=s.__v,n.__.__k[n.__i]=n,it(a,n,r),n.__e!=o&&at(n)));me.__r=0}function ot(e,t,n,s,o,a,r,l,u,c,p){var i,_,h,y,F,x,S=s&&s.__k||st,w=t.length;for(u=tn(n,t,S,u,w),i=0;i<w;i++)(h=n.__k[i])!=null&&(_=h.__i==-1?re:S[h.__i]||re,h.__i=i,x=Re(e,h,_,o,a,r,l,u,c,p),y=h.__e,h.ref&&_.ref!=h.ref&&(_.ref&&Fe(_.ref,null,h),p.push(h.ref,h.__c||y,h)),F==null&&y!=null&&(F=y),4&h.__u||_.__k===h.__k?u=rt(h,u,e):typeof h.type=="function"&&x!==void 0?u=x:y&&(u=y.nextSibling),h.__u&=-7);return n.__e=F,u}function tn(e,t,n,s,o){var a,r,l,u,c,p=n.length,i=p,_=0;for(e.__k=new Array(o),a=0;a<o;a++)(r=t[a])!=null&&typeof r!="boolean"&&typeof r!="function"?(u=a+_,(r=e.__k[a]=typeof r=="string"||typeof r=="number"||typeof r=="bigint"||r.constructor==String?_e(null,r,null,null,null):$e(r)?_e(ve,{children:r},null,null,null):r.constructor==null&&r.__b>0?_e(r.type,r.props,r.key,r.ref?r.ref:null,r.__v):r).__=e,r.__b=e.__b+1,l=null,(c=r.__i=nn(r,n,u,i))!=-1&&(i--,(l=n[c])&&(l.__u|=2)),l==null||l.__v==null?(c==-1&&(o>p?_--:o<p&&_++),typeof r.type!="function"&&(r.__u|=4)):c!=u&&(c==u-1?_--:c==u+1?_++:(c>u?_--:_++,r.__u|=4))):e.__k[a]=null;if(i)for(a=0;a<p;a++)(l=n[a])!=null&&(2&l.__u)==0&&(l.__e==s&&(s=ne(l)),ct(l,l));return s}function rt(e,t,n){var s,o;if(typeof e.type=="function"){for(s=e.__k,o=0;s&&o<s.length;o++)s[o]&&(s[o].__=e,t=rt(s[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=ne(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function nn(e,t,n,s){var o,a,r=e.key,l=e.type,u=t[n];if(u===null&&e.key==null||u&&r==u.key&&l==u.type&&(2&u.__u)==0)return n;if(s>(u!=null&&(2&u.__u)==0?1:0))for(o=n-1,a=n+1;o>=0||a<t.length;){if(o>=0){if((u=t[o])&&(2&u.__u)==0&&r==u.key&&l==u.type)return o;o--}if(a<t.length){if((u=t[a])&&(2&u.__u)==0&&r==u.key&&l==u.type)return a;a++}}return-1}function Xe(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||en.test(t)?n:n+"px"}function pe(e,t,n,s,o){var a,r;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof s=="string"&&(e.style.cssText=s=""),s)for(t in s)n&&t in n||Xe(e.style,t,"");if(n)for(t in n)s&&n[t]==s[t]||Xe(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")a=t!=(t=t.replace(nt,"$1")),r=t.toLowerCase(),t=r in e||t=="onFocusOut"||t=="onFocusIn"?r.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+a]=n,n?s?n.u=s.u:(n.u=xe,e.addEventListener(t,a?Ce:Te,a)):e.removeEventListener(t,a?Ce:Te,a);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ye(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=xe++;else if(t.t<n.u)return;return n(E.event?E.event(t):t)}}}function Re(e,t,n,s,o,a,r,l,u,c){var p,i,_,h,y,F,x,S,w,L,P,B,W,f,N,m,b,g=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),a=[l=t.__e=n.__e]),(p=E.__b)&&p(t);e:if(typeof g=="function")try{if(S=t.props,w="prototype"in g&&g.prototype.render,L=(p=g.contextType)&&s[p.__c],P=p?L?L.props.value:p.__:s,n.__c?x=(i=t.__c=n.__c).__=i.__E:(w?t.__c=i=new g(S,P):(t.__c=i=new fe(S,P),i.constructor=g,i.render=an),L&&L.sub(i),i.props=S,i.state||(i.state={}),i.context=P,i.__n=s,_=i.__d=!0,i.__h=[],i._sb=[]),w&&i.__s==null&&(i.__s=i.state),w&&g.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=G({},i.__s)),G(i.__s,g.getDerivedStateFromProps(S,i.__s))),h=i.props,y=i.state,i.__v=t,_)w&&g.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),w&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(w&&g.getDerivedStateFromProps==null&&S!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(S,P),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(S,i.__s,P)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=S,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(R){R&&(R.__=t)}),B=0;B<i._sb.length;B++)i.__h.push(i._sb[B]);i._sb=[],i.__h.length&&r.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(S,i.__s,P),w&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,y,F)})}if(i.context=P,i.props=S,i.__P=e,i.__e=!1,W=E.__r,f=0,w){for(i.state=i.__s,i.__d=!1,W&&W(t),p=i.render(i.props,i.state,i.context),N=0;N<i._sb.length;N++)i.__h.push(i._sb[N]);i._sb=[]}else do i.__d=!1,W&&W(t),p=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++f<25);i.state=i.__s,i.getChildContext!=null&&(s=G(G({},s),i.getChildContext())),w&&!_&&i.getSnapshotBeforeUpdate!=null&&(F=i.getSnapshotBeforeUpdate(h,y)),m=p,p!=null&&p.type===ve&&p.key==null&&(m=lt(p.props.children)),l=ot(e,$e(m)?m:[m],t,n,s,o,a,r,l,u,c),i.base=t.__e,t.__u&=-161,i.__h.length&&r.push(i),x&&(i.__E=i.__=null)}catch(R){if(t.__v=null,u||a!=null)if(R.then){for(t.__u|=u?160:128;l&&l.nodeType==8&&l.nextSibling;)l=l.nextSibling;a[a.indexOf(l)]=null,t.__e=l}else for(b=a.length;b--;)Ee(a[b]);else t.__e=n.__e,t.__k=n.__k;E.__e(R,t,n)}else a==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):l=t.__e=sn(n.__e,t,n,s,o,a,r,u,c);return(p=E.diffed)&&p(t),128&t.__u?void 0:l}function it(e,t,n){for(var s=0;s<n.length;s++)Fe(n[s],n[++s],n[++s]);E.__c&&E.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(a){a.call(o)})}catch(a){E.__e(a,o.__v)}})}function lt(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:$e(e)?e.map(lt):G({},e)}function sn(e,t,n,s,o,a,r,l,u){var c,p,i,_,h,y,F,x=n.props,S=t.props,w=t.type;if(w=="svg"?o="http://www.w3.org/2000/svg":w=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),a!=null){for(c=0;c<a.length;c++)if((h=a[c])&&"setAttribute"in h==!!w&&(w?h.localName==w:h.nodeType==3)){e=h,a[c]=null;break}}if(e==null){if(w==null)return document.createTextNode(S);e=document.createElementNS(o,w,S.is&&S),l&&(E.__m&&E.__m(t,a),l=!1),a=null}if(w==null)x===S||l&&e.data==S||(e.data=S);else{if(a=a&&he.call(e.childNodes),x=n.props||re,!l&&a!=null)for(x={},c=0;c<e.attributes.length;c++)x[(h=e.attributes[c]).name]=h.value;for(c in x)if(h=x[c],c!="children"){if(c=="dangerouslySetInnerHTML")i=h;else if(!(c in S)){if(c=="value"&&"defaultValue"in S||c=="checked"&&"defaultChecked"in S)continue;pe(e,c,null,h,o)}}for(c in S)h=S[c],c=="children"?_=h:c=="dangerouslySetInnerHTML"?p=h:c=="value"?y=h:c=="checked"?F=h:l&&typeof h!="function"||x[c]===h||pe(e,c,h,x[c],o);if(p)l||i&&(p.__html==i.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(i&&(e.innerHTML=""),ot(t.type=="template"?e.content:e,$e(_)?_:[_],t,n,s,w=="foreignObject"?"http://www.w3.org/1999/xhtml":o,a,r,a?a[0]:n.__k&&ne(n,0),l,u),a!=null)for(c=a.length;c--;)Ee(a[c]);l||(c="value",w=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[c]||w=="progress"&&!y||w=="option"&&y!=x[c])&&pe(e,c,y,x[c],o),c="checked",F!=null&&F!=e[c]&&pe(e,c,F,x[c],o))}return e}function Fe(e,t,n){try{if(typeof e=="function"){var s=typeof e.__u=="function";s&&e.__u(),s&&t==null||(e.__u=e(t))}else e.current=t}catch(o){E.__e(o,n)}}function ct(e,t,n){var s,o;if(E.unmount&&E.unmount(e),(s=e.ref)&&(s.current&&s.current!=e.__e||Fe(s,null,t)),(s=e.__c)!=null){if(s.componentWillUnmount)try{s.componentWillUnmount()}catch(a){E.__e(a,t)}s.base=s.__P=null}if(s=e.__k)for(o=0;o<s.length;o++)s[o]&&ct(s[o],t,n||typeof e.type!="function");n||Ee(e.__e),e.__c=e.__=e.__e=void 0}function an(e,t,n){return this.constructor(e,n)}function dt(e,t,n){var s,o,a,r;t==document&&(t=document.documentElement),E.__&&E.__(e,t),o=(s=typeof n=="function")?null:n&&n.__k||t.__k,a=[],r=[],Re(t,e=(!s&&n||t).__k=ie(ve,null,[e]),o||re,re,t.namespaceURI,!s&&n?[n]:o?null:t.firstChild?he.call(t.childNodes):null,a,!s&&n?n:o?o.__e:t.firstChild,s,r),it(a,e,r)}he=st.slice,E={__e:function(e,t,n,s){for(var o,a,r;t=t.__;)if((o=t.__c)&&!o.__)try{if((a=o.constructor)&&a.getDerivedStateFromError!=null&&(o.setState(a.getDerivedStateFromError(e)),r=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,s||{}),r=o.__d),r)return o.__E=o}catch(l){e=l}throw e}},Ze=0,Yt=function(e){return e!=null&&e.constructor==null},fe.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=G({},this.state),typeof e=="function"&&(e=e(G({},n),this.props)),e&&G(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),ze(this))},fe.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),ze(this))},fe.prototype.render=ve,J=[],et=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,tt=function(e,t){return e.__v.__b-t.__v.__b},me.__r=0,nt=/(PointerCapture)$|Capture$/i,xe=0,Te=Ye(!1),Ce=Ye(!0),Zt=0;var le,I,Ie,ut,ce=0,gt=[],A=E,pt=A.__b,_t=A.__r,ft=A.diffed,mt=A.__c,ht=A.unmount,$t=A.__;function Ne(e,t){A.__h&&A.__h(I,e,ce||t),ce=0;var n=I.__H||(I.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function v(e){return ce=1,on(kt,e)}function on(e,t,n){var s=Ne(le++,2);if(s.t=e,!s.__c&&(s.__=[n?n(t):kt(void 0,t),function(l){var u=s.__N?s.__N[0]:s.__[0],c=s.t(u,l);u!==c&&(s.__N=[c,s.__[1]],s.__c.setState({}))}],s.__c=I,!I.__f)){var o=function(l,u,c){if(!s.__c.__H)return!0;var p=s.__c.__H.__.filter(function(_){return!!_.__c});if(p.every(function(_){return!_.__N}))return!a||a.call(this,l,u,c);var i=s.__c.props!==l;return p.forEach(function(_){if(_.__N){var h=_.__[0];_.__=_.__N,_.__N=void 0,h!==_.__[0]&&(i=!0)}}),a&&a.call(this,l,u,c)||i};I.__f=!0;var a=I.shouldComponentUpdate,r=I.componentWillUpdate;I.componentWillUpdate=function(l,u,c){if(this.__e){var p=a;a=void 0,o(l,u,c),a=p}r&&r.call(this,l,u,c)},I.shouldComponentUpdate=o}return s.__N||s.__}function z(e,t){var n=Ne(le++,3);!A.__s&&bt(n.__H,t)&&(n.__=e,n.u=t,I.__H.__h.push(n))}function ye(e){return ce=5,yt(function(){return{current:e}},[])}function yt(e,t){var n=Ne(le++,7);return bt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function wt(e,t){return ce=8,yt(function(){return e},t)}function rn(){for(var e;e=gt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ge),e.__H.__h.forEach(Ae),e.__H.__h=[]}catch(t){e.__H.__h=[],A.__e(t,e.__v)}}A.__b=function(e){I=null,pt&&pt(e)},A.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),$t&&$t(e,t)},A.__r=function(e){_t&&_t(e),le=0;var t=(I=e.__c).__H;t&&(Ie===I?(t.__h=[],I.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ge),t.__h.forEach(Ae),t.__h=[],le=0)),Ie=I},A.diffed=function(e){ft&&ft(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(gt.push(t)!==1&&ut===A.requestAnimationFrame||((ut=A.requestAnimationFrame)||ln)(rn)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ie=I=null},A.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ge),n.__h=n.__h.filter(function(s){return!s.__||Ae(s)})}catch(s){t.some(function(o){o.__h&&(o.__h=[])}),t=[],A.__e(s,n.__v)}}),mt&&mt(e,t)},A.unmount=function(e){ht&&ht(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(s){try{ge(s)}catch(o){t=o}}),n.__H=void 0,t&&A.__e(t,n.__v))};var vt=typeof requestAnimationFrame=="function";function ln(e){var t,n=function(){clearTimeout(s),vt&&cancelAnimationFrame(t),setTimeout(e)},s=setTimeout(n,35);vt&&(t=requestAnimationFrame(n))}function ge(e){var t=I,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),I=t}function Ae(e){var t=I;e.__c=e.__(),I=t}function bt(e,t){return!e||e.length!==t.length||t.some(function(n,s){return n!==e[s]})}function kt(e,t){return typeof t=="function"?t(e):t}var Ct=Xt(Tt()),Pe="/api/v1",se=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},cn=e=>new Promise(t=>setTimeout(t,e));async function ue(e,t,n){let s=typeof n=="string";for(let o=1;;o++){let a;try{a=await fetch(Pe+t,{method:e,headers:n===void 0?{}:{"Content-Type":s?"application/x-pem-file":"application/json"},body:n===void 0?void 0:s?n:JSON.stringify(n)})}catch{if(o>=4)throw new se(0,{message:"gateway unreachable"});await cn(250*o);continue}let r=await a.text(),l=null;try{l=r?JSON.parse(r):null}catch{l={message:r}}if(!a.ok)throw new se(a.status,l);return l}}var V=e=>ue("GET",e),K=(e,t)=>ue("POST",e,t),j=(e,t)=>ue("PUT",e,t),de=(e,t)=>ue("PATCH",e,t),Le=e=>ue("DELETE",e),U=encodeURIComponent,Me={get:()=>V("/system"),restart:()=>K("/system/restart")},De={get:()=>V("/config"),update:e=>de("/config",e)},X={all:()=>V("/mqtt"),updateAll:e=>de("/mqtt",e),update:(e,t)=>de(`/mqtt/${e}`,t),trust:e=>K(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>Le(`/mqtt/${e}/certificate`)},q={get:()=>V("/tls"),update:e=>de("/tls",e),selfSigned:e=>K("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Pe}/tls/csr`,installCertificate:e=>j("/tls/certificate",e),setTrustAnchor:e=>j("/tls/trust-anchor",e),removeTrustAnchor:()=>Le("/tls/trust-anchor"),setIdentity:e=>j("/tls/est/identity",e),removeIdentity:()=>Le("/tls/est/identity"),enroll:()=>K("/tls/est/enroll")},H={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${U(e)}`),update:(e,t)=>de(`/devices/${U(e)}`,t),action:(e,t)=>K(`/devices/${U(e)}/${t}`),silence:(e,t)=>j(`/devices/${U(e)}/silence`,{on:t}),relay:(e,t,n,s)=>j(`/devices/${U(e)}/relays/${t}`,{state:n,duration_ms:s}),rollershutter:(e,t,n,s)=>j(`/devices/${U(e)}/rollershutters/${t}`,{state:n,duration_ms:s}),lamps:(e,t,n,s)=>j(`/devices/${U(e)}/lamps/${t}`,{value:n,bitmask:s}),heating:(e,t,n)=>j(`/devices/${U(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${U(e)}/heating/manual`),heatingManual:(e,t,n,s)=>j(`/devices/${U(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:s})},Y={update:(e,t,n)=>j(`/devices/${U(e)}/sensors/${t}`,n),refresh:e=>K(`/devices/${U(e)}/sensors/refresh`),forget:e=>K(`/devices/${U(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${U(e)}`:"",s=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...s.sensors),s.sensors.length===0||t.length>=s.total)return t}}},ae={action:e=>K(`/bus/${e}`),silence:e=>j("/bus/silence",{on:e}),typeAction:(e,t)=>K(`/device-types/${e}/${t}`)},Ue={job:()=>V("/firmware/job"),upload(e,t,n){let s=Ct.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((a,r)=>{let l=new XMLHttpRequest;l.open("PUT",`${Pe}${o}?crc32=${s}`),l.setRequestHeader("Content-Type","application/octet-stream"),l.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),l.onload=()=>{let u=null;try{u=JSON.parse(l.responseText)}catch{}l.status>=200&&l.status<300?a(u):r(new se(l.status,u))},l.onerror=()=>r(new se(0,{message:"upload failed"})),l.send(t)})}};var Et=function(e,t,n,s){var o;t[0]=0;for(var a=1;a<t.length;a++){var r=t[a++],l=t[a]?(t[0]|=r?1:2,n[t[a++]]):t[++a];r===3?s[0]=l:r===4?s[1]=Object.assign(s[1]||{},l):r===5?(s[1]=s[1]||{})[t[++a]]=l:r===6?s[1][t[++a]]+=l+"":r?(o=e.apply(l,Et(e,l,n,["",null])),s.push(o),l[0]?t[0]|=2:(t[a-2]=0,t[a]=o)):s.push(l)}return s},xt=new Map;function Rt(e){var t=xt.get(this);return t||(t=new Map,xt.set(this,t)),(t=Et(this,t.get(e)||(t.set(e,t=function(n){for(var s,o,a=1,r="",l="",u=[0],c=function(_){a===1&&(_||(r=r.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,_,r):a===3&&(_||r)?(u.push(3,_,r),a=2):a===2&&r==="..."&&_?u.push(4,_,0):a===2&&r&&!_?u.push(5,0,!0,r):a>=5&&((r||!_&&a===5)&&(u.push(a,0,r,o),a=6),_&&(u.push(a,_,0,o),a=6)),r=""},p=0;p<n.length;p++){p&&(a===1&&c(),c(p));for(var i=0;i<n[p].length;i++)s=n[p][i],a===1?s==="<"?(c(),u=[u],a=3):r+=s:a===4?r==="--"&&s===">"?(a=1,r=""):r=s+r[0]:l?s===l?l="":r+=s:s==='"'||s==="'"?l=s:s===">"?(c(),a=1):a&&(s==="="?(a=5,o=r,r=""):s==="/"&&(a<5||n[p][i+1]===">")?(c(),a===3&&(u=u[0]),a=u,(u=u[0]).push(2,0,a),a=0):s===" "||s==="	"||s===`
`||s==="\r"?(c(),a=2):r+=s),a===3&&r==="!--"&&(a=4,u=u[0])}return c(),u}(e)),t),arguments,[])).length>1?t:t[0]}var d=Rt.bind(ie),qe=()=>{};function O(e,t="ok"){qe(e,t)}function Ft(){let[e,t]=v([]);return z(()=>{let n=0;return qe=(s,o)=>{let a={id:++n,message:s,kind:o};t(r=>[...r,a]),setTimeout(()=>t(r=>r.filter(l=>l!==a)),o==="error"?8e3:3e3)},()=>qe=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function T(e,t){try{let n=await e();return t&&O(t),n}catch(n){O(n.message,"error");return}}function M(e,t){let[n,s]=v({data:void 0,error:void 0}),o=ye(e);o.current=e;let a=wt(async()=>{try{s({data:await o.current(),error:void 0})}catch(r){s(l=>({data:l.data,error:r}))}},[]);return z(()=>{let r=!1,l,u=async()=>{await a(),t&&!r&&(l=setTimeout(u,t))};return u(),()=>{r=!0,clearTimeout(l)}},[t,a]),{...n,reload:a}}var k=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,D=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:s})=>{let[o,a]=v(!1);return d`<button class=${t||""} disabled=${s||o} onClick=${async l=>{a(!0);try{await n(l)}finally{a(!1)}}}>${e}</button>`},Oe=e=>"0x"+e.toString(16).padStart(2,"0");function ee(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function It(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),s=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${s} min`:`${s} min`}function we({target:e,label:t,others:n=[],onDone:s}){let[o,a]=v(null),[r,l]=v(null),[u,c]=v(""),[p,i]=v(null),_=ye(null);z(()=>()=>clearInterval(_.current),[]);let h=()=>{clearInterval(_.current),_.current=setInterval(async()=>{try{i(await Ue.job())}catch{}},1500)},y=async(w,L)=>{c(w),l(0),L!=="gateway"&&h();try{let P=await o.arrayBuffer();return await Ue.upload(L,P,l)||{}}finally{clearInterval(_.current),l(null)}},F=async w=>{if(!o)return;let L=0;for(let{name:P,target:B}of w)try{let W=await y(P,B);L+=1,W.restarting&&O("Firmware installed, the gateway restarts\u2026")}catch(W){O(`${P}: ${W.message}`,"error");break}L===w.length&&w[0].target!=="gateway"&&O(L===1?"Firmware sent; the device restarts into it":`Firmware sent to ${L} devices`),c(""),i(null),s&&s()},x=r!==null,S=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>a(w.target.files[0]||null)} />
      <${$} onClick=${()=>F([{name:t||"device",target:e}])} disabled=${!o||x}>${t||"Upload"}<//>
      ${n.length>0&&d`<${$} onClick=${()=>F([{name:"this device",target:e},...n])} disabled=${!o||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&d`<progress max="1" value=${r}></progress>`}
      ${x&&d`<p class="muted wide">${u}${S?" \u2014 "+S:""}</p>`}
    </div>`}var be=new Set;function dn(e){e!==location.pathname&&history.pushState(null,"",e),be.forEach(t=>t())}addEventListener("popstate",()=>be.forEach(e=>e()));function At(){let[e,t]=v(location.pathname);return z(()=>{let n=()=>t(location.pathname);return be.add(n),()=>be.delete(n)},[]),e}function Nt(e,t){let n=t.split("/").filter(Boolean);for(let s of e){let o=s.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let a={};if(o.every((l,u)=>l.startsWith(":")?(a[l.slice(1)]=decodeURIComponent(n[u]),!0):l===n[u]))return{route:s,params:a}}return null}function te({href:e,children:t,...n}){return ie("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),dn(e))},...n},t)}var un={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},Ht={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},We=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],pn={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},oe=e=>pn[e]||e;function ke(e,t=5e3){let n=M(()=>Y.list(e),t),s=[...new Set((n.data||[]).map(a=>a.device))];return{...n,ask:async()=>{for(let a of e?[e]:s)await T(()=>Y.refresh(a));setTimeout(n.reload,1500)}}}function _n({s:e,device:t,reload:n}){let[s,o]=v(!1),[a,r]=v(e.name||""),[l,u]=v(e.role||"none"),c=async()=>{let p={};if(a!==(e.name||"")&&(p.name=a),l!==(e.role||"none")&&(p.role=l),Object.keys(p).length===0)return o(!1);await T(()=>Y.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${te} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${s?d`<input class="inline" maxlength="7" placeholder="name" value=${a} onInput=${p=>r(p.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${un[e.kind]||e.kind}</td>
    <td>${s?d`<select value=${l} onChange=${p=>u(p.target.value)}>${We.map(p=>d`<option value=${p}>${oe(p)}</option>`)}</select>`:e.role&&e.role!=="none"?oe(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind in Ht?e.value.toFixed(Ht[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ee(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":s?d`<${$} kind="primary" onClick=${c}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function je({device:e}){let{data:t,error:n,reload:s,ask:o}=ke(e);if(!t)return d`<${D} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let a=t.some(r=>r.named_by_node&&r.slot===null);return d`
    ${a&&d`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(r=>d`<${_n} key=${r.device_key+r.kind+r.sensor_id} s=${r} device=${e} reload=${s} />`)}
      </tbody>
    </table></div>`}function Lt(){let{ask:e}=ke(void 0,0);return d`<${k} title="Sensors" aside=${d`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${je} />
  <//>`}var fn=[2,5,8,9],mn=[7],hn=[3],$n=3,Ve=[9],vn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],gn=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Dt({device:e}){let{data:t,error:n,reload:s}=M(()=>H.get(e),5e3);return t?d`
    <${wn} d=${t} reload=${s} />
    ${fn.includes(t.device_type)&&d`<${Pt} d=${t} kind="relay" />`}
    ${mn.includes(t.device_type)&&d`<${Pt} d=${t} kind="rollershutter" />`}
    ${hn.includes(t.device_type)&&d`<${Mt} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===$n&&d`<${Mt} d=${t} firstBank=${1} />`}
    ${Ve.includes(t.device_type)&&d`<${bn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${Sn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${Tn} d=${t} />`}
    <${k} title="Sensors"><${je} device=${t.name||t.key} /><//>
    <${Cn} d=${t} reload=${s} />
    <${yn} d=${t} />`:d`<${D} error=${n} />`}function yn({d:e}){let t=e.name||e.key,{data:n}=M(H.list),s=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${k} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${we} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${s} />
    <//>`}function wn({d:e,reload:t}){let n=e.name||e.key,s=(o,a)=>async()=>{await T(()=>H.action(n,o),a),setTimeout(t,1500)};return d`
    <${k} title=${n}
      aside=${d`<span class="buttons">
        <${$} onClick=${s("ping","Ping sent")}>Ping<//>
        <${$} onClick=${s("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${s("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ee(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Pt({d:e,kind:t}){let n=e.name||e.key,[s,o]=v(1),[a,r]=v(0),l=t==="rollershutter",u=c=>()=>T(()=>H[t](n,s,c,Math.round(a*1e3)),`${l?"Rollershutter":"Relay"} ${s}: ${c}`);return d`
    <${k} title=${l?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${s} onInput=${c=>o(+c.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${a} onInput=${c=>r(+c.target.value)} /><//>
      </div>
      <div class="buttons">
        ${l?d`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:d`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function Mt({d:e,firstBank:t=0}){let n=e.name||e.key,[s,o]=v(t),[a,r]=v(255),[l,u]=v(Array(24).fill(!1)),c=l.reduce((p,i,_)=>i?p|1<<23-_:p,0);return d`
    <${k} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min=${t} max="255" value=${s} onInput=${p=>o(+p.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${p=>r(+p.target.value)} /><//>
      </div>
      <div class="lamps">
        ${l.map((p,i)=>d`<label key=${i} class=${"lamp"+(p?" on":"")}>
            <input type="checkbox" checked=${p} onChange=${()=>u(l.map((_,h)=>h===i?!_:_))} />${23-i}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>T(()=>H.lamps(n,s,a,c),"Lamps set")}>Send<//>
    <//>`}function bn({d:e}){let t=e.name||e.key,[n,s]=v(45),[o,a]=v(!1),[r,l]=v(0),[u,c]=v(!1),[p,i]=v(0),[_,h]=v(55);return d`
    <${k} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>s(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${y=>a(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>T(()=>H.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${r} onInput=${y=>l(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${y=>c(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>T(()=>H.heating(t,"energy",{power_w:r,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>i(+y.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${_} onInput=${y=>h(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>T(()=>H.heating(t,"emergency",{stage:p,tank_c:_}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var kn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function Sn({d:e}){let t=e.name||e.key,{data:n,error:s,reload:o,ask:a}=ke(t);if(!n)return d`<${k} title="Sensor assignment"><${D} error=${s} /><//>`;let r=n.filter(i=>i.kind==="temperature"),l=i=>r.find(_=>_.role===i),u=i=>i.name?`${i.name} (${i.sensor_id})`:i.sensor_id,c=r.every(i=>i.slot!==null),p=i=>async _=>{let h=_.target.value,y;if(h===""){let F=l(i);if(!F)return;y=await T(()=>Y.update(t,F.slot,{role:"none"}),`${oe(i)} cleared`)}else{let F=r.find(x=>x.sensor_id===h);y=await T(()=>Y.update(t,F.slot,{role:i}),`${u(F)} is ${oe(i)} now`)}y&&setTimeout(o,1500)};return d`
    <${k} title="Sensor assignment" aside=${d`<${$} onClick=${a}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!c&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${We.filter(i=>i!=="none").map(i=>d`<label key=${i} class="field">
            <span>${oe(i)}</span>
            <select value=${(l(i)||{}).sensor_id||""} onChange=${p(i)} disabled=${!c}>
              <option value="">(none)</option>
              ${r.map(_=>d`<option value=${_.sensor_id}>${u(_)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Tn({d:e}){let t=e.name||e.key,{data:n,error:s,reload:o}=M(()=>H.heatingManualState(t),3e3),a=!!(n&&n.enabled),r=p=>!!(n&&n.relays.includes(p)),l=async()=>{let p=!a;await T(()=>H.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},u=p=>async()=>{await T(()=>H.heatingManual(t,!0,p,!r(p)),`Relay ${p} ${r(p)?"off":"on"}`)&&setTimeout(o,800)},c=p=>p===8&&r(9)||p===9&&r(8);return d`
    <${k} title="Manual mode"
      aside=${d`<${$} kind=${a?"danger":""} disabled=${!n} onClick=${l}>${a?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${s&&d`<p class="error">The controller does not answer: ${s.message}</p>`}
      ${a&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${kn.map(([p,i])=>d`<button key=${p} class=${r(p)?"primary":""} disabled=${!a||c(p)} onClick=${u(p)}>
            <span>${i}</span><small>relay ${p}: ${r(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Cn({d:e,reload:t}){let n=e.name||e.key,[s,o]=v({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[a,r]=v(!1),l=c=>p=>o({...s,[c]:p.target.value}),u=async()=>{let c={};if(s.custom_string!==e.name&&(c.custom_string=s.custom_string),+s.hwrev!==e.hwrev&&(c.hwrev=+s.hwrev),s.relais_mode&&(c.relais_mode=s.relais_mode),s.extension_mode&&(c.extension_mode=s.extension_mode),Object.keys(c).length===0)return O("Nothing changed");await T(()=>H.update(n,c),"Settings sent")&&setTimeout(t,1500)};return d`
    <${k} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${s.custom_string} onInput=${l("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${s.hwrev} onInput=${l("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${s.relais_mode} onChange=${l("relais_mode")}>
          <option value="">(unchanged)</option>${vn.map(c=>d`<option>${c}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${s.extension_mode} onChange=${l("extension_mode")}>
          <option value="">(unchanged)</option>${gn.map(c=>d`<option>${c}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await T(()=>H.silence(n,!a),a?"Device may talk again":"Device silenced"),r(!a)}}>${a?"End silence":"Silence"}<//>
        <${$} onClick=${()=>T(()=>H.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Ut(){let{data:e,error:t,reload:n}=M(H.list,5e3),[s,o]=v(""),a=(c,p)=>async()=>{await T(c,p),setTimeout(n,1500)},r=async()=>{let c=s.trim();c&&await T(()=>H.action(c,"ping"),`Ping sent to ${c}`)},l=async()=>{confirm("Restart every device on the bus?")&&await a(()=>ae.action("restart"),"Restart sent to every device")()},u=a(()=>ae.action("discover"),"Scanning: every device was asked to announce itself");return d`
    <${k} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${a(()=>ae.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${a(()=>ae.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${a(()=>ae.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${l}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${s} onInput=${c=>o(c.target.value)} onKeyDown=${c=>c.key==="Enter"&&r()} />
        <${$} onClick=${r}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(c=>d`<tr key=${c.key}>
                    <td><${te} href=${"/devices/"+encodeURIComponent(c.name||c.key)}>${c.name||c.key}<//></td>
                    <td><code>${Oe(c.device_id)}</code></td>
                    <td>${c.type_name} <code>${Oe(c.device_type)}</code></td>
                    <td>${c.version}</td>
                    <td>${ee(c.last_seen_minutes_ago)}</td>
                    <td>${c.uptime?ee(Math.floor(c.uptime/60)):""}</td>
                    <td>${c.error?d`<span class="badge bad">error ${c.error}</span>`:c.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${D} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function qt(){let e=M(Me.get,5e3);return d`<${xn} ...${e} /><${En} ...${e} /><${Rn} /><${Fn} />`}function xn({data:e,error:t}){return d`
    <${k} title="Gateway" aside=${d`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await T(Me.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${It(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${D} error=${t} />`}
    <//>`}function En({data:e,error:t}){if(!e)return d`<${k} title="Network"><${D} error=${t} /><//>`;let n=e.network;if(!n)return d`<${k} title="Network"><p>No Ethernet.</p><//>`;let s=a=>a.map(r=>d`<div>${r.address} <span class="muted">(${r.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${k} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?s(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?s(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function Rn(){let{data:e,error:t,reload:n}=M(De.get),[s,o]=v({});if(!e)return d`<${D} error=${t} />`;let a=u=>u in s?s[u]:e[u],r=(u,c)=>p=>o({...s,[u]:c?+p.target.value:p.target.value}),l=async()=>{let u={...s};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return O("Nothing changed");let c=await T(()=>De.update(u),"Saved");c&&(c.restart_required&&O("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${k} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${a("hostname")} onInput=${r("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${a("can_bitrate")} onChange=${r("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${a("update_delay_ms")} onInput=${r("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${a("web_username")} onInput=${r("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${s.web_password||""} onInput=${r("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}function Fn(){return d`
    <${k} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${we} target="gateway" label="Install and restart" />
    <//>`}var In=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],An={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Nn={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},Q=async(e,t)=>await T(e,t)!==void 0,Be=e=>e?new Date(e).toLocaleString():"\u2014";function Ge({label:e,accept:t,send:n,success:s,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async r=>{let l=r.target.files[0];if(r.target.value="",!l)return;let u=await l.text();await Q(()=>n(u),s)&&o&&o()}} hidden /></label>`}function Ot(){let{data:e,error:t,reload:n}=M(q.get,1e4);return e?d`
    <${Hn} d=${e} />
    <${Ln} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${Pn} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${Mn} reload=${n} />`}
    ${e.mode==="est"&&d`<${Dn} d=${e} reload=${n} />`}
    <${Un} d=${e} reload=${n} />
    <${qn} d=${e} reload=${n} />`:d`<${D} error=${t} />`}function Ke({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Be(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Be(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function Hn({d:e}){let t=e.certificate,[n,s]=t?An[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${k} title="Certificate" aside=${d`<span class=${"badge "+s}>${n}</span>`}>
      ${t?d`<${Ke} c=${t} />
            <p class="muted">Made: ${Nn[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Ln({d:e,reload:t}){let[n,s]=v(e.fqdn),[o,a]=v(e.mode),r=async()=>{let l={};if(n!==e.fqdn&&(l.fqdn=n.trim()),o!==e.mode&&(l.mode=o),Object.keys(l).length===0)return O("Nothing changed");await Q(()=>q.update(l),"Saved")&&t()};return d`
    <${k} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${l=>s(l.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${In.map(([l,u,c])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${l} checked=${o===l} onChange=${()=>a(l)} />
          <span><strong>${u}</strong><small class="muted">${c}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${$} kind="primary" onClick=${r}>Save<//></div>
    <//>`}function Pn({d:e,reload:t}){let[n,s]=v(e.validity_years);return d`
    <${k} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${a=>s(+a.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await Q(()=>q.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function Mn({reload:e}){return d`
    <${k} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${q.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Ge} label="Upload certificate" send=${q.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function Dn({d:e,reload:t}){let n=e.est,[s,o]=v(n.url),[a,r]=v(n.auto_renew),l=async()=>{await Q(()=>q.update({est_url:s.trim(),est_auto_renew:a}),"Saved")&&t()},u=async()=>{await Q(q.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${k} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${s} onInput=${c=>o(c.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a} onChange=${c=>r(c.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Be(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${Ke} c=${n.identity} />`}
      <div class="buttons">
        <${Ge} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${q.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${$} kind="danger" onClick=${async()=>await Q(q.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${l}>Save<//>
        <${$} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function Un({d:e,reload:t}){let n=e.trust_anchor;return d`
    <${k} title="Trust anchor (CA)">
      <p class="muted">The CA the EST server's certificate has to chain to. TLS to the EST server is always verified against it.</p>
      ${n?d`<${Ke} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${Ge} label=${n?"Replace":"Upload"} send=${q.setTrustAnchor} success="Trust anchor installed" after=${t} />
        ${n&&d`<${$} kind="danger" onClick=${async()=>confirm("Remove the trust anchor?")&&await Q(q.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function qn({d:e,reload:t}){let[n,s]=v(e.ntp_server),o=async()=>{await Q(()=>q.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${k} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates and EST need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} placeholder="automatic" onInput=${a=>s(a.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. In use: ${e.ntp_server_in_use}</p>
      <div class="buttons"><${$} onClick=${o}>Save<//></div>
    <//>`}var On={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function jt(){let{data:e,error:t,reload:n}=M(X.all,5e3);return e?d`
    <${Wt} slot="primary" b=${e.primary} reload=${n} />
    <${Wt} slot="secondary" b=${e.secondary} reload=${n} />
    <${Wn} on=${e.home_assistant} reload=${n} />`:d`<${D} error=${t} />`}function Wn({on:e,reload:t}){return d`
    <${k} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async s=>{let o=s.target.checked;await T(()=>X.updateAll({home_assistant:o}),o?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}function Wt({slot:e,b:t,reload:n}){let[s,o]=v({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[a,r]=v(null),l=s.uri.startsWith("mqtts://"),u=i=>_=>o({...s,[i]:_.target.type==="checkbox"?_.target.checked:_.target.value}),c=async()=>{let i={uri:s.uri,user:s.user,enabled:s.enabled,tls_insecure:s.tls_insecure};s.password&&(i.password=s.password),await T(()=>X.update(e,i),`${e} broker saved, reconnecting`)&&(o({...s,password:""}),setTimeout(n,2500))},p=async()=>{let i=await T(()=>X.certificate(e));i&&r(i)};return d`
    <${k}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${On[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${s.uri} onInput=${u("uri")} /><//>
        <${C} label="User"><input value=${s.user} onInput=${u("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${s.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${s.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${l&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${s.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await T(()=>X.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${$} kind="danger" onClick=${async()=>{await T(()=>X.forget(e),"Certificate forgotten"),r(null),n()}}>Forget<//>`}
          </div>
          ${a&&d`<p>${a.pinned?d`SHA-256 <code>${a.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}var jn=[{path:"/",title:"Devices",page:Ut},{path:"/devices/:device",title:"Device",page:Dt},{path:"/sensors",title:"Sensors",page:Lt},{path:"/mqtt",title:"MQTT",page:jt},{path:"/gateway",title:"Gateway",page:qt},{path:"/https",title:"HTTPS",page:Ot}],Vn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function Bn(){let e=At(),t=Nt(jn,e),n=t?t.route.page:null,s=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${Vn.map(([o,a])=>d`<${te} href=${o} class=${s(o)?"active":""}>${a}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${te} href="/">Devices<//></p>`}
    </main>
    <${Ft} />`}dt(d`<${Bn} />`,document.getElementById("app"));
