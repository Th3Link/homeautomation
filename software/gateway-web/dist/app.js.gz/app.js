var Pa=Object.create;var Bt=Object.defineProperty;var Ra=Object.getOwnPropertyDescriptor;var Ma=Object.getOwnPropertyNames;var Da=Object.getPrototypeOf,Ua=Object.prototype.hasOwnProperty;var Ba=(e,t,n)=>t in e?Bt(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var Ha=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Ka=(e,t,n,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Ma(t))!Ua.call(e,o)&&o!==n&&Bt(e,o,{get:()=>t[o],enumerable:!(i=Ra(t,o))||i.enumerable});return e};var qa=(e,t,n)=>(n=e!=null?Pa(Da(e)):{},Ka(t||!e||!e.__esModule?Bt(n,"default",{value:e,enumerable:!0}):n,e));var ue=(e,t,n)=>Ba(e,typeof t!="symbol"?t+"":t,n);var Ii=Ha(zt=>{var Ni;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof zt=="object"?e(zt):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(Ni={}):e(Ni={})})(function(e){e.version="1.2.2";function t(){for(var w=0,T=new Array(256),b=0;b!=256;++b)w=b,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,T[b]=w;return typeof Int32Array<"u"?new Int32Array(T):T}var n=t();function i(w){var T=0,b=0,P=0,k=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(P=0;P!=256;++P)k[P]=w[P];for(P=0;P!=256;++P)for(b=w[P],T=256+P;T<4096;T+=256)b=k[T]=b>>>8^w[b&255];var F=[];for(P=1;P!=16;++P)F[P-1]=typeof Int32Array<"u"?k.subarray(P*256,P*256+256):k.slice(P*256,P*256+256);return F}var o=i(n),a=o[0],s=o[1],r=o[2],l=o[3],u=o[4],c=o[5],p=o[6],f=o[7],h=o[8],m=o[9],y=o[10],$=o[11],g=o[12],v=o[13],B=o[14];function S(w,T){for(var b=T^-1,P=0,k=w.length;P<k;)b=b>>>8^n[(b^w.charCodeAt(P++))&255];return~b}function A(w,T){for(var b=T^-1,P=w.length-15,k=0;k<P;)b=B[w[k++]^b&255]^v[w[k++]^b>>8&255]^g[w[k++]^b>>16&255]^$[w[k++]^b>>>24]^y[w[k++]]^m[w[k++]]^h[w[k++]]^f[w[k++]]^p[w[k++]]^c[w[k++]]^u[w[k++]]^l[w[k++]]^r[w[k++]]^s[w[k++]]^a[w[k++]]^n[w[k++]];for(P+=15;k<P;)b=b>>>8^n[(b^w[k++])&255];return~b}function R(w,T){for(var b=T^-1,P=0,k=w.length,F=0,q=0;P<k;)F=w.charCodeAt(P++),F<128?b=b>>>8^n[(b^F)&255]:F<2048?(b=b>>>8^n[(b^(192|F>>6&31))&255],b=b>>>8^n[(b^(128|F&63))&255]):F>=55296&&F<57344?(F=(F&1023)+64,q=w.charCodeAt(P++)&1023,b=b>>>8^n[(b^(240|F>>8&7))&255],b=b>>>8^n[(b^(128|F>>2&63))&255],b=b>>>8^n[(b^(128|q>>6&15|(F&3)<<4))&255],b=b>>>8^n[(b^(128|q&63))&255]):(b=b>>>8^n[(b^(224|F>>12&15))&255],b=b>>>8^n[(b^(128|F>>6&63))&255],b=b>>>8^n[(b^(128|F&63))&255]);return~b}e.table=n,e.bstr=S,e.buf=A,e.str=R})});var pt,H,ri,Wa,Ee,ni,si,li,ci,qt,Ht,Kt,ja,Je={},ui=[],Ya=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,ft=Array.isArray;function _e(e,t){for(var n in t)e[n]=t[n];return e}function Wt(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function Ze(e,t,n){var i,o,a,s={};for(a in t)a=="key"?i=t[a]:a=="ref"?o=t[a]:s[a]=t[a];if(arguments.length>2&&(s.children=arguments.length>3?pt.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(a in e.defaultProps)s[a]===void 0&&(s[a]=e.defaultProps[a]);return ct(e,s,i,o,null)}function ct(e,t,n,i,o){var a={type:e,props:t,key:n,ref:i,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++ri,__i:-1,__u:0};return o==null&&H.vnode!=null&&H.vnode(a),a}function ht(e){return e.children}function ut(e,t){this.props=e,this.context=t}function Ie(e,t){if(t==null)return e.__?Ie(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?Ie(e):null}function di(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return di(e)}}function ii(e){(!e.__d&&(e.__d=!0)&&Ee.push(e)&&!dt.__r++||ni!=H.debounceRendering)&&((ni=H.debounceRendering)||si)(dt)}function dt(){for(var e,t,n,i,o,a,s,r=1;Ee.length;)Ee.length>r&&Ee.sort(li),e=Ee.shift(),r=Ee.length,e.__d&&(n=void 0,o=(i=(t=e).__v).__e,a=[],s=[],t.__P&&((n=_e({},i)).__v=i.__v+1,H.vnode&&H.vnode(n),jt(t.__P,n,i,t.__n,t.__P.namespaceURI,32&i.__u?[o]:null,a,o??Ie(i),!!(32&i.__u),s),n.__v=i.__v,n.__.__k[n.__i]=n,hi(a,n,s),n.__e!=o&&di(n)));dt.__r=0}function pi(e,t,n,i,o,a,s,r,l,u,c){var p,f,h,m,y,$,g=i&&i.__k||ui,v=t.length;for(l=Ga(n,t,g,l,v),p=0;p<v;p++)(h=n.__k[p])!=null&&(f=h.__i==-1?Je:g[h.__i]||Je,h.__i=p,$=jt(e,h,f,o,a,s,r,l,u,c),m=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&Yt(f.ref,null,h),c.push(h.ref,h.__c||m,h)),y==null&&m!=null&&(y=m),4&h.__u||f.__k===h.__k?l=fi(h,l,e):typeof h.type=="function"&&$!==void 0?l=$:m&&(l=m.nextSibling),h.__u&=-7);return n.__e=y,l}function Ga(e,t,n,i,o){var a,s,r,l,u,c=n.length,p=c,f=0;for(e.__k=new Array(o),a=0;a<o;a++)(s=t[a])!=null&&typeof s!="boolean"&&typeof s!="function"?(l=a+f,(s=e.__k[a]=typeof s=="string"||typeof s=="number"||typeof s=="bigint"||s.constructor==String?ct(null,s,null,null,null):ft(s)?ct(ht,{children:s},null,null,null):s.constructor==null&&s.__b>0?ct(s.type,s.props,s.key,s.ref?s.ref:null,s.__v):s).__=e,s.__b=e.__b+1,r=null,(u=s.__i=Va(s,n,l,p))!=-1&&(p--,(r=n[u])&&(r.__u|=2)),r==null||r.__v==null?(u==-1&&(o>c?f--:o<c&&f++),typeof s.type!="function"&&(s.__u|=4)):u!=l&&(u==l-1?f--:u==l+1?f++:(u>l?f--:f++,s.__u|=4))):e.__k[a]=null;if(p)for(a=0;a<c;a++)(r=n[a])!=null&&(2&r.__u)==0&&(r.__e==i&&(i=Ie(r)),gi(r,r));return i}function fi(e,t,n){var i,o;if(typeof e.type=="function"){for(i=e.__k,o=0;i&&o<i.length;o++)i[o]&&(i[o].__=e,t=fi(i[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=Ie(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function Va(e,t,n,i){var o,a,s=e.key,r=e.type,l=t[n];if(l===null&&e.key==null||l&&s==l.key&&r==l.type&&(2&l.__u)==0)return n;if(i>(l!=null&&(2&l.__u)==0?1:0))for(o=n-1,a=n+1;o>=0||a<t.length;){if(o>=0){if((l=t[o])&&(2&l.__u)==0&&s==l.key&&r==l.type)return o;o--}if(a<t.length){if((l=t[a])&&(2&l.__u)==0&&s==l.key&&r==l.type)return a;a++}}return-1}function oi(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Ya.test(t)?n:n+"px"}function lt(e,t,n,i,o){var a,s;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof i=="string"&&(e.style.cssText=i=""),i)for(t in i)n&&t in n||oi(e.style,t,"");if(n)for(t in n)i&&n[t]==i[t]||oi(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")a=t!=(t=t.replace(ci,"$1")),s=t.toLowerCase(),t=s in e||t=="onFocusOut"||t=="onFocusIn"?s.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+a]=n,n?i?n.u=i.u:(n.u=qt,e.addEventListener(t,a?Kt:Ht,a)):e.removeEventListener(t,a?Kt:Ht,a);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function ai(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=qt++;else if(t.t<n.u)return;return n(H.event?H.event(t):t)}}}function jt(e,t,n,i,o,a,s,r,l,u){var c,p,f,h,m,y,$,g,v,B,S,A,R,w,T,b,P,k=t.type;if(t.constructor!=null)return null;128&n.__u&&(l=!!(32&n.__u),a=[r=t.__e=n.__e]),(c=H.__b)&&c(t);e:if(typeof k=="function")try{if(g=t.props,v="prototype"in k&&k.prototype.render,B=(c=k.contextType)&&i[c.__c],S=c?B?B.props.value:c.__:i,n.__c?$=(p=t.__c=n.__c).__=p.__E:(v?t.__c=p=new k(g,S):(t.__c=p=new ut(g,S),p.constructor=k,p.render=za),B&&B.sub(p),p.props=g,p.state||(p.state={}),p.context=S,p.__n=i,f=p.__d=!0,p.__h=[],p._sb=[]),v&&p.__s==null&&(p.__s=p.state),v&&k.getDerivedStateFromProps!=null&&(p.__s==p.state&&(p.__s=_e({},p.__s)),_e(p.__s,k.getDerivedStateFromProps(g,p.__s))),h=p.props,m=p.state,p.__v=t,f)v&&k.getDerivedStateFromProps==null&&p.componentWillMount!=null&&p.componentWillMount(),v&&p.componentDidMount!=null&&p.__h.push(p.componentDidMount);else{if(v&&k.getDerivedStateFromProps==null&&g!==h&&p.componentWillReceiveProps!=null&&p.componentWillReceiveProps(g,S),!p.__e&&p.shouldComponentUpdate!=null&&p.shouldComponentUpdate(g,p.__s,S)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(p.props=g,p.state=p.__s,p.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(F){F&&(F.__=t)}),A=0;A<p._sb.length;A++)p.__h.push(p._sb[A]);p._sb=[],p.__h.length&&s.push(p);break e}p.componentWillUpdate!=null&&p.componentWillUpdate(g,p.__s,S),v&&p.componentDidUpdate!=null&&p.__h.push(function(){p.componentDidUpdate(h,m,y)})}if(p.context=S,p.props=g,p.__P=e,p.__e=!1,R=H.__r,w=0,v){for(p.state=p.__s,p.__d=!1,R&&R(t),c=p.render(p.props,p.state,p.context),T=0;T<p._sb.length;T++)p.__h.push(p._sb[T]);p._sb=[]}else do p.__d=!1,R&&R(t),c=p.render(p.props,p.state,p.context),p.state=p.__s;while(p.__d&&++w<25);p.state=p.__s,p.getChildContext!=null&&(i=_e(_e({},i),p.getChildContext())),v&&!f&&p.getSnapshotBeforeUpdate!=null&&(y=p.getSnapshotBeforeUpdate(h,m)),b=c,c!=null&&c.type===ht&&c.key==null&&(b=mi(c.props.children)),r=pi(e,ft(b)?b:[b],t,n,i,o,a,s,r,l,u),p.base=t.__e,t.__u&=-161,p.__h.length&&s.push(p),$&&(p.__E=p.__=null)}catch(F){if(t.__v=null,l||a!=null)if(F.then){for(t.__u|=l?160:128;r&&r.nodeType==8&&r.nextSibling;)r=r.nextSibling;a[a.indexOf(r)]=null,t.__e=r}else for(P=a.length;P--;)Wt(a[P]);else t.__e=n.__e,t.__k=n.__k;H.__e(F,t,n)}else a==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):r=t.__e=Qa(n.__e,t,n,i,o,a,s,l,u);return(c=H.diffed)&&c(t),128&t.__u?void 0:r}function hi(e,t,n){for(var i=0;i<n.length;i++)Yt(n[i],n[++i],n[++i]);H.__c&&H.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(a){a.call(o)})}catch(a){H.__e(a,o.__v)}})}function mi(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:ft(e)?e.map(mi):_e({},e)}function Qa(e,t,n,i,o,a,s,r,l){var u,c,p,f,h,m,y,$=n.props,g=t.props,v=t.type;if(v=="svg"?o="http://www.w3.org/2000/svg":v=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),a!=null){for(u=0;u<a.length;u++)if((h=a[u])&&"setAttribute"in h==!!v&&(v?h.localName==v:h.nodeType==3)){e=h,a[u]=null;break}}if(e==null){if(v==null)return document.createTextNode(g);e=document.createElementNS(o,v,g.is&&g),r&&(H.__m&&H.__m(t,a),r=!1),a=null}if(v==null)$===g||r&&e.data==g||(e.data=g);else{if(a=a&&pt.call(e.childNodes),$=n.props||Je,!r&&a!=null)for($={},u=0;u<e.attributes.length;u++)$[(h=e.attributes[u]).name]=h.value;for(u in $)if(h=$[u],u!="children"){if(u=="dangerouslySetInnerHTML")p=h;else if(!(u in g)){if(u=="value"&&"defaultValue"in g||u=="checked"&&"defaultChecked"in g)continue;lt(e,u,null,h,o)}}for(u in g)h=g[u],u=="children"?f=h:u=="dangerouslySetInnerHTML"?c=h:u=="value"?m=h:u=="checked"?y=h:r&&typeof h!="function"||$[u]===h||lt(e,u,h,$[u],o);if(c)r||p&&(c.__html==p.__html||c.__html==e.innerHTML)||(e.innerHTML=c.__html),t.__k=[];else if(p&&(e.innerHTML=""),pi(t.type=="template"?e.content:e,ft(f)?f:[f],t,n,i,v=="foreignObject"?"http://www.w3.org/1999/xhtml":o,a,s,a?a[0]:n.__k&&Ie(n,0),r,l),a!=null)for(u=a.length;u--;)Wt(a[u]);r||(u="value",v=="progress"&&m==null?e.removeAttribute("value"):m!=null&&(m!==e[u]||v=="progress"&&!m||v=="option"&&m!=$[u])&&lt(e,u,m,$[u],o),u="checked",y!=null&&y!=e[u]&&lt(e,u,y,$[u],o))}return e}function Yt(e,t,n){try{if(typeof e=="function"){var i=typeof e.__u=="function";i&&e.__u(),i&&t==null||(e.__u=e(t))}else e.current=t}catch(o){H.__e(o,n)}}function gi(e,t,n){var i,o;if(H.unmount&&H.unmount(e),(i=e.ref)&&(i.current&&i.current!=e.__e||Yt(i,null,t)),(i=e.__c)!=null){if(i.componentWillUnmount)try{i.componentWillUnmount()}catch(a){H.__e(a,t)}i.base=i.__P=null}if(i=e.__k)for(o=0;o<i.length;o++)i[o]&&gi(i[o],t,n||typeof e.type!="function");n||Wt(e.__e),e.__c=e.__=e.__e=void 0}function za(e,t,n){return this.constructor(e,n)}function $i(e,t,n){var i,o,a,s;t==document&&(t=document.documentElement),H.__&&H.__(e,t),o=(i=typeof n=="function")?null:n&&n.__k||t.__k,a=[],s=[],jt(t,e=(!i&&n||t).__k=Ze(ht,null,[e]),o||Je,Je,t.namespaceURI,!i&&n?[n]:o?null:t.firstChild?pt.call(t.childNodes):null,a,!i&&n?n:o?o.__e:t.firstChild,i,s),hi(a,e,s)}pt=ui.slice,H={__e:function(e,t,n,i){for(var o,a,s;t=t.__;)if((o=t.__c)&&!o.__)try{if((a=o.constructor)&&a.getDerivedStateFromError!=null&&(o.setState(a.getDerivedStateFromError(e)),s=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,i||{}),s=o.__d),s)return o.__E=o}catch(r){e=r}throw e}},ri=0,Wa=function(e){return e!=null&&e.constructor==null},ut.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=_e({},this.state),typeof e=="function"&&(e=e(_e({},n),this.props)),e&&_e(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),ii(this))},ut.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),ii(this))},ut.prototype.render=ht,Ee=[],si=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,li=function(e,t){return e.__v.__b-t.__v.__b},dt.__r=0,ci=/(PointerCapture)$|Capture$/i,qt=0,Ht=ai(!1),Kt=ai(!0),ja=0;var et,G,Gt,vi,tt=0,Ti=[],V=H,_i=V.__b,yi=V.__r,bi=V.diffed,wi=V.__c,ki=V.unmount,Si=V.__;function Qt(e,t){V.__h&&V.__h(G,e,tt||t),tt=0;var n=G.__H||(G.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function _(e){return tt=1,Xa(Li,e)}function Xa(e,t,n){var i=Qt(et++,2);if(i.t=e,!i.__c&&(i.__=[n?n(t):Li(void 0,t),function(r){var l=i.__N?i.__N[0]:i.__[0],u=i.t(l,r);l!==u&&(i.__N=[u,i.__[1]],i.__c.setState({}))}],i.__c=G,!G.__f)){var o=function(r,l,u){if(!i.__c.__H)return!0;var c=i.__c.__H.__.filter(function(f){return!!f.__c});if(c.every(function(f){return!f.__N}))return!a||a.call(this,r,l,u);var p=i.__c.props!==r;return c.forEach(function(f){if(f.__N){var h=f.__[0];f.__=f.__N,f.__N=void 0,h!==f.__[0]&&(p=!0)}}),a&&a.call(this,r,l,u)||p};G.__f=!0;var a=G.shouldComponentUpdate,s=G.componentWillUpdate;G.componentWillUpdate=function(r,l,u){if(this.__e){var c=a;a=void 0,o(r,l,u),a=c}s&&s.call(this,r,l,u)},G.shouldComponentUpdate=o}return i.__N||i.__}function Q(e,t){var n=Qt(et++,3);!V.__s&&xi(n.__H,t)&&(n.__=e,n.u=t,G.__H.__h.push(n))}function de(e){return tt=5,Ei(function(){return{current:e}},[])}function Ei(e,t){var n=Qt(et++,7);return xi(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function Ai(e,t){return tt=8,Ei(function(){return e},t)}function Ja(){for(var e;e=Ti.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(mt),e.__H.__h.forEach(Vt),e.__H.__h=[]}catch(t){e.__H.__h=[],V.__e(t,e.__v)}}V.__b=function(e){G=null,_i&&_i(e)},V.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Si&&Si(e,t)},V.__r=function(e){yi&&yi(e),et=0;var t=(G=e.__c).__H;t&&(Gt===G?(t.__h=[],G.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(mt),t.__h.forEach(Vt),t.__h=[],et=0)),Gt=G},V.diffed=function(e){bi&&bi(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(Ti.push(t)!==1&&vi===V.requestAnimationFrame||((vi=V.requestAnimationFrame)||Za)(Ja)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Gt=G=null},V.__c=function(e,t){t.some(function(n){try{n.__h.forEach(mt),n.__h=n.__h.filter(function(i){return!i.__||Vt(i)})}catch(i){t.some(function(o){o.__h&&(o.__h=[])}),t=[],V.__e(i,n.__v)}}),wi&&wi(e,t)},V.unmount=function(e){ki&&ki(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(i){try{mt(i)}catch(o){t=o}}),n.__H=void 0,t&&V.__e(t,n.__v))};var Ci=typeof requestAnimationFrame=="function";function Za(e){var t,n=function(){clearTimeout(i),Ci&&cancelAnimationFrame(t),setTimeout(e)},i=setTimeout(n,35);Ci&&(t=requestAnimationFrame(n))}function mt(e){var t=G,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),G=t}function Vt(e){var t=G;e.__c=e.__(),G=t}function xi(e,t){return!e||e.length!==t.length||t.some(function(n,i){return n!==e[i]})}function Li(e,t){return typeof t=="function"?t(e):t}var Pi=qa(Ii()),Zt="/api/v1",Oe=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error,this.field=n&&n.field}},er=e=>new Promise(t=>setTimeout(t,e));async function Fe(e,t,n,i=!1){for(let o=1;;o++){let a;try{a=await fetch(Zt+t,{method:e,headers:n===void 0?{}:{"Content-Type":i?"application/x-pem-file":"application/json"},body:n===void 0?void 0:i?n:JSON.stringify(n)})}catch{if(o>=4)throw new Oe(0,{message:"gateway unreachable"});await er(250*o);continue}let s=await a.text(),r=null;try{r=s?JSON.parse(s):null}catch{r={message:s}}if(!a.ok)throw new Oe(a.status,r);return r}}var z=e=>Fe("GET",e),$e=(e,t)=>Fe("POST",e,t),se=(e,t)=>Fe("PUT",e,t),Xt=(e,t)=>Fe("PUT",e,t,!0),ge=(e,t)=>Fe("PATCH",e,t),nt=e=>Fe("DELETE",e),W=encodeURIComponent,en={get:()=>z("/system"),restart:()=>$e("/system/restart")},tn={get:()=>z("/config"),update:e=>ge("/config",e)},nn={get:()=>z("/location"),update:e=>ge("/location",e)},on={get:()=>z("/network"),put:e=>se("/network",e)},Ae={all:()=>z("/mqtt"),updateAll:e=>ge("/mqtt",e),update:(e,t)=>ge(`/mqtt/${e}`,t),trust:e=>$e(`/mqtt/${e}/trust`),certificate:e=>z(`/mqtt/${e}/certificate`),forget:e=>nt(`/mqtt/${e}/certificate`)},ae={get:()=>z("/tls"),update:e=>ge("/tls",e),selfSigned:e=>$e("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Zt}/tls/csr`,installCertificate:e=>Xt("/tls/certificate",e),setTrustAnchor:e=>Xt("/tls/trust-anchor",e),removeTrustAnchor:()=>nt("/tls/trust-anchor"),setIdentity:e=>Xt("/tls/est/identity",e),removeIdentity:()=>nt("/tls/est/identity"),enroll:()=>$e("/tls/est/enroll")},j={async list(){let e=[];for(;;){let t=await z(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>z(`/devices/${W(e)}`),update:(e,t)=>ge(`/devices/${W(e)}`,t),action:(e,t)=>$e(`/devices/${W(e)}/${t}`),silence:(e,t)=>se(`/devices/${W(e)}/silence`,{on:t}),relay:(e,t,n,i)=>se(`/devices/${W(e)}/relays/${t}`,{state:n,duration_ms:i}),rollershutter:(e,t,n,i)=>se(`/devices/${W(e)}/rollershutters/${t}`,{state:n,duration_ms:i}),lamps:(e,t,n,i)=>se(`/devices/${W(e)}/lamps/${t}`,{value:n,bitmask:i}),heating:(e,t,n)=>se(`/devices/${W(e)}/heating/${t}`,n),heatingManualState:e=>z(`/devices/${W(e)}/heating/manual`),heatingManual:(e,t,n,i)=>se(`/devices/${W(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:i})},ye={update:(e,t,n)=>se(`/devices/${W(e)}/sensors/${t}`,n),refresh:e=>$e(`/devices/${W(e)}/sensors/refresh`),forget:e=>$e(`/devices/${W(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${W(e)}`:"",i=await z(`/sensors?offset=${t.length}${n}`);if(t.push(...i.sensors),i.sensors.length===0||t.length>=i.total)return t}}},Pe={action:e=>$e(`/bus/${e}`),silence:e=>se("/bus/silence",{on:e}),typeAction:(e,t)=>$e(`/device-types/${e}/${t}`)},an={job:()=>z("/firmware/job"),upload(e,t,n){let i=Pi.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((a,s)=>{let r=new XMLHttpRequest;r.open("PUT",`${Zt}${o}?crc32=${i}`),r.setRequestHeader("Content-Type","application/octet-stream"),r.upload.onprogress=l=>l.lengthComputable&&n&&n(l.loaded/l.total),r.onload=()=>{let l=null;try{l=JSON.parse(r.responseText)}catch{}r.status>=200&&r.status<300?a(l):s(new Oe(r.status,l))},r.onerror=()=>s(new Oe(0,{message:"upload failed"})),r.send(t)})}},rn={read:e=>z(`/logs?from=${e}`),setCanToMqtt:e=>ge("/logs",{can_to_mqtt:e})},Jt=e=>({list:()=>z(`/automation/${e}`).then(t=>t.items),get:t=>z(`/automation/${e}/${W(t)}`),put:(t,n)=>se(`/automation/${e}/${W(t)}`,n),remove:t=>nt(`/automation/${e}/${W(t)}`)});async function Oi(e){let t=[];for(;;){let n=await z(`${e}?offset=${t.length}`);if(t.push(...n.items),n.items.length===0||t.length>=n.total)return t}}var Fi=e=>"0x"+(268435456+(e.type<<16)+(e.id<<8)).toString(16),N={status:()=>z("/automation"),setEnabled:e=>ge("/automation",{enabled:e}),outputs:{...Jt("outputs"),command:(e,t)=>$e(`/automation/outputs/${W(e)}/command`,t)},switches:{list:()=>Oi("/automation/switches"),get:e=>z(`/automation/switches/${W(e)}`),put:(e,t)=>se(`/automation/switches/${W(e)}`,t),remove:e=>nt(`/automation/switches/${W(e)}`),button:(e,t)=>z(`/automation/switches/${W(e)}/${t}`),putButton:(e,t,n)=>se(`/automation/switches/${W(e)}/${t}`,n)},motion:{...Jt("motion"),setEnabled:(e,t)=>ge(`/automation/motion/${W(e)}`,{enabled:t})},schedules:{...Jt("schedules"),setEnabled:(e,t)=>ge(`/automation/schedules/${W(e)}`,{enabled:t})},devices:{list:()=>Oi("/automation/devices"),get:e=>z(`/automation/devices/${Fi(e)}`),put:(e,t)=>se(`/automation/devices/${Fi(e)}`,t)}};var gt=new Set;function tr(e){e!==location.pathname&&history.pushState(null,"",e),gt.forEach(t=>t())}addEventListener("popstate",()=>gt.forEach(e=>e()));function Ri(){let[e,t]=_(location.pathname);return Q(()=>{let n=()=>t(location.pathname);return gt.add(n),()=>gt.delete(n)},[]),e}function Mi(e,t){let n=t.split("/").filter(Boolean);for(let i of e){let o=i.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let a={};if(o.every((r,l)=>r.startsWith(":")?(a[r.slice(1)]=decodeURIComponent(n[l]),!0):r===n[l]))return{route:i,params:a}}return null}function J({href:e,children:t,...n}){return Ze("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),tr(e))},...n},t)}var Ui=function(e,t,n,i){var o;t[0]=0;for(var a=1;a<t.length;a++){var s=t[a++],r=t[a]?(t[0]|=s?1:2,n[t[a++]]):t[++a];s===3?i[0]=r:s===4?i[1]=Object.assign(i[1]||{},r):s===5?(i[1]=i[1]||{})[t[++a]]=r:s===6?i[1][t[++a]]+=r+"":s?(o=e.apply(r,Ui(e,r,n,["",null])),i.push(o),r[0]?t[0]|=2:(t[a-2]=0,t[a]=o)):i.push(r)}return i},Di=new Map;function Bi(e){var t=Di.get(this);return t||(t=new Map,Di.set(this,t)),(t=Ui(this,t.get(e)||(t.set(e,t=function(n){for(var i,o,a=1,s="",r="",l=[0],u=function(f){a===1&&(f||(s=s.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?l.push(0,f,s):a===3&&(f||s)?(l.push(3,f,s),a=2):a===2&&s==="..."&&f?l.push(4,f,0):a===2&&s&&!f?l.push(5,0,!0,s):a>=5&&((s||!f&&a===5)&&(l.push(a,0,s,o),a=6),f&&(l.push(a,f,0,o),a=6)),s=""},c=0;c<n.length;c++){c&&(a===1&&u(),u(c));for(var p=0;p<n[c].length;p++)i=n[c][p],a===1?i==="<"?(u(),l=[l],a=3):s+=i:a===4?s==="--"&&i===">"?(a=1,s=""):s=i+s[0]:r?i===r?r="":s+=i:i==='"'||i==="'"?r=i:i===">"?(u(),a=1):a&&(i==="="?(a=5,o=s,s=""):i==="/"&&(a<5||n[c][p+1]===">")?(u(),a===3&&(l=l[0]),a=l,(l=l[0]).push(2,0,a),a=0):i===" "||i==="	"||i===`
`||i==="\r"?(u(),a=2):s+=i),a===3&&s==="!--"&&(a=4,l=l[0])}return u(),l}(e)),t),arguments,[])).length>1?t:t[0]}var d=Bi.bind(Ze),sn=()=>{};function U(e,t="ok"){sn(e,t)}function Hi(){let[e,t]=_([]);return Q(()=>{let n=0;return sn=(i,o)=>{let a={id:++n,message:i,kind:o};t(s=>[...s,a]),setTimeout(()=>t(s=>s.filter(r=>r!==a)),o==="error"?8e3:3e3)},()=>sn=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function E(e,t){try{let n=await e();return t&&U(t),n}catch(n){U(n.message,"error");return}}function X(e,t){let[n,i]=_({data:void 0,error:void 0}),o=de(e);o.current=e;let a=Ai(async()=>{try{i({data:await o.current(),error:void 0})}catch(s){i(r=>({data:r.data,error:s}))}},[]);return Q(()=>{let s=!1,r,l=async()=>{await a(),t&&!s&&(r=setTimeout(l,t))};return l(),()=>{s=!0,clearTimeout(r)}},[t,a]),{...n,reload:a}}var x=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,K=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,O=({children:e,kind:t,onClick:n,disabled:i})=>{let[o,a]=_(!1);return d`<button class=${t||""} disabled=${i||o} onClick=${async r=>{a(!0);try{await n(r)}finally{a(!1)}}}>${e}</button>`},ln=e=>"0x"+e.toString(16).padStart(2,"0");function xe(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function Ki(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),i=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${i} min`:`${i} min`}var M=Symbol("NOT_RESOLVED");function ne(e,t){return{tagName:e,nodeKind:"scalar",implicit:t.implicit??!1,matchByTagPrefix:t.matchByTagPrefix??!1,implicitFirstChars:t.implicitFirstChars??null,resolve:t.resolve,identify:t.identify,represent:t.represent??(n=>String(n)),representTagName:t.representTagName??(()=>e)}}function Tn(e,t){let n=t.finalize===void 0;return{tagName:e,nodeKind:"sequence",implicit:!1,matchByTagPrefix:t.matchByTagPrefix??!1,create:t.create,addItem:t.addItem,finalize:t.finalize??(i=>i),carrierIsResult:n,identify:t.identify,represent:t.represent??(i=>i),representTagName:t.representTagName??(()=>e)}}function wt(e,t){let n=t.finalize===void 0;return{tagName:e,nodeKind:"mapping",implicit:!1,matchByTagPrefix:t.matchByTagPrefix??!1,create:t.create,addPair:t.addPair,has:t.has,keys:t.keys,get:t.get,finalize:t.finalize??(i=>i),carrierIsResult:n,identify:t.identify,represent:t.represent??(i=>i),representTagName:t.representTagName??(()=>e)}}var nr=ne("tag:yaml.org,2002:str",{resolve:e=>e,identify:e=>typeof e=="string"}),ir=["","~","null","Null","NULL"],or=ne("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["","~","n","N"],resolve:e=>ir.indexOf(e)!==-1?null:M,identify:e=>e===null,represent:()=>"null"}),ar=ne("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["n"],resolve:(e,t)=>e==="null"||t&&e===""?null:M,identify:e=>e===null,represent:()=>"null"}),rr=["","~","null","Null","NULL"],sr=ne("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["","~","n","N"],resolve:e=>rr.indexOf(e)!==-1?null:M,identify:e=>e===null,represent:()=>"null"}),lr=["true","True","TRUE"],cr=["false","False","FALSE"],ur=ne("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["t","T","f","F"],resolve:e=>lr.indexOf(e)!==-1?!0:cr.indexOf(e)!==-1?!1:M,identify:e=>Object.prototype.toString.call(e)==="[object Boolean]",represent:e=>e?"true":"false"}),dr=["true"],pr=["false"],fr=ne("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["t","f"],resolve:e=>dr.indexOf(e)!==-1?!0:pr.indexOf(e)!==-1?!1:M,identify:e=>Object.prototype.toString.call(e)==="[object Boolean]",represent:e=>e?"true":"false"}),hr=["true","True","TRUE","y","Y","yes","Yes","YES","on","On","ON"],mr=["false","False","FALSE","n","N","no","No","NO","off","Off","OFF"],gr=ne("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["y","Y","n","N","t","T","f","F","o","O"],resolve:e=>hr.indexOf(e)!==-1?!0:mr.indexOf(e)!==-1?!1:M,identify:e=>Object.prototype.toString.call(e)==="[object Boolean]",represent:e=>e?"true":"false"}),$r=new RegExp("^(?:0o[0-7]+|0x[0-9a-fA-F]+|[-+]?[0-9]+)$"),vr=new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$");function _r(e){let t=e,n=1;return(t[0]==="-"||t[0]==="+")&&(t[0]==="-"&&(n=-1),t=t.slice(1)),t.startsWith("0b")?n*parseInt(t.slice(2),2):t.startsWith("0o")?n*parseInt(t.slice(2),8):t.startsWith("0x")?n*parseInt(t.slice(2),16):n*parseInt(t,10)}function yr(e,t){if(t){if(!vr.test(e))return M}else if(!$r.test(e))return M;let n=_r(e);return Number.isFinite(n)?n:M}var ro=ne("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-","+",..."0123456789"],resolve:yr,identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),br=new RegExp("^-?(?:0|[1-9][0-9]*)$"),wr=new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$");function kr(e){let t=e,n=1;return(t[0]==="-"||t[0]==="+")&&(t[0]==="-"&&(n=-1),t=t.slice(1)),t.startsWith("0b")?n*parseInt(t.slice(2),2):t.startsWith("0o")?n*parseInt(t.slice(2),8):t.startsWith("0x")?n*parseInt(t.slice(2),16):n*parseInt(t,10)}function Sr(e,t){if(t){if(!wr.test(e))return M}else if(!br.test(e))return M;let n=kr(e);return Number.isFinite(n)?n:M}var Cr=ne("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-",..."0123456789"],resolve:Sr,identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),Tr=new RegExp("^(?:[-+]?0b[0-1_]+|[-+]?0[0-7_]+|[-+]?0x[0-9a-fA-F_]+|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+|[-+]?(?:0|[1-9][0-9_]*))$");function Er(e){let t=e.replace(/_/g,""),n=1;if((t[0]==="-"||t[0]==="+")&&(t[0]==="-"&&(n=-1),t=t.slice(1)),t.startsWith("0b"))return n*parseInt(t.slice(2),2);if(t.startsWith("0x"))return n*parseInt(t.slice(2),16);if(t.includes(":")){let i=0;for(let o of t.split(":"))i=i*60+Number(o);return n*i}return t!=="0"&&t[0]==="0"?n*parseInt(t,8):n*parseInt(t,10)}function Ar(e){if(!Tr.test(e))return M;let t=Er(e);return Number.isFinite(t)?t:M}var gn=ne("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-","+",..."0123456789"],resolve:Ar,identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),xr=new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),Lr=new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");function Nr(e){if(!xr.test(e))return M;let t=e.toLowerCase(),n=t[0]==="-"?-1:1;if("+-".includes(t[0])&&(t=t.slice(1)),t===".inf")return n===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(t===".nan")return NaN;let i=n*parseFloat(t);return Number.isFinite(i)||Lr.test(e)?i:M}function Ir(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";let t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}var so=ne("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-","+",".",..."0123456789"],resolve:Nr,identify:e=>typeof e=="number"&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:Ir}),Or=new RegExp("^-?(?:0|[1-9][0-9]*)(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$"),Fr=new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");function Pr(e,t){if(t){if(!Fr.test(e))return M;let i=e.toLowerCase(),o=i[0]==="-"?-1:1;if("+-".includes(i[0])&&(i=i.slice(1)),i===".inf")return o===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(i===".nan")return NaN;let a=o*parseFloat(i);return Number.isFinite(a)?a:M}if(!Or.test(e))return M;let n=Number(e);return Number.isFinite(n)?n:M}function Rr(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";let t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}var Mr=ne("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-",..."0123456789"],resolve:Pr,identify:e=>typeof e=="number"&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:Rr}),Dr=new RegExp("^(?:[-+]?(?:(?:[0-9][0-9_]*)?\\.[0-9_]*)(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),Ur=new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");function Br(e){if(!Dr.test(e))return M;let t=e.toLowerCase().replace(/_/g,""),n=t[0]==="-"?-1:1;if("+-".includes(t[0])&&(t=t.slice(1)),t===".inf")return n===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(t===".nan")return NaN;let i=0;if(t.includes(":")){for(let o of t.split(":"))i=i*60+Number(o);i*=n}else i=n*parseFloat(t);return Number.isFinite(i)||Ur.test(e)?i:M}function Hr(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";let t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}var $n=ne("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-","+",".",..."0123456789"],resolve:Br,identify:e=>typeof e=="number"&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:Hr}),Kr=ne("tag:yaml.org,2002:merge",{implicit:!0,implicitFirstChars:["<"],resolve:(e,t)=>e==="<<"||t&&e===""?"<<":M,identify:()=>!1}),qr=/^[A-Za-z0-9+/]*={0,2}$/;function Wr(e){let t=e.replace(/\s/g,"");if(t.length%4!==0||!qr.test(t))return M;let n=atob(t),i=new Uint8Array(n.length);for(let o=0;o<n.length;o++)i[o]=n.charCodeAt(o);return i}function jr(e){let t="";for(let n=0;n<e.length;n++)t+=String.fromCharCode(e[n]);return btoa(t)}var Yr=ne("tag:yaml.org,2002:binary",{resolve:Wr,identify:e=>Object.prototype.toString.call(e)==="[object Uint8Array]",represent:jr}),Gr=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"),Vr=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");function qi(e,t,n,i=0,o=0,a=0,s=0){let r=new Date(Date.UTC(e,t,n,i,o,a,s));return r.setUTCFullYear(e,t,n),r}function Qr(e){let t=Gr.exec(e);if(t===null&&(t=Vr.exec(e)),t===null)return M;let n=+t[1],i=+t[2]-1,o=+t[3];if(!t[4]){let c=qi(n,i,o);return c.getUTCFullYear()!==n||c.getUTCMonth()!==i||c.getUTCDate()!==o?M:c}let a=+t[4],s=+t[5],r=+t[6],l=0;if(a>23||s>59||r>59)return M;if(t[7]){let c=t[7].slice(0,3);for(;c.length<3;)c+="0";l=+c}let u=qi(n,i,o,a,s,r,l);if(u.getUTCFullYear()!==n||u.getUTCMonth()!==i||u.getUTCDate()!==o)return M;if(t[9]){let c=+t[10],p=+(t[11]||0);if(c>23||p>59)return M;let f=(c*60+p)*6e4;u.setTime(u.getTime()-(t[9]==="-"?-f:f))}return u}var zr=ne("tag:yaml.org,2002:timestamp",{implicit:!0,implicitFirstChars:[..."0123456789"],resolve:Qr,identify:e=>e instanceof Date,represent:e=>e.toISOString()}),Xr=Tn("tag:yaml.org,2002:seq",{create:()=>[],addItem:(e,t)=>{e.push(t)},identify:Array.isArray});function kt(e){if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=Object.getPrototypeOf(e);return t===null||t===Object.prototype}function vn(e,t){let n={};for(let i of t)e[i]!==void 0&&(n[i]=e[i]);return n}var Jr=Tn("tag:yaml.org,2002:omap",{create:()=>({list:[],seen:new Set}),addItem:(e,t)=>{let n;if(t instanceof Map){if(t.size!==1)return"cannot resolve an ordered map item";n=t.keys().next().value}else if(kt(t)){let i=Object.keys(t);if(i.length!==1)return"cannot resolve an ordered map item";n=i[0]}else return"cannot resolve an ordered map item";return e.seen.has(n)?"duplicate key in ordered map":(e.seen.add(n),e.list.push(t),"")},finalize:e=>e.list,identify:()=>!1}),Zr=Tn("tag:yaml.org,2002:pairs",{create:()=>[],addItem:(e,t)=>{if(t instanceof Map)return t.size!==1?"cannot resolve a pairs item":(e.push(t.entries().next().value),"");if(Object.prototype.toString.call(t)!=="[object Object]")return"cannot resolve a pairs item";let n=t,i=Object.keys(n);return i.length!==1?"cannot resolve a pairs item":(e.push([i[0],n[i[0]]]),"")},identify:()=>!1}),es=wt("tag:yaml.org,2002:map",{create:()=>({}),identify:kt,represent:e=>{let t=new Map;for(let n of Object.keys(e))t.set(n,e[n]);return t},addPair:(e,t,n)=>{if(t!==null&&typeof t=="object")return"object-based map does not support complex keys";let i=String(t);return i==="__proto__"?Object.defineProperty(e,i,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[i]=n,""},has:(e,t)=>t!==null&&typeof t=="object"?!1:Object.prototype.hasOwnProperty.call(e,String(t)),keys:e=>Object.keys(e),get:(e,t)=>{let n=String(t);return Object.prototype.hasOwnProperty.call(e,n)?e[n]:null}}),ts=wt("tag:yaml.org,2002:set",{create:()=>new Set,identify:e=>e instanceof Set,represent:e=>{let t=new Map;for(let n of e)t.set(n,null);return t},addPair:(e,t,n)=>n!==null?"cannot resolve a set item":(e.add(t),""),has:(e,t)=>e.has(t),keys:e=>e.keys(),get:()=>null});function ns(){return{scalar:Object.create(null),sequence:Object.create(null),mapping:Object.create(null)}}function is(){return{scalar:[],sequence:[],mapping:[]}}function os(e){let t=[];for(let n of e){let i=t.length;for(let o=0;o<t.length;o++){let a=t[o];if(a.nodeKind===n.nodeKind&&a.tagName===n.tagName&&a.matchByTagPrefix===n.matchByTagPrefix){i=o;break}}t[i]=n}return t}var St=class lo{constructor(t){ue(this,"tags");ue(this,"implicitScalarTags");ue(this,"implicitScalarByFirstChar");ue(this,"implicitScalarAnyFirstChar");ue(this,"defaultScalarTag");ue(this,"defaultSequenceTag");ue(this,"defaultMappingTag");ue(this,"exact");ue(this,"prefix");let n=os(t),i=[],o=ns(),a=is();for(let c of n){if(c.nodeKind==="scalar"&&c.implicit){if(c.matchByTagPrefix)throw new Error("Implicit scalar tags cannot match by tag prefix");i.push(c)}switch(c.nodeKind){case"scalar":c.matchByTagPrefix?a.scalar.push(c):o.scalar[c.tagName]=c;break;case"sequence":c.matchByTagPrefix?a.sequence.push(c):o.sequence[c.tagName]=c;break;case"mapping":c.matchByTagPrefix?a.mapping.push(c):o.mapping[c.tagName]=c}}let s=i.filter(c=>c.implicitFirstChars===null),r=new Set;for(let c of i)if(c.implicitFirstChars!==null)for(let p of c.implicitFirstChars)r.add(p);let l=new Map;for(let c of r)l.set(c,i.filter(p=>p.implicitFirstChars===null||p.implicitFirstChars.indexOf(c)!==-1));let u=o.scalar["tag:yaml.org,2002:str"];if(!u)throw new Error("schema does not define the default scalar tag (tag:yaml.org,2002:str)");this.tags=n,this.implicitScalarTags=i,this.implicitScalarByFirstChar=l,this.implicitScalarAnyFirstChar=s,this.defaultScalarTag=u,this.defaultSequenceTag=o.sequence["tag:yaml.org,2002:seq"],this.defaultMappingTag=o.mapping["tag:yaml.org,2002:map"],this.exact=o,this.prefix=a}lookupScalarTag(t){let n=this.exact.scalar[t];if(n)return n;for(let i of this.prefix.scalar)if(t.startsWith(i.tagName))return i}lookupSequenceTag(t){let n=this.exact.sequence[t];if(n)return n;for(let i of this.prefix.sequence)if(t.startsWith(i.tagName))return i}lookupMappingTag(t){let n=this.exact.mapping[t];if(n)return n;for(let i of this.prefix.mapping)if(t.startsWith(i.tagName))return i}resolveImplicitScalarTag(t){let n=this.implicitScalarByFirstChar.get(t.charAt(0))??this.implicitScalarAnyFirstChar;for(let o of n){let a=o.resolve(t,!1,o.tagName);if(a!==M)return{value:a,tag:o}}let i=this.defaultScalarTag;return{value:i.resolve(t,!1,i.tagName),tag:i}}withTags(...t){let n=[];for(let i of t)n=n.concat(i);return new lo([...this.tags,...n])}},En=new St([nr,Xr,es]),Yu=new St([...En.tags,ar,fr,Cr,Mr]),as=new St([...En.tags,or,ur,ro,so]),rs=new St([...En.tags,sr,gr,gn,$n,zr,Kr,Yr,Jr,Zr,ts]),ss=rs.withTags({...gn,resolve:(e,t,n)=>{let i=gn.resolve(e,t,n);return i===M?ro.resolve(e,t,n):i}},{...$n,resolve:(e,t,n)=>{let i=$n.resolve(e,t,n);return i===M?so.resolve(e,t,n):i}}),Gu=wt("tag:yaml.org,2002:map",{create:()=>new Map,addPair:(e,t,n)=>(e.set(t,n),""),has:(e,t)=>e.has(t),keys:e=>e.keys(),get:(e,t)=>e.get(t),identify:e=>e instanceof Map||kt(e),represent:e=>{if(e instanceof Map)return e;let t=new Map,n=e;for(let i of Object.keys(n))t.set(i,n[i]);return t}});function Wi(e){if(Array.isArray(e)){let t=Array.prototype.slice.call(e);for(let n=0;n<t.length;n++){if(Array.isArray(t[n]))return null;typeof t[n]=="object"&&Object.prototype.toString.call(t[n])==="[object Object]"&&(t[n]="[object Object]")}return String(t)}return typeof e=="object"&&Object.prototype.toString.call(e)==="[object Object]"?"[object Object]":String(e)}var Vu=wt("tag:yaml.org,2002:map",{create:()=>({}),identify:kt,represent:e=>{let t=new Map;for(let n of Object.keys(e))t.set(n,e[n]);return t},addPair:(e,t,n)=>{let i=Wi(t);return i===null?"nested arrays are not supported inside keys":(i==="__proto__"?Object.defineProperty(e,i,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[i]=n,"")},has:(e,t)=>{let n=Wi(t);return n!==null&&Object.prototype.hasOwnProperty.call(e,n)},keys:e=>Object.keys(e),get:(e,t)=>{let n=String(t);return Object.prototype.hasOwnProperty.call(e,n)?e[n]:null}}),ls={maxLength:79,indent:1,linesBefore:3,linesAfter:2};function cn(e,t,n,i,o){let a="",s="",r=Math.floor(o/2)-1;return i-t>r&&(a=" ... ",t=i-r+a.length),n-i>r&&(s=" ...",n=i+r-s.length),{str:a+e.slice(t,n).replace(/\t/g,"\u2192")+s,pos:i-t+a.length}}function un(e,t){return" ".repeat(Math.max(t-e.length,0))+e}function cs(e,t){if(!e.buffer)return null;let n={...ls,...t},i=/\r?\n|\r|\0/g,o=[0],a=[],s,r=-1;for(;s=i.exec(e.buffer);)a.push(s.index),o.push(s.index+s[0].length),e.position<=s.index&&r<0&&(r=o.length-2);r<0&&(r=o.length-1);let l="",u=Math.min(e.line+n.linesAfter,a.length).toString().length,c=n.maxLength-(n.indent+u+3);for(let f=1;f<=n.linesBefore&&!(r-f<0);f++){let h=cn(e.buffer,o[r-f],a[r-f],e.position-(o[r]-o[r-f]),c);l=`${" ".repeat(n.indent)}${un((e.line-f+1).toString(),u)} | ${h.str}
${l}`}let p=cn(e.buffer,o[r],a[r],e.position,c);l+=`${" ".repeat(n.indent)}${un((e.line+1).toString(),u)} | ${p.str}
`,l+=`${"-".repeat(n.indent+u+3+p.pos)}^
`;for(let f=1;f<=n.linesAfter&&!(r+f>=a.length);f++){let h=cn(e.buffer,o[r+f],a[r+f],e.position-(o[r]-o[r+f]),c);l+=`${" ".repeat(n.indent)}${un((e.line+f+1).toString(),u)} | ${h.str}
`}return l.replace(/\n$/,"")}function ji(e,t){let n="";return e.mark?(e.mark.name&&(n+=`in "${e.mark.name}" `),n+=`(${e.mark.line+1}:${e.mark.column+1})`,!t&&e.mark.snippet&&(n+=`

${e.mark.snippet}`),`${e.reason} ${n}`):e.reason}var Se=class co extends Error{constructor(n,i){super();ue(this,"reason");ue(this,"mark");this.name="YAMLException",this.reason=n,this.mark=i,this.message=ji(this,!1),Error.captureStackTrace&&Error.captureStackTrace(this,this.constructor)}toString(n){return`${this.name}: ${ji(this,n)}`}static throwAt(n,i,o,a=""){let s=0,r=0;for(let u=0;u<i;u++){let c=n.charCodeAt(u);c===10?(s++,r=u+1):c===13&&(s++,n.charCodeAt(u+1)===10&&u++,r=u+1)}let l={name:a,buffer:n,position:i,line:s,column:i-r};throw l.snippet=cs(l),new co(o,l)}},Y={DOCUMENT:1,SEQUENCE:2,MAPPING:3,SCALAR:4,ALIAS:5,POP:6},I={PLAIN:1,SINGLE_QUOTED:2,DOUBLE_QUOTED:3,LITERAL_BLOCK:4,FOLDED_BLOCK:5},re={BLOCK:1,FLOW:2},ce={CLIP:1,STRIP:2,KEEP:3},us=-1;function Yi(e){switch(e){case 48:return"\0";case 97:return"\x07";case 98:return"\b";case 116:return"	";case 9:return"	";case 110:return`
`;case 118:return"\v";case 102:return"\f";case 114:return"\r";case 101:return"\x1B";case 32:return" ";case 34:return'"';case 47:return"/";case 92:return"\\";case 78:return"\x85";case 95:return"\xA0";case 76:return"\u2028";case 80:return"\u2029";default:return""}}var uo=new Array(256),po=new Array(256);for(let e=0;e<256;e++)uo[e]=Yi(e)?1:0,po[e]=Yi(e);function ds(e){return e<=65535?String.fromCharCode(e):String.fromCharCode((e-65536>>10)+55296,(e-65536&1023)+56320)}function ps(e){return e>=48&&e<=57?e-48:(e|32)-97+10}function fs(e){return e===120?2:e===117?4:8}function vt(e,t,n){let i=0;for(;t<n;){let o=e.charCodeAt(t);if(o===10)i++,t++;else if(o===13)i++,t++,e.charCodeAt(t)===10&&t++;else if(o===32||o===9)t++;else break}return{position:t,breaks:i}}function An(e){return e===1?" ":`
`.repeat(e-1)}function hs(e,t,n){let i="",o=t,a=t,s=t;for(;o<n;){let r=e.charCodeAt(o);if(r===10||r===13){i+=e.slice(a,s);let l=vt(e,o,n);i+=An(l.breaks),o=a=s=l.position}else o++,r!==32&&r!==9&&(s=o)}return i+e.slice(a,s)}function ms(e,t,n){let i="",o=t,a=t,s=t;for(;o<n;){let r=e.charCodeAt(o);if(r===39)i+=e.slice(a,o)+"'",o+=2,a=s=o;else if(r===10||r===13){i+=e.slice(a,s);let l=vt(e,o,n);i+=An(l.breaks),o=a=s=l.position}else o++,r!==32&&r!==9&&(s=o)}return i+e.slice(a,n)}function gs(e,t,n){let i="",o=t,a=t,s=t;for(;o<n;){let r=e.charCodeAt(o);if(r===92){i+=e.slice(a,o),o++;let l=e.charCodeAt(o);if(l===10||l===13)o=vt(e,o,n).position;else if(l<256&&uo[l])i+=po[l],o++;else{let u=fs(l),c=0;for(;u>0;u--){o++;let p=ps(e.charCodeAt(o));c=(c<<4)+p}i+=ds(c),o++}a=s=o}else if(r===10||r===13){i+=e.slice(a,s);let l=vt(e,o,n);i+=An(l.breaks),o=a=s=l.position}else o++,r!==32&&r!==9&&(s=o)}return i+e.slice(a,n)}function Gi(e,t,n,i,o,a){let s=i<0?0:i,r=e.slice(t,n).replace(/\r\n?/g,`
`),l=r===""?[]:(r.endsWith(`
`)?r.slice(0,-1):r).split(`
`),u="",c=!1,p=0,f=!1;for(let h of l){let m=0;for(;m<s&&h.charCodeAt(m)===32;)m++;if(i<0||m>=h.length){p++;continue}let y=h.slice(s),$=y.charCodeAt(0);a?$===32||$===9?(f=!0,u+=`
`.repeat(c?1+p:p)):f?(f=!1,u+=`
`.repeat(p+1)):p===0?c&&(u+=" "):u+=`
`.repeat(p):u+=`
`.repeat(c?1+p:p),u+=y,c=!0,p=0}return o===ce.KEEP?u+=`
`.repeat(c?1+p:p):o!==ce.STRIP&&c&&(u+=`
`),u}function $s(e,t){if(t.valueStart===us)return"";let{valueStart:n,valueEnd:i}=t;if(t.fast)return e.slice(n,i);switch(t.style){case I.SINGLE_QUOTED:return ms(e,n,i);case I.DOUBLE_QUOTED:return gs(e,n,i);case I.LITERAL_BLOCK:return Gi(e,n,i,t.indent,t.chomping,!1);case I.FOLDED_BLOCK:return Gi(e,n,i,t.indent,t.chomping,!0);default:return hs(e,n,i)}}var vs=Object.assign(Object.create(null),{"!":"!","!!":"tag:yaml.org,2002:"}),fo="-#;/?:@&=+$_.~*'()",_s=fo+"!,[]",Vi="0123456789ABCDEF";function ve(e){return"%"+Vi[e>>4]+Vi[e&15]}function dn(e,t){let n=t?fo:_s,i="";for(let o=0;o<e.length;o++){let a=e.charCodeAt(o);if(a>=48&&a<=57||a>=65&&a<=90||a>=97&&a<=122||n.includes(e[o])){i+=e[o];continue}a>=55296&&a<=56319&&(a=65536+((a&1023)<<10)+(e.charCodeAt(++o)&1023)),a<128?i+=ve(a):a<2048?i+=ve(192|a>>6)+ve(128|a&63):a<65536?i+=ve(224|a>>12)+ve(128|a>>6&63)+ve(128|a&63):i+=ve(240|a>>18)+ve(128|a>>12&63)+ve(128|a>>6&63)+ve(128|a&63)}return i}function pn(e){let t="",n=0;for(;n<e.length;){if(e.charCodeAt(n)!==37){t+=e[n++];continue}let i=parseInt(e.slice(n+1,n+3),16);if(n+=3,i>=192){let o=i<224?1:i<240?2:3;for(i&=(1<<6-o)-1;o-- >0;)i=i<<6|parseInt(e.slice(n+1,n+3),16)&63,n+=3}i<65536?t+=String.fromCharCode(i):(i-=65536,t+=String.fromCharCode(55296|i>>10,56320|i&1023))}return t}function ho(e,t){if(e.startsWith("!<")&&e.endsWith(">"))return pn(e.slice(2,-1));let n=e.indexOf("!",1),i=n===-1?"!":e.slice(0,n+1);return pn(t?.[i]??vs[i]??i)+pn(e.slice(i.length))}function mo(e){let t=e;return t.charCodeAt(0)===33?(t=t.slice(1),`!${dn(t,!0)}`):t.slice(0,18)==="tag:yaml.org,2002:"?`!!${dn(t.slice(18),!0)}`:`!<${dn(t,!1)}>`}var Re=-1,ys="tag:yaml.org,2002:merge",xn={filename:"",schema:as,json:!1,maxTotalMergeKeys:1e4,maxAliases:-1};function bs(e){return"tagStart"in e&&e.tagStart!==Re?e.tagStart:"anchorStart"in e&&e.anchorStart!==Re?e.anchorStart:"valueStart"in e&&e.valueStart!==Re?e.valueStart:"start"in e?e.start:0}function ee(e,t){Se.throwAt(e.source,e.position,t,e.filename)}function go(e,t,n,i){try{return n.finalize(i)}catch(o){if(o instanceof Se)throw o;Se.throwAt(e.source,t,o instanceof Error?o.message:String(o),e.filename)}}function ws(e,t){let n=$s(e.source,t),i=t.tagStart===Re?"":e.source.slice(t.tagStart,t.tagEnd),o=e.schema.defaultScalarTag;if(i!==""){if(i==="!")return{value:n,tag:o};let a=ho(i,e.tagHandlers),s=e.schema.lookupScalarTag(a);if(s){let l=s.resolve(n,!0,a);return l===M&&ee(e,`cannot resolve a node with !<${a}> explicit tag`),{value:l,tag:s}}let r=e.schema.lookupMappingTag(a)??e.schema.lookupSequenceTag(a);if(r){n!==""&&ee(e,`cannot resolve a node with !<${a}> explicit tag`);let l=r.create(a);return{value:r.carrierIsResult?l:go(e,e.position,r,l),tag:r}}ee(e,`unknown scalar tag !<${a}>`)}return t.style===I.PLAIN?e.schema.resolveImplicitScalarTag(n):{value:o.resolve(n,!1,o.tagName),tag:o}}function Qi(e,t,n){let i=t.tagStart===Re?"":e.source.slice(t.tagStart,t.tagEnd);return i===""||i==="!"?n:ho(i,e.tagHandlers)}function $o(e){return e.nodeKind==="mapping"}function zi(e){e.totalMergeKeys++,e.maxTotalMergeKeys!==-1&&e.totalMergeKeys>e.maxTotalMergeKeys&&ee(e,`merge keys exceeded maxTotalMergeKeys (${e.maxTotalMergeKeys})`)}function Xi(e,t,n,i){zi(e);for(let o of i.keys(n)){if(zi(e),t.tag.has(t.value,o))continue;let a=t.tag.addPair(t.value,o,i.get(n,o));a&&ee(e,a),t.overridable??(t.overridable=new Set),t.overridable.add(o)}}function ks(e,t,n,i){if(e.position=t.keyPosition,$o(i))Xi(e,t,n,i);else if(i.nodeKind==="sequence"&&Array.isArray(n)){n.length>100&&ee(e,"abnormal merge sequence size");for(let o of n){let a=e.nodeTags.get(o);a||ee(e,"cannot merge mappings; the provided source object is unacceptable"),Xi(e,t,o,a)}}else ee(e,"cannot merge mappings; the provided source object is unacceptable")}function Ss(e,t,n,i,o){if(e.position=t.keyPosition,t.keyIsMerge){ks(e,t,i,o);return}!e.json&&t.tag.has(t.value,n)&&!t.overridable?.has(n)&&ee(e,"duplicated mapping key");let a=t.tag.addPair(t.value,n,i);a&&ee(e,a),t.overridable?.delete(n)}function fn(e,t,n){let i=e.frames[e.frames.length-1];if(i.kind==="document")i.value=t,i.hasValue=!0;else if(i.kind==="sequence"){$o(n)&&e.nodeTags.set(t,n);let o=i.tag.addItem(i.value,t,i.index++);o&&ee(e,o)}else if(i.hasKey){let o=i.key;i.key=void 0,i.hasKey=!1,Ss(e,i,o,t,n)}else i.key=t,i.keyPosition=e.position,i.hasKey=!0,i.keyIsMerge=n.tagName===ys}function hn(e,t,n,i,o){if(t.anchorStart!==Re){let a={value:n,tag:i,isValueFinal:o};return e.anchors.set(e.source.slice(t.anchorStart,t.anchorEnd),a),a}return null}function Cs(e,t){let n={...xn,...t,events:e,documents:[],eventIndex:0,position:0,frames:[],anchors:new Map,nodeTags:new Map,tagHandlers:Object.create(null),totalMergeKeys:0,aliasCount:0};for(;n.eventIndex<n.events.length;){let i=n.events[n.eventIndex++];switch(n.position=bs(i),i.type){case Y.DOCUMENT:n.anchors=new Map,n.nodeTags=new Map,n.aliasCount=0,n.tagHandlers=Object.create(null);for(let o of i.directives)o.kind==="tag"&&(n.tagHandlers[o.handle]=o.prefix);n.frames.push({kind:"document",position:n.position,value:void 0,hasValue:!1});break;case Y.SCALAR:{let{value:o,tag:a}=ws(n,i);hn(n,i,o,a,!0),fn(n,o,a);break}case Y.SEQUENCE:{let o=Qi(n,i,"tag:yaml.org,2002:seq"),a=n.schema.lookupSequenceTag(o);a||ee(n,`unknown sequence tag !<${o}>`);let s=a.create(o),r=hn(n,i,s,a,a.carrierIsResult);n.frames.push({kind:"sequence",position:n.position,value:s,tag:a,anchor:r,index:0});break}case Y.MAPPING:{let o=Qi(n,i,"tag:yaml.org,2002:map"),a=n.schema.lookupMappingTag(o);a||ee(n,`unknown mapping tag !<${o}>`);let s=a.create(o),r=hn(n,i,s,a,a.carrierIsResult);n.frames.push({kind:"mapping",position:n.position,value:s,tag:a,anchor:r,key:void 0,keyPosition:n.position,hasKey:!1,keyIsMerge:!1,overridable:null});break}case Y.ALIAS:{n.maxAliases!==-1&&++n.aliasCount>n.maxAliases&&ee(n,`aliases exceeded maxAliases (${n.maxAliases})`);let o=n.source.slice(i.anchorStart,i.anchorEnd),a=n.anchors.get(o);a||ee(n,`unidentified alias "${o}"`),a.isValueFinal||ee(n,`recursive alias "${o}" is not supported for tag ${a.tag.tagName} because it uses finalize()`),fn(n,a.value,a.tag);break}case Y.POP:{let o=n.frames.pop();if(o.kind==="mapping"&&o.hasKey&&(n.position=o.keyPosition,ee(n,"incomplete mapping pair in event stream")),o.kind==="document")n.documents.push(o.value);else{let a=o.tag.carrierIsResult?o.value:go(n,o.position,o.tag,o.value);o.anchor&&(o.anchor.value=a,o.anchor.isValueFinal=!0),fn(n,a,o.tag)}break}}}return n.documents}var D=-1,vo=Object.prototype.hasOwnProperty,Be=1,_o=2,yo=3,_t=4,Ts=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,Es=/[,\[\]{}]/,bo=/^(?:!|!!|![0-9A-Za-z-]+!)$/,_n=String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$,_.!~*'()\[\]])`,wo=String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$.~*'()_])`,As=new RegExp(`^(?:${_n})*$`),xs=new RegExp(`^(?:${wo})+$`),Ls=new RegExp(`^(?:!(?:${_n})*|${wo}(?:${_n})*)$`),Ln={filename:"",maxDepth:100};function Ns(e,t,n){e.events.push({type:Y.DOCUMENT,explicitStart:t,explicitEnd:n,directives:e.directives})}function ko(e,t,n,i,o,a,s){e.events.push({type:Y.SEQUENCE,start:t,anchorStart:n,anchorEnd:i,tagStart:o,tagEnd:a,style:s})}function So(e,t,n,i,o,a,s){e.events.push({type:Y.MAPPING,start:t,anchorStart:n,anchorEnd:i,tagStart:o,tagEnd:a,style:s})}function Ji(e,t){e.events.splice(t.eventsLength,0,{type:Y.MAPPING,start:t.position,anchorStart:D,anchorEnd:D,tagStart:D,tagEnd:D,style:re.FLOW})}function qe(e,t,n,i,o,a,s,r,l=ce.CLIP,u=-1,c=!1){e.events.push({type:Y.SCALAR,valueStart:t,valueEnd:n,anchorStart:i,anchorEnd:o,tagStart:a,tagEnd:s,style:r,chomping:l,indent:u,fast:c})}function Is(e,t,n){e.events.push({type:Y.ALIAS,anchorStart:t,anchorEnd:n})}function Me(e){e.events.push({type:Y.POP})}function oe(e){qe(e,D,D,D,D,D,D,I.PLAIN)}function Zi(){return{anchorStart:D,anchorEnd:D,tagStart:D,tagEnd:D}}function De(e){return{position:e.position,line:e.line,lineStart:e.lineStart,lineIndent:e.lineIndent,firstTabInLine:e.firstTabInLine,eventsLength:e.events.length}}function Ue(e,t){e.position=t.position,e.line=t.line,e.lineStart=t.lineStart,e.lineIndent=t.lineIndent,e.firstTabInLine=t.firstTabInLine,e.events.length=t.eventsLength}function L(e,t){Se.throwAt(e.input.slice(0,e.length),e.position,t,e.filename)}function Z(e){return e===10||e===13}function We(e){return e===9||e===32}function pe(e){return We(e)||Z(e)}function be(e){return e===0||pe(e)}function Ne(e){return e===44||e===91||e===93||e===123||e===125}function Os(e){return e>=48&&e<=57?e-48:-1}function Fs(e){if(e>=48&&e<=57)return e-48;let t=e|32;return t>=97&&t<=102?t-97+10:-1}function Ps(e){return e===120?2:e===117?4:e===85?8:0}function Rs(e){return e===48||e===97||e===98||e===116||e===9||e===110||e===118||e===102||e===114||e===101||e===32||e===34||e===47||e===92||e===78||e===95||e===76||e===80}function yt(e){e.input.charCodeAt(e.position)===10?e.position++:(e.position++,e.input.charCodeAt(e.position)===10&&e.position++),e.line++,e.lineStart=e.position,e.lineIndent=0,e.firstTabInLine=-1}function te(e,t){let n=0,i=e.input.charCodeAt(e.position),o=e.position===e.lineStart||pe(e.input.charCodeAt(e.position-1));for(;i!==0;){for(;We(i);)o=!0,i===9&&e.firstTabInLine===-1&&(e.firstTabInLine=e.position),i=e.input.charCodeAt(++e.position);if(t&&o&&i===35)do i=e.input.charCodeAt(++e.position);while(!Z(i)&&i!==0);if(!Z(i))break;for(yt(e),n++,o=!0,i=e.input.charCodeAt(e.position);i===32;)e.lineIndent++,i=e.input.charCodeAt(++e.position)}return n}function He(e,t=e.position){let n=e.input.charCodeAt(t);if((n===45||n===46)&&n===e.input.charCodeAt(t+1)&&n===e.input.charCodeAt(t+2)){let i=e.input.charCodeAt(t+3);return i===0||pe(i)}return!1}function Co(e){e.position===e.lineStart&&e.input.charCodeAt(e.position)===65279&&(e.position++,e.lineStart=e.position)}function Nn(e){if(e.position!==e.lineStart)return!1;if(He(e))return!0;if(e.input.charCodeAt(e.position)!==65279)return!1;let t=De(e);Co(e),te(e,!0);let n=e.input.charCodeAt(e.position),i=e.position===e.lineStart&&(n===37||n===45&&He(e));return Ue(e,t),i}function eo(e){let t=e.input.charCodeAt(e.position);for(;t!==0&&!Z(t);)t=e.input.charCodeAt(++e.position)}function To(e,t,n){let i=Ts.exec(e.input.slice(t,n));i!==null&&(e.position=t+i.index+i[0].length-1,L(e,"the stream contains non-printable characters"))}function Ms(e,t,n){if(e.input.charCodeAt(e.position)!==33)return!1;t.tagStart!==D&&L(e,"duplication of a tag property");let i=e.position,o=!1,a=!1,s="!",r=e.input.charCodeAt(++e.position);r===60?(o=!0,r=e.input.charCodeAt(++e.position)):r===33&&(a=!0,s="!!",r=e.input.charCodeAt(++e.position));let l=e.position,u;if(o){for(;r!==0&&r!==62;)r=e.input.charCodeAt(++e.position);r!==62&&L(e,"unexpected end of the stream within a verbatim tag"),u=e.input.slice(l,e.position),e.position++}else{for(;r!==0&&!pe(r)&&!(n&&Ne(r));)r===33&&(a?L(e,"tag suffix cannot contain exclamation marks"):(s=e.input.slice(l-1,e.position+1),bo.test(s)||L(e,"named tag handle cannot contain such characters"),a=!0,l=e.position+1)),r=e.input.charCodeAt(++e.position);u=e.input.slice(l,e.position),Es.test(u)&&L(e,"tag suffix cannot contain flow indicator characters")}return u&&!(o?As.test(u):xs.test(u))&&L(e,`tag name cannot contain such characters: ${u}`),!o&&s!=="!"&&s!=="!!"&&!vo.call(e.tagHandlers,s)&&L(e,`undeclared tag handle "${s}"`),t.tagStart=i,t.tagEnd=e.position,!0}function Ds(e,t){if(e.input.charCodeAt(e.position)!==38)return!1;t.anchorStart!==D&&L(e,"duplication of an anchor property"),e.position++;let n=e.position;for(;e.input.charCodeAt(e.position)!==0&&!pe(e.input.charCodeAt(e.position))&&!Ne(e.input.charCodeAt(e.position));)e.position++;return e.position===n&&L(e,"name of an anchor node must contain at least one character"),t.anchorStart=n,t.anchorEnd=e.position,!0}function Us(e,t){if(e.input.charCodeAt(e.position)!==42)return!1;(t.anchorStart!==D||t.tagStart!==D)&&L(e,"alias node should not have any properties"),e.position++;let n=e.position;for(;e.input.charCodeAt(e.position)!==0&&!pe(e.input.charCodeAt(e.position))&&!Ne(e.input.charCodeAt(e.position));)e.position++;return e.position===n&&L(e,"name of an alias node must contain at least one character"),Is(e,n,e.position),!0}function yn(e,t){te(e,!1),e.lineIndent<t&&L(e,"deficient indentation")}function Bs(e,t,n){if(e.input.charCodeAt(e.position)!==39)return!1;e.position++;let i=e.position,o=!0;for(;e.input.charCodeAt(e.position)!==0;){let a=e.input.charCodeAt(e.position);if(a===39){if(e.input.charCodeAt(e.position+1)===39){o=!1,e.position+=2;continue}let s=e.position;return e.position++,qe(e,i,s,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,I.SINGLE_QUOTED,ce.CLIP,-1,o),!0}Z(a)?(o=!1,yn(e,t)):e.position===e.lineStart&&He(e)?L(e,"unexpected end of the document within a single quoted scalar"):a!==9&&a<32?L(e,"expected valid JSON character"):e.position++}L(e,"unexpected end of the stream within a single quoted scalar")}function Hs(e,t,n){if(e.input.charCodeAt(e.position)!==34)return!1;e.position++;let i=e.position,o=!0;for(;e.input.charCodeAt(e.position)!==0;){let a=e.input.charCodeAt(e.position);if(a===34){let s=e.position;return e.position++,qe(e,i,s,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,I.DOUBLE_QUOTED,ce.CLIP,-1,o),!0}if(a===92){o=!1;let s=e.input.charCodeAt(++e.position);if(Z(s))yn(e,t);else if(Rs(s))e.position++;else{let r=Ps(s);for(r===0&&L(e,"unknown escape sequence");r-- >0;)e.position++,Fs(e.input.charCodeAt(e.position))<0&&L(e,"expected hexadecimal character");e.position++}}else Z(a)?(o=!1,yn(e,t)):e.position===e.lineStart&&He(e)?L(e,"unexpected end of the document within a double quoted scalar"):a!==9&&a<32?L(e,"expected valid JSON character"):e.position++}L(e,"unexpected end of the stream within a double quoted scalar")}function Ks(e,t,n){let i=e.input.charCodeAt(e.position),o=ce.CLIP,a=-1,s=!1;if(i!==124&&i!==62)return!1;let r=i===124?I.LITERAL_BLOCK:I.FOLDED_BLOCK;for(e.position++;e.input.charCodeAt(e.position)!==0;){let h=e.input.charCodeAt(e.position),m=Os(h);if(h===43||h===45)o!==ce.CLIP&&L(e,"repeat of a chomping mode identifier"),o=h===43?ce.KEEP:ce.STRIP,e.position++;else if(m>=0)m===0&&L(e,"bad explicit indentation width of a block scalar; it cannot be less than one"),s&&L(e,"repeat of an indentation width identifier"),a=t+m-1,s=!0,e.position++;else break}let l=!1;for(;We(e.input.charCodeAt(e.position));)l=!0,e.position++;l&&e.input.charCodeAt(e.position)===35&&eo(e),Z(e.input.charCodeAt(e.position))?yt(e):e.input.charCodeAt(e.position)!==0&&L(e,"a line break is expected");let u=s?a:-1,c=0,p=e.position,f=e.position;for(;e.input.charCodeAt(e.position)!==0;){let h=e.position,m=0;for(;e.input.charCodeAt(h+m)===32;)m++;let y=e.input.charCodeAt(h+m);if(y===0){u>=0?m>u&&(f=h+m):m>0&&(f=h+m);break}if(Nn(e))break;if(!s&&u===-1&&Z(y)&&(c=Math.max(c,m)),!s&&u===-1&&!Z(y)&&(y===9&&m<t&&(e.position=h+m,L(e,"tab characters must not be used in indentation")),m>=t&&m<c&&(e.position=h+m,L(e,"bad indentation of a mapping entry"))),u===-1&&y!==0&&!Z(y)&&m<t){e.lineIndent=m,e.position=h+m;break}!s&&y!==0&&!Z(y)&&u===-1&&(u=m);let $=u===-1?t+1:u;if(y!==0&&!Z(y)&&m<$){e.lineIndent=m,e.position=h+m;break}eo(e),f=e.position,Z(e.input.charCodeAt(e.position))&&(yt(e),f=e.position)}return To(e,p,f),qe(e,p,f,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,r,o,u),!0}function qs(e,t){let n=e.input.charCodeAt(e.position),i=t===Be;if(n===0||pe(n)||n===35||n===38||n===42||n===33||n===124||n===62||n===39||n===34||n===37||n===64||n===96||Ne(n))return!1;if(n===63||n===45){let o=e.input.charCodeAt(e.position+1);if(be(o)||i&&Ne(o))return!1}return!0}function Ws(e,t,n,i){if(!qs(e,n))return!1;let o=e.position,a=e.position,s=e.input.charCodeAt(e.position),r=n===Be,l=!1;for(;s!==0&&!Nn(e);){if(s===58){let u=e.input.charCodeAt(e.position+1);if(be(u)||r&&Ne(u))break}else if(s===35){if(pe(e.input.charCodeAt(e.position-1)))break}else{if(r&&Ne(s))break;if(Z(s)){let u=e.position,c=e.line,p=e.lineStart,f=e.lineIndent;if(te(e,!1),e.lineIndent>=t){l=!0,s=e.input.charCodeAt(e.position);continue}e.position=u,e.line=c,e.lineStart=p,e.lineIndent=f;break}}We(s)||(a=e.position+1),s=e.input.charCodeAt(++e.position)}return a===o?!1:(To(e,o,a),qe(e,o,a,i.anchorStart,i.anchorEnd,i.tagStart,i.tagEnd,I.PLAIN,ce.CLIP,-1,!l),!0)}function it(e,t){let n=e.line;te(e,!0),(e.line>n&&e.lineIndent<t||e.firstTabInLine!==-1&&e.lineIndent<t)&&L(e,"deficient indentation")}function js(e,t,n){let i=e.input.charCodeAt(e.position),o=i===123,a=e.position,s=!0;if(i!==91&&i!==123)return!1;let r=o?125:93;for(o?So(e,a,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,re.FLOW):ko(e,a,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,re.FLOW),e.position++;e.input.charCodeAt(e.position)!==0;){it(e,t);let l=e.input.charCodeAt(e.position);if(l===r)return e.position++,Me(e),!0;s?l===44&&L(e,"expected the node content, but found ','"):L(e,"missed comma between flow collection entries");let u=!1,c=!1;l===63&&pe(e.input.charCodeAt(e.position+1))&&(u=c=!0,e.position+=1,it(e,t));let p=e.line,f=De(e),h=Ke(e,t,Be,!1,!0);it(e,t),l=e.input.charCodeAt(e.position),(o||c||e.line===p)&&l===58?(u=!0,e.position++,it(e,t),o||Ji(e,f),h||oe(e),Ke(e,t,Be,!1,!0)||oe(e),it(e,t),o||Me(e)):o&&u?(h||oe(e),oe(e)):o?oe(e):u&&(Ji(e,f),h||oe(e),oe(e),Me(e)),l=e.input.charCodeAt(e.position),l===44?(s=!0,e.position++):s=!1}L(e,"unexpected end of the stream within a flow collection")}function to(e,t,n){if(e.firstTabInLine!==-1||e.input.charCodeAt(e.position)!==45||!be(e.input.charCodeAt(e.position+1)))return!1;for(ko(e,e.position,n.anchorStart,n.anchorEnd,n.tagStart,n.tagEnd,re.BLOCK);e.input.charCodeAt(e.position)===45&&be(e.input.charCodeAt(e.position+1));){e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,L(e,"tab characters must not be used in indentation"));let i=e.line;e.position++;let o=te(e,!0)>0;if(e.firstTabInLine!==-1&&e.input.charCodeAt(e.position)===45&&be(e.input.charCodeAt(e.position+1))&&L(e,"bad indentation of a sequence entry"),o&&e.lineIndent<=t?oe(e):Ke(e,t,yo,!1,!0),te(e,!0),e.lineIndent<t||e.position>=e.length)break;e.lineIndent>t&&L(e,"bad indentation of a sequence entry"),e.line===i&&e.input.charCodeAt(e.position)===45&&be(e.input.charCodeAt(e.position+1))&&L(e,"bad indentation of a sequence entry")}return Me(e),!0}function mn(e,t,n,i){let o=!1,a=!1,s=!1,r=!1;if(e.firstTabInLine!==-1)return!1;let l=e.input.charCodeAt(e.position);for(;l!==0;){!o&&e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,L(e,"tab characters must not be used in indentation"));let u=e.input.charCodeAt(e.position+1),c=e.line;if((l===63||l===58)&&be(u))s||(So(e,e.position,i.anchorStart,i.anchorEnd,i.tagStart,i.tagEnd,re.BLOCK),s=!0),l===63?(o&&oe(e),a=!0,o=!0):(o||(oe(e),a=!0),o=!1),e.position+=1,r=!0;else{o&&(oe(e),o=!1);let p=De(e);if(!Ke(e,n,_o,!1,!0))break;if(e.line===c){for(l=e.input.charCodeAt(e.position);We(l);)l=e.input.charCodeAt(++e.position);if(l===58)l=e.input.charCodeAt(++e.position),be(l)||L(e,"a whitespace character is expected after the key-value separator within a block mapping"),s||(e.events.splice(p.eventsLength,0,{type:Y.MAPPING,start:p.position,anchorStart:i.anchorStart,anchorEnd:i.anchorEnd,tagStart:i.tagStart,tagEnd:i.tagEnd,style:re.BLOCK}),s=!0),a=!0,o=!1,r=!1;else if(a)L(e,"expected ':' after a mapping key");else return i.anchorStart!==D||i.tagStart!==D?(Ue(e,p),!1):!0}else if(a)L(e,"can not read a block mapping entry; a multiline key may not be an implicit key");else return i.anchorStart!==D||i.tagStart!==D?(Ue(e,p),!1):!0}if(Ke(e,t,_t,!0,r)&&(r=!1),o||r&&(oe(e),r=!1),te(e,!0),l=e.input.charCodeAt(e.position),(e.line===c||e.lineIndent>t)&&l!==0)L(e,"bad indentation of a mapping entry");else if(e.lineIndent<t)break}return a?(o&&oe(e),s&&Me(e),!0):!1}function Ke(e,t,n,i,o,a=!0){e.depth>=e.maxDepth&&L(e,`nesting exceeded maxDepth (${e.maxDepth})`),e.depth++;let s=1,r=!1,l=!1,u=null,c=Zi(),p=n===_t||n===yo,f=p,h=p;if(i&&te(e,!0)&&(r=!0,e.lineIndent>t?s=1:e.lineIndent===t?s=0:s=-1),s===1)for(;;){let m=e.input.charCodeAt(e.position),y=De(e);if(r&&s!==1&&(m===33||m===38))break;if(r&&h&&(c.tagStart!==D||c.anchorStart!==D)&&(m===33||m===38)){let $=De(e),g=t+1;if(mn(e,e.position-e.lineStart,g,c)&&e.events[$.eventsLength]?.type===Y.MAPPING)return e.depth--,!0;Ue(e,$)}if(r&&(m===33&&c.tagStart!==D||m===38&&c.anchorStart!==D)||!Ms(e,c,n===Be)&&!Ds(e,c))break;u===null&&(u=y),te(e,!0)?(r=!0,f=h,e.lineIndent>t?s=1:e.lineIndent===t?s=0:s=-1):f=!1}if(f&&(f=r||o),s===1||n===_t){let m=n===Be||n===_o?t:t+1,y=e.position-e.lineStart;if(s===1)if(f&&(to(e,y,c)||mn(e,y,m,c))||js(e,m,c))l=!0;else{let $=e.input.charCodeAt(e.position);if(u!==null&&a&&h&&!f&&$!==124&&$!==62){let g=De(e),v=u.position-u.lineStart;Ue(e,u),mn(e,v,m,Zi())&&e.events[g.eventsLength]?.type===Y.MAPPING?l=!0:Ue(e,g)}!l&&(p&&Ks(e,m,c)||Bs(e,m,c)||Hs(e,m,c)||Us(e,c)||Ws(e,m,n,c))&&(l=!0)}else s===0&&(l=f&&to(e,y,c))}return p=p&&!l,!l&&(c.anchorStart!==D||c.tagStart!==D||p)&&(qe(e,D,D,c.anchorStart,c.anchorEnd,c.tagStart,c.tagEnd,I.PLAIN),l=!0),e.depth--,l||c.anchorStart!==D||c.tagStart!==D}function Ys(e){if(e.lineIndent>0||e.input.charCodeAt(e.position)!==37)return!1;e.position++;let t=e.position;for(;e.input.charCodeAt(e.position)!==0&&!pe(e.input.charCodeAt(e.position));)e.position++;let n=e.input.slice(t,e.position),i=[];for(n.length===0&&L(e,"directive name must not be less than one character in length");e.input.charCodeAt(e.position)!==0&&!Z(e.input.charCodeAt(e.position));){for(;We(e.input.charCodeAt(e.position));)e.position++;if(e.input.charCodeAt(e.position)===35||Z(e.input.charCodeAt(e.position))||e.input.charCodeAt(e.position)===0)break;let o=e.position;for(;e.input.charCodeAt(e.position)!==0&&!pe(e.input.charCodeAt(e.position));)e.position++;i.push(e.input.slice(o,e.position))}if(Z(e.input.charCodeAt(e.position))&&yt(e),n==="YAML"){e.directives.some(a=>a.kind==="yaml")&&L(e,"duplication of %YAML directive"),i.length!==1&&L(e,"YAML directive accepts exactly one argument");let o=/^([0-9]+)\.([0-9]+)$/.exec(i[0]);o===null&&L(e,"ill-formed argument of the YAML directive"),parseInt(o[1],10)!==1&&L(e,"unacceptable YAML version of the document"),e.directives.push({kind:"yaml",version:i[0]})}else if(n==="TAG"){i.length!==2&&L(e,"TAG directive accepts exactly two arguments");let[o,a]=i;bo.test(o)||L(e,"ill-formed tag handle (first argument) of the TAG directive"),vo.call(e.tagHandlers,o)&&L(e,`there is a previously declared suffix for "${o}" tag handle`),Ls.test(a)||L(e,"ill-formed tag prefix (second argument) of the TAG directive"),e.tagHandlers[o]=a,e.directives.push({kind:"tag",handle:o,prefix:a})}return!0}function Gs(e){e.directives=[],e.tagHandlers=Object.create(null);let t=!1;for(te(e,!0);Ys(e);)t=!0,te(e,!0);let n=!1,i=!1,o=!0;if(e.lineIndent===0&&e.input.charCodeAt(e.position)===45&&e.input.charCodeAt(e.position+1)===45&&e.input.charCodeAt(e.position+2)===45&&be(e.input.charCodeAt(e.position+3))){n=!0;let r=e.line;e.position+=3,te(e,!0),o=e.line>r}else t&&L(e,"directives end mark is expected");let a=e.events.length;if(!n&&e.position===e.lineStart&&e.input.charCodeAt(e.position)===46&&He(e)){e.position+=3,te(e,!0);return}if(Ns(e,n,!1),Ke(e,e.lineIndent-1,_t,!1,o,o)||oe(e),te(e,!0),e.position===e.lineStart&&He(e)&&(i=e.input.charCodeAt(e.position)===46,i)){let r=e.line;e.position+=3,te(e,!0),e.line===r&&e.position<e.length&&L(e,"end of the stream or a document separator is expected")}let s=e.events[a];s?.type===Y.DOCUMENT&&(s.explicitEnd=i),Me(e),!i&&e.position<e.length&&!Nn(e)&&L(e,"end of the stream or a document separator is expected")}function Vs(e,t){let n=e.length,i={...Ln,...t,input:`${e}\0`,length:n,position:0,line:0,lineStart:0,lineIndent:0,firstTabInLine:-1,depth:0,directives:[],tagHandlers:Object.create(null),events:[]},o=e.indexOf("\0");for(o!==-1&&Se.throwAt(e,o,"null byte is not allowed in input",i.filename);i.position<i.length&&(Co(i),te(i,!0),!(i.position>=i.length));){let a=i.position;Gs(i),i.position===a&&L(i,"can not read a document")}return i.events}var Qs={...Ln,...xn};function zs(e,t={}){let n={...Qs,...t},i=String(e),o=Object.keys(Ln),a=Object.keys(xn);return Cs(Vs(i,vn(n,o)),{...vn(n,a),source:i})}function Eo(e,t){let n=zs(e,t);if(n.length===0)throw new Se("expected a document, but the input is empty");if(n.length===1)return n[0];throw new Se("expected a single document in the stream, but found more")}var Le=Symbol("INVALID");function Xs(e){let t=new Set([e.defaultScalarTag,e.defaultSequenceTag,e.defaultMappingTag].filter(a=>a!==void 0)),n=e.implicitScalarTags,i=e.tags.filter(a=>!(a.nodeKind==="scalar"&&a.implicit)&&!t.has(a)),o=e.tags.filter(a=>t.has(a));return[...n.map(a=>({tag:a,implicitTag:!0})),...i.map(a=>({tag:a,implicitTag:!1})),...o.map(a=>({tag:a,implicitTag:!0}))]}function Js(e,t){for(let n=0,i=e.representTypes.length;n<i;n+=1){let{tag:o,implicitTag:a}=e.representTypes[n];if(o.identify(t)){let s;return o.matchByTagPrefix?s=o.representTagName(t):s=o.tagName,{tag:o,tagName:s,implicitTag:a}}}return null}function at(e,t){if(!e.noRefs&&t!==null&&typeof t=="object"){let u=e.refs.get(t);if(u)return u.anchor===void 0&&(u.anchor=`ref_${e.refCounter++}`),{kind:"alias",anchor:u.anchor}}let n=Js(e,t);if(!n){if(t===void 0||e.skipInvalid)return Le;throw new Se(`unacceptable kind of an object to dump ${Object.prototype.toString.call(t)}`)}let{tag:i,tagName:o,implicitTag:a}=n,s=a?o:mo(o);if(i.nodeKind==="scalar")return{kind:"scalar",tag:s,tagged:!a,style:I.PLAIN,value:i.represent(t)};if(i.nodeKind==="sequence"){let u=i.represent(t),c={kind:"sequence",tag:s,tagged:!a,style:re.BLOCK,items:[]};e.noRefs||e.refs.set(t,c);for(let p=0,f=u.length;p<f;p+=1){let h=at(e,u[p]);h===Le&&u[p]===void 0&&(h=at(e,null)),h!==Le&&c.items.push(h)}return c}let r=i.represent(t),l={kind:"mapping",tag:s,tagged:!a,style:re.BLOCK,items:[]};e.noRefs||e.refs.set(t,l);for(let[u,c]of r){let p=at(e,u);if(p===Le)continue;let f=at(e,c);f!==Le&&l.items.push({key:p,value:f})}return l}function Zs(e,t,n={}){let i=at({representTypes:Xs(t),noRefs:n.noRefs??!1,skipInvalid:n.skipInvalid??!1,refs:new Map,refCounter:0},e);return[{contents:i===Le?null:i,directives:[]}]}var el=Symbol("visit:break"),Ao=Symbol("visit:skip");function $t(e,t,n){let i=t(e,n);if(i===el)return!0;if(i===Ao)return!1;let o=n.depth+1;switch(e.kind){case"sequence":for(let a of e.items)if($t(a,t,{depth:o,parent:e,isKey:!1}))return!0;break;case"mapping":for(let{key:a,value:s}of e.items)if($t(a,t,{depth:o,parent:e,isKey:!0})||$t(s,t,{depth:o,parent:e,isKey:!1}))return!0}return!1}function no(e,t){for(let n of e)if(n.contents&&$t(n.contents,t,{depth:0,parent:null,isKey:!1}))return}function Ct(e,t){return(e&1<<t)!==0}var io={applyQuoteFlowKeysOption:tl,doubleQuoteForInvisibles:nl,doubleQuoteWhitespaceOnly:il,applyForceQuotesOption:ol,tryLongOrMultilineAsBlock:al,quoteInvalidPlain:rl,fallbackToDoubleQuoted:sl};function xo(e){return e.presenterOptions.quoteStyle==="single"&&Ct(e.allowedStylesMask,I.SINGLE_QUOTED)?I.SINGLE_QUOTED:I.DOUBLE_QUOTED}function tl(e){e.presenterOptions.quoteFlowKeys&&(!e.isKey||!e.flowOnly||e.style!==I.PLAIN||(e.style=I.DOUBLE_QUOTED))}function nl(e){e.style===I.PLAIN&&/[\t\x7F-\xA0\u2028\u2029\uFEFF\uFFFE\uFFFF]/.test(e.node.value)&&(e.style=I.DOUBLE_QUOTED)}function il(e){e.style===I.PLAIN&&/^\s+$/.test(e.node.value)&&(e.style=I.DOUBLE_QUOTED)}function ol(e){e.presenterOptions.forceQuotes&&(e.isKey||e.style!==I.PLAIN||e.node.tag===e.presenterOptions.schema.defaultScalarTag.tagName&&(e.style=e.node.value.includes(`
`)?I.DOUBLE_QUOTED:xo(e)))}function al(e){if(e.style!==I.PLAIN||e.isKey)return;let t=e.node.value,n=t.indexOf(`
`)!==-1;if(!Ct(e.allowedStylesMask,I.LITERAL_BLOCK)){n&&(e.style=I.DOUBLE_QUOTED);return}let i=e.presenterOptions.lineWidth;if(i===-1){n&&(e.style=I.LITERAL_BLOCK);return}let o=Math.max(Math.min(i,40),i-e.shiftOfContent),a=0,s=!1;for(;a<=t.length;){let r=t.length,l=t.indexOf(`
`,a);l!==-1&&(r=l);let u=t.slice(a,r);if(u.length>o&&u[0]!==" "&&/ [^ \t]/.test(u)&&(s=!0),l===-1)break;a=l+1}s?e.style=I.FOLDED_BLOCK:n&&(e.style=I.LITERAL_BLOCK)}function rl(e){e.style===I.PLAIN&&!Ct(e.allowedStylesMask,I.PLAIN)&&(e.style=xo(e))}function sl(e){Ct(e.allowedStylesMask,e.style)||(e.style=I.DOUBLE_QUOTED)}function ot(e,t){return e|1<<t}var ll="[\\x09\\x0A\\x0D\\x20-\\x7E\\x85\\xA0-\\uD7FF\\uE000-\\uFFFD\\u{10000}-\\u{10FFFF}]",cl="[\\n\\r]",ul="\\uFEFF",In="[ \\t]",Lo=`(?:(?!(?:${cl}|${ul}))${ll})`,Tt=`(?:(?!${In})${Lo})`,No="[\\x09\\x20-\\uD7FF\\uE000-\\uFFFF\\u{10000}-\\u{10FFFF}]",Io="[-?:,\\[\\]{}#&*!|>'\"%@`]",dl="[,\\[\\]{}]",bn=Tt,wn=`(?:(?!${dl})${Tt})`,pl=`(?:(?:(?!${Io})${Tt})|[?:-](?=${bn}))`,fl=`(?:(?:(?!${Io})${Tt})|[?:-](?=${wn}))`,Oo=`(?:(?:(?![:#])${bn})|:(?=${bn}))#*`,Fo=`(?:(?:(?![:#])${wn})|:(?=${wn}))#*`,Po=`(?:${In}*${Oo})*`,Ro=`(?:${In}*${Fo})*`,Mo=`${pl}#*${Po}`,Do=`${fl}#*${Ro}`,hl=Mo,ml=Do,gl=`\\n+${Oo}${Po}`,$l=`\\n+${Fo}${Ro}`,vl=`${Mo}(?:${gl})*`,_l=`${Do}(?:${$l})*`,yl=new RegExp(`^(?:${vl})$`,"u"),bl=new RegExp(`^(?:${_l})$`,"u"),wl=new RegExp(`^(?:${hl})$`,"u"),kl=new RegExp(`^(?:${ml})$`,"u"),Sl=new RegExp(`^(?:${No})*$`,"u"),Cl=new RegExp(`^(?:${No}|\\n)*$`,"u"),Tl=new RegExp(`^(?:${Lo}|\\n)*$`,"u"),El=/^(?:---|\.\.\.)(?=$|[ \t\n\r])/,On=/^(?:---|\.\.\.)(?=$|[ \t\n\r])/m;function Al(e){let t=e.node.value;if(t!==""){if(!(e.isKey?e.flowOnly?kl:wl:e.flowOnly?bl:yl).test(t)||e.shiftOfFirstLine===0&&El.test(t))return!1;if(e.shiftOfContent===0){let i=t.indexOf(`
`);if(i!==-1){let o=t.slice(i+1);if(On.test(o))return!1}}}let n=e.presenterOptions.schema.resolveImplicitScalarTag(t).tag.tagName;return!(!e.node.tagged&&n!==e.node.tag||!e.node.tagged&&t==="="&&n===e.presenterOptions.schema.defaultScalarTag.tagName)}function xl(e){let t=e.node.value;if(!(e.isKey?Sl:Cl).test(t)||/[ \t]\n|\n[ \t]/.test(t))return!1;if(!e.isKey&&e.shiftOfContent===0){let n=t.indexOf(`
`);if(n!==-1&&On.test(t.slice(n+1)))return!1}return!0}function Ll(e){if(e.flowOnly||!Tl.test(e.node.value))return!1;let t=e.shiftOfContent-e.shiftOfParent;return!(t<1||t>9&&/^\n* /.test(e.node.value)||e.shiftOfContent===0&&On.test(e.node.value))}function Nl(e){let t=ot(0,I.DOUBLE_QUOTED);Al(e)&&(t=ot(t,I.PLAIN)),xl(e)&&(t=ot(t,I.SINGLE_QUOTED)),Ll(e)&&(t=ot(ot(t,I.LITERAL_BLOCK),I.FOLDED_BLOCK)),e.allowedStylesMask=t}function Il(e){switch(e.style){case I.PLAIN:return Ol(e);case I.SINGLE_QUOTED:return Fl(e);case I.LITERAL_BLOCK:return Pl(e);case I.FOLDED_BLOCK:return Rl(e);case I.DOUBLE_QUOTED:return Ml(e)}}function Ol(e){return Uo(e.node.value,e.shiftOfContent)}function Fl(e){return`'${Uo(e.node.value,e.shiftOfContent).replace(/'/g,"''")}'`}function Pl(e){let t=e.node.value;return"|"+Ho(t,e.shiftOfParent,e.shiftOfContent)+Ko(Bo(t,e.shiftOfContent))}function Rl(e){let t=e.node.value,n=e.presenterOptions.lineWidth,i=1/0;return n!==-1&&(i=Math.max(Math.min(n,40),n-e.shiftOfContent)),">"+Ho(t,e.shiftOfParent,e.shiftOfContent)+Ko(Bo(Ul(t,i),e.shiftOfContent))}function Ml(e){return`"${Kl(e.node.value)}"`}function Uo(e,t){let n=e.indexOf(`
`);if(n===-1)return e;let i=" ".repeat(t),o=e.slice(0,n),a=/(\n+)([^\n]*)/g;a.lastIndex=n;let s;for(;s=a.exec(e);){let r=s[1].length,l=s[2];o+=`
`.repeat(r+1)+i+l}return o}function Bo(e,t){let n=" ".repeat(t),i=0,o="",a=e.length;for(;i<a;){let s,r=e.indexOf(`
`,i);r===-1?(s=e.slice(i),i=a):(s=e.slice(i,r+1),i=r+1),s.length&&s!==`
`&&(o+=n),o+=s}return o}function Dl(e){return/^\n* /.test(e)}function Ho(e,t,n){let i=Dl(e)?String(n-t):"",o=e[e.length-1]===`
`;return`${i}${o&&(e[e.length-2]===`
`||e===`
`)?"+":o?"":"-"}
`}function Ko(e){return e[e.length-1]===`
`?e.slice(0,-1):e}function kn(e){return e===" "||e==="	"}function oo(e,t){if(e===""||kn(e[0]))return e;let n=/ [^ \t]/g,i,o=0,a,s=0,r=0,l="";for(;i=n.exec(e);)r=i.index,r-o>t&&(a=s>o?s:r,l+=`
${e.slice(o,a)}`,o=a+1),s=r;return l+=`
`,e.length-o>t&&s>o?l+=`${e.slice(o,s)}
${e.slice(s+1)}`:l+=e.slice(o),l.slice(1)}function Ul(e,t){let n=/(\n+)([^\n]*)/g,i=e.indexOf(`
`);i===-1&&(i=e.length),n.lastIndex=i;let o=oo(e.slice(0,i),t),a=e[0]===`
`||kn(e[0]),s,r;for(;r=n.exec(e);){let l=r[1],u=r[2];s=u!==""&&kn(u[0]),o+=l+(!a&&!s&&u!==""?`
`:"")+oo(u,t),a=s}return o}var Bl=/["\\\x00-\x1F\x7F-\xA0\u2028\u2029\uD800-\uDFFF\uFEFF\uFFFE\uFFFF]/gu;function Hl(e){switch(e){case"\0":return"\\0";case"\x07":return"\\a";case"\b":return"\\b";case"	":return"\\t";case`
`:return"\\n";case"\v":return"\\v";case"\f":return"\\f";case"\r":return"\\r";case"\x1B":return"\\e";case'"':return'\\"';case"\\":return"\\\\";case"\x85":return"\\N";case"\xA0":return"\\_";case"\u2028":return"\\L";case"\u2029":return"\\P"}let t=e.charCodeAt(0),n=t.toString(16).toUpperCase();return t<=255?`\\x${"0".repeat(2-n.length)}${n}`:`\\u${"0".repeat(4-n.length)}${n}`}function Kl(e){return e.replace(Bl,Hl)}var bt=10,Fn={indent:2,seqNoIndent:!1,seqInlineFirst:!0,lineWidth:80,flowBracketPadding:!1,flowSkipCommaSpace:!1,flowSkipColonSpace:!1,quoteFlowKeys:!1,quoteStyle:"single",forceQuotes:!1,scalarStyleRules:Object.keys(io).map(e=>Reflect.get(io,e)),tagBeforeAnchor:!1};function ql(e){return e.tagged?e.tag:mo(e.tag)}function Wl(e){let t={...Fn,...e};return t.flowSkipColonSpace&&(t.quoteFlowKeys=!0),{...t,defaultScalarTagName:t.schema.defaultScalarTag.tagName,openEnded:!1}}function Sn(e,t){return`
${" ".repeat(e.indent*t)}`}function jl(e,t,n,i,o,a){return{node:t,parent:n,level:i,isKey:o,flowOnly:a,shiftOfParent:i===0?-1:e.indent*(i-1),shiftOfContent:e.indent*Math.max(1,i),shiftOfFirstLine:i===0?0:e.indent*i,presenterOptions:e,allowedStylesMask:0,style:t.style}}function Yl(e,t,n){let i="";for(let a=0,s=n.items.length;a<s;a+=1){let r=we(e,t,n.items[a],n,{}).text;a>0&&(i+=`,${e.flowSkipCommaSpace?"":" "}`),i+=r}let o=e.flowBracketPadding&&n.items.length>0?" ":"";return`[${o}${i}${o}]`}function ao(e,t,n,i){let o="";for(let a=0,s=n.items.length;a<s;a+=1){let r=we(e,t+1,n.items[a],n,{block:!0,compact:e.seqInlineFirst,isblockseq:!0}).text;(!i||o!=="")&&(o+=Sn(e,t)),r===""||bt===r.charCodeAt(0)?o+="-":o+="- ",o+=r}return o}function Gl(e,t,n){let i="";for(let{key:a,value:s}of n.items){let r="";i!==""&&(r+=`,${e.flowSkipCommaSpace?"":" "}`);let l=we(e,t,a,n,{iskey:!0}),u=l.text,c=we(e,t,s,n,{}).text,p=e.flowSkipColonSpace||c===""?"":" ",f=a.kind==="scalar"&&l.noBody&&(a.tagged||a.anchor!==void 0),h=a.kind==="alias"||f?" ":"";r+=`${u}${h}:${p}${c}`,i+=r}let o=e.flowBracketPadding&&i!==""?" ":"";return`{${o}${i}${o}}`}function Vl(e,t,n,i){let o="";for(let a=0,s=n.items.length;a<s;a+=1){let r="";(!i||o!=="")&&(r+=Sn(e,t));let{key:l,value:u}=n.items[a],c=(l.kind==="mapping"||l.kind==="sequence")&&l.style===re.BLOCK&&l.items.length!==0||l.kind==="scalar"&&(l.style===I.LITERAL_BLOCK||l.style===I.FOLDED_BLOCK),p=c?we(e,t+1,l,n,{block:!0,compact:!0,isblockseq:!Cn(e,l,t+1)}):we(e,t+1,l,n,{block:!0,compact:!0,iskey:!0}),f=p.text,h=l.kind==="scalar"&&l.value.indexOf(`
`)!==-1,m=f.length>1024&&/^[\s\S]{1025}/u.test(f),y=c||h||m;y&&(f&&bt===f.charCodeAt(0)?r+="?":r+="? "),r+=f,y&&(r+=Sn(e,t));let $=we(e,t+1,u,n,{block:!0,compact:y,isblockseq:y&&!Cn(e,u,t+1)}).text,g=l.kind==="scalar"&&p.noBody&&(l.tagged||l.anchor!==void 0),v=!y&&(l.kind==="alias"||g)?" ":"";$===""||bt===$.charCodeAt(0)?r+=`${v}:`:r+=`${v}: `,r+=$,o+=r}return o}function Cn(e,t,n){return t.kind==="alias"?!0:t.tagged||t.anchor!==void 0||e.indent<2&&n>0}function we(e,t,n,i,o){if(n.kind==="alias")return e.openEnded=!1,{text:`*${n.anchor}`,noBody:!1};let{block:a=!1,iskey:s=!1,isblockseq:r=!1}=o,l=o.compact??!1,u=n.anchor!==void 0;Cn(e,n,t)&&(l=!1);let c,p=n.tagged,f=a&&(n.kind==="mapping"||n.kind==="sequence")&&n.style===re.BLOCK&&n.items.length!==0;if(n.kind==="mapping")f?c=Vl(e,t,n,l):c=Gl(e,t,n);else if(n.kind==="sequence")f?e.seqNoIndent&&!r&&t>0?c=ao(e,t-1,n,l):c=ao(e,t,n,l):c=Yl(e,t,n);else{let y=jl(e,n,i,t,s,!a);Nl(y);for(let $ of e.scalarStyleRules)$(y);c=Il(y),e.openEnded=(y.style===I.LITERAL_BLOCK||y.style===I.FOLDED_BLOCK)&&(n.value===`
`||n.value.endsWith(`

`)),p=n.tagged||c===""&&y.flowOnly&&i?.kind==="sequence"&&!u||y.style!==I.PLAIN&&n.tag!==e.defaultScalarTagName}(n.kind==="mapping"||n.kind==="sequence")&&!f&&(e.openEnded=!1),f&&l&&t>0&&e.indent>2&&(c=`${" ".repeat(e.indent-2)}${c}`);let h=c==="",m=c;if(p||u){let y=[],$=p?ql(n):null,g=u?`&${n.anchor}`:null;e.tagBeforeAnchor?($!==null&&y.push($),g!==null&&y.push(g)):(g!==null&&y.push(g),$!==null&&y.push($));let v=c===""||c.charCodeAt(0)===bt?"":" ";m=`${y.join(" ")}${v}${c}`}return{text:m,noBody:h}}function Ql(e){return(e.kind==="sequence"||e.kind==="mapping")&&e.style===re.BLOCK&&e.items.length!==0&&!e.tagged&&e.anchor===void 0}function zl(e){let t="";for(let n of e.directives){if(n.kind==="yaml"){t+=`%YAML ${n.version}
`;continue}let{handle:i,prefix:o}=n;t+=`%TAG ${i} ${o}
`}return t}function Xl(e,t){let n=Wl(t),i="",o=!1;for(let a=0;a<e.length;a+=1){let s=e[a];n.openEnded=!1;let r=zl(s),l=r!=="",u=s.explicitStart||l||a>0&&!o;if(i+=r,s.contents===null)u&&(i+=`---
`);else if(u){let c=we(n,0,s.contents,null,{block:!0,compact:!0}).text,p=c===""?"":l||Ql(s.contents)?`
`:" ";i+=`---${p}${c}
`}else i+=we(n,0,s.contents,null,{block:!0,compact:!0}).text+`
`;o=s.explicitEnd||n.openEnded,o&&(i+=`...
`)}return i}var Jl={...Fn,schema:ss,skipInvalid:!1,noRefs:!1,flowLevel:-1,sortKeys:!1,transform:()=>{}};function Zl(e,t){let n=String(e),i=String(t);return n<i?-1:n>i?1:0}function qo(e,t={}){let n={...Jl,...t},i=Zs(e,n.schema,{noRefs:n.noRefs,skipInvalid:n.skipInvalid});if(n.flowLevel>=0&&no(i,(o,a)=>{if(!(a.depth<n.flowLevel))return(o.kind==="sequence"||o.kind==="mapping")&&(o.style=re.FLOW),Ao}),n.sortKeys){let o=n.sortKeys===!0?Zl:n.sortKeys;no(i,a=>{a.kind==="mapping"&&a.items.sort((s,r)=>o(s.key.kind==="scalar"?s.key.value:"",r.key.kind==="scalar"?r.key.value:""))})}return n.transform(i),Xl(i,{...vn(n,Object.keys(Fn)),schema:n.schema})}var Qu=Y.DOCUMENT,zu=Y.SEQUENCE,Xu=Y.MAPPING,Ju=Y.SCALAR,Zu=Y.ALIAS,ed=Y.POP,td=I.PLAIN,nd=I.SINGLE_QUOTED,id=I.DOUBLE_QUOTED,od=I.LITERAL_BLOCK,ad=I.FOLDED_BLOCK,rd=re.BLOCK,sd=re.FLOW,ld=ce.CLIP,cd=ce.STRIP,ud=ce.KEEP;var Et;function Ce(){let[e,t]=_([]);return Q(()=>{Et=Et||j.list().catch(()=>(Et=void 0,[])),Et.then(t)},[]),e}var fe=e=>e?`${e.type}:${e.id}`:"",ec=e=>{let[t,n]=e.split(":").map(Number);return{type:t,id:n}};function ie(e,t){if(!t)return"\u2014";let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n&&n.name?n.name:`${n?n.type_name:"type "+t.type} / 0x${t.id.toString(16).padStart(2,"0")}`}var rt;function Nt(){let[e,t]=_(new Map);return Q(()=>{rt=rt||N.devices.list().then(n=>new Map(n.map(i=>[fe(i.device),i.features]))).catch(()=>(rt=void 0,new Map)),rt.then(t)},[]),e}var jo=()=>rt=void 0,Yo=[["extension","Extension board (buttons 4\u20137)"],["pir","Motion detector (PIR)"],["nightlight","Night light"],["veml7700","Brightness (VEML7700)"],["bme680","BME680"],["bme280","BME280"],["dht22","DHT22"],["scd30","SCD30 (CO\u2082)"]];function It(e,t,n){let i=e.filter(o=>(t.get(fe({type:o.device_type,id:o.device_id}))||[]).includes(n));return i.length?i:e}var Go=(e,t,n)=>(e.get(fe(t))||[]).includes(n);function Rn(e,t){let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n?n.name||n.key:"0x"+(268435456+(t.type<<16)+(t.id<<8)).toString(16)}function he({value:e,onChange:t,devices:n,types:i}){let o=n.filter(r=>!i||i.includes(r.device_type)),a=fe(e),s=o.some(r=>fe({type:r.device_type,id:r.device_id})===a);return d`<div class="device-select">
    <select value=${s?a:e?"manual":""} onChange=${r=>{let l=r.target.value;l==="manual"?t(e||{type:i&&i[0]||0,id:1}):l&&t(ec(l))}}>
      <option value="" disabled>Choose a device…</option>
      ${o.map(r=>d`<option value=${fe({type:r.device_type,id:r.device_id})}>
          ${ie(n,{type:r.device_type,id:r.device_id})} (${r.type_name})
        </option>`)}
      <option value="manual">Other: type and id…</option>
    </select>
    ${e&&!s&&d`<span class="pair">
      <input type="number" min="0" max="63" title="Device type" value=${e.type} onInput=${r=>t({...e,type:+r.target.value})} />
      <input type="number" min="1" max="255" title="Device id" value=${e.id} onInput=${r=>t({...e,id:+r.target.value})} />
    </span>`}
  </div>`}var Vo=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]],tc=e=>(Vo.find(([t])=>t===e)||[e,e])[1],xt=e=>String(e).padStart(2,"0");function je(e){if(!e)return"";if(e.clock)return`${xt(e.clock.hour)}:${xt(e.clock.minute)}`;let t=e.sun.offset_min||0;return tc(e.sun.event)+(t?` ${t>0?"+":"\u2212"} ${Math.abs(t)} min`:"")}function Ye({value:e,onChange:t}){let n=!!e.sun;return d`<span class="time-edit">
    <select value=${n?"sun":"clock"} onChange=${i=>t(i.target.value==="sun"?{sun:{event:"sunset",offset_min:0}}:{clock:{hour:22,minute:0}})}>
      <option value="clock">Clock</option>
      <option value="sun">Sun</option>
    </select>
    ${n?d`<select value=${e.sun.event} onChange=${i=>t({sun:{...e.sun,event:i.target.value}})}>
            ${Vo.map(([i,o])=>d`<option value=${i}>${o}</option>`)}
          </select>
          <input type="number" class="short" min="-720" max="720" title="Offset in minutes (negative: before)" value=${e.sun.offset_min||0}
            onInput=${i=>t({sun:{...e.sun,offset_min:+i.target.value}})} /><small>min</small>`:d`<input type="time" value=${`${xt(e.clock.hour)}:${xt(e.clock.minute)}`} onInput=${i=>{let[o,a]=i.target.value.split(":").map(Number);isNaN(o)||t({clock:{hour:o,minute:a||0}})}} />`}
  </span>`}var nc=[["dark","Darker than"],["bright","At least as bright as"],["between","Time between"],["sun_below","Sun lower than"],["sun_above","Sun at least"]],ic=(e,t)=>{let n={type:0,id:1};switch(e){case"dark":case"bright":return{[e]:{sensor:n,lux:40}};case"between":return{between:{from:{clock:{hour:22,minute:0}},to:{clock:{hour:6,minute:0}}}};default:return{[e]:{degrees:-6}}}},Qo=e=>Object.keys(e)[0];function Mn(e,t){let n=Qo(e),i=e[n];switch(n){case"dark":return`darker than ${i.lux} lx at ${ie(t,i.sensor)}`;case"bright":return`at least ${i.lux} lx at ${ie(t,i.sensor)}`;case"between":return`between ${je(i.from)} and ${je(i.to)}`;case"sun_below":return`sun below ${i.degrees}\xB0`;case"sun_above":return`sun at least ${i.degrees}\xB0`}return n}var At;function oc(){let[e,t]=_([]);return Q(()=>{At=At||ye.list().then(n=>n.filter(i=>i.kind==="brightness")).catch(()=>(At=void 0,[])),At.then(t)},[]),e}function Dn({value:e,onChange:t,devices:n}){let i=Qo(e),o=e[i],a=oc(),s=n.filter(l=>a.some(u=>u.device_key.toLowerCase()===l.key.toLowerCase())),r=l=>t({[i]:{...o,...l}});return d`<span class="condition">
    <select value=${i} onChange=${l=>t(ic(l.target.value,n))}>
      ${nc.map(([l,u])=>d`<option value=${l}>${u}</option>`)}
    </select>
    ${(i==="dark"||i==="bright")&&d`<input type="number" class="short" min="0" value=${o.lux} onInput=${l=>r({lux:+l.target.value})} /><small>lx at</small>
      <${he} value=${o.sensor.type?o.sensor:null} devices=${s.length?s:n} onChange=${l=>r({sensor:l})} />`}
    ${i==="between"&&d`<${Ye} value=${o.from} onChange=${l=>r({from:l})} /><small>and</small><${Ye} value=${o.to} onChange=${l=>r({to:l})} />`}
    ${(i==="sun_below"||i==="sun_above")&&d`<input type="number" class="short" min="-90" max="90" value=${o.degrees} onInput=${l=>r({degrees:+l.target.value})} /><small>° (−6: civil twilight ends)</small>`}
  </span>`}function me({items:e,onChange:t,max:n,make:i,render:o,addLabel:a}){return d`<div class="list-edit">
    ${e.map((s,r)=>d`<div class="list-row" key=${r}>
        <div class="list-body">${o(s,l=>t(e.map((u,c)=>c===r?l:u)),r)}</div>
        <button class="icon" title="Remove" onClick=${()=>t(e.filter((l,u)=>u!==r))}>×</button>
      </div>`)}
    ${e.length<n&&d`<button onClick=${()=>t([...e,i()])}>+ ${a}</button>`}
  </div>`}var Un=[["light","Light (levels)"],["dimmer","Dimmer (0\u2013255)"],["relay","Relay"],["shutter","Roller shutter"],["group","Group"]],Lt={light:[["toggle","Toggle"],["on","On (last level)"],["at_least","On, at least level",!0],["off","Off"],["set","Level",!0],["max","Brightest"],["inc","Brighter"],["dec","Darker"]],dimmer:[["toggle","Toggle"],["on","On (last value)"],["at_least","On, at least value",!0],["off","Off"],["set","Value",!0],["max","Full"],["inc","Brighter"],["dec","Darker"]],relay:[["toggle","Toggle"],["on","On"],["off","Off"],["on_for","On for (ms)",!0]],shutter:[["up","Up / stop"],["down","Down / stop"],["up_hold","Up (while held)"],["down_hold","Down (while held)"],["stop","Stop"]],group:[["toggle","Toggle"],["on","On"],["off","Off"],["up","Up / stop"],["down","Down / stop"],["stop","Stop"]]},zo=e=>typeof e=="string"?[e,void 0]:[Object.keys(e)[0],Object.values(e)[0]],Wo=(e,t)=>t===void 0?e:{[e]:t};function Xo(e,t){let[n,i]=zo(e),o=(Lt[t]||Object.values(Lt).flat()).find(([s])=>s===n),a=o?o[1].replace(/ \(.*\)$/,""):n;return i===void 0?a:`${a} ${i}`}function Jo({value:e,onChange:t,kind:n}){let i=Lt[n]||Lt.light,[o,a]=zo(e),s=r=>(i.find(([l])=>l===r)||[])[2];return d`<span class="op">
    <select value=${o} onChange=${r=>t(Wo(r.target.value,s(r.target.value)?r.target.value==="on_for"?6e4:1:void 0))}>
      ${i.map(([r,l])=>d`<option value=${r}>${l}</option>`)}
    </select>
    ${s(o)&&d`<input type="number" class="short" min="0" value=${a} onInput=${r=>t(Wo(o,+r.target.value))} />`}
  </span>`}var st=e=>qo(e,{flowLevel:0,lineWidth:-1}).trim(),Bn=e=>e===null||typeof e!="object",ac=e=>(Array.isArray(e)?e:Object.values(e)).every(Bn)&&st(e).length<=60;function Pn(e,t){let n=[],i=Array.isArray(e)?e.map(o=>[null,o]):Object.entries(e);if(!i.length)return[t+st(e)];for(let[o,a]of i){let s=o===null?"- ":`${st(o)}: `;if(Bn(a)||ac(a))n.push(t+s+st(a));else if(o===null){let r=Pn(a,t+"  ");n.push(t+"- "+r[0].slice(t.length+2),...r.slice(1))}else n.push(t+s.trimEnd(),...Pn(a,t+"  "))}return n}var Ot=e=>(Bn(e)?st(e):Pn(e,"").join(`
`))+`
`,Ft=e=>Eo(e);function Ge({title:e,intro:t,children:n,onSave:i,onCancel:o,error:a,value:s,onText:r}){let[l,u]=_(!1),[c,p]=_(null),[f,h]=_(""),m=()=>{try{let g=Ft(c);if(!g||typeof g!="object")throw new Error("not an object");return h(""),g}catch(g){h(g.message);return}},y=()=>{if(c===null)return;let g=m();g!==void 0&&(r(g),p(null))},$=async()=>{let g;if(!(c!==null&&(g=m())===void 0)){u(!0);try{await i(g)}finally{u(!1)}}};return d`<section class="card editor">
    <header><h2>${e}</h2>
      ${s!==void 0&&d`<div class="seg" role="group" aria-label="Edit as">
        <button class=${c===null?"active":""} onClick=${y}>Form</button>
        <button class=${c!==null?"active":""} onClick=${()=>c===null&&p(Ot(s))}>YAML</button>
      </div>`}
    </header>
    ${t&&d`<p class="muted intro">${t}</p>`}
    ${c===null?n:d`<textarea class="code" rows=${Math.min(30,Math.max(8,c.split(`
`).length+1))} spellcheck="false"
          value=${c} onInput=${g=>p(g.target.value)} />
          ${f&&d`<p class="error">${f}</p>`}
          <p class="muted">Back to the form with <em>Form</em>; <em>Save</em> saves the text as it is.</p>`}
    ${a&&d`<p class="error">${a}</p>`}
    <div class="buttons">
      <button class="primary" disabled=${l} onClick=${$}>Save</button>
      <button onClick=${o}>Cancel</button>
    </div>
  </section>`}var Ve=e=>e.field?`${e.field}: ${e.message}`:e.message;var rc=/^[A-Za-z0-9_-]{1,20}$/,Zo=["Mo","Tu","We","Th","Fr","Sa","Su"],ea=e=>(e||[]).filter(t=>["light","dimmer","relay"].includes(t.kind));function ta({value:e,onChange:t,outputs:n}){return d`<select value=${e} onChange=${i=>t(i.target.value)}>
    ${!n.some(i=>i.name===e)&&d`<option value=${e}>${e||"Choose\u2026"}</option>`}
    ${n.map(i=>d`<option value=${i.name}>${i.name}</option>`)}
  </select>`}function sc({title:e,intro:t,oldName:n,initial:i,api:o,done:a,children:s}){let[r,l]=_(n||""),[u,c]=_(i),[p,f]=_(""),h=async m=>{let y=m||u;if(!rc.test(r))return f("Name: 1\u201320 letters, digits, - and _");if(JSON.stringify(y).includes('"sensor":{"type":0,'))return f("Choose the brightness sensor");let $=y.detectors?{...y,detectors:y.detectors.filter(Boolean)}:y;try{await o.put(r,$),n&&n!==r&&await o.remove(n),U(`${r} saved`),a(!0)}catch(g){f(Ve(g))}};return d`<${Ge} title=${n?`${e} ${n}`:`New ${e.toLowerCase()}`} onSave=${h} onCancel=${()=>a(!1)} error=${p}
    value=${u} onText=${c} intro=${t}>
    <div class="row">
      <${C} label="Name" hint="Letters, digits, - and _; also the MQTT topic and the switch in Home Assistant">
        <input value=${r} maxlength="20" onInput=${m=>l(m.target.value.trim())} />
      <//>
    </div>
    ${s(u,c)}
  <//>`}var lc=e=>({detectors:[],output:e[0]?e[0].name:"",timeout_s:180,lockout_s:60,levels:[],conditions:[]}),cc="Motion switches the output on; it goes off again after a while without motion. Switched on by hand (a button, Home Assistant), it stays on until switched off. After it went off, motion is ignored for a moment, so it does not come straight back on for someone leaving.";function uc({value:e,onChange:t}){let n=e.level!==void 0&&e.level!==null;return d`<span class="period">
    <small>From</small><${Ye} value=${e.from} onChange=${i=>t({...e,from:i})} />
    <select aria-label="Level" value=${n?"fixed":"last"} onChange=${i=>t(i.target.value==="fixed"?{from:e.from,level:1}:{from:e.from,min:1})}>
      <option value="fixed">always level</option>
      <option value="last">the last level, at least</option>
    </select>
    <input type="number" class="short" min="1" max="255" aria-label="Level" value=${n?e.level:e.min||0}
      onInput=${i=>t(n?{from:e.from,level:+i.target.value}:{from:e.from,min:+i.target.value})} />
  </span>`}function dc({m:e,set:t,outputs:n,devices:i,features:o}){let a=s=>t({...e,...s});return d`
    <div class="row">
      <${C} label="Switches"><${ta} value=${e.output} outputs=${n} onChange=${s=>a({output:s})} /><//>
      <${C} label="Off after no motion for (min)">
        <input type="number" min="0.1" max="1440" step="0.5" value=${e.timeout_s/60} onInput=${s=>a({timeout_s:Math.max(1,Math.round(+s.target.value*60))})} />
      <//>
      <${C} label="Then ignore motion for (s)" hint="So it doesn't come straight back on for someone leaving">
        <input type="number" min="0" max="3600" value=${e.lockout_s} onInput=${s=>a({lockout_s:+s.target.value})} />
      <//>
    </div>
    <h3>Motion detectors</h3>
    <p class="muted">Switches with a PIR (marked on their device page).</p>
    <${me} items=${e.detectors} max=${4} addLabel="motion detector" onChange=${s=>a({detectors:s})}
      make=${()=>null}
      render=${(s,r)=>d`<${he} value=${s} devices=${It(i,o,"pir")} onChange=${r} />`} />
    <h3>Level by the time of day</h3>
    <p class="muted">Without any: the level it had last. E.g. from 22:00 always level 1; from sunrise the last level, but at least 4.</p>
    <${me} items=${e.levels||[]} max=${4} addLabel="time of day" onChange=${s=>a({levels:s})}
      make=${()=>({from:{clock:{hour:22,minute:0}},level:1})}
      render=${(s,r)=>d`<${uc} value=${s} onChange=${r} />`} />
    <h3>Only switches on if</h3>
    <p class="muted">All of these hold. One that can't be told (no reading, no clock) counts as holding. Switching it on by hand stops the timer until it is switched off.</p>
    <${me} items=${e.conditions||[]} max=${3} addLabel="condition" onChange=${s=>a({conditions:s})}
      make=${()=>({sun_below:{degrees:-6}})}
      render=${(s,r)=>d`<${Dn} value=${s} devices=${i} onChange=${r} />`} />`}var pc="Switches an output on and off in time windows: by the clock, relative to the sun, and off early when it gets bright. Only the start and the end switch, so switching it off by hand in between sticks. Sun times use the location on the Gateway page.",na=()=>({start:{sun:{event:"civil_dusk",offset_min:-30}},end:[{at:{clock:{hour:23,minute:0}}}],days:127});function fc({value:e,onChange:t,devices:n}){let i=!!e.bright;return d`<span class="end">
    <select value=${i?"bright":"at"} onChange=${o=>t(o.target.value==="bright"?{bright:{sensor:{type:0,id:1},lux:200,for_min:5}}:{at:{clock:{hour:8,minute:0}}})}>
      <option value="at">At</option>
      <option value="bright">When bright</option>
    </select>
    ${i?d`<input type="number" class="short" min="0" value=${e.bright.lux} onInput=${o=>t({bright:{...e.bright,lux:+o.target.value}})} /><small>lx for</small>
          <input type="number" class="short" min="0" max="600" value=${e.bright.for_min} onInput=${o=>t({bright:{...e.bright,for_min:+o.target.value}})} /><small>min at</small>
          <${he} value=${e.bright.sensor.type?e.bright.sensor:null} devices=${n} onChange=${o=>t({bright:{...e.bright,sensor:o}})} />`:d`<${Ye} value=${e.at} onChange=${o=>t({at:o})} />`}
  </span>`}function hc({w:e,set:t,devices:n}){let i=o=>t({...e,...o});return d`<div class="window">
    <div class="row">
      <${C} label="On at"><${Ye} value=${e.start} onChange=${o=>i({start:o})} /><//>
      <div class="field"><span>Days</span>
        <div class="days">
          ${Zo.map((o,a)=>d`<label class=${"lamp"+(e.days&1<<a?" on":"")} key=${o}>
              <input type="checkbox" checked=${!!(e.days&1<<a)} onChange=${()=>i({days:e.days^1<<a})} />${o}
            </label>`)}
        </div>
      </div>
    </div>
    <div class="row tight">
      <label class="check"><input type="checkbox" checked=${!!e.only_if} onChange=${o=>{let{only_if:a,...s}=e;t(o.target.checked?{...s,only_if:{sun_below:{degrees:-6}}}:s)}} /> Only if, at the start:</label>
      ${e.only_if&&d`<${Dn} value=${e.only_if} devices=${n} onChange=${o=>i({only_if:o})} />`}
    </div>
    <span class="label">Off at the first of</span>
    <${me} items=${e.end} max=${3} addLabel="end" onChange=${o=>i({end:o})}
      make=${()=>({at:{clock:{hour:8,minute:0}}})}
      render=${(o,a)=>d`<${fc} value=${o} devices=${n} onChange=${a} />`} />
  </div>`}function mc({s:e,set:t,outputs:n,devices:i}){return d`
    <div class="row">
      <${C} label="Switches" hint="On at its last level"><${ta} value=${e.output} outputs=${n} onChange=${o=>t({...e,output:o})} /><//>
    </div>
    <h3>Time windows</h3>
    <p class="muted">Only the start and the end switch: switching it off by hand in between sticks. Nothing switches while the clock isn't set.</p>
    <${me} items=${e.windows} max=${4} addLabel="time window" onChange=${o=>t({...e,windows:o})}
      make=${na}
      render=${(o,a)=>d`<${hc} w=${o} set=${a} devices=${i} />`} />`}function gc(e,t){let n=e.days===127?"":` (${Zo.filter((a,s)=>e.days&1<<s).join(" ")})`,i=e.only_if?` if ${Mn(e.only_if,t)}`:"",o=e.end.map(a=>a.at?je(a.at):`\u2265 ${a.bright.lux} lx`).join(" / ");return`${je(e.start)}${i} \u2192 ${o}${n}`}var $c={idle:["Waiting","muted"],auto:["On by motion","ok"],manual:["On by hand","warn"],lockout:["Locked","muted"],running:["Running","ok"]};function ia({kind:e,title:t,items:n,outputs:i,reload:o,empty:a}){let s=Ce(),r=Nt(),[l,u]=_(null),c=e==="motion"?N.motion:N.schedules,[p,f]=_({}),h=async g=>{let v=g?await E(()=>c.get(g)):e==="motion"?lc(i):{output:i[0]?i[0].name:"",windows:[na()]};v&&u({oldName:g,initial:v})},m=async g=>{await E(()=>c.setEnabled(g.name,!g.enabled),`${g.name} ${g.enabled?"disabled":"enabled"}`),setTimeout(o,300)},y=async g=>{confirm(`Delete ${g}?`)&&await E(()=>c.remove(g),`${g} deleted`)!==void 0&&setTimeout(o,300)},$=async g=>{if(p[g])return f({...p,[g]:void 0});let v=await E(()=>c.get(g));v&&f({...p,[g]:v})};return l?d`<${sc} title=${t} ...${l} api=${c} intro=${e==="motion"?cc:pc}
      done=${g=>{u(null),g&&setTimeout(o,300)}}>
      ${(g,v)=>e==="motion"?d`<${dc} m=${g} set=${v} outputs=${i} devices=${s} features=${r} />`:d`<${mc} s=${g} set=${v} outputs=${i} devices=${s} />`}
    <//>`:d`<${x} title=${t+"s"} aside=${d`<button class="primary" onClick=${()=>h()}>+ New ${t.toLowerCase()}</button>`}>
    ${n?n.length===0?d`<p class="muted">${a}</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>State</th><th>Enabled</th><th></th></tr></thead>
            <tbody>
              ${n.map(g=>{let[v,B]=$c[g.state]||[g.state,"muted"],S=p[g.name];return d`<tr key=${g.name}>
                    <td><a href="#" onClick=${A=>(A.preventDefault(),$(g.name))}><strong>${g.name}</strong></a></td>
                    <td><span class=${"badge "+(g.enabled?B:"muted")}>${v}</span>${g.remaining_s!==void 0?d` <small class="muted">${Math.ceil(g.remaining_s/60)} min</small>`:""}</td>
                    <td><label class="switch"><input type="checkbox" checked=${g.enabled} onChange=${()=>m(g)} /><span></span></label></td>
                    <td class="actions">
                      <button onClick=${()=>h(g.name)}>Edit</button>
                      <button class="danger" onClick=${()=>y(g.name)}>Delete</button>
                    </td>
                  </tr>
                  ${S&&d`<tr class="details"><td colspan="4">
                    ${e==="motion"?`${S.output}${(S.levels||[]).length?" ("+S.levels.map(A=>`from ${je(A.from)} ${A.level?"level "+A.level:"at least "+A.min}`).join(", ")+")":""}; off ${S.timeout_s/60} min after the last motion at ${S.detectors.map(A=>ie(s,A)).join(", ")}; locked ${S.lockout_s} s${(S.conditions||[]).length?"; only if "+S.conditions.map(A=>Mn(A,s)).join(" and "):""}`:d`${S.output}: ${S.windows.map(A=>d`<div>${gc(A,s)}</div>`)}`}
                  </td></tr>`}`})}
            </tbody>
          </table></div>`:d`<${K} />`}
  <//>`}var oa=({motion:e,outputs:t,reload:n})=>d`<${ia} kind="motion" title="Motion light" items=${e} outputs=${ea(t)} reload=${n}
  empty="None yet. A motion light switches an output on by motion and off after a while without it; it can be bound to a button (three times down: off) and switched in Home Assistant." />`,aa=({schedules:e,outputs:t,reload:n})=>d`<${ia} kind="schedule" title="Schedule" items=${e} outputs=${ea(t)} reload=${n}
  empty="None yet. A schedule switches an output in time windows: by the clock, relative to the sun, and off when it gets bright." />`;var vc=[3],_c=8,ra=15,Hn=e=>Object.keys(e)[0],yc=e=>(Un.find(([t])=>t===e)||[e,e])[1],sa={light:()=>({light:{groups:[{device:{type:3,id:1},mask:1}],levels:[[40],[80],[127]],default_level:2}}),dimmer:()=>({dimmer:{lamps:{device:{type:3,id:1},mask:1},default_value:127}}),relay:()=>({relay:{device:{type:5,id:1},channel:0,bank:0}}),shutter:()=>({shutter:{device:{type:5,id:1},channel:0,bank:0,travel_ms:2e4,up:1}}),group:()=>({group:{members:[]}})};function bc(e,t){let n=Hn(e),i=e[n];switch(n){case"light":return`${i.levels.length} levels, ${i.groups.length} lamp group${i.groups.length>1?"s":""} on ${[...new Set(i.groups.map(o=>ie(t,o.device)))].join(", ")}`;case"dimmer":return`${ie(t,i.lamps.device)}, mask 0x${i.lamps.mask.toString(16)}`;case"relay":return`${ie(t,i.device)}, channel ${i.channel}`;case"shutter":return`${ie(t,i.device)}, shutter ${i.channel}, ${i.travel_ms/1e3} s`;case"group":return i.members.join(", ")}return""}function wc(e){let[t,n]=_([]),i=e?`${e.type}:${e.id}`:"",o=()=>e&&N.devices.get(e).then(a=>n(a.lamps||[]),()=>n([]));return Q(()=>{o()},[i]),[t,o]}function ca({value:e,onChange:t,lit:n,onPick:i,names:o=[]}){return d`<div class="lamps named">
    ${Array.from({length:24},(a,s)=>23-s).map(a=>{let s=e>>>a&1,r=()=>i?i(a):t((e^1<<a)>>>0);return d`<label key=${a} title=${o[a]||`Lamp ${a}`} class=${"lamp"+(s?" on":"")+(a===n?" lit":"")}>
        <input type="checkbox" checked=${!!s} onChange=${r} /><b>${a}</b>${o[a]&&d`<small>${o[a]}</small>`}
      </label>`})}
  </div>`}var la=127;function kc({group:e,onChange:t,devices:n,names:i,reloadNames:o}){let[a,s]=_(null),[r,l]=_(""),u=Rn(n,e.device),c=e.bank??0,p=(g,v)=>E(()=>j.lamps(u,c,g,v)),f=async g=>{a!==null&&a!==g&&await p(0,1<<a),await p(la,1<<g),s(g),l(i[g]||"")},h=async()=>{let g=await E(()=>N.devices.get(e.device));if(!g)return;let v=Array.from({length:24},(B,S)=>(g.lamps||[])[S]||"");for(v[a]=r.trim().slice(0,16);v.length&&!v[v.length-1];)v.pop();await E(()=>N.devices.put(e.device,{...g,lamps:v}),`Lamp ${a} named`)!==void 0&&o()},m=async()=>{a!==null&&await p(0,1<<a),s(null)},y=()=>t({...e,mask:(e.mask^1<<a)>>>0}),$=a!==null&&e.mask>>>a&1;return d`<div class="explore">
    <p class="muted">Click a lamp: it lights up in the room (the one before goes off). The controller takes about one change per second. Give it a name while it's lit: the name is kept with the controller and shown everywhere.</p>
    <${ca} value=${e.mask} lit=${a} onPick=${f} names=${i} />
    ${a!==null&&d`<div class="row tight">
      <input aria-label=${`Name of lamp ${a}`} placeholder=${`Name of lamp ${a}, e.g. \u201Cliving white 2\u201D`} maxlength="16" value=${r} onInput=${g=>l(g.target.value)} />
      <button onClick=${h}>Save name</button>
    </div>`}
    <div class="buttons">
      <button class="primary" disabled=${a===null} onClick=${y}>
        ${a===null?"Click a lamp first":$?`Remove lamp ${a} from the group`:`Add lamp ${a} to the group`}
      </button>
      <button disabled=${!e.mask} onClick=${()=>p(la,e.mask)}>Light the whole group</button>
      <button onClick=${m}>Done: switch off</button>
    </div>
  </div>`}function ua({value:e,onChange:t,devices:n}){let[i,o]=_(!1),[a,s]=wc(e.device);return d`<div class="row">
    <${C} label="Lamp controller">
      <${he} value=${e.device} devices=${n} types=${vc} onChange=${r=>t({...e,device:r})} />
    <//>
    <${C} label="Bank" hint="Empty: the controller's only one">
      <input type="number" min="0" max="255" value=${e.bank??""} onInput=${r=>{let{bank:l,...u}=e;t(r.target.value===""?u:{...u,bank:+r.target.value})}} />
    <//>
    <div class="field wide">
      <span>Lamps (mask 0x${e.mask.toString(16).padStart(6,"0")})
        <button class="link" onClick=${()=>o(!i)}>${i?"Close":"Find a lamp\u2026"}</button></span>
      ${i?d`<${kc} group=${e} devices=${n} onChange=${t} names=${a} reloadNames=${s} />`:d`<${ca} value=${e.mask} names=${a} onChange=${r=>t({...e,mask:r})} />`}
    </div>
  </div>`}function Sc(e,t,n,i,o){return Array.from({length:e},(a,s)=>{let r=Math.round(n+(i-n)*Math.pow((s+1)/e,o));return Array(t).fill(Math.max(1,Math.min(255,r)))})}function Cc({value:e,onChange:t,devices:n}){let[i,o]=_(127),a=e.groups,s=c=>{let p=e.levels.map(f=>c.map((h,m)=>m<f.length?f[m]:f[f.length-1]??0));t({...e,groups:c,levels:p})},r=(c,p,f)=>t({...e,levels:e.levels.map((h,m)=>m===c?h.map((y,$)=>$===p?f:y):h)}),l=async c=>{for(let[p,f]of a.entries())await E(()=>j.lamps(Rn(n,f.device),f.bank??0,c?c[p]:0,f.mask))},u=c=>{let p=e.levels.slice(0,c);for(;p.length<c;)p.push([...p[p.length-1]||a.map(()=>0)]);t({...e,levels:p,default_level:Math.min(e.default_level,c)})};return d`
    <h3>Lamp groups</h3>
    <p class="muted">Lamps that always have the same value in every level form a group. A light may span several controllers.</p>
    <${me} items=${a} max=${_c} addLabel="lamp group" onChange=${s}
      make=${()=>({device:a.length?a[a.length-1].device:{type:3,id:1},mask:1})}
      render=${(c,p)=>d`<${ua} value=${c} devices=${n} onChange=${p} />`} />

    <h3>Levels</h3>
    <p class="muted">The value (0–255) of each lamp group per level; level 0 is off. The controllers fade by themselves and take one change per second.</p>
    <div class="row">
      <${C} label="Levels">
        <input type="number" min="1" max=${ra} value=${e.levels.length} onInput=${c=>c.target.value&&u(Math.max(1,Math.min(ra,+c.target.value)))} />
      <//>
      <${C} label="Default level" hint="What “on” switches to the first time">
        <select value=${e.default_level} onChange=${c=>t({...e,default_level:+c.target.value})}>
          ${e.levels.map((c,p)=>d`<option value=${p+1}>${p+1}</option>`)}
        </select>
      <//>
      <${C} label="Ramp up to" hint="Fills every level, all groups alike">
        <input type="number" min="1" max="255" value=${i} onInput=${c=>o(+c.target.value)} />
      <//>
      <button onClick=${()=>t({...e,levels:Sc(e.levels.length,a.length,2,i,3)})}>Fill ramp</button>
    </div>
    <div class="table-wrap"><table class="levels">
      <thead><tr><th>Level</th>${a.map((c,p)=>d`<th>Group ${p+1}</th>`)}<th><button class="link" onClick=${()=>l(null)}>All off</button></th></tr></thead>
      <tbody>
        ${e.levels.map((c,p)=>d`<tr key=${p}>
            <td>${p+1}${p+1===e.default_level&&d` <span class="badge muted">default</span>`}</td>
            ${c.map((f,h)=>d`<td><input type="number" class="short" min="0" max="255" aria-label=${`Level ${p+1}, group ${h+1}`} value=${f} onInput=${m=>r(p,h,+m.target.value)} /></td>`)}
            <td><button onClick=${()=>l(c)} title="Show this level on the lamps">Try</button></td>
          </tr>`)}
      </tbody>
    </table></div>`}var Qe=(e,t,n,i={},o)=>d`<${C} label=${e} hint=${o}>
  <input type="number" value=${t} ...${i} onInput=${a=>n(+a.target.value)} />
<//>`;function Tc({output:e,onChange:t,devices:n,names:i,kinds:o={}}){let a=Hn(e),s=u=>o[u],r=e[a],l=u=>t({[a]:{...r,...u}});switch(a){case"light":return d`<${Cc} value=${r} devices=${n} onChange=${u=>t({light:u})} />`;case"dimmer":return d`<${ua} value=${r.lamps} devices=${n} onChange=${u=>l({lamps:u})} />
        <div class="row">${Qe("Default value",r.default_value,u=>l({default_value:u}),{min:1,max:255},"What \u201Con\u201D switches to the first time")}</div>`;case"relay":return d`<div class="row">
        <${C} label="Relay node"><${he} value=${r.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${Qe("Channel",r.channel,u=>l({channel:u}),{min:0,max:255})}
        ${Qe("Bank",r.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>`;case"shutter":return d`<div class="row">
        <${C} label="Shutter node"><${he} value=${r.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${Qe("Shutter",r.channel,u=>l({channel:u}),{min:0,max:255})}
        ${Qe("Bank",r.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>
      <div class="row">
        ${Qe("Travel time (s)",r.travel_ms/1e3,u=>l({travel_ms:Math.round(u*1e3)}),{min:1,max:600,step:.5},"A full move; sent with up and down")}
        <${C} label="Up is" hint="Depends on the wiring: swap it if up and down are the wrong way round">
          <select value=${r.up} onChange=${u=>l({up:+u.target.value})}>
            <option value="1">Direction 1</option>
            <option value="2">Direction 2</option>
          </select>
        <//>
      </div>`;case"group":return d`<p class="muted">Switched together, e.g. “all lights” for one button that switches everything off. Up to every other output; groups can't contain groups.</p>
        <div class="buttons">
          <button onClick=${()=>l({members:i})}>All</button>
          <button onClick=${()=>l({members:i.filter(u=>s(u)==="light"||s(u)==="dimmer")})}>All lights</button>
          <button onClick=${()=>l({members:[]})}>None</button>
        </div>
        <div class="checks">
          ${i.map(u=>d`<label class="check" key=${u}>
              <input type="checkbox" checked=${r.members.includes(u)} onChange=${c=>l({members:c.target.checked?[...r.members,u]:r.members.filter(p=>p!==u)})} /> ${u}
            </label>`)}
        </div>`}return null}var Ec={light:"A room light in levels: lamp groups on one or more lamp controllers, and the value of each group per level. \u201COn\u201D goes back to the level it had last.",dimmer:"One lamp group switched with a value 0\u2013255, without a level table.",relay:"A relay channel of a relay node: on and off.",shutter:"A roller shutter on a relay node: up, down and stop. Pressing up while it moves up stops it.",group:"Outputs switched together: on, off, toggle, and up/down for the shutters in it."};function Ac({original:e,name:t,outputs:n,devices:i,done:o}){let[a,s]=_(t||""),[r,l]=_(e||sa.light()),[u,c]=_(""),p=Hn(r),f=n.filter(m=>m.kind!=="group"&&m.name!==t).map(m=>m.name),h=async m=>{if(!/^[A-Za-z0-9_-]{1,20}$/.test(a))return c("Name: 1\u201320 letters, digits, - and _");try{await N.outputs.put(a,m||r),t&&t!==a&&await N.outputs.remove(t),U(`${a} saved`),o(!0)}catch(y){c(Ve(y))}};return d`<${Ge} title=${t?`Output ${t}`:"New output"} onSave=${h} onCancel=${()=>o(!1)} error=${u}
    value=${r} onText=${l} intro=${Ec[p]}>
    <div class="row">
      <${C} label="Name" hint=${t&&a!==t?"Renaming: bindings and automations that use the old name stop working":"Letters, digits, - and _"}>
        <input value=${a} maxlength="20" onInput=${m=>s(m.target.value.trim())} />
      <//>
      <${C} label="Kind">
        <select value=${p} disabled=${!!t} onChange=${m=>l(sa[m.target.value]())}>
          ${Un.map(([m,y])=>d`<option value=${m}>${y}</option>`)}
        </select>
      <//>
    </div>
    <${Tc} output=${r} onChange=${l} devices=${i} names=${f}
      kinds=${Object.fromEntries(n.map(m=>[m.name,m.kind]))} />
  <//>`}function da({outputs:e,reload:t}){let n=Ce(),[i,o]=_(null),[a,s]=_({}),[r,l]=_(0),u=(e||[]).map(f=>f.name).join(",");Q(()=>{let f=!1;return(async()=>{let h={};for(let m of u?u.split(","):[]){try{h[m]=await N.outputs.get(m)}catch{}if(f)return}s(h)})(),()=>f=!0},[u,r]);let c=async f=>{let h=f?await E(()=>N.outputs.get(f)):void 0;f&&!h||o({name:f,original:h})},p=async f=>{confirm(`Delete the output ${f}? Bindings and automations that use it stop working.`)&&await E(()=>N.outputs.remove(f),`${f} deleted`)!==void 0&&t()};return i?d`<${Ac} ...${i} outputs=${e||[]} devices=${n}
      done=${f=>{o(null),f&&(l(h=>h+1),setTimeout(t,300))}} />`:d`<${x} title="Outputs" aside=${d`<button class="primary" onClick=${()=>c()}>+ New output</button>`}>
    ${e?e.length===0?d`<p class="muted">Nothing yet. An output is what the automation switches: a room light with its levels, a dimmer, a relay, a roller shutter, or a group of them (“all lights”).</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Kind</th><th>What</th><th></th></tr></thead>
            <tbody>
              ${e.map(f=>d`<tr key=${f.name}>
                  <td><strong>${f.name}</strong></td>
                  <td>${yc(f.kind)}</td>
                  <td class="muted-cell">${a[f.name]?bc(a[f.name],n):""}</td>
                  <td class="actions">
                    <button onClick=${()=>c(f.name)}>Edit</button>
                    <button class="danger" onClick=${()=>p(f.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${K} />`}
  <//>`}var Pt=[["single","Once","Pressed once"],["double","Twice","Pressed twice"],["triple","3 times","Pressed three times"],["hold","Held","Held: repeats every 0.5 s"],["released","Let go","Let go after holding"]],Rt=e=>(Pt.find(([t])=>t===e)||[e,e,e])[2],ze=8,xc=4,pa=8,Lc=/^[A-Za-z0-9_-]{1,20}$/,fa=[4],qn=()=>Array.from({length:ze},()=>({})),Nc=e=>Object.fromEntries((e||[]).map(t=>[t.event,t.actions])),Kn=e=>({events:Pt.map(([t])=>t).filter(t=>(e[t]||[]).length).map(t=>({event:t,actions:e[t]}))});function Wn(e){let t={};return e.buttons.forEach((n,i)=>{let o=Object.fromEntries(Object.entries(n).filter(([,a])=>a&&a.length));Object.keys(o).length&&(t[i]=o)}),{switches:e.switches,buttons:t}}function Mt(e){let t=qn();for(let[n,i]of Object.entries(e.buttons||{}))+n>=0&&+n<ze&&(t[+n]={...i});return{switches:e.switches||[],buttons:t}}async function jn(e,t){let n=await N.switches.get(e),i=qn();for(let o=0;o<ze;o++)t&1<<o&&(i[o]=Nc((await N.switches.button(e,o)).events));return{switches:n.switches,buttons:i}}async function Yn(e,t,n){await N.switches.put(e,{switches:t.switches});for(let i=0;i<ze;i++){let o=JSON.stringify(Kn(t.buttons[i])),a=n?JSON.stringify(Kn(n.buttons[i])):'{"events":[]}';o!==a&&await N.switches.putButton(e,i,Kn(t.buttons[i]))}}function Ic(e,t,n){return e.output?`${e.output.name}: ${Xo(e.output.op,n[e.output.name]).toLowerCase()}`:e.automation?`${e.automation.name}: ${e.automation.switch}`:e.nightlight?`night light ${ie(t,e.nightlight.device)}: ${e.nightlight.value}`:"?"}function Oc({value:e,onChange:t,devices:n,features:i,outputs:o,automations:a}){let s=Object.keys(e)[0],r=e[s],l=Object.fromEntries(o.map(c=>[c.name,c.kind])),u=c=>{c==="output"&&t({output:{name:o[0]?o[0].name:"",op:"toggle"}}),c==="automation"&&t({automation:{name:a[0]||"",switch:"toggle"}}),c==="nightlight"&&t({nightlight:{device:{type:4,id:1},value:0}})};return d`<span class="action">
    <select value=${s} onChange=${c=>u(c.target.value)} aria-label="Kind of action">
      <option value="output">Output</option>
      <option value="automation">Motion light / schedule</option>
      <option value="nightlight">Night light</option>
    </select>
    ${s==="output"&&d`<select value=${r.name} aria-label="Output" onChange=${c=>t({output:{name:c.target.value,op:"toggle"}})}>
        ${!o.some(c=>c.name===r.name)&&d`<option value=${r.name}>${r.name||"Choose\u2026"}</option>`}
        ${o.map(c=>d`<option value=${c.name}>${c.name}</option>`)}
      </select>
      <${Jo} value=${r.op} kind=${l[r.name]} onChange=${c=>t({output:{...r,op:c}})} />`}
    ${s==="automation"&&d`<select value=${r.name} aria-label="Motion light or schedule" onChange=${c=>t({automation:{...r,name:c.target.value}})}>
        ${!a.includes(r.name)&&d`<option value=${r.name}>${r.name||"Choose\u2026"}</option>`}
        ${a.map(c=>d`<option value=${c}>${c}</option>`)}
      </select>
      <select value=${r.switch} aria-label="Switch it" onChange=${c=>t({automation:{...r,switch:c.target.value}})}>
        <option value="toggle">Toggle</option>
        <option value="enable">Enable</option>
        <option value="disable">Disable</option>
      </select>`}
    ${s==="nightlight"&&d`<${he} value=${r.device} devices=${It(n,i,"nightlight")} types=${fa}
        onChange=${c=>t({nightlight:{...r,device:c}})} />
      <input type="number" class="short" min="0" max="255" aria-label="Brightness 0–255" value=${r.value}
        onInput=${c=>t({nightlight:{...r,value:+c.target.value}})} />`}
  </span>`}function ha({onLearn:e,label:t="Learn: press a button"}){let[n,i]=_(!1),o=de(!1);return Q(()=>()=>o.current=!0,[]),n?d`<button class="learning" onClick=${()=>o.current=!0}>Press the button on the wall now… (cancel)</button>`:d`<button onClick=${async()=>{i(!0),o.current=!1;let s=Date.now();for(;!o.current&&Date.now()<s+3e4;){try{let r=await N.status();if(r.last_button&&r.last_button.age_s+1<=(Date.now()-s)/1e3){e(r.last_button.trigger);break}}catch{}await new Promise(r=>setTimeout(r,700))}i(!1)}}>${t}</button>`}function Fc(e,t){let n=i=>[{output:{name:t,op:i}}];return e==="shutter"?[{single:n("up"),hold:n("up_hold"),released:n("stop")},{single:n("down"),hold:n("down_hold"),released:n("stop")}]:e==="relay"||e==="group"?[{single:n("on")},{single:n("off")}]:[{single:n("on"),double:n("max"),hold:n("inc")},{single:n("off"),hold:n("dec")}]}function Pc({outputs:e,onApply:t,buttons:n}){let[i,o]=_(0),[a,s]=_(e[0]?e[0].name:""),r=(e.find(l=>l.name===a)||{}).kind;return d`<div class="template">
    <span class="label">Quick fill:</span>
    <select value=${i} aria-label="Buttons" onChange=${l=>o(+l.target.value)}>
      ${Array.from({length:n/2},(l,u)=>d`<option value=${u}>buttons ${2*u} (up) and ${2*u+1} (down)</option>`)}
    </select>
    <span class="label">as a rocker for</span>
    <select value=${a} aria-label="Output" onChange=${l=>s(l.target.value)}>
      ${e.map(l=>d`<option value=${l.name}>${l.name}</option>`)}
    </select>
    <button disabled=${!a} onClick=${()=>t(2*i,Fc(r,a))}>Fill</button>
    <small class="muted">${r==="shutter"?"Up/down, held: moves, let go: stops":r==="light"||r==="dimmer"?"Up: on, twice: brightest, held: brighter; down: off, held: darker":"Up: on, down: off"}</small>
  </div>`}function Rc({name:e,original:t,devices:n,features:i,outputs:o,automations:a,done:s,learned:r}){let[l,u]=_(e||""),[c,p]=_(t||{switches:r?[r.device]:[],buttons:qn()}),[f,h]=_(r?[r.button,r.event]:[0,"single"]),[m,y]=_(""),$=Object.fromEntries(o.map(k=>[k.name,k.kind])),g=c.switches.some(k=>Go(i,k,"extension"))||c.buttons.slice(4).some(k=>Object.keys(k).length),[v,B]=_(!1),S=g||v||f[0]>=4?ze:4,[A,R]=f,w=c.buttons[A][R]||[],T=k=>p({...c,buttons:c.buttons.map((F,q)=>q===A?{...F,[R]:k}:F)}),b=k=>{!c.switches.some(q=>fe(q)===fe(k.device))&&c.switches.length<pa&&p(q=>({...q,switches:[...q.switches,k.device]})),h([k.button,k.event]),U(`Button ${k.button}, ${Rt(k.event).toLowerCase()}`)},P=async k=>{let F=k?Mt(k):c;if(!Lc.test(l))return y("Name: 1\u201320 letters, digits, - and _");if(!F.switches.length)return y("Add at least one switch, or learn it");try{let q=e&&e!==l;await Yn(l,F,q?void 0:t),q&&await N.switches.remove(e),U(`${l} saved`),s(!0)}catch(q){y(Ve(q))}};return d`<${Ge} title=${e?`Switch ${e}`:"New switch configuration"} onSave=${P} onCancel=${()=>s(!1)} error=${m}
    value=${Wn(c)} onText=${k=>p(Mt(k))}
    intro="What each button does. Several switches can share one configuration (both bedroom switches): they all do the same.">
    <div class="row">
      <${C} label="Name" hint="Letters, digits, - and _">
        <input value=${l} maxlength="20" onInput=${k=>u(k.target.value.trim())} />
      <//>
      <div class="field grow"><span>Switches</span>
        <${me} items=${c.switches} max=${pa} addLabel="switch" onChange=${k=>p({...c,switches:k})}
          make=${()=>null}
          render=${(k,F)=>d`<${he} value=${k} devices=${n} types=${fa} onChange=${F} />`} />
      </div>
    </div>
    <div class="row tight">
      <${ha} onLearn=${b} label="Learn: press a button on the wall" />
      <small class="muted">Adds the switch and picks the button and kind of press.</small>
    </div>

    <h3>Buttons</h3>
    <div class="table-wrap"><table class="grid">
      <thead><tr><th>Button</th>${Pt.map(([k,F,q])=>d`<th title=${q}>${F}</th>`)}</tr></thead>
      <tbody>
        ${Array.from({length:S},(k,F)=>d`<tr key=${F}>
          <th scope="row">${F}${F>=4?d` <small class="muted">ext.</small>`:""}</th>
          ${Pt.map(([q])=>{let Te=c.buttons[F][q]||[],ti=A===F&&R===q;return d`<td key=${q}><button class=${"cell"+(ti?" active":"")+(Te.length?" used":"")}
              aria-pressed=${ti} onClick=${()=>h([F,q])}>
              ${Te.length?Te.map(Fa=>Ic(Fa,n,$)).join(", "):"\u2014"}
            </button></td>`})}
        </tr>`)}
      </tbody>
    </table></div>
    ${!g&&S===4&&d`<button class="link" onClick=${()=>B(!0)}>Show buttons 4–7 (extension board)</button>`}

    <div class="cell-edit">
      <h3>Button ${A}, ${Rt(R).toLowerCase()}</h3>
      <${me} items=${w} max=${xc} addLabel="action" onChange=${T}
        make=${()=>({output:{name:o[0]?o[0].name:"",op:"toggle"}})}
        render=${(k,F)=>d`<${Oc} value=${k} onChange=${F} devices=${n} features=${i} outputs=${o} automations=${a} />`} />
      ${w.length===0&&d`<p class="muted">Does nothing. Add an action, or fill a rocker below.</p>`}
    </div>
    ${o.length>0&&d`<${Pc} outputs=${o} buttons=${S}
      onApply=${(k,F)=>{p({...c,buttons:c.buttons.map((q,Te)=>Te===k||Te===k+1?{...q,...F[Te-k]}:q)}),h([k,"single"])}} />`}
  <//>`}function ma({outputs:e,motion:t,schedules:n}){let i=Ce(),o=Nt(),[a,s]=_(),[r,l]=_(),[u,c]=_(null),p=async()=>{try{s(await N.switches.list())}catch($){l($)}};Q(()=>{p()},[]);let f=[...t||[],...n||[]].map($=>$.name),h=async $=>{let g=await E(()=>jn($.name,$.buttons));g&&c({name:$.name,original:g})},m=$=>{let g=(a||[]).find(v=>v.switches.some(B=>fe(B)===fe($.device)));g?h(g):c({learned:$})},y=async $=>{confirm(`Delete the switch configuration ${$}? Its buttons stop doing anything.`)&&await E(()=>N.switches.remove($),`${$} deleted`)!==void 0&&p()};return u?d`<${Rc} ...${u} devices=${i} features=${o} outputs=${e||[]} automations=${f}
      done=${$=>{c(null),$&&p()}} />`:d`<${x} title="Switches" aside=${d`<div class="buttons">
      <${ha} onLearn=${m} label="Which switch is this?" />
      <button class="primary" onClick=${()=>c({})}>+ New</button>
    </div>`}>
    <p class="muted">A configuration says what each button of a switch does when pressed once, twice, three times, held or let go. Switches that do the same share one.</p>
    ${a?a.length===0?d`<p>No switch does anything yet. Press <em>Which switch is this?</em> and a button on the wall to start with that switch.</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Switches</th><th>Buttons</th><th></th></tr></thead>
            <tbody>
              ${a.map($=>d`<tr key=${$.name}>
                  <td><strong>${$.name}</strong></td>
                  <td class="wrap">${$.switches.map(g=>ie(i,g)).join(", ")}</td>
                  <td><span class="chips">${Array.from({length:ze},(g,v)=>v).filter(g=>$.buttons&1<<g).map(g=>d`<span class="chip">${g}</span>`)}</span></td>
                  <td class="actions">
                    <button onClick=${()=>h($)}>Edit</button>
                    <button class="danger" onClick=${()=>y($.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${K} error=${r} />`}
  <//>`}var Mc=[["","Overview"],["switches","Switches"],["outputs","Outputs"],["motion","Motion lights"],["schedules","Schedules"],["backup","Backup"]];async function Dc(){let e=await N.status(),t=await N.outputs.list(),n=await N.motion.list(),i=await N.schedules.list();return{status:e,outputs:t,motion:n,schedules:i}}function Vn({tab:e=""}){let{data:t,error:n,reload:i}=X(Dc,e===""?2500:0),o=t||{};return d`
    <nav class="tabs">
      ${Mc.map(([a,s])=>d`<${J} href=${"/automation"+(a?"/"+a:"")} class=${a===e?"active":""}>${s}<//>`)}
    </nav>
    ${!t&&d`<${K} error=${n} />`}
    ${t&&e===""&&d`<${Hc} ...${o} reload=${i} />`}
    ${t&&e==="switches"&&d`<${ma} outputs=${o.outputs} motion=${o.motion} schedules=${o.schedules} />`}
    ${t&&e==="outputs"&&d`<${da} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="motion"&&d`<${oa} motion=${o.motion} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="schedules"&&d`<${aa} schedules=${o.schedules} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="backup"&&d`<${qc} ...${o} reload=${i} />`}
    ${n&&t&&d`<p class="error">${n.message}</p>`}`}function _a(e,t){let[n,i]=_(null),o=async(a,s)=>{i(s),await E(()=>N.outputs.command(e.name,a)),setTimeout(async()=>{await t(),i(null)},600)};return[n===null?e.level:n,o]}function Uc({o:e,reload:t}){let[n,i]=_a(e,t),o=e.kind==="light"?e.top:255,a=e.kind==="light"?1:25,s=r=>i({set:r},Math.max(0,Math.min(o,r)));return d`<div class="stepper">
      <button aria-label="Darker" disabled=${n<=0} onClick=${()=>i("dec",Math.max(0,n-a))}>−</button>
      ${e.kind==="light"?d`<select aria-label="Level" value=${n} onChange=${r=>s(+r.target.value)}>
            ${Array.from({length:o+1},(r,l)=>d`<option value=${l}>${l===0?"off":`level ${l}`}</option>`)}
          </select>`:d`<input type="number" aria-label="Value 0–255" min="0" max="255" value=${n} onChange=${r=>s(+r.target.value)} />`}
      <button aria-label="Brighter" disabled=${n>=o} onClick=${()=>i("inc",Math.min(o,n+a))}>+</button>
    </div>
    <div class="buttons fixed"><button onClick=${()=>i("on",n||1)}>On</button><button onClick=${()=>i("off",0)}>Off</button></div>`}function ga({o:e,reload:t}){let[,n]=_a(e,t),i,o;switch(e.kind){case"light":case"dimmer":i=e.level>0?e.kind==="light"?`level ${e.level} of ${e.top}`:`${Math.round(e.level/255*100)} %`:"off",o=d`<${Uc} o=${e} reload=${t} />`;break;case"relay":i=e.level>0?"on":"off",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",1)}>On</button><button onClick=${()=>n("off",0)}>Off</button></div>`;break;case"shutter":i={up:"moving up",down:"moving down",stopped:"stopped"}[e.movement],o=d`<div class="buttons fixed">
        <button aria-label="Up" onClick=${()=>n("up",e.level)}>▲</button>
        <button aria-label="Stop" onClick=${()=>n("stop",e.level)}>■</button>
        <button aria-label="Down" onClick=${()=>n("down",e.level)}>▼</button>
      </div>`;break;default:i="group",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",0)}>All on</button><button onClick=${()=>n("off",0)}>All off</button></div>`}let a=e.level>0||e.kind==="shutter"&&e.movement!=="stopped";return d`<div class=${"tile"+(a?" lit":"")}>
    <div class="tile-head"><strong>${e.name}</strong></div>
    <div class="tile-state">${i}</div>
    ${o}
  </div>`}var Bc={idle:"waiting",auto:"on by motion",manual:"on by hand",lockout:"locked",running:"in a time window"};function Hc({status:e,outputs:t,motion:n,schedules:i,reload:o}){let a=Ce(),s=async f=>{await E(()=>N.setEnabled(f),f?"Automation on":"Automation off"),o()},r=(f,h)=>async()=>{await E(()=>f.setEnabled(h.name,!h.enabled),`${h.name} ${h.enabled?"disabled":"enabled"}`),setTimeout(o,400)},l=e.last_button,u=!t.length&&!n.length&&!i.length,c=t.filter(f=>f.kind==="group"),p=t.filter(f=>f.kind!=="group");return d`
    <${x} title="Automation" aside=${d`<label class="switch big" title="The master switch">
      <input type="checkbox" checked=${e.enabled} onChange=${f=>s(f.target.checked)} /><span></span>
      ${e.enabled?"On":"Off"}
    </label>`}>
      <p class="muted">
        Switches, motion lights and schedules run on the gateway itself: they keep working without the network, MQTT or Home Assistant.
        This page is for testing and watching them.
        ${!e.enabled&&d` <strong>Switched off:</strong> nothing switches by itself; outputs can still be switched here.`}
      </p>
      <dl class="facts">
        <div><dt>Switch configurations</dt><dd><${J} href="/automation/switches">${e.switches}<//></dd></div>
        <div><dt>Outputs</dt><dd><${J} href="/automation/outputs">${e.outputs}<//></dd></div>
        <div><dt>Motion lights</dt><dd><${J} href="/automation/motion">${e.motion}<//></dd></div>
        <div><dt>Schedules</dt><dd><${J} href="/automation/schedules">${e.schedules}<//></dd></div>
        <div><dt>Last button pressed</dt>
        <dd>${l?`${ie(a,l.trigger.device)}, button ${l.trigger.button}, ${Rt(l.trigger.event).toLowerCase()} (${l.age_s} s ago)`:"\u2014"}</dd></div>
      </dl>
      ${u&&d`<ol class="steps">
        <li>Create the <${J} href="/automation/outputs">outputs<//>: the lights, relays and shutters the automation switches.</li>
        <li>Tell the <${J} href="/automation/switches">switches<//> what their buttons do.</li>
        <li>Add <${J} href="/automation/motion">motion lights<//> and <${J} href="/automation/schedules">schedules<//>.</li>
        <li>Or restore a <${J} href="/automation/backup">backup<//>.</li>
      </ol>`}
    <//>
    ${c.length>0&&d`<${x} title="Groups">
      <div class="tiles">${c.map(f=>d`<${ga} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${p.length>0&&d`<${x} title="Outputs">
      <div class="tiles">${p.map(f=>d`<${ga} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${n.length+i.length>0&&d`<${x} title="Motion lights and schedules">
      <div class="tiles">
        ${[...n.map(f=>[f,N.motion]),...i.map(f=>[f,N.schedules])].map(([f,h])=>d`<div class=${"tile"+(f.enabled&&f.state!=="idle"?" lit":"")} key=${f.name}>
            <div class="tile-head"><strong>${f.name}</strong></div>
            <div class="tile-state">${f.enabled?Bc[f.state]:"disabled"}${f.enabled&&f.remaining_s!==void 0?` \xB7 ${f.remaining_s} s`:""}</div>
            <label class="switch"><input type="checkbox" checked=${f.enabled} onChange=${r(h,f)} /><span></span>${f.enabled?"Enabled":"Disabled"}</label>
          </div>`)}
      </div>
    <//>`}`}var ya="gateway-automation",Gn=2,Kc=e=>new Promise(t=>setTimeout(t,e));async function $a(e,t,n,i){let o={format:ya,version:Gn,enabled:e.enabled,outputs:[],switches:[],motion:[],schedules:[],devices:[]};for(let a of t)o.outputs.push({name:a.name,output:await N.outputs.get(a.name)});for(let a of await N.switches.list())o.switches.push({name:a.name,...Wn(await jn(a.name,a.buttons))});for(let a of n)o.motion.push({name:a.name,enabled:a.enabled,config:await N.motion.get(a.name)});for(let a of i)o.schedules.push({name:a.name,enabled:a.enabled,config:await N.schedules.get(a.name)});for(let a of await N.devices.list())o.devices.push({device:a.device,...await N.devices.get(a.device)});return o}function va(e,t,n){let i=document.createElement("a");i.href=URL.createObjectURL(new Blob([e],{type:n})),i.download=t,i.click(),URL.revokeObjectURL(i.href)}function qc({status:e,outputs:t,motion:n,schedules:i,reload:o}){let[a,s]=_([]),[r,l]=_(!1),[u,c]=_(!1),[p,f]=_(null),h=S=>s(A=>[...A,S]),m=async S=>{l(!0),s([]);try{let A=await $a(e,t,n,i),R=new Date().toISOString().slice(0,10);S?va(Ot(A),`automation-${R}.yaml`,"application/yaml"):va(JSON.stringify(A,null,2),`automation-${R}.json`,"application/json"),h(`Exported ${A.outputs.length} outputs, ${A.switches.length} switch configurations, ${A.motion.length} motion lights, ${A.schedules.length} schedules.`)}catch(A){h(`Failed: ${A.message}`)}l(!1)},y=async()=>{l(!0);try{f(Ot(await $a(e,t,n,i)))}catch(S){U(S.message,"error")}l(!1)},$=async(S,A)=>{try{await A(),h(`\u2713 ${S}`)}catch(R){h(`\u2717 ${S}: ${R.field?R.field+": ":""}${R.message}`)}},g=async S=>{if(!S||S.format!==ya)return U("Not an automation backup","error");if(S.version!==Gn)return U(`Version ${S.version} isn't supported (this page writes ${Gn})`,"error");if(u&&!confirm("Delete every output, switch configuration, motion light and schedule on the gateway first?"))return;if(l(!0),s([]),u){for(let b of await N.switches.list())await $(`delete switch ${b.name}`,()=>N.switches.remove(b.name));for(let b of n)await $(`delete ${b.name}`,()=>N.motion.remove(b.name));for(let b of i)await $(`delete ${b.name}`,()=>N.schedules.remove(b.name));let T=[...t].sort((b,P)=>(P.kind==="group")-(b.kind==="group"));for(let b of T)await $(`delete ${b.name}`,()=>N.outputs.remove(b.name))}let A=T=>Object.keys(T.output)[0]==="group",R=S.outputs||[];for(let T of[...R.filter(b=>!A(b)),...R.filter(A)])await $(`output ${T.name}`,()=>N.outputs.put(T.name,T.output));for(let T of S.motion||[])await $(`motion light ${T.name}`,()=>N.motion.put(T.name,T.config));for(let T of S.schedules||[])await $(`schedule ${T.name}`,()=>N.schedules.put(T.name,T.config));for(let T of S.switches||[])await $(`switch ${T.name}`,()=>Yn(T.name,Mt(T)));for(let T of S.devices||[])await $(`device notes ${ie([],T.device)}`,()=>N.devices.put(T.device,{features:T.features||[],lamps:T.lamps||[]}));let w=[...(S.motion||[]).map(T=>[T,N.motion]),...(S.schedules||[]).map(T=>[T,N.schedules])].filter(([T])=>T.enabled===!1);w.length&&await Kc(1e3);for(let[T,b]of w)await $(`disable ${T.name}`,()=>b.setEnabled(T.name,!1));typeof S.enabled=="boolean"&&S.enabled!==e.enabled&&await $(`master switch ${S.enabled?"on":"off"}`,()=>N.setEnabled(S.enabled)),h("Done."),l(!1),o()},v=async S=>{let A=S.target.files[0];if(S.target.value="",!!A)try{await g(Ft(await A.text()))}catch(R){U(`${A.name}: ${R.message}`,"error")}},B=async()=>{let S;try{S=Ft(p)}catch(A){return U(A.message,"error")}await g(S),f(null)};return d`<${x} title="Backup">
    <p class="muted">The whole configuration as one file (YAML or JSON): to keep, to edit, to write by hand, or to move to another gateway. Devices are stored by type and id.</p>
    <div class="buttons">
      <button class="primary" disabled=${r} onClick=${()=>m(!0)}>Export YAML</button>
      <button disabled=${r} onClick=${()=>m(!1)}>Export JSON</button>
      <label class=${"button"+(r?" disabled":"")}>Import…<input type="file" accept=".json,.yaml,.yml,application/json,application/yaml" hidden disabled=${r} onChange=${v} /></label>
      <button disabled=${r||p!==null} onClick=${y}>Edit everything as YAML</button>
      <label class="check"><input type="checkbox" checked=${u} onChange=${S=>c(S.target.checked)} /> Delete everything first</label>
    </div>
    ${p!==null&&d`<div class="text-all">
      <textarea class="code" rows="28" spellcheck="false" value=${p} onInput=${S=>f(S.target.value)} />
      <div class="buttons">
        <button class="primary" disabled=${r} onClick=${B}>Apply</button>
        <button onClick=${()=>f(null)}>Cancel</button>
        <small class="muted">Applying stores every item as written; with “Delete everything first”, what isn't in the text is removed.</small>
      </div>
    </div>`}
    ${a.length>0&&d`<pre class="log">${a.join(`
`)}</pre>`}
  <//>`}function Dt({target:e,label:t,others:n=[],onDone:i}){let[o,a]=_(null),[s,r]=_(null),[l,u]=_(""),[c,p]=_(null),f=de(null);Q(()=>()=>clearInterval(f.current),[]);let h=()=>{clearInterval(f.current),f.current=setInterval(async()=>{try{p(await an.job())}catch{}},1500)},m=async(v,B)=>{u(v),r(0),B!=="gateway"&&h();try{let S=await o.arrayBuffer();return await an.upload(B,S,r)||{}}finally{clearInterval(f.current),r(null)}},y=async v=>{if(!o)return;let B=0;for(let{name:S,target:A}of v)try{let R=await m(S,A);B+=1,R.restarting&&U("Firmware installed, the gateway restarts\u2026")}catch(R){U(`${S}: ${R.message}`,"error");break}B===v.length&&v[0].target!=="gateway"&&U(B===1?"Firmware sent; the device restarts into it":`Firmware sent to ${B} devices`),u(""),p(null),i&&i()},$=s!==null,g=c&&c.state==="running"?`${c.sent} of ${c.total} bytes acknowledged${c.protocol?` (${c.protocol})`:""}${c.retries?`, ${c.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${v=>a(v.target.files[0]||null)} />
      <${O} onClick=${()=>y([{name:t||"device",target:e}])} disabled=${!o||$}>${t||"Upload"}<//>
      ${n.length>0&&d`<${O} onClick=${()=>y([{name:"this device",target:e},...n])} disabled=${!o||$}>Send to all ${n.length+1} of this type<//>`}
      ${$&&d`<progress max="1" value=${s}></progress>`}
      ${$&&d`<p class="muted wide">${l}${g?" \u2014 "+g:""}</p>`}
    </div>`}var Wc={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},ba={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},Qn=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],jc={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},Xe=e=>jc[e]||e;function Ut(e,t=5e3){let n=X(()=>ye.list(e),t),i=[...new Set((n.data||[]).map(a=>a.device))];return{...n,ask:async()=>{for(let a of e?[e]:i)await E(()=>ye.refresh(a));setTimeout(n.reload,1500)}}}function Yc({s:e,device:t,reload:n}){let[i,o]=_(!1),[a,s]=_(e.name||""),[r,l]=_(e.role||"none"),u=async()=>{let c={};if(a!==(e.name||"")&&(c.name=a),r!==(e.role||"none")&&(c.role=r),Object.keys(c).length===0)return o(!1);await E(()=>ye.update(e.device,e.slot,c),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${J} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${i?d`<input class="inline" maxlength="7" placeholder="name" value=${a} onInput=${c=>s(c.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${Wc[e.kind]||e.kind}</td>
    <td>${i?d`<select value=${r} onChange=${c=>l(c.target.value)}>${Qn.map(c=>d`<option value=${c}>${Xe(c)}</option>`)}</select>`:e.role&&e.role!=="none"?Xe(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind in ba?e.value.toFixed(ba[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:xe(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":i?d`<${O} kind="primary" onClick=${u}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function zn({device:e}){let{data:t,error:n,reload:i,ask:o}=Ut(e);if(!t)return d`<${K} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let a=t.some(s=>s.named_by_node&&s.slot===null);return d`
    ${a&&d`<p class="muted">The names and roles of some sensors are not known yet. <${O} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(s=>d`<${Yc} key=${s.device_key+s.kind+s.sensor_id} s=${s} device=${e} reload=${i} />`)}
      </tbody>
    </table></div>`}function wa(){let{ask:e}=Ut(void 0,0);return d`<${x} title="Sensors" aside=${d`<${O} onClick=${e}>Reload names and roles<//>`}>
    <${zn} />
  <//>`}var Gc=[2,5,8,9],Vc=[7],Qc=[3],zc=3,Xn=[9],Xc=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],Jc=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ca({device:e}){let{data:t,error:n,reload:i}=X(()=>j.get(e),5e3);return t?d`
    <${tu} d=${t} reload=${i} />
    ${Gc.includes(t.device_type)&&d`<${ka} d=${t} kind="relay" />`}
    ${Vc.includes(t.device_type)&&d`<${ka} d=${t} kind="rollershutter" />`}
    ${Qc.includes(t.device_type)&&d`<${Sa} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===zc&&d`<${Sa} d=${t} firstBank=${1} />`}
    ${Xn.includes(t.device_type)&&d`<${nu} d=${t} />`}
    ${Xn.includes(t.device_type)&&d`<${ou} d=${t} />`}
    ${Xn.includes(t.device_type)&&d`<${au} d=${t} />`}
    <${x} title="Sensors"><${zn} device=${t.name||t.key} /><//>
    <${Zc} d=${t} />
    <${ru} d=${t} reload=${i} />
    <${eu} d=${t} />`:d`<${K} error=${n} />`}function Zc({d:e}){let t={type:e.device_type,id:e.device_id},{data:n,error:i,reload:o}=X(()=>N.devices.get(t)),[a,s]=_(!1);if(!n)return d`<${x} title="On board"><${K} error=${i} /><//>`;let r=async l=>{let u=n.features.includes(l)?n.features.filter(c=>c!==l):[...n.features,l];s(!0),await E(()=>N.devices.put(t,{...n,features:u}),"Saved")!==void 0&&(jo(),await o()),s(!1)};return d`<${x} title="On board">
    <p class="muted">What this device has, for the automation: it offers motion detectors, brightness sensors and night lights only where they are.</p>
    <div class="checks">
      ${Yo.map(([l,u])=>d`<label class="check" key=${l}>
          <input type="checkbox" disabled=${a} checked=${n.features.includes(l)} onChange=${()=>r(l)} /> ${u}
        </label>`)}
    </div>
  <//>`}function eu({d:e}){let t=e.name||e.key,{data:n}=X(j.list),i=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${x} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${Dt} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${i} />
    <//>`}function tu({d:e,reload:t}){let n=e.name||e.key,i=(o,a)=>async()=>{await E(()=>j.action(n,o),a),setTimeout(t,1500)};return d`
    <${x} title=${n}
      aside=${d`<span class="buttons">
        <${O} onClick=${i("ping","Ping sent")}>Ping<//>
        <${O} onClick=${i("refresh","Refresh requested")}>Refresh<//>
        <${O} kind="danger" onClick=${i("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${xe(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function ka({d:e,kind:t}){let n=e.name||e.key,[i,o]=_(1),[a,s]=_(0),r=t==="rollershutter",l=u=>()=>E(()=>j[t](n,i,u,Math.round(a*1e3)),`${r?"Rollershutter":"Relay"} ${i}: ${u}`);return d`
    <${x} title=${r?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${i} onInput=${u=>o(+u.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${a} onInput=${u=>s(+u.target.value)} /><//>
      </div>
      <div class="buttons">
        ${r?d`<${O} onClick=${l("up")}>Up<//><${O} onClick=${l("down")}>Down<//><${O} onClick=${l("off")}>Stop<//>`:d`<${O} kind="primary" onClick=${l("on")}>On<//><${O} onClick=${l("off")}>Off<//>`}
      </div>
    <//>`}function Sa({d:e,firstBank:t=0}){let n=e.name||e.key,[i,o]=_(t),[a,s]=_(255),[r,l]=_(Array(24).fill(!1)),u=r.reduce((c,p,f)=>p?c|1<<23-f:c,0);return d`
    <${x} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min=${t} max="255" value=${i} onInput=${c=>o(+c.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${c=>s(+c.target.value)} /><//>
      </div>
      <div class="lamps">
        ${r.map((c,p)=>d`<label key=${p} class=${"lamp"+(c?" on":"")}>
            <input type="checkbox" checked=${c} onChange=${()=>l(r.map((f,h)=>h===p?!f:f))} />${23-p}
          </label>`)}
      </div>
      <${O} kind="primary" onClick=${()=>E(()=>j.lamps(n,i,a,u),"Lamps set")}>Send<//>
    <//>`}function nu({d:e}){let t=e.name||e.key,[n,i]=_(45),[o,a]=_(!1),[s,r]=_(0),[l,u]=_(!1),[c,p]=_(0),[f,h]=_(55);return d`
    <${x} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${m=>i(+m.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${m=>a(m.target.checked)} /> from the tank</label>
        <${O} onClick=${()=>E(()=>j.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${s} onInput=${m=>r(+m.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${l} onChange=${m=>u(m.target.checked)} /> rod released</label>
        <${O} onClick=${()=>E(()=>j.heating(t,"energy",{power_w:s,rod_enabled:l}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${c} onInput=${m=>p(+m.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${f} onInput=${m=>h(+m.target.value)} /><//>
        <${O} kind="danger" onClick=${()=>E(()=>j.heating(t,"emergency",{stage:c,tank_c:f}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var iu=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function ou({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o,ask:a}=Ut(t);if(!n)return d`<${x} title="Sensor assignment"><${K} error=${i} /><//>`;let s=n.filter(p=>p.kind==="temperature"),r=p=>s.find(f=>f.role===p),l=p=>p.name?`${p.name} (${p.sensor_id})`:p.sensor_id,u=s.every(p=>p.slot!==null),c=p=>async f=>{let h=f.target.value,m;if(h===""){let y=r(p);if(!y)return;m=await E(()=>ye.update(t,y.slot,{role:"none"}),`${Xe(p)} cleared`)}else{let y=s.find($=>$.sensor_id===h);m=await E(()=>ye.update(t,y.slot,{role:p}),`${l(y)} is ${Xe(p)} now`)}m&&setTimeout(o,1500)};return d`
    <${x} title="Sensor assignment" aside=${d`<${O} onClick=${a}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!u&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${Qn.filter(p=>p!=="none").map(p=>d`<label key=${p} class="field">
            <span>${Xe(p)}</span>
            <select value=${(r(p)||{}).sensor_id||""} onChange=${c(p)} disabled=${!u}>
              <option value="">(none)</option>
              ${s.map(f=>d`<option value=${f.sensor_id}>${l(f)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function au({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o}=X(()=>j.heatingManualState(t),3e3),a=!!(n&&n.enabled),s=c=>!!(n&&n.relays.includes(c)),r=async()=>{let c=!a;await E(()=>j.heatingManual(t,c),c?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},l=c=>async()=>{await E(()=>j.heatingManual(t,!0,c,!s(c)),`Relay ${c} ${s(c)?"off":"on"}`)&&setTimeout(o,800)},u=c=>c===8&&s(9)||c===9&&s(8);return d`
    <${x} title="Manual mode"
      aside=${d`<${O} kind=${a?"danger":""} disabled=${!n} onClick=${r}>${a?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${i&&d`<p class="error">The controller does not answer: ${i.message}</p>`}
      ${a&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${iu.map(([c,p])=>d`<button key=${c} class=${s(c)?"primary":""} disabled=${!a||u(c)} onClick=${l(c)}>
            <span>${p}</span><small>relay ${c}: ${s(c)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function ru({d:e,reload:t}){let n=e.name||e.key,[i,o]=_({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[a,s]=_(!1),r=u=>c=>o({...i,[u]:c.target.value}),l=async()=>{let u={};if(i.custom_string!==e.name&&(u.custom_string=i.custom_string),+i.hwrev!==e.hwrev&&(u.hwrev=+i.hwrev),i.relais_mode&&(u.relais_mode=i.relais_mode),i.extension_mode&&(u.extension_mode=i.extension_mode),Object.keys(u).length===0)return U("Nothing changed");await E(()=>j.update(n,u),"Settings sent")&&setTimeout(t,1500)};return d`
    <${x} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${i.custom_string} onInput=${r("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${i.hwrev} onInput=${r("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${i.relais_mode} onChange=${r("relais_mode")}>
          <option value="">(unchanged)</option>${Xc.map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${i.extension_mode} onChange=${r("extension_mode")}>
          <option value="">(unchanged)</option>${Jc.map(u=>d`<option>${u}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${O} kind="primary" onClick=${l}>Save<//>
        <${O} onClick=${async()=>{await E(()=>j.silence(n,!a),a?"Device may talk again":"Device silenced"),s(!a)}}>${a?"End silence":"Silence"}<//>
        <${O} onClick=${()=>E(()=>j.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Ta(){let{data:e,error:t,reload:n}=X(j.list,5e3),[i,o]=_(""),a=(u,c)=>async()=>{await E(u,c),setTimeout(n,1500)},s=async()=>{let u=i.trim();u&&await E(()=>j.action(u,"ping"),`Ping sent to ${u}`)},r=async()=>{confirm("Restart every device on the bus?")&&await a(()=>Pe.action("restart"),"Restart sent to every device")()},l=a(()=>Pe.action("discover"),"Scanning: every device was asked to announce itself");return d`
    <${x} title="Devices">
      <div class="toolbar">
        <${O} onClick=${n}>Refresh<//>
        <${O} onClick=${a(()=>Pe.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${O} onClick=${a(()=>Pe.silence(!0),"Every device is silenced")}>Silence on<//>
        <${O} onClick=${a(()=>Pe.silence(!1),"Every device may talk again")}>Silence off<//>
        <${O} kind="danger" onClick=${r}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${i} onInput=${u=>o(u.target.value)} onKeyDown=${u=>u.key==="Enter"&&s()} />
        <${O} onClick=${s}>Ping<//>
        <${O} onClick=${l}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(u=>d`<tr key=${u.key}>
                    <td><${J} href=${"/devices/"+encodeURIComponent(u.name||u.key)}>${u.name||u.key}<//></td>
                    <td><code>${ln(u.device_id)}</code></td>
                    <td>${u.type_name} <code>${ln(u.device_type)}</code></td>
                    <td>${u.version}</td>
                    <td>${xe(u.last_seen_minutes_ago)}</td>
                    <td>${u.uptime?xe(Math.floor(u.uptime/60)):""}</td>
                    <td>${u.error?d`<span class="badge bad">error ${u.error}</span>`:u.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${K} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function xa(){let e=X(en.get,5e3);return d`<${su} ...${e} /><${lu} ...${e} /><${du} /><${pu} /><${hu} /><${mu} />`}function su({data:e,error:t}){return d`
    <${x} title="Gateway" aside=${d`<${O} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await E(en.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${Ki(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${K} error=${t} />`}
    <//>`}function lu({data:e,error:t}){if(!e)return d`<${x} title="Network"><${K} error=${t} /><//>`;let n=e.network;if(!n)return d`<${x} title="Network"><p>No Ethernet.</p><//>`;let i=a=>a.map(s=>d`<div>${s.address} <span class="muted">(${s.origin})</span></div>`),o=n.dhcpv6_setting==="off"?"switched off":n.dhcpv6_setting==="auto"&&!n.slaac?"off (follows the routers, which SLAAC reads)":n.dhcpv6_setting==="enforce"?"enforced: addresses and configuration":{off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${x} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?i(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(${n.ipv4_origin})</span>`:n.ipv4_origin==="DHCP"?"no DHCP lease":"none"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?i(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}var Ea=(e,t)=>e?`${e}/${t}`:"";function Aa(e,t){let[n,i]=e.trim().split("/");return{address:n||null,prefix:i?+i:t}}var cu=e=>({ipv4_mode:e.ipv4_mode,ipv4:Ea(e.ipv4_address,e.ipv4_prefix),ipv4_gateway:e.ipv4_gateway||"",dns1:e.dns_servers[0]||"",dns2:e.dns_servers[1]||"",slaac:e.slaac,dhcpv6:e.dhcpv6,ipv6:Ea(e.ipv6_address,e.ipv6_prefix),ipv6_gateway:e.ipv6_gateway||""});function uu(e){let t=Aa(e.ipv4,24),n=Aa(e.ipv6,64);return{ipv4_mode:e.ipv4_mode,ipv4_address:e.ipv4_mode==="manual"?t.address:null,ipv4_prefix:t.prefix,ipv4_gateway:e.ipv4_mode==="manual"&&e.ipv4_gateway.trim()||null,dns_servers:[e.dns1,e.dns2].map(i=>i.trim()).filter(Boolean),slaac:e.slaac,dhcpv6:e.dhcpv6,ipv6_address:n.address,ipv6_prefix:n.prefix,ipv6_gateway:e.ipv6_gateway.trim()||null}}function du(){let{data:e,error:t,reload:n}=X(on.get),[i,o]=_(null),a="Network settings";if(!e)return d`<${x} title=${a}><${K} error=${t} /><//>`;let s=i||cu(e.settings),r=c=>p=>o({...s,[c]:p.target.type==="checkbox"?p.target.checked:p.target.value}),l=s.ipv4_mode==="manual",u=async()=>{if(!i)return U("Nothing changed");confirm("Store the network settings? They take effect after a restart. If the gateway is unreachable then, the serial console's network-reset brings back DHCP and SLAAC.")&&await E(()=>on.put(uu(i)),"Saved")&&(o(null),n())};return d`
    <${x} title=${a} aside=${e.restart_required?d`<span class="badge warn">restart to apply</span>`:null}>
      <h3>IPv4</h3>
      <div class="row">
        <${C} label="Address"><select value=${s.ipv4_mode} onChange=${r("ipv4_mode")}>
          <option value="dhcp">DHCP</option>
          <option value="link_local">Link-local (${e.link_local_ipv4})</option>
          <option value="manual">Manual</option>
        </select><//>
        ${l&&d`
          <${C} label="Address/prefix" hint="e.g. 192.168.1.20/24"><input value=${s.ipv4} onInput=${r("ipv4")} /><//>
          <${C} label="Gateway" hint="empty: the local network only"><input value=${s.ipv4_gateway} onInput=${r("ipv4_gateway")} /><//>`}
      </div>
      <div class="row">
        <${C} label="DNS server 1" hint=${l?"at least one":"optional: replaces the DHCP server's"}><input value=${s.dns1} onInput=${r("dns1")} /><//>
        <${C} label="DNS server 2"><input value=${s.dns2} onInput=${r("dns2")} /><//>
      </div>
      <h3>IPv6</h3>
      <div class="row">
        <label class="check"><input type="checkbox" checked=${s.slaac} onChange=${r("slaac")} /> SLAAC (addresses and router from the routers' advertisements)</label>
        <${C} label="DHCPv6"><select value=${s.dhcpv6} onChange=${r("dhcpv6")}>
          <option value="auto">As the routers ask (M/O flags)</option>
          <option value="enforce">Always (address and configuration)</option>
          <option value="off">Off</option>
        </select><//>
      </div>
      ${!s.slaac&&s.dhcpv6==="auto"&&d`<p class="muted">Without SLAAC the routers' flags aren't read, so DHCPv6 only runs when enforced.</p>`}
      <div class="row">
        <${C} label="Address/prefix" hint="optional, next to the others, e.g. 2001:db8::20/64"><input value=${s.ipv6} onInput=${r("ipv6")} /><//>
        <${C} label="Gateway" hint=${s.slaac?"only used without SLAAC":"e.g. fe80::1"}><input value=${s.ipv6_gateway} onInput=${r("ipv6_gateway")} /><//>
      </div>
      <div class="buttons"><${O} kind="primary" onClick=${u}>Save<//>${i&&d`<button onClick=${()=>o(null)}>Discard</button>`}</div>
    <//>`}function pu(){let{data:e,error:t,reload:n}=X(tn.get),[i,o]=_({});if(!e)return d`<${K} error=${t} />`;let a=l=>l in i?i[l]:e[l],s=(l,u)=>c=>o({...i,[l]:u?+c.target.value:c.target.value}),r=async()=>{let l={...i};if(l.web_password||delete l.web_password,Object.keys(l).length===0)return U("Nothing changed");let u=await E(()=>tn.update(l),"Saved");u&&(u.restart_required&&U("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${x} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${a("hostname")} onInput=${s("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${a("can_bitrate")} onChange=${s("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${a("update_delay_ms")} onInput=${s("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${a("web_username")} onInput=${s("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${i.web_password||""} onInput=${s("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${O} kind="primary" onClick=${r}>Save<//></div>
    <//>`}var fu=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function hu(){let{data:e,error:t,reload:n}=X(nn.get),[i,o]=_({});if(!e)return d`<${x} title="Location and time"><${K} error=${t} /><//>`;let a=p=>p in i?i[p]:e[p]??"",s=p=>f=>o({...i,[p]:f.target.value}),r=async()=>{let p={};if(("latitude"in i||"longitude"in i)&&(p.latitude=parseFloat(a("latitude")),p.longitude=parseFloat(a("longitude")),Number.isNaN(p.latitude)||Number.isNaN(p.longitude)))return U("Latitude and longitude are numbers");if("timezone"in i&&(p.timezone=i.timezone.trim()),Object.keys(p).length===0)return U("Nothing changed");await E(()=>nn.update(p),"Saved")&&(o({}),n())},l=()=>{if(!navigator.geolocation)return U("This browser has no location","error");navigator.geolocation.getCurrentPosition(p=>o({...i,latitude:p.coords.latitude.toFixed(4),longitude:p.coords.longitude.toFixed(4)}),p=>U(`No location: ${p.message}`,"error"),{timeout:15e3})},u=e.utc_offset_minutes,c=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return d`
    <${x} title="Location and time">
      <p class="muted">
        For switching by local time and by the sun (schedules, motion light levels). Two decimals (about 1 km) are plenty.
        Take this browser's location, or look the place up on a map: in OpenStreetMap or Google Maps a right click on the house shows
        latitude and longitude. Save, then check today's sunrise and sunset below.
      </p>
      <div class="row">
        <${C} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${a("latitude")} onInput=${s("latitude")} /><//>
        <${C} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${a("longitude")} onInput=${s("longitude")} /><//>
        <${C} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${a("timezone")} onInput=${s("timezone")} /><//>
      </div>
      <div class="buttons"><${O} kind="primary" onClick=${r}>Save<//><button onClick=${l}>Use this browser's location</button></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${c})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?fu.map(([p,f])=>d`<div><dt>${f}</dt><dd>${e.sun[p]||d`<span class="muted">not today</span>`}</dd></div>`):d`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function mu(){return d`
    <${x} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${Dt} target="gateway" label="Install and restart" />
    <//>`}var gu=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],$u={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},vu={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},ke=async(e,t)=>await E(e,t)!==void 0,Jn=e=>e?new Date(e).toLocaleString():"\u2014";function Zn({label:e,accept:t,send:n,success:i,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async s=>{let r=s.target.files[0];if(s.target.value="",!r)return;let l=await r.text();await ke(()=>n(l),i)&&o&&o()}} hidden /></label>`}function La(){let{data:e,error:t,reload:n}=X(ae.get,1e4);return e?d`
    <${_u} d=${e} />
    <${yu} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${bu} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${wu} reload=${n} />`}
    ${e.mode==="est"&&d`<${ku} d=${e} reload=${n} />`}
    <${Su} d=${e} reload=${n} />
    <${Cu} d=${e} reload=${n} />`:d`<${K} error=${t} />`}function ei({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Jn(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Jn(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function _u({d:e}){let t=e.certificate,[n,i]=t?$u[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${x} title="Certificate" aside=${d`<span class=${"badge "+i}>${n}</span>`}>
      ${t?d`<${ei} c=${t} />
            <p class="muted">Made: ${vu[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&d`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function yu({d:e,reload:t}){let[n,i]=_(e.fqdn),[o,a]=_(e.mode),s=async()=>{let r={};if(n!==e.fqdn&&(r.fqdn=n.trim()),o!==e.mode&&(r.mode=o),Object.keys(r).length===0)return U("Nothing changed");await ke(()=>ae.update(r),"Saved")&&t()};return d`
    <${x} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${r=>i(r.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${gu.map(([r,l,u])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${r} checked=${o===r} onChange=${()=>a(r)} />
          <span><strong>${l}</strong><small class="muted">${u}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${O} kind="primary" onClick=${s}>Save<//></div>
    <//>`}function bu({d:e,reload:t}){let[n,i]=_(e.validity_years);return d`
    <${x} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${a=>i(+a.target.value)} /><//>
      </div>
      <div class="buttons"><${O} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await ke(()=>ae.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function wu({reload:e}){return d`
    <${x} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${ae.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Zn} label="Upload certificate" send=${ae.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function ku({d:e,reload:t}){let n=e.est,[i,o]=_(n.url),[a,s]=_(n.auto_renew),r=async()=>{await ke(()=>ae.update({est_url:i.trim(),est_auto_renew:a}),"Saved")&&t()},l=async()=>{await ke(ae.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${x} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${i} onInput=${u=>o(u.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a} onChange=${u=>s(u.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Jn(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${ei} c=${n.identity} />`}
      <div class="buttons">
        <${Zn} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${ae.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${O} kind="danger" onClick=${async()=>await ke(ae.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${O} kind="primary" onClick=${r}>Save<//>
        <${O} onClick=${l}>Enroll / renew now<//>
      </div>
    <//>`}function Su({d:e,reload:t}){let n=e.trust_anchor,i=async o=>{await ke(()=>ae.update({built_in_roots:o}),o?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return d`
    <${x} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${o=>i(o.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?d`<${ei} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${Zn} label=${n?"Replace":"Upload"} send=${ae.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&d`<${O} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await ke(ae.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function Cu({d:e,reload:t}){let[n,i]=_(e.ntp_server),o=async()=>{await ke(()=>ae.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${x} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} placeholder="automatic" onInput=${a=>i(a.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&d`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?d` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${O} onClick=${o}>Save<//></div>
    <//>`}var Tu=2e3;function Na(){let[e,t]=_([]),[n,i]=_(null),[o,a]=_(!1),[s,r]=_(""),[l,u]=_(!1),c=de(0),p=de(null),f=de(!0),h=de(!1);h.current=o,Q(()=>{let v=!1,B,S=async()=>{if(!h.current)try{for(let A=0;A<10;A++){let R=await rn.read(c.current);if(u(R.can_to_mqtt),i(null),R.from>c.current&&c.current>0&&t(w=>[...w,"\u2026 (older lines were overwritten)"]),c.current=R.next,R.text&&t(w=>[...w,...R.text.replace(/\n$/,"").split(`
`)].slice(-Tu)),!R.text)break}}catch(A){i(A.message)}v||(B=setTimeout(S,2e3))};return S(),()=>{v=!0,clearTimeout(B)}},[]),Q(()=>{let v=p.current;v&&f.current&&(v.scrollTop=v.scrollHeight)},[e,s]);let m=()=>{let v=p.current;f.current=v.scrollHeight-v.scrollTop-v.clientHeight<30},y=s?e.filter(v=>v.toLowerCase().includes(s.toLowerCase())):e,$=async v=>{let B=await E(()=>rn.setCanToMqtt(v),v?"CAN frames go to MQTT":"CAN frames no longer go to MQTT");B&&u(B.can_to_mqtt)};return d`
    <${x} title="Log" aside=${d`<div class="buttons">
      <button onClick=${()=>a(!o)}>${o?"Resume":"Pause"}</button>
      <button onClick=${()=>t([])}>Clear view</button>
      <button onClick=${()=>{let v=document.createElement("a");v.href=URL.createObjectURL(new Blob([e.join(`
`)+`
`],{type:"text/plain"})),v.download=`gateway-log-${new Date().toISOString().slice(0,19).replace(/:/g,"")}.txt`,v.click(),URL.revokeObjectURL(v.href)}} disabled=${!e.length}>Save as file</button>
    </div>`}>
      <p class="muted">What the gateway printed on its console, newest at the bottom; the gateway keeps the last few kilobytes. Times are seconds since the start.</p>
      <div class="row tight">
        <input type="search" placeholder="Filter, e.g. mqtt or automation" aria-label="Filter" value=${s} onInput=${v=>r(v.target.value)} />
      </div>
      <pre class="log console" ref=${p} onScroll=${m}>${y.join(`
`)||(n?"":"Waiting for lines\u2026")}</pre>
      ${n&&d`<p class="error">${n}</p>`}
    <//>
    <${x} title="CAN traffic to MQTT">
      <p class="muted">Every CAN frame sent and received also goes to <code>${"canbus/log/0x<id>"}</code> (<code>0x</code> and the data bytes, <code>R…</code> for a request), as the old gateway did. For debugging: it is a lot of messages. Off again after a restart. Frames can be sent to the bus with <code>${"canbus/debug/<id>"}</code>.</p>
      <label class="switch"><input type="checkbox" checked=${l} onChange=${v=>$(v.target.checked)} /><span></span>${l?"On":"Off"}</label>
    <//>`}var Eu={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Oa(){let{data:e,error:t,reload:n}=X(Ae.all,5e3);return e?d`
    <${Ia} slot="primary" b=${e.primary} reload=${n} />
    <${Ia} slot="secondary" b=${e.secondary} reload=${n} />
    <${Au} on=${e.home_assistant} reload=${n} />`:d`<${K} error=${t} />`}function Au({on:e,reload:t}){return d`
    <${x} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async i=>{let o=i.target.checked;await E(()=>Ae.updateAll({home_assistant:o}),o?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}var xu={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function Ia({slot:e,b:t,reload:n}){let[i,o]=_({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[a,s]=_(null),r=i.uri.startsWith("mqtts://"),l=p=>f=>o({...i,[p]:f.target.type==="checkbox"?f.target.checked:f.target.value}),u=async()=>{let p={uri:i.uri,user:i.user,enabled:i.enabled,tls_insecure:i.tls_insecure};i.password&&(p.password=i.password),await E(()=>Ae.update(e,p),`${e} broker saved, reconnecting`)&&(o({...i,password:""}),setTimeout(n,2500))},c=async()=>{let p=await E(()=>Ae.certificate(e));p&&s(p)};return d`
    <${x}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${Eu[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${i.uri} onInput=${l("uri")} /><//>
        <${C} label="User"><input value=${i.user} onInput=${l("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${i.password} onInput=${l("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${i.enabled} onChange=${l("enabled")} /> Connect to this broker</label>
      ${r&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${xu[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${i.tls_insecure} onChange=${l("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${O} onClick=${async()=>{await E(()=>Ae.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),c()},4e3)}}>Trust the broker's certificate now<//>
            <${O} onClick=${c}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${O} kind="danger" onClick=${async()=>{await E(()=>Ae.forget(e),"Certificate forgotten"),s(null),n()}}>Forget<//>`}
          </div>
          ${a&&d`<p>${a.pinned?d`SHA-256 <code>${a.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${O} kind="primary" onClick=${u}>Save<//></div>
    <//>`}var Lu=[{path:"/",title:"Devices",page:Ta},{path:"/devices/:device",title:"Device",page:Ca},{path:"/sensors",title:"Sensors",page:wa},{path:"/automation",title:"Automation",page:Vn},{path:"/automation/:tab",title:"Automation",page:Vn},{path:"/mqtt",title:"MQTT",page:Oa},{path:"/gateway",title:"Gateway",page:xa},{path:"/https",title:"HTTPS",page:La},{path:"/log",title:"Log",page:Na}],Nu=[["/","Devices"],["/sensors","Sensors"],["/automation","Automation"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"],["/log","Log"]];function Iu(){let e=Ri(),t=Mi(Lu,e),n=t?t.route.page:null,i=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${Nu.map(([o,a])=>d`<${J} href=${o} class=${i(o)?"active":""}>${a}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${J} href="/">Devices<//></p>`}
    </main>
    <${Hi} />`}$i(d`<${Iu} />`,document.getElementById("app"));
