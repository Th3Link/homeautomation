var Wo=Object.create;var Sn=Object.defineProperty;var Ko=Object.getOwnPropertyDescriptor;var Go=Object.getOwnPropertyNames;var Vo=Object.getPrototypeOf,Qo=Object.prototype.hasOwnProperty;var Xo=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var zo=(e,t,n,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Go(t))!Qo.call(e,o)&&o!==n&&Sn(e,o,{get:()=>t[o],enumerable:!(i=Ko(t,o))||i.enumerable});return e};var Jo=(e,t,n)=>(n=e!=null?Wo(Vo(e)):{},zo(t||!e||!e.__esModule?Sn(n,"default",{value:e,enumerable:!0}):n,e));var ii=Xo(Mt=>{var ni;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Mt=="object"?e(Mt):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(ni={}):e(ni={})})(function(e){e.version="1.2.2";function t(){for(var k=0,S=new Array(256),b=0;b!=256;++b)k=b,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,k=k&1?-306674912^k>>>1:k>>>1,S[b]=k;return typeof Int32Array<"u"?new Int32Array(S):S}var n=t();function i(k){var S=0,b=0,N=0,w=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(N=0;N!=256;++N)w[N]=k[N];for(N=0;N!=256;++N)for(b=k[N],S=256+N;S<4096;S+=256)b=w[S]=b>>>8^k[b&255];var I=[];for(N=1;N!=16;++N)I[N-1]=typeof Int32Array<"u"?w.subarray(N*256,N*256+256):w.slice(N*256,N*256+256);return I}var o=i(n),r=o[0],a=o[1],s=o[2],l=o[3],u=o[4],p=o[5],c=o[6],f=o[7],h=o[8],$=o[9],y=o[10],v=o[11],m=o[12],g=o[13],B=o[14];function x(k,S){for(var b=S^-1,N=0,w=k.length;N<w;)b=b>>>8^n[(b^k.charCodeAt(N++))&255];return~b}function O(k,S){for(var b=S^-1,N=k.length-15,w=0;w<N;)b=B[k[w++]^b&255]^g[k[w++]^b>>8&255]^m[k[w++]^b>>16&255]^v[k[w++]^b>>>24]^y[k[w++]]^$[k[w++]]^h[k[w++]]^f[k[w++]]^c[k[w++]]^p[k[w++]]^u[k[w++]]^l[k[w++]]^s[k[w++]]^a[k[w++]]^r[k[w++]]^n[k[w++]];for(N+=15;w<N;)b=b>>>8^n[(b^k[w++])&255];return~b}function R(k,S){for(var b=S^-1,N=0,w=k.length,I=0,P=0;N<w;)I=k.charCodeAt(N++),I<128?b=b>>>8^n[(b^I)&255]:I<2048?(b=b>>>8^n[(b^(192|I>>6&31))&255],b=b>>>8^n[(b^(128|I&63))&255]):I>=55296&&I<57344?(I=(I&1023)+64,P=k.charCodeAt(N++)&1023,b=b>>>8^n[(b^(240|I>>8&7))&255],b=b>>>8^n[(b^(128|I>>2&63))&255],b=b>>>8^n[(b^(128|P>>6&15|(I&3)<<4))&255],b=b>>>8^n[(b^(128|P&63))&255]):(b=b>>>8^n[(b^(224|I>>12&15))&255],b=b>>>8^n[(b^(128|I>>6&63))&255],b=b>>>8^n[(b^(128|I&63))&255]);return~b}e.table=n,e.bstr=x,e.buf=O,e.str=R})});var nt,D,On,Zo,_e,An,Fn,In,Nn,Tt,St,At,er,Ue={},Mn=[],tr=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,it=Array.isArray;function ue(e,t){for(var n in t)e[n]=t[n];return e}function Et(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function Be(e,t,n){var i,o,r,a={};for(r in t)r=="key"?i=t[r]:r=="ref"?o=t[r]:a[r]=t[r];if(arguments.length>2&&(a.children=arguments.length>3?nt.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)a[r]===void 0&&(a[r]=e.defaultProps[r]);return Ze(e,a,i,o,null)}function Ze(e,t,n,i,o){var r={type:e,props:t,key:n,ref:i,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++On,__i:-1,__u:0};return o==null&&D.vnode!=null&&D.vnode(r),r}function ot(e){return e.children}function et(e,t){this.props=e,this.context=t}function xe(e,t){if(t==null)return e.__?xe(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?xe(e):null}function Rn(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Rn(e)}}function Tn(e){(!e.__d&&(e.__d=!0)&&_e.push(e)&&!tt.__r++||An!=D.debounceRendering)&&((An=D.debounceRendering)||Fn)(tt)}function tt(){for(var e,t,n,i,o,r,a,s=1;_e.length;)_e.length>s&&_e.sort(In),e=_e.shift(),s=_e.length,e.__d&&(n=void 0,o=(i=(t=e).__v).__e,r=[],a=[],t.__P&&((n=ue({},i)).__v=i.__v+1,D.vnode&&D.vnode(n),Lt(t.__P,n,i,t.__n,t.__P.namespaceURI,32&i.__u?[o]:null,r,o??xe(i),!!(32&i.__u),a),n.__v=i.__v,n.__.__k[n.__i]=n,Hn(r,n,a),n.__e!=o&&Rn(n)));tt.__r=0}function Dn(e,t,n,i,o,r,a,s,l,u,p){var c,f,h,$,y,v,m=i&&i.__k||Mn,g=t.length;for(l=nr(n,t,m,l,g),c=0;c<g;c++)(h=n.__k[c])!=null&&(f=h.__i==-1?Ue:m[h.__i]||Ue,h.__i=c,v=Lt(e,h,f,o,r,a,s,l,u,p),$=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&Ot(f.ref,null,h),p.push(h.ref,h.__c||$,h)),y==null&&$!=null&&(y=$),4&h.__u||f.__k===h.__k?l=Pn(h,l,e):typeof h.type=="function"&&v!==void 0?l=v:$&&(l=$.nextSibling),h.__u&=-7);return n.__e=y,l}function nr(e,t,n,i,o){var r,a,s,l,u,p=n.length,c=p,f=0;for(e.__k=new Array(o),r=0;r<o;r++)(a=t[r])!=null&&typeof a!="boolean"&&typeof a!="function"?(l=r+f,(a=e.__k[r]=typeof a=="string"||typeof a=="number"||typeof a=="bigint"||a.constructor==String?Ze(null,a,null,null,null):it(a)?Ze(ot,{children:a},null,null,null):a.constructor==null&&a.__b>0?Ze(a.type,a.props,a.key,a.ref?a.ref:null,a.__v):a).__=e,a.__b=e.__b+1,s=null,(u=a.__i=ir(a,n,l,c))!=-1&&(c--,(s=n[u])&&(s.__u|=2)),s==null||s.__v==null?(u==-1&&(o>p?f--:o<p&&f++),typeof a.type!="function"&&(a.__u|=4)):u!=l&&(u==l-1?f--:u==l+1?f++:(u>l?f--:f++,a.__u|=4))):e.__k[r]=null;if(c)for(r=0;r<p;r++)(s=n[r])!=null&&(2&s.__u)==0&&(s.__e==i&&(i=xe(s)),Bn(s,s));return i}function Pn(e,t,n){var i,o;if(typeof e.type=="function"){for(i=e.__k,o=0;i&&o<i.length;o++)i[o]&&(i[o].__=e,t=Pn(i[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=xe(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function ir(e,t,n,i){var o,r,a=e.key,s=e.type,l=t[n];if(l===null&&e.key==null||l&&a==l.key&&s==l.type&&(2&l.__u)==0)return n;if(i>(l!=null&&(2&l.__u)==0?1:0))for(o=n-1,r=n+1;o>=0||r<t.length;){if(o>=0){if((l=t[o])&&(2&l.__u)==0&&a==l.key&&s==l.type)return o;o--}if(r<t.length){if((l=t[r])&&(2&l.__u)==0&&a==l.key&&s==l.type)return r;r++}}return-1}function En(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||tr.test(t)?n:n+"px"}function Je(e,t,n,i,o){var r,a;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof i=="string"&&(e.style.cssText=i=""),i)for(t in i)n&&t in n||En(e.style,t,"");if(n)for(t in n)i&&n[t]==i[t]||En(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Nn,"$1")),a=t.toLowerCase(),t=a in e||t=="onFocusOut"||t=="onFocusIn"?a.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?i?n.u=i.u:(n.u=Tt,e.addEventListener(t,r?At:St,r)):e.removeEventListener(t,r?At:St,r);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ln(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=Tt++;else if(t.t<n.u)return;return n(D.event?D.event(t):t)}}}function Lt(e,t,n,i,o,r,a,s,l,u){var p,c,f,h,$,y,v,m,g,B,x,O,R,k,S,b,N,w=t.type;if(t.constructor!=null)return null;128&n.__u&&(l=!!(32&n.__u),r=[s=t.__e=n.__e]),(p=D.__b)&&p(t);e:if(typeof w=="function")try{if(m=t.props,g="prototype"in w&&w.prototype.render,B=(p=w.contextType)&&i[p.__c],x=p?B?B.props.value:p.__:i,n.__c?v=(c=t.__c=n.__c).__=c.__E:(g?t.__c=c=new w(m,x):(t.__c=c=new et(m,x),c.constructor=w,c.render=rr),B&&B.sub(c),c.props=m,c.state||(c.state={}),c.context=x,c.__n=i,f=c.__d=!0,c.__h=[],c._sb=[]),g&&c.__s==null&&(c.__s=c.state),g&&w.getDerivedStateFromProps!=null&&(c.__s==c.state&&(c.__s=ue({},c.__s)),ue(c.__s,w.getDerivedStateFromProps(m,c.__s))),h=c.props,$=c.state,c.__v=t,f)g&&w.getDerivedStateFromProps==null&&c.componentWillMount!=null&&c.componentWillMount(),g&&c.componentDidMount!=null&&c.__h.push(c.componentDidMount);else{if(g&&w.getDerivedStateFromProps==null&&m!==h&&c.componentWillReceiveProps!=null&&c.componentWillReceiveProps(m,x),!c.__e&&c.shouldComponentUpdate!=null&&c.shouldComponentUpdate(m,c.__s,x)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(c.props=m,c.state=c.__s,c.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(I){I&&(I.__=t)}),O=0;O<c._sb.length;O++)c.__h.push(c._sb[O]);c._sb=[],c.__h.length&&a.push(c);break e}c.componentWillUpdate!=null&&c.componentWillUpdate(m,c.__s,x),g&&c.componentDidUpdate!=null&&c.__h.push(function(){c.componentDidUpdate(h,$,y)})}if(c.context=x,c.props=m,c.__P=e,c.__e=!1,R=D.__r,k=0,g){for(c.state=c.__s,c.__d=!1,R&&R(t),p=c.render(c.props,c.state,c.context),S=0;S<c._sb.length;S++)c.__h.push(c._sb[S]);c._sb=[]}else do c.__d=!1,R&&R(t),p=c.render(c.props,c.state,c.context),c.state=c.__s;while(c.__d&&++k<25);c.state=c.__s,c.getChildContext!=null&&(i=ue(ue({},i),c.getChildContext())),g&&!f&&c.getSnapshotBeforeUpdate!=null&&(y=c.getSnapshotBeforeUpdate(h,$)),b=p,p!=null&&p.type===ot&&p.key==null&&(b=Un(p.props.children)),s=Dn(e,it(b)?b:[b],t,n,i,o,r,a,s,l,u),c.base=t.__e,t.__u&=-161,c.__h.length&&a.push(c),v&&(c.__E=c.__=null)}catch(I){if(t.__v=null,l||r!=null)if(I.then){for(t.__u|=l?160:128;s&&s.nodeType==8&&s.nextSibling;)s=s.nextSibling;r[r.indexOf(s)]=null,t.__e=s}else for(N=r.length;N--;)Et(r[N]);else t.__e=n.__e,t.__k=n.__k;D.__e(I,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):s=t.__e=or(n.__e,t,n,i,o,r,a,l,u);return(p=D.diffed)&&p(t),128&t.__u?void 0:s}function Hn(e,t,n){for(var i=0;i<n.length;i++)Ot(n[i],n[++i],n[++i]);D.__c&&D.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(r){r.call(o)})}catch(r){D.__e(r,o.__v)}})}function Un(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:it(e)?e.map(Un):ue({},e)}function or(e,t,n,i,o,r,a,s,l){var u,p,c,f,h,$,y,v=n.props,m=t.props,g=t.type;if(g=="svg"?o="http://www.w3.org/2000/svg":g=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),r!=null){for(u=0;u<r.length;u++)if((h=r[u])&&"setAttribute"in h==!!g&&(g?h.localName==g:h.nodeType==3)){e=h,r[u]=null;break}}if(e==null){if(g==null)return document.createTextNode(m);e=document.createElementNS(o,g,m.is&&m),s&&(D.__m&&D.__m(t,r),s=!1),r=null}if(g==null)v===m||s&&e.data==m||(e.data=m);else{if(r=r&&nt.call(e.childNodes),v=n.props||Ue,!s&&r!=null)for(v={},u=0;u<e.attributes.length;u++)v[(h=e.attributes[u]).name]=h.value;for(u in v)if(h=v[u],u!="children"){if(u=="dangerouslySetInnerHTML")c=h;else if(!(u in m)){if(u=="value"&&"defaultValue"in m||u=="checked"&&"defaultChecked"in m)continue;Je(e,u,null,h,o)}}for(u in m)h=m[u],u=="children"?f=h:u=="dangerouslySetInnerHTML"?p=h:u=="value"?$=h:u=="checked"?y=h:s&&typeof h!="function"||v[u]===h||Je(e,u,h,v[u],o);if(p)s||c&&(p.__html==c.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(c&&(e.innerHTML=""),Dn(t.type=="template"?e.content:e,it(f)?f:[f],t,n,i,g=="foreignObject"?"http://www.w3.org/1999/xhtml":o,r,a,r?r[0]:n.__k&&xe(n,0),s,l),r!=null)for(u=r.length;u--;)Et(r[u]);s||(u="value",g=="progress"&&$==null?e.removeAttribute("value"):$!=null&&($!==e[u]||g=="progress"&&!$||g=="option"&&$!=v[u])&&Je(e,u,$,v[u],o),u="checked",y!=null&&y!=e[u]&&Je(e,u,y,v[u],o))}return e}function Ot(e,t,n){try{if(typeof e=="function"){var i=typeof e.__u=="function";i&&e.__u(),i&&t==null||(e.__u=e(t))}else e.current=t}catch(o){D.__e(o,n)}}function Bn(e,t,n){var i,o;if(D.unmount&&D.unmount(e),(i=e.ref)&&(i.current&&i.current!=e.__e||Ot(i,null,t)),(i=e.__c)!=null){if(i.componentWillUnmount)try{i.componentWillUnmount()}catch(r){D.__e(r,t)}i.base=i.__P=null}if(i=e.__k)for(o=0;o<i.length;o++)i[o]&&Bn(i[o],t,n||typeof e.type!="function");n||Et(e.__e),e.__c=e.__=e.__e=void 0}function rr(e,t,n){return this.constructor(e,n)}function jn(e,t,n){var i,o,r,a;t==document&&(t=document.documentElement),D.__&&D.__(e,t),o=(i=typeof n=="function")?null:n&&n.__k||t.__k,r=[],a=[],Lt(t,e=(!i&&n||t).__k=Be(ot,null,[e]),o||Ue,Ue,t.namespaceURI,!i&&n?[n]:o?null:t.firstChild?nt.call(t.childNodes):null,r,!i&&n?n:o?o.__e:t.firstChild,i,a),Hn(r,e,a)}nt=Mn.slice,D={__e:function(e,t,n,i){for(var o,r,a;t=t.__;)if((o=t.__c)&&!o.__)try{if((r=o.constructor)&&r.getDerivedStateFromError!=null&&(o.setState(r.getDerivedStateFromError(e)),a=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,i||{}),a=o.__d),a)return o.__E=o}catch(s){e=s}throw e}},On=0,Zo=function(e){return e!=null&&e.constructor==null},et.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=ue({},this.state),typeof e=="function"&&(e=e(ue({},n),this.props)),e&&ue(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Tn(this))},et.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Tn(this))},et.prototype.render=ot,_e=[],Fn=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,In=function(e,t){return e.__v.__b-t.__v.__b},tt.__r=0,Nn=/(PointerCapture)$|Capture$/i,Tt=0,St=Ln(!1),At=Ln(!0),er=0;var je,Y,Ft,Yn,Ye=0,zn=[],q=D,qn=q.__b,Wn=q.__r,Kn=q.diffed,Gn=q.__c,Vn=q.unmount,Qn=q.__;function Nt(e,t){q.__h&&q.__h(Y,e,Ye||t),Ye=0;var n=Y.__H||(Y.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function _(e){return Ye=1,ar(ti,e)}function ar(e,t,n){var i=Nt(je++,2);if(i.t=e,!i.__c&&(i.__=[n?n(t):ti(void 0,t),function(s){var l=i.__N?i.__N[0]:i.__[0],u=i.t(l,s);l!==u&&(i.__N=[u,i.__[1]],i.__c.setState({}))}],i.__c=Y,!Y.__f)){var o=function(s,l,u){if(!i.__c.__H)return!0;var p=i.__c.__H.__.filter(function(f){return!!f.__c});if(p.every(function(f){return!f.__N}))return!r||r.call(this,s,l,u);var c=i.__c.props!==s;return p.forEach(function(f){if(f.__N){var h=f.__[0];f.__=f.__N,f.__N=void 0,h!==f.__[0]&&(c=!0)}}),r&&r.call(this,s,l,u)||c};Y.__f=!0;var r=Y.shouldComponentUpdate,a=Y.componentWillUpdate;Y.componentWillUpdate=function(s,l,u){if(this.__e){var p=r;r=void 0,o(s,l,u),r=p}a&&a.call(this,s,l,u)},Y.shouldComponentUpdate=o}return i.__N||i.__}function X(e,t){var n=Nt(je++,3);!q.__s&&ei(n.__H,t)&&(n.__=e,n.u=t,Y.__H.__h.push(n))}function Ce(e){return Ye=5,Jn(function(){return{current:e}},[])}function Jn(e,t){var n=Nt(je++,7);return ei(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function Zn(e,t){return Ye=8,Jn(function(){return e},t)}function sr(){for(var e;e=zn.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(rt),e.__H.__h.forEach(It),e.__H.__h=[]}catch(t){e.__H.__h=[],q.__e(t,e.__v)}}q.__b=function(e){Y=null,qn&&qn(e)},q.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Qn&&Qn(e,t)},q.__r=function(e){Wn&&Wn(e),je=0;var t=(Y=e.__c).__H;t&&(Ft===Y?(t.__h=[],Y.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(rt),t.__h.forEach(It),t.__h=[],je=0)),Ft=Y},q.diffed=function(e){Kn&&Kn(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(zn.push(t)!==1&&Yn===q.requestAnimationFrame||((Yn=q.requestAnimationFrame)||lr)(sr)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ft=Y=null},q.__c=function(e,t){t.some(function(n){try{n.__h.forEach(rt),n.__h=n.__h.filter(function(i){return!i.__||It(i)})}catch(i){t.some(function(o){o.__h&&(o.__h=[])}),t=[],q.__e(i,n.__v)}}),Gn&&Gn(e,t)},q.unmount=function(e){Vn&&Vn(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(i){try{rt(i)}catch(o){t=o}}),n.__H=void 0,t&&q.__e(t,n.__v))};var Xn=typeof requestAnimationFrame=="function";function lr(e){var t,n=function(){clearTimeout(i),Xn&&cancelAnimationFrame(t),setTimeout(e)},i=setTimeout(n,35);Xn&&(t=requestAnimationFrame(n))}function rt(e){var t=Y,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),Y=t}function It(e){var t=Y;e.__c=e.__(),Y=t}function ei(e,t){return!e||e.length!==t.length||t.some(function(n,i){return n!==e[i]})}function ti(e,t){return typeof t=="function"?t(e):t}var ai=Jo(ii()),Pt="/api/v1",Se=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error,this.field=n&&n.field}},cr=e=>new Promise(t=>setTimeout(t,e));async function Ae(e,t,n,i=!1){for(let o=1;;o++){let r;try{r=await fetch(Pt+t,{method:e,headers:n===void 0?{}:{"Content-Type":i?"application/x-pem-file":"application/json"},body:n===void 0?void 0:i?n:JSON.stringify(n)})}catch{if(o>=4)throw new Se(0,{message:"gateway unreachable"});await cr(250*o);continue}let a=await r.text(),s=null;try{s=a?JSON.parse(a):null}catch{s={message:a}}if(!r.ok)throw new Se(r.status,s);return s}}var V=e=>Ae("GET",e),le=(e,t)=>Ae("POST",e,t),ie=(e,t)=>Ae("PUT",e,t),Rt=(e,t)=>Ae("PUT",e,t,!0),de=(e,t)=>Ae("PATCH",e,t),qe=e=>Ae("DELETE",e),H=encodeURIComponent,Ht={get:()=>V("/system"),restart:()=>le("/system/restart")},Ut={get:()=>V("/config"),update:e=>de("/config",e)},Bt={get:()=>V("/location"),update:e=>de("/location",e)},be={all:()=>V("/mqtt"),updateAll:e=>de("/mqtt",e),update:(e,t)=>de(`/mqtt/${e}`,t),trust:e=>le(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>qe(`/mqtt/${e}/certificate`)},ee={get:()=>V("/tls"),update:e=>de("/tls",e),selfSigned:e=>le("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Pt}/tls/csr`,installCertificate:e=>Rt("/tls/certificate",e),setTrustAnchor:e=>Rt("/tls/trust-anchor",e),removeTrustAnchor:()=>qe("/tls/trust-anchor"),setIdentity:e=>Rt("/tls/est/identity",e),removeIdentity:()=>qe("/tls/est/identity"),enroll:()=>le("/tls/est/enroll")},j={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${H(e)}`),update:(e,t)=>de(`/devices/${H(e)}`,t),action:(e,t)=>le(`/devices/${H(e)}/${t}`),silence:(e,t)=>ie(`/devices/${H(e)}/silence`,{on:t}),relay:(e,t,n,i)=>ie(`/devices/${H(e)}/relays/${t}`,{state:n,duration_ms:i}),rollershutter:(e,t,n,i)=>ie(`/devices/${H(e)}/rollershutters/${t}`,{state:n,duration_ms:i}),lamps:(e,t,n,i)=>ie(`/devices/${H(e)}/lamps/${t}`,{value:n,bitmask:i}),heating:(e,t,n)=>ie(`/devices/${H(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${H(e)}/heating/manual`),heatingManual:(e,t,n,i)=>ie(`/devices/${H(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:i})},pe={update:(e,t,n)=>ie(`/devices/${H(e)}/sensors/${t}`,n),refresh:e=>le(`/devices/${H(e)}/sensors/refresh`),forget:e=>le(`/devices/${H(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${H(e)}`:"",i=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...i.sensors),i.sensors.length===0||t.length>=i.total)return t}}},Te={action:e=>le(`/bus/${e}`),silence:e=>ie("/bus/silence",{on:e}),typeAction:(e,t)=>le(`/device-types/${e}/${t}`)},jt={job:()=>V("/firmware/job"),upload(e,t,n){let i=ai.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((r,a)=>{let s=new XMLHttpRequest;s.open("PUT",`${Pt}${o}?crc32=${i}`),s.setRequestHeader("Content-Type","application/octet-stream"),s.upload.onprogress=l=>l.lengthComputable&&n&&n(l.loaded/l.total),s.onload=()=>{let l=null;try{l=JSON.parse(s.responseText)}catch{}s.status>=200&&s.status<300?r(l):a(new Se(s.status,l))},s.onerror=()=>a(new Se(0,{message:"upload failed"})),s.send(t)})}},Dt=e=>({list:()=>V(`/automation/${e}`).then(t=>t.items),get:t=>V(`/automation/${e}/${H(t)}`),put:(t,n)=>ie(`/automation/${e}/${H(t)}`,n),remove:t=>qe(`/automation/${e}/${H(t)}`)});async function oi(e){let t=[];for(;;){let n=await V(`${e}?offset=${t.length}`);if(t.push(...n.items),n.items.length===0||t.length>=n.total)return t}}var ri=e=>"0x"+(268435456+(e.type<<16)+(e.id<<8)).toString(16),A={status:()=>V("/automation"),setEnabled:e=>de("/automation",{enabled:e}),outputs:{...Dt("outputs"),command:(e,t)=>le(`/automation/outputs/${H(e)}/command`,t)},switches:{list:()=>oi("/automation/switches"),get:e=>V(`/automation/switches/${H(e)}`),put:(e,t)=>ie(`/automation/switches/${H(e)}`,t),remove:e=>qe(`/automation/switches/${H(e)}`),button:(e,t)=>V(`/automation/switches/${H(e)}/${t}`),putButton:(e,t,n)=>ie(`/automation/switches/${H(e)}/${t}`,n)},motion:{...Dt("motion"),setEnabled:(e,t)=>de(`/automation/motion/${H(e)}`,{enabled:t})},schedules:{...Dt("schedules"),setEnabled:(e,t)=>de(`/automation/schedules/${H(e)}`,{enabled:t})},devices:{list:()=>oi("/automation/devices"),get:e=>V(`/automation/devices/${ri(e)}`),put:(e,t)=>ie(`/automation/devices/${ri(e)}`,t)}};var at=new Set;function ur(e){e!==location.pathname&&history.pushState(null,"",e),at.forEach(t=>t())}addEventListener("popstate",()=>at.forEach(e=>e()));function si(){let[e,t]=_(location.pathname);return X(()=>{let n=()=>t(location.pathname);return at.add(n),()=>at.delete(n)},[]),e}function li(e,t){let n=t.split("/").filter(Boolean);for(let i of e){let o=i.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let r={};if(o.every((s,l)=>s.startsWith(":")?(r[s.slice(1)]=decodeURIComponent(n[l]),!0):s===n[l]))return{route:i,params:r}}return null}function Q({href:e,children:t,...n}){return Be("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),ur(e))},...n},t)}var ui=function(e,t,n,i){var o;t[0]=0;for(var r=1;r<t.length;r++){var a=t[r++],s=t[r]?(t[0]|=a?1:2,n[t[r++]]):t[++r];a===3?i[0]=s:a===4?i[1]=Object.assign(i[1]||{},s):a===5?(i[1]=i[1]||{})[t[++r]]=s:a===6?i[1][t[++r]]+=s+"":a?(o=e.apply(s,ui(e,s,n,["",null])),i.push(o),s[0]?t[0]|=2:(t[r-2]=0,t[r]=o)):i.push(s)}return i},ci=new Map;function di(e){var t=ci.get(this);return t||(t=new Map,ci.set(this,t)),(t=ui(this,t.get(e)||(t.set(e,t=function(n){for(var i,o,r=1,a="",s="",l=[0],u=function(f){r===1&&(f||(a=a.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?l.push(0,f,a):r===3&&(f||a)?(l.push(3,f,a),r=2):r===2&&a==="..."&&f?l.push(4,f,0):r===2&&a&&!f?l.push(5,0,!0,a):r>=5&&((a||!f&&r===5)&&(l.push(r,0,a,o),r=6),f&&(l.push(r,f,0,o),r=6)),a=""},p=0;p<n.length;p++){p&&(r===1&&u(),u(p));for(var c=0;c<n[p].length;c++)i=n[p][c],r===1?i==="<"?(u(),l=[l],r=3):a+=i:r===4?a==="--"&&i===">"?(r=1,a=""):a=i+a[0]:s?i===s?s="":a+=i:i==='"'||i==="'"?s=i:i===">"?(u(),r=1):r&&(i==="="?(r=5,o=a,a=""):i==="/"&&(r<5||n[p][c+1]===">")?(u(),r===3&&(l=l[0]),r=l,(l=l[0]).push(2,0,r),r=0):i===" "||i==="	"||i===`
`||i==="\r"?(u(),r=2):a+=i),r===3&&a==="!--"&&(r=4,l=l[0])}return u(),l}(e)),t),arguments,[])).length>1?t:t[0]}var d=di.bind(Be),Yt=()=>{};function M(e,t="ok"){Yt(e,t)}function pi(){let[e,t]=_([]);return X(()=>{let n=0;return Yt=(i,o)=>{let r={id:++n,message:i,kind:o};t(a=>[...a,r]),setTimeout(()=>t(a=>a.filter(s=>s!==r)),o==="error"?8e3:3e3)},()=>Yt=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function E(e,t){try{let n=await e();return t&&M(t),n}catch(n){M(n.message,"error");return}}function K(e,t){let[n,i]=_({data:void 0,error:void 0}),o=Ce(e);o.current=e;let r=Zn(async()=>{try{i({data:await o.current(),error:void 0})}catch(a){i(s=>({data:s.data,error:a}))}},[]);return X(()=>{let a=!1,s,l=async()=>{await r(),t&&!a&&(s=setTimeout(l,t))};return l(),()=>{a=!0,clearTimeout(s)}},[t,r]),{...n,reload:r}}var F=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,U=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,T=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,L=({children:e,kind:t,onClick:n,disabled:i})=>{let[o,r]=_(!1);return d`<button class=${t||""} disabled=${i||o} onClick=${async s=>{r(!0);try{await n(s)}finally{r(!1)}}}>${e}</button>`},qt=e=>"0x"+e.toString(16).padStart(2,"0");function ye(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function fi(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),i=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${i} min`:`${i} min`}function Ei(e){return typeof e>"u"||e===null}function dr(e){return typeof e=="object"&&e!==null}function pr(e){return Array.isArray(e)?e:Ei(e)?[]:[e]}function fr(e,t){var n,i,o,r;if(t)for(r=Object.keys(t),n=0,i=r.length;n<i;n+=1)o=r[n],e[o]=t[o];return e}function hr(e,t){var n="",i;for(i=0;i<t;i+=1)n+=e;return n}function mr(e){return e===0&&Number.NEGATIVE_INFINITY===1/e}var $r=Ei,vr=dr,gr=pr,_r=hr,br=mr,yr=fr,G={isNothing:$r,isObject:vr,toArray:gr,repeat:_r,isNegativeZero:br,extend:yr};function Li(e,t){var n="",i=e.reason||"(unknown reason)";return e.mark?(e.mark.name&&(n+='in "'+e.mark.name+'" '),n+="("+(e.mark.line+1)+":"+(e.mark.column+1)+")",!t&&e.mark.snippet&&(n+=`

`+e.mark.snippet),i+" "+n):i}function Ke(e,t){Error.call(this),this.name="YAMLException",this.reason=e,this.mark=t,this.message=Li(this,!1),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=new Error().stack||""}Ke.prototype=Object.create(Error.prototype);Ke.prototype.constructor=Ke;Ke.prototype.toString=function(t){return this.name+": "+Li(this,t)};var te=Ke;function Wt(e,t,n,i,o){var r="",a="",s=Math.floor(o/2)-1;return i-t>s&&(r=" ... ",t=i-s+r.length),n-i>s&&(a=" ...",n=i+s-a.length),{str:r+e.slice(t,n).replace(/\t/g,"\u2192")+a,pos:i-t+r.length}}function Kt(e,t){return G.repeat(" ",t-e.length)+e}function wr(e,t){if(t=Object.create(t||null),!e.buffer)return null;t.maxLength||(t.maxLength=79),typeof t.indent!="number"&&(t.indent=1),typeof t.linesBefore!="number"&&(t.linesBefore=3),typeof t.linesAfter!="number"&&(t.linesAfter=2);for(var n=/\r?\n|\r|\0/g,i=[0],o=[],r,a=-1;r=n.exec(e.buffer);)o.push(r.index),i.push(r.index+r[0].length),e.position<=r.index&&a<0&&(a=i.length-2);a<0&&(a=i.length-1);var s="",l,u,p=Math.min(e.line+t.linesAfter,o.length).toString().length,c=t.maxLength-(t.indent+p+3);for(l=1;l<=t.linesBefore&&!(a-l<0);l++)u=Wt(e.buffer,i[a-l],o[a-l],e.position-(i[a]-i[a-l]),c),s=G.repeat(" ",t.indent)+Kt((e.line-l+1).toString(),p)+" | "+u.str+`
`+s;for(u=Wt(e.buffer,i[a],o[a],e.position,c),s+=G.repeat(" ",t.indent)+Kt((e.line+1).toString(),p)+" | "+u.str+`
`,s+=G.repeat("-",t.indent+p+3+u.pos)+`^
`,l=1;l<=t.linesAfter&&!(a+l>=o.length);l++)u=Wt(e.buffer,i[a+l],o[a+l],e.position-(i[a]-i[a+l]),c),s+=G.repeat(" ",t.indent)+Kt((e.line+l+1).toString(),p)+" | "+u.str+`
`;return s.replace(/\n$/,"")}var kr=wr,xr=["kind","multi","resolve","construct","instanceOf","predicate","represent","representName","defaultStyle","styleAliases"],Cr=["scalar","sequence","mapping"];function Sr(e){var t={};return e!==null&&Object.keys(e).forEach(function(n){e[n].forEach(function(i){t[String(i)]=n})}),t}function Ar(e,t){if(t=t||{},Object.keys(t).forEach(function(n){if(xr.indexOf(n)===-1)throw new te('Unknown option "'+n+'" is met in definition of "'+e+'" YAML type.')}),this.options=t,this.tag=e,this.kind=t.kind||null,this.resolve=t.resolve||function(){return!0},this.construct=t.construct||function(n){return n},this.instanceOf=t.instanceOf||null,this.predicate=t.predicate||null,this.represent=t.represent||null,this.representName=t.representName||null,this.defaultStyle=t.defaultStyle||null,this.multi=t.multi||!1,this.styleAliases=Sr(t.styleAliases||null),Cr.indexOf(this.kind)===-1)throw new te('Unknown kind "'+this.kind+'" is specified for "'+e+'" YAML type.')}var z=Ar;function hi(e,t){var n=[];return e[t].forEach(function(i){var o=n.length;n.forEach(function(r,a){r.tag===i.tag&&r.kind===i.kind&&r.multi===i.multi&&(o=a)}),n[o]=i}),n}function Tr(){var e={scalar:{},sequence:{},mapping:{},fallback:{},multi:{scalar:[],sequence:[],mapping:[],fallback:[]}},t,n;function i(o){o.multi?(e.multi[o.kind].push(o),e.multi.fallback.push(o)):e[o.kind][o.tag]=e.fallback[o.tag]=o}for(t=0,n=arguments.length;t<n;t+=1)arguments[t].forEach(i);return e}function Vt(e){return this.extend(e)}Vt.prototype.extend=function(t){var n=[],i=[];if(t instanceof z)i.push(t);else if(Array.isArray(t))i=i.concat(t);else if(t&&(Array.isArray(t.implicit)||Array.isArray(t.explicit)))t.implicit&&(n=n.concat(t.implicit)),t.explicit&&(i=i.concat(t.explicit));else throw new te("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");n.forEach(function(r){if(!(r instanceof z))throw new te("Specified list of YAML types (or a single Type object) contains a non-Type object.");if(r.loadKind&&r.loadKind!=="scalar")throw new te("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");if(r.multi)throw new te("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.")}),i.forEach(function(r){if(!(r instanceof z))throw new te("Specified list of YAML types (or a single Type object) contains a non-Type object.")});var o=Object.create(Vt.prototype);return o.implicit=(this.implicit||[]).concat(n),o.explicit=(this.explicit||[]).concat(i),o.compiledImplicit=hi(o,"implicit"),o.compiledExplicit=hi(o,"explicit"),o.compiledTypeMap=Tr(o.compiledImplicit,o.compiledExplicit),o};var Er=Vt,Lr=new z("tag:yaml.org,2002:str",{kind:"scalar",construct:function(e){return e!==null?e:""}}),Or=new z("tag:yaml.org,2002:seq",{kind:"sequence",construct:function(e){return e!==null?e:[]}}),Fr=new z("tag:yaml.org,2002:map",{kind:"mapping",construct:function(e){return e!==null?e:{}}}),Ir=new Er({explicit:[Lr,Or,Fr]});function Nr(e){if(e===null)return!0;var t=e.length;return t===1&&e==="~"||t===4&&(e==="null"||e==="Null"||e==="NULL")}function Mr(){return null}function Rr(e){return e===null}var Dr=new z("tag:yaml.org,2002:null",{kind:"scalar",resolve:Nr,construct:Mr,predicate:Rr,represent:{canonical:function(){return"~"},lowercase:function(){return"null"},uppercase:function(){return"NULL"},camelcase:function(){return"Null"},empty:function(){return""}},defaultStyle:"lowercase"});function Pr(e){if(e===null)return!1;var t=e.length;return t===4&&(e==="true"||e==="True"||e==="TRUE")||t===5&&(e==="false"||e==="False"||e==="FALSE")}function Hr(e){return e==="true"||e==="True"||e==="TRUE"}function Ur(e){return Object.prototype.toString.call(e)==="[object Boolean]"}var Br=new z("tag:yaml.org,2002:bool",{kind:"scalar",resolve:Pr,construct:Hr,predicate:Ur,represent:{lowercase:function(e){return e?"true":"false"},uppercase:function(e){return e?"TRUE":"FALSE"},camelcase:function(e){return e?"True":"False"}},defaultStyle:"lowercase"});function jr(e){return 48<=e&&e<=57||65<=e&&e<=70||97<=e&&e<=102}function Yr(e){return 48<=e&&e<=55}function qr(e){return 48<=e&&e<=57}function Wr(e){if(e===null)return!1;var t=e.length,n=0,i=!1,o;if(!t)return!1;if(o=e[n],(o==="-"||o==="+")&&(o=e[++n]),o==="0"){if(n+1===t)return!0;if(o=e[++n],o==="b"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(o!=="0"&&o!=="1")return!1;i=!0}return i&&o!=="_"}if(o==="x"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(!jr(e.charCodeAt(n)))return!1;i=!0}return i&&o!=="_"}if(o==="o"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(!Yr(e.charCodeAt(n)))return!1;i=!0}return i&&o!=="_"}}if(o==="_")return!1;for(;n<t;n++)if(o=e[n],o!=="_"){if(!qr(e.charCodeAt(n)))return!1;i=!0}return!(!i||o==="_")}function Kr(e){var t=e,n=1,i;if(t.indexOf("_")!==-1&&(t=t.replace(/_/g,"")),i=t[0],(i==="-"||i==="+")&&(i==="-"&&(n=-1),t=t.slice(1),i=t[0]),t==="0")return 0;if(i==="0"){if(t[1]==="b")return n*parseInt(t.slice(2),2);if(t[1]==="x")return n*parseInt(t.slice(2),16);if(t[1]==="o")return n*parseInt(t.slice(2),8)}return n*parseInt(t,10)}function Gr(e){return Object.prototype.toString.call(e)==="[object Number]"&&e%1===0&&!G.isNegativeZero(e)}var Vr=new z("tag:yaml.org,2002:int",{kind:"scalar",resolve:Wr,construct:Kr,predicate:Gr,represent:{binary:function(e){return e>=0?"0b"+e.toString(2):"-0b"+e.toString(2).slice(1)},octal:function(e){return e>=0?"0o"+e.toString(8):"-0o"+e.toString(8).slice(1)},decimal:function(e){return e.toString(10)},hexadecimal:function(e){return e>=0?"0x"+e.toString(16).toUpperCase():"-0x"+e.toString(16).toUpperCase().slice(1)}},defaultStyle:"decimal",styleAliases:{binary:[2,"bin"],octal:[8,"oct"],decimal:[10,"dec"],hexadecimal:[16,"hex"]}}),Qr=new RegExp("^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");function Xr(e){return!(e===null||!Qr.test(e)||e[e.length-1]==="_")}function zr(e){var t,n;return t=e.replace(/_/g,"").toLowerCase(),n=t[0]==="-"?-1:1,"+-".indexOf(t[0])>=0&&(t=t.slice(1)),t===".inf"?n===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY:t===".nan"?NaN:n*parseFloat(t,10)}var Jr=/^[-+]?[0-9]+e/;function Zr(e,t){var n;if(isNaN(e))switch(t){case"lowercase":return".nan";case"uppercase":return".NAN";case"camelcase":return".NaN"}else if(Number.POSITIVE_INFINITY===e)switch(t){case"lowercase":return".inf";case"uppercase":return".INF";case"camelcase":return".Inf"}else if(Number.NEGATIVE_INFINITY===e)switch(t){case"lowercase":return"-.inf";case"uppercase":return"-.INF";case"camelcase":return"-.Inf"}else if(G.isNegativeZero(e))return"-0.0";return n=e.toString(10),Jr.test(n)?n.replace("e",".e"):n}function ea(e){return Object.prototype.toString.call(e)==="[object Number]"&&(e%1!==0||G.isNegativeZero(e))}var ta=new z("tag:yaml.org,2002:float",{kind:"scalar",resolve:Xr,construct:zr,predicate:ea,represent:Zr,defaultStyle:"lowercase"}),na=Ir.extend({implicit:[Dr,Br,Vr,ta]}),ia=na,Oi=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"),Fi=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");function oa(e){return e===null?!1:Oi.exec(e)!==null||Fi.exec(e)!==null}function ra(e){var t,n,i,o,r,a,s,l=0,u=null,p,c,f;if(t=Oi.exec(e),t===null&&(t=Fi.exec(e)),t===null)throw new Error("Date resolve error");if(n=+t[1],i=+t[2]-1,o=+t[3],!t[4])return new Date(Date.UTC(n,i,o));if(r=+t[4],a=+t[5],s=+t[6],t[7]){for(l=t[7].slice(0,3);l.length<3;)l+="0";l=+l}return t[9]&&(p=+t[10],c=+(t[11]||0),u=(p*60+c)*6e4,t[9]==="-"&&(u=-u)),f=new Date(Date.UTC(n,i,o,r,a,s,l)),u&&f.setTime(f.getTime()-u),f}function aa(e){return e.toISOString()}var sa=new z("tag:yaml.org,2002:timestamp",{kind:"scalar",resolve:oa,construct:ra,instanceOf:Date,represent:aa});function la(e){return e==="<<"||e===null}var ca=new z("tag:yaml.org,2002:merge",{kind:"scalar",resolve:la}),Zt=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;function ua(e){if(e===null)return!1;var t,n,i=0,o=e.length,r=Zt;for(n=0;n<o;n++)if(t=r.indexOf(e.charAt(n)),!(t>64)){if(t<0)return!1;i+=6}return i%8===0}function da(e){var t,n,i=e.replace(/[\r\n=]/g,""),o=i.length,r=Zt,a=0,s=[];for(t=0;t<o;t++)t%4===0&&t&&(s.push(a>>16&255),s.push(a>>8&255),s.push(a&255)),a=a<<6|r.indexOf(i.charAt(t));return n=o%4*6,n===0?(s.push(a>>16&255),s.push(a>>8&255),s.push(a&255)):n===18?(s.push(a>>10&255),s.push(a>>2&255)):n===12&&s.push(a>>4&255),new Uint8Array(s)}function pa(e){var t="",n=0,i,o,r=e.length,a=Zt;for(i=0;i<r;i++)i%3===0&&i&&(t+=a[n>>18&63],t+=a[n>>12&63],t+=a[n>>6&63],t+=a[n&63]),n=(n<<8)+e[i];return o=r%3,o===0?(t+=a[n>>18&63],t+=a[n>>12&63],t+=a[n>>6&63],t+=a[n&63]):o===2?(t+=a[n>>10&63],t+=a[n>>4&63],t+=a[n<<2&63],t+=a[64]):o===1&&(t+=a[n>>2&63],t+=a[n<<4&63],t+=a[64],t+=a[64]),t}function fa(e){return Object.prototype.toString.call(e)==="[object Uint8Array]"}var ha=new z("tag:yaml.org,2002:binary",{kind:"scalar",resolve:ua,construct:da,predicate:fa,represent:pa}),ma=Object.prototype.hasOwnProperty,$a=Object.prototype.toString;function va(e){if(e===null)return!0;var t=[],n,i,o,r,a,s=e;for(n=0,i=s.length;n<i;n+=1){if(o=s[n],a=!1,$a.call(o)!=="[object Object]")return!1;for(r in o)if(ma.call(o,r))if(!a)a=!0;else return!1;if(!a)return!1;if(t.indexOf(r)===-1)t.push(r);else return!1}return!0}function ga(e){return e!==null?e:[]}var _a=new z("tag:yaml.org,2002:omap",{kind:"sequence",resolve:va,construct:ga}),ba=Object.prototype.toString;function ya(e){if(e===null)return!0;var t,n,i,o,r,a=e;for(r=new Array(a.length),t=0,n=a.length;t<n;t+=1){if(i=a[t],ba.call(i)!=="[object Object]"||(o=Object.keys(i),o.length!==1))return!1;r[t]=[o[0],i[o[0]]]}return!0}function wa(e){if(e===null)return[];var t,n,i,o,r,a=e;for(r=new Array(a.length),t=0,n=a.length;t<n;t+=1)i=a[t],o=Object.keys(i),r[t]=[o[0],i[o[0]]];return r}var ka=new z("tag:yaml.org,2002:pairs",{kind:"sequence",resolve:ya,construct:wa}),xa=Object.prototype.hasOwnProperty;function Ca(e){if(e===null)return!0;var t,n=e;for(t in n)if(xa.call(n,t)&&n[t]!==null)return!1;return!0}function Sa(e){return e!==null?e:{}}var Aa=new z("tag:yaml.org,2002:set",{kind:"mapping",resolve:Ca,construct:Sa}),Ii=ia.extend({implicit:[sa,ca],explicit:[ha,_a,ka,Aa]}),$e=Object.prototype.hasOwnProperty,st=1,Ni=2,Mi=3,lt=4,Gt=1,Ta=2,mi=3,Ea=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,La=/[\x85\u2028\u2029]/,Oa=/[,\[\]\{\}]/,Ri=/^(?:!|!!|![a-z\-]+!)$/i,Di=/^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;function $i(e){return Object.prototype.toString.call(e)}function ce(e){return e===10||e===13}function ke(e){return e===9||e===32}function ne(e){return e===9||e===32||e===10||e===13}function Le(e){return e===44||e===91||e===93||e===123||e===125}function Fa(e){var t;return 48<=e&&e<=57?e-48:(t=e|32,97<=t&&t<=102?t-97+10:-1)}function Ia(e){return e===120?2:e===117?4:e===85?8:0}function Na(e){return 48<=e&&e<=57?e-48:-1}function vi(e){return e===48?"\0":e===97?"\x07":e===98?"\b":e===116||e===9?"	":e===110?`
`:e===118?"\v":e===102?"\f":e===114?"\r":e===101?"\x1B":e===32?" ":e===34?'"':e===47?"/":e===92?"\\":e===78?"\x85":e===95?"\xA0":e===76?"\u2028":e===80?"\u2029":""}function Ma(e){return e<=65535?String.fromCharCode(e):String.fromCharCode((e-65536>>10)+55296,(e-65536&1023)+56320)}var Pi=new Array(256),Hi=new Array(256);for(we=0;we<256;we++)Pi[we]=vi(we)?1:0,Hi[we]=vi(we);var we;function Ra(e,t){this.input=e,this.filename=t.filename||null,this.schema=t.schema||Ii,this.onWarning=t.onWarning||null,this.legacy=t.legacy||!1,this.json=t.json||!1,this.listener=t.listener||null,this.implicitTypes=this.schema.compiledImplicit,this.typeMap=this.schema.compiledTypeMap,this.length=e.length,this.position=0,this.line=0,this.lineStart=0,this.lineIndent=0,this.firstTabInLine=-1,this.documents=[]}function Ui(e,t){var n={name:e.filename,buffer:e.input.slice(0,-1),position:e.position,line:e.line,column:e.position-e.lineStart};return n.snippet=kr(n),new te(t,n)}function C(e,t){throw Ui(e,t)}function ct(e,t){e.onWarning&&e.onWarning.call(null,Ui(e,t))}var gi={YAML:function(t,n,i){var o,r,a;t.version!==null&&C(t,"duplication of %YAML directive"),i.length!==1&&C(t,"YAML directive accepts exactly one argument"),o=/^([0-9]+)\.([0-9]+)$/.exec(i[0]),o===null&&C(t,"ill-formed argument of the YAML directive"),r=parseInt(o[1],10),a=parseInt(o[2],10),r!==1&&C(t,"unacceptable YAML version of the document"),t.version=i[0],t.checkLineBreaks=a<2,a!==1&&a!==2&&ct(t,"unsupported YAML version of the document")},TAG:function(t,n,i){var o,r;i.length!==2&&C(t,"TAG directive accepts exactly two arguments"),o=i[0],r=i[1],Ri.test(o)||C(t,"ill-formed tag handle (first argument) of the TAG directive"),$e.call(t.tagMap,o)&&C(t,'there is a previously declared suffix for "'+o+'" tag handle'),Di.test(r)||C(t,"ill-formed tag prefix (second argument) of the TAG directive");try{r=decodeURIComponent(r)}catch{C(t,"tag prefix is malformed: "+r)}t.tagMap[o]=r}};function me(e,t,n,i){var o,r,a,s;if(t<n){if(s=e.input.slice(t,n),i)for(o=0,r=s.length;o<r;o+=1)a=s.charCodeAt(o),a===9||32<=a&&a<=1114111||C(e,"expected valid JSON character");else Ea.test(s)&&C(e,"the stream contains non-printable characters");e.result+=s}}function _i(e,t,n,i){var o,r,a,s;for(G.isObject(n)||C(e,"cannot merge mappings; the provided source object is unacceptable"),o=Object.keys(n),a=0,s=o.length;a<s;a+=1)r=o[a],$e.call(t,r)||(t[r]=n[r],i[r]=!0)}function Oe(e,t,n,i,o,r,a,s,l){var u,p;if(Array.isArray(o))for(o=Array.prototype.slice.call(o),u=0,p=o.length;u<p;u+=1)Array.isArray(o[u])&&C(e,"nested arrays are not supported inside keys"),typeof o=="object"&&$i(o[u])==="[object Object]"&&(o[u]="[object Object]");if(typeof o=="object"&&$i(o)==="[object Object]"&&(o="[object Object]"),o=String(o),t===null&&(t={}),i==="tag:yaml.org,2002:merge")if(Array.isArray(r))for(u=0,p=r.length;u<p;u+=1)_i(e,t,r[u],n);else _i(e,t,r,n);else!e.json&&!$e.call(n,o)&&$e.call(t,o)&&(e.line=a||e.line,e.lineStart=s||e.lineStart,e.position=l||e.position,C(e,"duplicated mapping key")),o==="__proto__"?Object.defineProperty(t,o,{configurable:!0,enumerable:!0,writable:!0,value:r}):t[o]=r,delete n[o];return t}function en(e){var t;t=e.input.charCodeAt(e.position),t===10?e.position++:t===13?(e.position++,e.input.charCodeAt(e.position)===10&&e.position++):C(e,"a line break is expected"),e.line+=1,e.lineStart=e.position,e.firstTabInLine=-1}function W(e,t,n){for(var i=0,o=e.input.charCodeAt(e.position);o!==0;){for(;ke(o);)o===9&&e.firstTabInLine===-1&&(e.firstTabInLine=e.position),o=e.input.charCodeAt(++e.position);if(t&&o===35)do o=e.input.charCodeAt(++e.position);while(o!==10&&o!==13&&o!==0);if(ce(o))for(en(e),o=e.input.charCodeAt(e.position),i++,e.lineIndent=0;o===32;)e.lineIndent++,o=e.input.charCodeAt(++e.position);else break}return n!==-1&&i!==0&&e.lineIndent<n&&ct(e,"deficient indentation"),i}function pt(e){var t=e.position,n;return n=e.input.charCodeAt(t),!!((n===45||n===46)&&n===e.input.charCodeAt(t+1)&&n===e.input.charCodeAt(t+2)&&(t+=3,n=e.input.charCodeAt(t),n===0||ne(n)))}function tn(e,t){t===1?e.result+=" ":t>1&&(e.result+=G.repeat(`
`,t-1))}function Da(e,t,n){var i,o,r,a,s,l,u,p,c=e.kind,f=e.result,h;if(h=e.input.charCodeAt(e.position),ne(h)||Le(h)||h===35||h===38||h===42||h===33||h===124||h===62||h===39||h===34||h===37||h===64||h===96||(h===63||h===45)&&(o=e.input.charCodeAt(e.position+1),ne(o)||n&&Le(o)))return!1;for(e.kind="scalar",e.result="",r=a=e.position,s=!1;h!==0;){if(h===58){if(o=e.input.charCodeAt(e.position+1),ne(o)||n&&Le(o))break}else if(h===35){if(i=e.input.charCodeAt(e.position-1),ne(i))break}else{if(e.position===e.lineStart&&pt(e)||n&&Le(h))break;if(ce(h))if(l=e.line,u=e.lineStart,p=e.lineIndent,W(e,!1,-1),e.lineIndent>=t){s=!0,h=e.input.charCodeAt(e.position);continue}else{e.position=a,e.line=l,e.lineStart=u,e.lineIndent=p;break}}s&&(me(e,r,a,!1),tn(e,e.line-l),r=a=e.position,s=!1),ke(h)||(a=e.position+1),h=e.input.charCodeAt(++e.position)}return me(e,r,a,!1),e.result?!0:(e.kind=c,e.result=f,!1)}function Pa(e,t){var n,i,o;if(n=e.input.charCodeAt(e.position),n!==39)return!1;for(e.kind="scalar",e.result="",e.position++,i=o=e.position;(n=e.input.charCodeAt(e.position))!==0;)if(n===39)if(me(e,i,e.position,!0),n=e.input.charCodeAt(++e.position),n===39)i=e.position,e.position++,o=e.position;else return!0;else ce(n)?(me(e,i,o,!0),tn(e,W(e,!1,t)),i=o=e.position):e.position===e.lineStart&&pt(e)?C(e,"unexpected end of the document within a single quoted scalar"):(e.position++,o=e.position);C(e,"unexpected end of the stream within a single quoted scalar")}function Ha(e,t){var n,i,o,r,a,s;if(s=e.input.charCodeAt(e.position),s!==34)return!1;for(e.kind="scalar",e.result="",e.position++,n=i=e.position;(s=e.input.charCodeAt(e.position))!==0;){if(s===34)return me(e,n,e.position,!0),e.position++,!0;if(s===92){if(me(e,n,e.position,!0),s=e.input.charCodeAt(++e.position),ce(s))W(e,!1,t);else if(s<256&&Pi[s])e.result+=Hi[s],e.position++;else if((a=Ia(s))>0){for(o=a,r=0;o>0;o--)s=e.input.charCodeAt(++e.position),(a=Fa(s))>=0?r=(r<<4)+a:C(e,"expected hexadecimal character");e.result+=Ma(r),e.position++}else C(e,"unknown escape sequence");n=i=e.position}else ce(s)?(me(e,n,i,!0),tn(e,W(e,!1,t)),n=i=e.position):e.position===e.lineStart&&pt(e)?C(e,"unexpected end of the document within a double quoted scalar"):(e.position++,i=e.position)}C(e,"unexpected end of the stream within a double quoted scalar")}function Ua(e,t){var n=!0,i,o,r,a=e.tag,s,l=e.anchor,u,p,c,f,h,$=Object.create(null),y,v,m,g;if(g=e.input.charCodeAt(e.position),g===91)p=93,h=!1,s=[];else if(g===123)p=125,h=!0,s={};else return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=s),g=e.input.charCodeAt(++e.position);g!==0;){if(W(e,!0,t),g=e.input.charCodeAt(e.position),g===p)return e.position++,e.tag=a,e.anchor=l,e.kind=h?"mapping":"sequence",e.result=s,!0;n?g===44&&C(e,"expected the node content, but found ','"):C(e,"missed comma between flow collection entries"),v=y=m=null,c=f=!1,g===63&&(u=e.input.charCodeAt(e.position+1),ne(u)&&(c=f=!0,e.position++,W(e,!0,t))),i=e.line,o=e.lineStart,r=e.position,Fe(e,t,st,!1,!0),v=e.tag,y=e.result,W(e,!0,t),g=e.input.charCodeAt(e.position),(f||e.line===i)&&g===58&&(c=!0,g=e.input.charCodeAt(++e.position),W(e,!0,t),Fe(e,t,st,!1,!0),m=e.result),h?Oe(e,s,$,v,y,m,i,o,r):c?s.push(Oe(e,null,$,v,y,m,i,o,r)):s.push(y),W(e,!0,t),g=e.input.charCodeAt(e.position),g===44?(n=!0,g=e.input.charCodeAt(++e.position)):n=!1}C(e,"unexpected end of the stream within a flow collection")}function Ba(e,t){var n,i,o=Gt,r=!1,a=!1,s=t,l=0,u=!1,p,c;if(c=e.input.charCodeAt(e.position),c===124)i=!1;else if(c===62)i=!0;else return!1;for(e.kind="scalar",e.result="";c!==0;)if(c=e.input.charCodeAt(++e.position),c===43||c===45)Gt===o?o=c===43?mi:Ta:C(e,"repeat of a chomping mode identifier");else if((p=Na(c))>=0)p===0?C(e,"bad explicit indentation width of a block scalar; it cannot be less than one"):a?C(e,"repeat of an indentation width identifier"):(s=t+p-1,a=!0);else break;if(ke(c)){do c=e.input.charCodeAt(++e.position);while(ke(c));if(c===35)do c=e.input.charCodeAt(++e.position);while(!ce(c)&&c!==0)}for(;c!==0;){for(en(e),e.lineIndent=0,c=e.input.charCodeAt(e.position);(!a||e.lineIndent<s)&&c===32;)e.lineIndent++,c=e.input.charCodeAt(++e.position);if(!a&&e.lineIndent>s&&(s=e.lineIndent),ce(c)){l++;continue}if(e.lineIndent<s){o===mi?e.result+=G.repeat(`
`,r?1+l:l):o===Gt&&r&&(e.result+=`
`);break}for(i?ke(c)?(u=!0,e.result+=G.repeat(`
`,r?1+l:l)):u?(u=!1,e.result+=G.repeat(`
`,l+1)):l===0?r&&(e.result+=" "):e.result+=G.repeat(`
`,l):e.result+=G.repeat(`
`,r?1+l:l),r=!0,a=!0,l=0,n=e.position;!ce(c)&&c!==0;)c=e.input.charCodeAt(++e.position);me(e,n,e.position,!1)}return!0}function bi(e,t){var n,i=e.tag,o=e.anchor,r=[],a,s=!1,l;if(e.firstTabInLine!==-1)return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=r),l=e.input.charCodeAt(e.position);l!==0&&(e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,C(e,"tab characters must not be used in indentation")),!(l!==45||(a=e.input.charCodeAt(e.position+1),!ne(a))));){if(s=!0,e.position++,W(e,!0,-1)&&e.lineIndent<=t){r.push(null),l=e.input.charCodeAt(e.position);continue}if(n=e.line,Fe(e,t,Mi,!1,!0),r.push(e.result),W(e,!0,-1),l=e.input.charCodeAt(e.position),(e.line===n||e.lineIndent>t)&&l!==0)C(e,"bad indentation of a sequence entry");else if(e.lineIndent<t)break}return s?(e.tag=i,e.anchor=o,e.kind="sequence",e.result=r,!0):!1}function ja(e,t,n){var i,o,r,a,s,l,u=e.tag,p=e.anchor,c={},f=Object.create(null),h=null,$=null,y=null,v=!1,m=!1,g;if(e.firstTabInLine!==-1)return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=c),g=e.input.charCodeAt(e.position);g!==0;){if(!v&&e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,C(e,"tab characters must not be used in indentation")),i=e.input.charCodeAt(e.position+1),r=e.line,(g===63||g===58)&&ne(i))g===63?(v&&(Oe(e,c,f,h,$,null,a,s,l),h=$=y=null),m=!0,v=!0,o=!0):v?(v=!1,o=!0):C(e,"incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"),e.position+=1,g=i;else{if(a=e.line,s=e.lineStart,l=e.position,!Fe(e,n,Ni,!1,!0))break;if(e.line===r){for(g=e.input.charCodeAt(e.position);ke(g);)g=e.input.charCodeAt(++e.position);if(g===58)g=e.input.charCodeAt(++e.position),ne(g)||C(e,"a whitespace character is expected after the key-value separator within a block mapping"),v&&(Oe(e,c,f,h,$,null,a,s,l),h=$=y=null),m=!0,v=!1,o=!1,h=e.tag,$=e.result;else if(m)C(e,"can not read an implicit mapping pair; a colon is missed");else return e.tag=u,e.anchor=p,!0}else if(m)C(e,"can not read a block mapping entry; a multiline key may not be an implicit key");else return e.tag=u,e.anchor=p,!0}if((e.line===r||e.lineIndent>t)&&(v&&(a=e.line,s=e.lineStart,l=e.position),Fe(e,t,lt,!0,o)&&(v?$=e.result:y=e.result),v||(Oe(e,c,f,h,$,y,a,s,l),h=$=y=null),W(e,!0,-1),g=e.input.charCodeAt(e.position)),(e.line===r||e.lineIndent>t)&&g!==0)C(e,"bad indentation of a mapping entry");else if(e.lineIndent<t)break}return v&&Oe(e,c,f,h,$,null,a,s,l),m&&(e.tag=u,e.anchor=p,e.kind="mapping",e.result=c),m}function Ya(e){var t,n=!1,i=!1,o,r,a;if(a=e.input.charCodeAt(e.position),a!==33)return!1;if(e.tag!==null&&C(e,"duplication of a tag property"),a=e.input.charCodeAt(++e.position),a===60?(n=!0,a=e.input.charCodeAt(++e.position)):a===33?(i=!0,o="!!",a=e.input.charCodeAt(++e.position)):o="!",t=e.position,n){do a=e.input.charCodeAt(++e.position);while(a!==0&&a!==62);e.position<e.length?(r=e.input.slice(t,e.position),a=e.input.charCodeAt(++e.position)):C(e,"unexpected end of the stream within a verbatim tag")}else{for(;a!==0&&!ne(a);)a===33&&(i?C(e,"tag suffix cannot contain exclamation marks"):(o=e.input.slice(t-1,e.position+1),Ri.test(o)||C(e,"named tag handle cannot contain such characters"),i=!0,t=e.position+1)),a=e.input.charCodeAt(++e.position);r=e.input.slice(t,e.position),Oa.test(r)&&C(e,"tag suffix cannot contain flow indicator characters")}r&&!Di.test(r)&&C(e,"tag name cannot contain such characters: "+r);try{r=decodeURIComponent(r)}catch{C(e,"tag name is malformed: "+r)}return n?e.tag=r:$e.call(e.tagMap,o)?e.tag=e.tagMap[o]+r:o==="!"?e.tag="!"+r:o==="!!"?e.tag="tag:yaml.org,2002:"+r:C(e,'undeclared tag handle "'+o+'"'),!0}function qa(e){var t,n;if(n=e.input.charCodeAt(e.position),n!==38)return!1;for(e.anchor!==null&&C(e,"duplication of an anchor property"),n=e.input.charCodeAt(++e.position),t=e.position;n!==0&&!ne(n)&&!Le(n);)n=e.input.charCodeAt(++e.position);return e.position===t&&C(e,"name of an anchor node must contain at least one character"),e.anchor=e.input.slice(t,e.position),!0}function Wa(e){var t,n,i;if(i=e.input.charCodeAt(e.position),i!==42)return!1;for(i=e.input.charCodeAt(++e.position),t=e.position;i!==0&&!ne(i)&&!Le(i);)i=e.input.charCodeAt(++e.position);return e.position===t&&C(e,"name of an alias node must contain at least one character"),n=e.input.slice(t,e.position),$e.call(e.anchorMap,n)||C(e,'unidentified alias "'+n+'"'),e.result=e.anchorMap[n],W(e,!0,-1),!0}function Fe(e,t,n,i,o){var r,a,s,l=1,u=!1,p=!1,c,f,h,$,y,v;if(e.listener!==null&&e.listener("open",e),e.tag=null,e.anchor=null,e.kind=null,e.result=null,r=a=s=lt===n||Mi===n,i&&W(e,!0,-1)&&(u=!0,e.lineIndent>t?l=1:e.lineIndent===t?l=0:e.lineIndent<t&&(l=-1)),l===1)for(;Ya(e)||qa(e);)W(e,!0,-1)?(u=!0,s=r,e.lineIndent>t?l=1:e.lineIndent===t?l=0:e.lineIndent<t&&(l=-1)):s=!1;if(s&&(s=u||o),(l===1||lt===n)&&(st===n||Ni===n?y=t:y=t+1,v=e.position-e.lineStart,l===1?s&&(bi(e,v)||ja(e,v,y))||Ua(e,y)?p=!0:(a&&Ba(e,y)||Pa(e,y)||Ha(e,y)?p=!0:Wa(e)?(p=!0,(e.tag!==null||e.anchor!==null)&&C(e,"alias node should not have any properties")):Da(e,y,st===n)&&(p=!0,e.tag===null&&(e.tag="?")),e.anchor!==null&&(e.anchorMap[e.anchor]=e.result)):l===0&&(p=s&&bi(e,v))),e.tag===null)e.anchor!==null&&(e.anchorMap[e.anchor]=e.result);else if(e.tag==="?"){for(e.result!==null&&e.kind!=="scalar"&&C(e,'unacceptable node kind for !<?> tag; it should be "scalar", not "'+e.kind+'"'),c=0,f=e.implicitTypes.length;c<f;c+=1)if($=e.implicitTypes[c],$.resolve(e.result)){e.result=$.construct(e.result),e.tag=$.tag,e.anchor!==null&&(e.anchorMap[e.anchor]=e.result);break}}else if(e.tag!=="!"){if($e.call(e.typeMap[e.kind||"fallback"],e.tag))$=e.typeMap[e.kind||"fallback"][e.tag];else for($=null,h=e.typeMap.multi[e.kind||"fallback"],c=0,f=h.length;c<f;c+=1)if(e.tag.slice(0,h[c].tag.length)===h[c].tag){$=h[c];break}$||C(e,"unknown tag !<"+e.tag+">"),e.result!==null&&$.kind!==e.kind&&C(e,"unacceptable node kind for !<"+e.tag+'> tag; it should be "'+$.kind+'", not "'+e.kind+'"'),$.resolve(e.result,e.tag)?(e.result=$.construct(e.result,e.tag),e.anchor!==null&&(e.anchorMap[e.anchor]=e.result)):C(e,"cannot resolve a node with !<"+e.tag+"> explicit tag")}return e.listener!==null&&e.listener("close",e),e.tag!==null||e.anchor!==null||p}function Ka(e){var t=e.position,n,i,o,r=!1,a;for(e.version=null,e.checkLineBreaks=e.legacy,e.tagMap=Object.create(null),e.anchorMap=Object.create(null);(a=e.input.charCodeAt(e.position))!==0&&(W(e,!0,-1),a=e.input.charCodeAt(e.position),!(e.lineIndent>0||a!==37));){for(r=!0,a=e.input.charCodeAt(++e.position),n=e.position;a!==0&&!ne(a);)a=e.input.charCodeAt(++e.position);for(i=e.input.slice(n,e.position),o=[],i.length<1&&C(e,"directive name must not be less than one character in length");a!==0;){for(;ke(a);)a=e.input.charCodeAt(++e.position);if(a===35){do a=e.input.charCodeAt(++e.position);while(a!==0&&!ce(a));break}if(ce(a))break;for(n=e.position;a!==0&&!ne(a);)a=e.input.charCodeAt(++e.position);o.push(e.input.slice(n,e.position))}a!==0&&en(e),$e.call(gi,i)?gi[i](e,i,o):ct(e,'unknown document directive "'+i+'"')}if(W(e,!0,-1),e.lineIndent===0&&e.input.charCodeAt(e.position)===45&&e.input.charCodeAt(e.position+1)===45&&e.input.charCodeAt(e.position+2)===45?(e.position+=3,W(e,!0,-1)):r&&C(e,"directives end mark is expected"),Fe(e,e.lineIndent-1,lt,!1,!0),W(e,!0,-1),e.checkLineBreaks&&La.test(e.input.slice(t,e.position))&&ct(e,"non-ASCII line breaks are interpreted as content"),e.documents.push(e.result),e.position===e.lineStart&&pt(e)){e.input.charCodeAt(e.position)===46&&(e.position+=3,W(e,!0,-1));return}if(e.position<e.length-1)C(e,"end of the stream or a document separator is expected");else return}function Bi(e,t){e=String(e),t=t||{},e.length!==0&&(e.charCodeAt(e.length-1)!==10&&e.charCodeAt(e.length-1)!==13&&(e+=`
`),e.charCodeAt(0)===65279&&(e=e.slice(1)));var n=new Ra(e,t),i=e.indexOf("\0");for(i!==-1&&(n.position=i,C(n,"null byte is not allowed in input")),n.input+="\0";n.input.charCodeAt(n.position)===32;)n.lineIndent+=1,n.position+=1;for(;n.position<n.length-1;)Ka(n);return n.documents}function Ga(e,t,n){t!==null&&typeof t=="object"&&typeof n>"u"&&(n=t,t=null);var i=Bi(e,n);if(typeof t!="function")return i;for(var o=0,r=i.length;o<r;o+=1)t(i[o])}function Va(e,t){var n=Bi(e,t);if(n.length!==0){if(n.length===1)return n[0];throw new te("expected a single document in the stream, but found more")}}var Qa=Ga,Xa=Va,ji={loadAll:Qa,load:Xa},Yi=Object.prototype.toString,qi=Object.prototype.hasOwnProperty,nn=65279,za=9,Ge=10,Ja=13,Za=32,es=33,ts=34,Qt=35,ns=37,is=38,os=39,rs=42,Wi=44,as=45,ut=58,ss=61,ls=62,cs=63,us=64,Ki=91,Gi=93,ds=96,Vi=123,ps=124,Qi=125,J={};J[0]="\\0";J[7]="\\a";J[8]="\\b";J[9]="\\t";J[10]="\\n";J[11]="\\v";J[12]="\\f";J[13]="\\r";J[27]="\\e";J[34]='\\"';J[92]="\\\\";J[133]="\\N";J[160]="\\_";J[8232]="\\L";J[8233]="\\P";var fs=["y","Y","yes","Yes","YES","on","On","ON","n","N","no","No","NO","off","Off","OFF"],hs=/^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;function ms(e,t){var n,i,o,r,a,s,l;if(t===null)return{};for(n={},i=Object.keys(t),o=0,r=i.length;o<r;o+=1)a=i[o],s=String(t[a]),a.slice(0,2)==="!!"&&(a="tag:yaml.org,2002:"+a.slice(2)),l=e.compiledTypeMap.fallback[a],l&&qi.call(l.styleAliases,s)&&(s=l.styleAliases[s]),n[a]=s;return n}function $s(e){var t,n,i;if(t=e.toString(16).toUpperCase(),e<=255)n="x",i=2;else if(e<=65535)n="u",i=4;else if(e<=4294967295)n="U",i=8;else throw new te("code point within a string may not be greater than 0xFFFFFFFF");return"\\"+n+G.repeat("0",i-t.length)+t}var vs=1,Ve=2;function gs(e){this.schema=e.schema||Ii,this.indent=Math.max(1,e.indent||2),this.noArrayIndent=e.noArrayIndent||!1,this.skipInvalid=e.skipInvalid||!1,this.flowLevel=G.isNothing(e.flowLevel)?-1:e.flowLevel,this.styleMap=ms(this.schema,e.styles||null),this.sortKeys=e.sortKeys||!1,this.lineWidth=e.lineWidth||80,this.noRefs=e.noRefs||!1,this.noCompatMode=e.noCompatMode||!1,this.condenseFlow=e.condenseFlow||!1,this.quotingType=e.quotingType==='"'?Ve:vs,this.forceQuotes=e.forceQuotes||!1,this.replacer=typeof e.replacer=="function"?e.replacer:null,this.implicitTypes=this.schema.compiledImplicit,this.explicitTypes=this.schema.compiledExplicit,this.tag=null,this.result="",this.duplicates=[],this.usedDuplicates=null}function yi(e,t){for(var n=G.repeat(" ",t),i=0,o=-1,r="",a,s=e.length;i<s;)o=e.indexOf(`
`,i),o===-1?(a=e.slice(i),i=s):(a=e.slice(i,o+1),i=o+1),a.length&&a!==`
`&&(r+=n),r+=a;return r}function Xt(e,t){return`
`+G.repeat(" ",e.indent*t)}function _s(e,t){var n,i,o;for(n=0,i=e.implicitTypes.length;n<i;n+=1)if(o=e.implicitTypes[n],o.resolve(t))return!0;return!1}function dt(e){return e===Za||e===za}function Qe(e){return 32<=e&&e<=126||161<=e&&e<=55295&&e!==8232&&e!==8233||57344<=e&&e<=65533&&e!==nn||65536<=e&&e<=1114111}function wi(e){return Qe(e)&&e!==nn&&e!==Ja&&e!==Ge}function ki(e,t,n){var i=wi(e),o=i&&!dt(e);return(n?i:i&&e!==Wi&&e!==Ki&&e!==Gi&&e!==Vi&&e!==Qi)&&e!==Qt&&!(t===ut&&!o)||wi(t)&&!dt(t)&&e===Qt||t===ut&&o}function bs(e){return Qe(e)&&e!==nn&&!dt(e)&&e!==as&&e!==cs&&e!==ut&&e!==Wi&&e!==Ki&&e!==Gi&&e!==Vi&&e!==Qi&&e!==Qt&&e!==is&&e!==rs&&e!==es&&e!==ps&&e!==ss&&e!==ls&&e!==os&&e!==ts&&e!==ns&&e!==us&&e!==ds}function ys(e){return!dt(e)&&e!==ut}function We(e,t){var n=e.charCodeAt(t),i;return n>=55296&&n<=56319&&t+1<e.length&&(i=e.charCodeAt(t+1),i>=56320&&i<=57343)?(n-55296)*1024+i-56320+65536:n}function Xi(e){var t=/^\n* /;return t.test(e)}var zi=1,zt=2,Ji=3,Zi=4,Ee=5;function ws(e,t,n,i,o,r,a,s){var l,u=0,p=null,c=!1,f=!1,h=i!==-1,$=-1,y=bs(We(e,0))&&ys(We(e,e.length-1));if(t||a)for(l=0;l<e.length;u>=65536?l+=2:l++){if(u=We(e,l),!Qe(u))return Ee;y=y&&ki(u,p,s),p=u}else{for(l=0;l<e.length;u>=65536?l+=2:l++){if(u=We(e,l),u===Ge)c=!0,h&&(f=f||l-$-1>i&&e[$+1]!==" ",$=l);else if(!Qe(u))return Ee;y=y&&ki(u,p,s),p=u}f=f||h&&l-$-1>i&&e[$+1]!==" "}return!c&&!f?y&&!a&&!o(e)?zi:r===Ve?Ee:zt:n>9&&Xi(e)?Ee:a?r===Ve?Ee:zt:f?Zi:Ji}function ks(e,t,n,i,o){e.dump=function(){if(t.length===0)return e.quotingType===Ve?'""':"''";if(!e.noCompatMode&&(fs.indexOf(t)!==-1||hs.test(t)))return e.quotingType===Ve?'"'+t+'"':"'"+t+"'";var r=e.indent*Math.max(1,n),a=e.lineWidth===-1?-1:Math.max(Math.min(e.lineWidth,40),e.lineWidth-r),s=i||e.flowLevel>-1&&n>=e.flowLevel;function l(u){return _s(e,u)}switch(ws(t,s,e.indent,a,l,e.quotingType,e.forceQuotes&&!i,o)){case zi:return t;case zt:return"'"+t.replace(/'/g,"''")+"'";case Ji:return"|"+xi(t,e.indent)+Ci(yi(t,r));case Zi:return">"+xi(t,e.indent)+Ci(yi(xs(t,a),r));case Ee:return'"'+Cs(t)+'"';default:throw new te("impossible error: invalid scalar style")}}()}function xi(e,t){var n=Xi(e)?String(t):"",i=e[e.length-1]===`
`,o=i&&(e[e.length-2]===`
`||e===`
`),r=o?"+":i?"":"-";return n+r+`
`}function Ci(e){return e[e.length-1]===`
`?e.slice(0,-1):e}function xs(e,t){for(var n=/(\n+)([^\n]*)/g,i=function(){var u=e.indexOf(`
`);return u=u!==-1?u:e.length,n.lastIndex=u,Si(e.slice(0,u),t)}(),o=e[0]===`
`||e[0]===" ",r,a;a=n.exec(e);){var s=a[1],l=a[2];r=l[0]===" ",i+=s+(!o&&!r&&l!==""?`
`:"")+Si(l,t),o=r}return i}function Si(e,t){if(e===""||e[0]===" ")return e;for(var n=/ [^ ]/g,i,o=0,r,a=0,s=0,l="";i=n.exec(e);)s=i.index,s-o>t&&(r=a>o?a:s,l+=`
`+e.slice(o,r),o=r+1),a=s;return l+=`
`,e.length-o>t&&a>o?l+=e.slice(o,a)+`
`+e.slice(a+1):l+=e.slice(o),l.slice(1)}function Cs(e){for(var t="",n=0,i,o=0;o<e.length;n>=65536?o+=2:o++)n=We(e,o),i=J[n],!i&&Qe(n)?(t+=e[o],n>=65536&&(t+=e[o+1])):t+=i||$s(n);return t}function Ss(e,t,n){var i="",o=e.tag,r,a,s;for(r=0,a=n.length;r<a;r+=1)s=n[r],e.replacer&&(s=e.replacer.call(n,String(r),s)),(fe(e,t,s,!1,!1)||typeof s>"u"&&fe(e,t,null,!1,!1))&&(i!==""&&(i+=","+(e.condenseFlow?"":" ")),i+=e.dump);e.tag=o,e.dump="["+i+"]"}function Ai(e,t,n,i){var o="",r=e.tag,a,s,l;for(a=0,s=n.length;a<s;a+=1)l=n[a],e.replacer&&(l=e.replacer.call(n,String(a),l)),(fe(e,t+1,l,!0,!0,!1,!0)||typeof l>"u"&&fe(e,t+1,null,!0,!0,!1,!0))&&((!i||o!=="")&&(o+=Xt(e,t)),e.dump&&Ge===e.dump.charCodeAt(0)?o+="-":o+="- ",o+=e.dump);e.tag=r,e.dump=o||"[]"}function As(e,t,n){var i="",o=e.tag,r=Object.keys(n),a,s,l,u,p;for(a=0,s=r.length;a<s;a+=1)p="",i!==""&&(p+=", "),e.condenseFlow&&(p+='"'),l=r[a],u=n[l],e.replacer&&(u=e.replacer.call(n,l,u)),fe(e,t,l,!1,!1)&&(e.dump.length>1024&&(p+="? "),p+=e.dump+(e.condenseFlow?'"':"")+":"+(e.condenseFlow?"":" "),fe(e,t,u,!1,!1)&&(p+=e.dump,i+=p));e.tag=o,e.dump="{"+i+"}"}function Ts(e,t,n,i){var o="",r=e.tag,a=Object.keys(n),s,l,u,p,c,f;if(e.sortKeys===!0)a.sort();else if(typeof e.sortKeys=="function")a.sort(e.sortKeys);else if(e.sortKeys)throw new te("sortKeys must be a boolean or a function");for(s=0,l=a.length;s<l;s+=1)f="",(!i||o!=="")&&(f+=Xt(e,t)),u=a[s],p=n[u],e.replacer&&(p=e.replacer.call(n,u,p)),fe(e,t+1,u,!0,!0,!0)&&(c=e.tag!==null&&e.tag!=="?"||e.dump&&e.dump.length>1024,c&&(e.dump&&Ge===e.dump.charCodeAt(0)?f+="?":f+="? "),f+=e.dump,c&&(f+=Xt(e,t)),fe(e,t+1,p,!0,c)&&(e.dump&&Ge===e.dump.charCodeAt(0)?f+=":":f+=": ",f+=e.dump,o+=f));e.tag=r,e.dump=o||"{}"}function Ti(e,t,n){var i,o,r,a,s,l;for(o=n?e.explicitTypes:e.implicitTypes,r=0,a=o.length;r<a;r+=1)if(s=o[r],(s.instanceOf||s.predicate)&&(!s.instanceOf||typeof t=="object"&&t instanceof s.instanceOf)&&(!s.predicate||s.predicate(t))){if(n?s.multi&&s.representName?e.tag=s.representName(t):e.tag=s.tag:e.tag="?",s.represent){if(l=e.styleMap[s.tag]||s.defaultStyle,Yi.call(s.represent)==="[object Function]")i=s.represent(t,l);else if(qi.call(s.represent,l))i=s.represent[l](t,l);else throw new te("!<"+s.tag+'> tag resolver accepts not "'+l+'" style');e.dump=i}return!0}return!1}function fe(e,t,n,i,o,r,a){e.tag=null,e.dump=n,Ti(e,n,!1)||Ti(e,n,!0);var s=Yi.call(e.dump),l=i,u;i&&(i=e.flowLevel<0||e.flowLevel>t);var p=s==="[object Object]"||s==="[object Array]",c,f;if(p&&(c=e.duplicates.indexOf(n),f=c!==-1),(e.tag!==null&&e.tag!=="?"||f||e.indent!==2&&t>0)&&(o=!1),f&&e.usedDuplicates[c])e.dump="*ref_"+c;else{if(p&&f&&!e.usedDuplicates[c]&&(e.usedDuplicates[c]=!0),s==="[object Object]")i&&Object.keys(e.dump).length!==0?(Ts(e,t,e.dump,o),f&&(e.dump="&ref_"+c+e.dump)):(As(e,t,e.dump),f&&(e.dump="&ref_"+c+" "+e.dump));else if(s==="[object Array]")i&&e.dump.length!==0?(e.noArrayIndent&&!a&&t>0?Ai(e,t-1,e.dump,o):Ai(e,t,e.dump,o),f&&(e.dump="&ref_"+c+e.dump)):(Ss(e,t,e.dump),f&&(e.dump="&ref_"+c+" "+e.dump));else if(s==="[object String]")e.tag!=="?"&&ks(e,e.dump,t,r,l);else{if(s==="[object Undefined]")return!1;if(e.skipInvalid)return!1;throw new te("unacceptable kind of an object to dump "+s)}e.tag!==null&&e.tag!=="?"&&(u=encodeURI(e.tag[0]==="!"?e.tag.slice(1):e.tag).replace(/!/g,"%21"),e.tag[0]==="!"?u="!"+u:u.slice(0,18)==="tag:yaml.org,2002:"?u="!!"+u.slice(18):u="!<"+u+">",e.dump=u+" "+e.dump)}return!0}function Es(e,t){var n=[],i=[],o,r;for(Jt(e,n,i),o=0,r=i.length;o<r;o+=1)t.duplicates.push(n[i[o]]);t.usedDuplicates=new Array(r)}function Jt(e,t,n){var i,o,r;if(e!==null&&typeof e=="object")if(o=t.indexOf(e),o!==-1)n.indexOf(o)===-1&&n.push(o);else if(t.push(e),Array.isArray(e))for(o=0,r=e.length;o<r;o+=1)Jt(e[o],t,n);else for(i=Object.keys(e),o=0,r=i.length;o<r;o+=1)Jt(e[i[o]],t,n)}function Ls(e,t){t=t||{};var n=new gs(t);n.noRefs||Es(e,n);var i=e;return n.replacer&&(i=n.replacer.call({"":i},"",i)),fe(n,0,i,!0,!0)?n.dump+`
`:""}var Os=Ls,Fs={dump:Os};function on(e,t){return function(){throw new Error("Function yaml."+e+" is removed in js-yaml 4. Use yaml."+t+" instead, which is now safe by default.")}}var eo=ji.load,yc=ji.loadAll,to=Fs.dump;var wc=on("safeLoad","load"),kc=on("safeLoadAll","loadAll"),xc=on("safeDump","dump");var ft;function ve(){let[e,t]=_([]);return X(()=>{ft=ft||j.list().catch(()=>(ft=void 0,[])),ft.then(t)},[]),e}var re=e=>e?`${e.type}:${e.id}`:"",Is=e=>{let[t,n]=e.split(":").map(Number);return{type:t,id:n}};function Z(e,t){if(!t)return"\u2014";let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n&&n.name?n.name:`${n?n.type_name:"type "+t.type} / 0x${t.id.toString(16).padStart(2,"0")}`}var Xe;function vt(){let[e,t]=_(new Map);return X(()=>{Xe=Xe||A.devices.list().then(n=>new Map(n.map(i=>[re(i.device),i.features]))).catch(()=>(Xe=void 0,new Map)),Xe.then(t)},[]),e}var io=()=>Xe=void 0,oo=[["extension","Extension board (buttons 4\u20137)"],["pir","Motion detector (PIR)"],["nightlight","Night light"],["veml7700","Brightness (VEML7700)"],["bme680","BME680"],["bme280","BME280"],["dht22","DHT22"],["scd30","SCD30 (CO\u2082)"]];function gt(e,t,n){let i=e.filter(o=>(t.get(re({type:o.device_type,id:o.device_id}))||[]).includes(n));return i.length?i:e}var ro=(e,t,n)=>(e.get(re(t))||[]).includes(n);function an(e,t){let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n?n.name||n.key:"0x"+(268435456+(t.type<<16)+(t.id<<8)).toString(16)}function ae({value:e,onChange:t,devices:n,types:i}){let o=n.filter(s=>!i||i.includes(s.device_type)),r=re(e),a=o.some(s=>re({type:s.device_type,id:s.device_id})===r);return d`<div class="device-select">
    <select value=${a?r:e?"manual":""} onChange=${s=>{let l=s.target.value;l==="manual"?t(e||{type:i&&i[0]||0,id:1}):l&&t(Is(l))}}>
      <option value="" disabled>Choose a device…</option>
      ${o.map(s=>d`<option value=${re({type:s.device_type,id:s.device_id})}>
          ${Z(n,{type:s.device_type,id:s.device_id})} (${s.type_name})
        </option>`)}
      <option value="manual">Other: type and id…</option>
    </select>
    ${e&&!a&&d`<span class="pair">
      <input type="number" min="0" max="63" title="Device type" value=${e.type} onInput=${s=>t({...e,type:+s.target.value})} />
      <input type="number" min="1" max="255" title="Device id" value=${e.id} onInput=${s=>t({...e,id:+s.target.value})} />
    </span>`}
  </div>`}var ao=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]],Ns=e=>(ao.find(([t])=>t===e)||[e,e])[1],mt=e=>String(e).padStart(2,"0");function Ie(e){if(!e)return"";if(e.clock)return`${mt(e.clock.hour)}:${mt(e.clock.minute)}`;let t=e.sun.offset_min||0;return Ns(e.sun.event)+(t?` ${t>0?"+":"\u2212"} ${Math.abs(t)} min`:"")}function Ne({value:e,onChange:t}){let n=!!e.sun;return d`<span class="time-edit">
    <select value=${n?"sun":"clock"} onChange=${i=>t(i.target.value==="sun"?{sun:{event:"sunset",offset_min:0}}:{clock:{hour:22,minute:0}})}>
      <option value="clock">Clock</option>
      <option value="sun">Sun</option>
    </select>
    ${n?d`<select value=${e.sun.event} onChange=${i=>t({sun:{...e.sun,event:i.target.value}})}>
            ${ao.map(([i,o])=>d`<option value=${i}>${o}</option>`)}
          </select>
          <input type="number" class="short" min="-720" max="720" title="Offset in minutes (negative: before)" value=${e.sun.offset_min||0}
            onInput=${i=>t({sun:{...e.sun,offset_min:+i.target.value}})} /><small>min</small>`:d`<input type="time" value=${`${mt(e.clock.hour)}:${mt(e.clock.minute)}`} onInput=${i=>{let[o,r]=i.target.value.split(":").map(Number);isNaN(o)||t({clock:{hour:o,minute:r||0}})}} />`}
  </span>`}var Ms=[["dark","Darker than"],["bright","At least as bright as"],["between","Time between"],["sun_below","Sun lower than"],["sun_above","Sun at least"]],Rs=(e,t)=>{let n={type:0,id:1};switch(e){case"dark":case"bright":return{[e]:{sensor:n,lux:40}};case"between":return{between:{from:{clock:{hour:22,minute:0}},to:{clock:{hour:6,minute:0}}}};default:return{[e]:{degrees:-6}}}},so=e=>Object.keys(e)[0];function sn(e,t){let n=so(e),i=e[n];switch(n){case"dark":return`darker than ${i.lux} lx at ${Z(t,i.sensor)}`;case"bright":return`at least ${i.lux} lx at ${Z(t,i.sensor)}`;case"between":return`between ${Ie(i.from)} and ${Ie(i.to)}`;case"sun_below":return`sun below ${i.degrees}\xB0`;case"sun_above":return`sun at least ${i.degrees}\xB0`}return n}var ht;function Ds(){let[e,t]=_([]);return X(()=>{ht=ht||pe.list().then(n=>n.filter(i=>i.kind==="brightness")).catch(()=>(ht=void 0,[])),ht.then(t)},[]),e}function ln({value:e,onChange:t,devices:n}){let i=so(e),o=e[i],r=Ds(),a=n.filter(l=>r.some(u=>u.device_key.toLowerCase()===l.key.toLowerCase())),s=l=>t({[i]:{...o,...l}});return d`<span class="condition">
    <select value=${i} onChange=${l=>t(Rs(l.target.value,n))}>
      ${Ms.map(([l,u])=>d`<option value=${l}>${u}</option>`)}
    </select>
    ${(i==="dark"||i==="bright")&&d`<input type="number" class="short" min="0" value=${o.lux} onInput=${l=>s({lux:+l.target.value})} /><small>lx at</small>
      <${ae} value=${o.sensor.type?o.sensor:null} devices=${a.length?a:n} onChange=${l=>s({sensor:l})} />`}
    ${i==="between"&&d`<${Ne} value=${o.from} onChange=${l=>s({from:l})} /><small>and</small><${Ne} value=${o.to} onChange=${l=>s({to:l})} />`}
    ${(i==="sun_below"||i==="sun_above")&&d`<input type="number" class="short" min="-90" max="90" value=${o.degrees} onInput=${l=>s({degrees:+l.target.value})} /><small>° (−6: civil twilight ends)</small>`}
  </span>`}function se({items:e,onChange:t,max:n,make:i,render:o,addLabel:r}){return d`<div class="list-edit">
    ${e.map((a,s)=>d`<div class="list-row" key=${s}>
        <div class="list-body">${o(a,l=>t(e.map((u,p)=>p===s?l:u)),s)}</div>
        <button class="icon" title="Remove" onClick=${()=>t(e.filter((l,u)=>u!==s))}>×</button>
      </div>`)}
    ${e.length<n&&d`<button onClick=${()=>t([...e,i()])}>+ ${r}</button>`}
  </div>`}var cn=[["light","Light (levels)"],["dimmer","Dimmer (0\u2013255)"],["relay","Relay"],["shutter","Roller shutter"],["group","Group"]],$t={light:[["toggle","Toggle"],["on","On (last level)"],["at_least","On, at least level",!0],["off","Off"],["set","Level",!0],["max","Brightest"],["inc","Brighter"],["dec","Darker"]],dimmer:[["toggle","Toggle"],["on","On (last value)"],["at_least","On, at least value",!0],["off","Off"],["set","Value",!0],["max","Full"],["inc","Brighter"],["dec","Darker"]],relay:[["toggle","Toggle"],["on","On"],["off","Off"],["on_for","On for (ms)",!0]],shutter:[["up","Up / stop"],["down","Down / stop"],["up_hold","Up (while held)"],["down_hold","Down (while held)"],["stop","Stop"]],group:[["toggle","Toggle"],["on","On"],["off","Off"],["up","Up / stop"],["down","Down / stop"],["stop","Stop"]]},lo=e=>typeof e=="string"?[e,void 0]:[Object.keys(e)[0],Object.values(e)[0]],no=(e,t)=>t===void 0?e:{[e]:t};function co(e,t){let[n,i]=lo(e),o=($t[t]||Object.values($t).flat()).find(([a])=>a===n),r=o?o[1].replace(/ \(.*\)$/,""):n;return i===void 0?r:`${r} ${i}`}function uo({value:e,onChange:t,kind:n}){let i=$t[n]||$t.light,[o,r]=lo(e),a=s=>(i.find(([l])=>l===s)||[])[2];return d`<span class="op">
    <select value=${o} onChange=${s=>t(no(s.target.value,a(s.target.value)?s.target.value==="on_for"?6e4:1:void 0))}>
      ${i.map(([s,l])=>d`<option value=${s}>${l}</option>`)}
    </select>
    ${a(o)&&d`<input type="number" class="short" min="0" value=${r} onInput=${s=>t(no(o,+s.target.value))} />`}
  </span>`}var ze=e=>to(e,{flowLevel:0,lineWidth:-1}).trim(),un=e=>e===null||typeof e!="object",Ps=e=>(Array.isArray(e)?e:Object.values(e)).every(un)&&ze(e).length<=60;function rn(e,t){let n=[],i=Array.isArray(e)?e.map(o=>[null,o]):Object.entries(e);if(!i.length)return[t+ze(e)];for(let[o,r]of i){let a=o===null?"- ":`${ze(o)}: `;if(un(r)||Ps(r))n.push(t+a+ze(r));else if(o===null){let s=rn(r,t+"  ");n.push(t+"- "+s[0].slice(t.length+2),...s.slice(1))}else n.push(t+a.trimEnd(),...rn(r,t+"  "))}return n}var _t=e=>(un(e)?ze(e):rn(e,"").join(`
`))+`
`,bt=e=>eo(e);function Me({title:e,intro:t,children:n,onSave:i,onCancel:o,error:r,value:a,onText:s}){let[l,u]=_(!1),[p,c]=_(null),[f,h]=_(""),$=()=>{try{let m=bt(p);if(!m||typeof m!="object")throw new Error("not an object");return h(""),m}catch(m){h(m.message);return}},y=()=>{if(p===null)return;let m=$();m!==void 0&&(s(m),c(null))},v=async()=>{let m;if(!(p!==null&&(m=$())===void 0)){u(!0);try{await i(m)}finally{u(!1)}}};return d`<section class="card editor">
    <header><h2>${e}</h2>
      ${a!==void 0&&d`<div class="seg" role="group" aria-label="Edit as">
        <button class=${p===null?"active":""} onClick=${y}>Form</button>
        <button class=${p!==null?"active":""} onClick=${()=>p===null&&c(_t(a))}>YAML</button>
      </div>`}
    </header>
    ${t&&d`<p class="muted intro">${t}</p>`}
    ${p===null?n:d`<textarea class="code" rows=${Math.min(30,Math.max(8,p.split(`
`).length+1))} spellcheck="false"
          value=${p} onInput=${m=>c(m.target.value)} />
          ${f&&d`<p class="error">${f}</p>`}
          <p class="muted">Back to the form with <em>Form</em>; <em>Save</em> saves the text as it is.</p>`}
    ${r&&d`<p class="error">${r}</p>`}
    <div class="buttons">
      <button class="primary" disabled=${l} onClick=${v}>Save</button>
      <button onClick=${o}>Cancel</button>
    </div>
  </section>`}var Re=e=>e.field?`${e.field}: ${e.message}`:e.message;var Hs=/^[A-Za-z0-9_-]{1,20}$/,po=["Mo","Tu","We","Th","Fr","Sa","Su"],fo=e=>(e||[]).filter(t=>["light","dimmer","relay"].includes(t.kind));function ho({value:e,onChange:t,outputs:n}){return d`<select value=${e} onChange=${i=>t(i.target.value)}>
    ${!n.some(i=>i.name===e)&&d`<option value=${e}>${e||"Choose\u2026"}</option>`}
    ${n.map(i=>d`<option value=${i.name}>${i.name}</option>`)}
  </select>`}function Us({title:e,intro:t,oldName:n,initial:i,api:o,done:r,children:a}){let[s,l]=_(n||""),[u,p]=_(i),[c,f]=_(""),h=async $=>{let y=$||u;if(!Hs.test(s))return f("Name: 1\u201320 letters, digits, - and _");if(JSON.stringify(y).includes('"sensor":{"type":0,'))return f("Choose the brightness sensor");let v=y.detectors?{...y,detectors:y.detectors.filter(Boolean)}:y;try{await o.put(s,v),n&&n!==s&&await o.remove(n),M(`${s} saved`),r(!0)}catch(m){f(Re(m))}};return d`<${Me} title=${n?`${e} ${n}`:`New ${e.toLowerCase()}`} onSave=${h} onCancel=${()=>r(!1)} error=${c}
    value=${u} onText=${p} intro=${t}>
    <div class="row">
      <${T} label="Name" hint="Letters, digits, - and _; also the MQTT topic and the switch in Home Assistant">
        <input value=${s} maxlength="20" onInput=${$=>l($.target.value.trim())} />
      <//>
    </div>
    ${a(u,p)}
  <//>`}var Bs=e=>({detectors:[],output:e[0]?e[0].name:"",timeout_s:180,lockout_s:60,levels:[],conditions:[]}),js="Motion switches the output on; it goes off again after a while without motion. Switched on by hand (a button, Home Assistant), it stays on until switched off. After it went off, motion is ignored for a moment, so it does not come straight back on for someone leaving.";function Ys({value:e,onChange:t}){let n=e.level!==void 0&&e.level!==null;return d`<span class="period">
    <small>From</small><${Ne} value=${e.from} onChange=${i=>t({...e,from:i})} />
    <select aria-label="Level" value=${n?"fixed":"last"} onChange=${i=>t(i.target.value==="fixed"?{from:e.from,level:1}:{from:e.from,min:1})}>
      <option value="fixed">always level</option>
      <option value="last">the last level, at least</option>
    </select>
    <input type="number" class="short" min="1" max="255" aria-label="Level" value=${n?e.level:e.min||0}
      onInput=${i=>t(n?{from:e.from,level:+i.target.value}:{from:e.from,min:+i.target.value})} />
  </span>`}function qs({m:e,set:t,outputs:n,devices:i,features:o}){let r=a=>t({...e,...a});return d`
    <div class="row">
      <${T} label="Switches"><${ho} value=${e.output} outputs=${n} onChange=${a=>r({output:a})} /><//>
      <${T} label="Off after no motion for (min)">
        <input type="number" min="0.1" max="1440" step="0.5" value=${e.timeout_s/60} onInput=${a=>r({timeout_s:Math.max(1,Math.round(+a.target.value*60))})} />
      <//>
      <${T} label="Then ignore motion for (s)" hint="So it doesn't come straight back on for someone leaving">
        <input type="number" min="0" max="3600" value=${e.lockout_s} onInput=${a=>r({lockout_s:+a.target.value})} />
      <//>
    </div>
    <h3>Motion detectors</h3>
    <p class="muted">Switches with a PIR (marked on their device page).</p>
    <${se} items=${e.detectors} max=${4} addLabel="motion detector" onChange=${a=>r({detectors:a})}
      make=${()=>null}
      render=${(a,s)=>d`<${ae} value=${a} devices=${gt(i,o,"pir")} onChange=${s} />`} />
    <h3>Level by the time of day</h3>
    <p class="muted">Without any: the level it had last. E.g. from 22:00 always level 1; from sunrise the last level, but at least 4.</p>
    <${se} items=${e.levels||[]} max=${4} addLabel="time of day" onChange=${a=>r({levels:a})}
      make=${()=>({from:{clock:{hour:22,minute:0}},level:1})}
      render=${(a,s)=>d`<${Ys} value=${a} onChange=${s} />`} />
    <h3>Only switches on if</h3>
    <p class="muted">All of these hold. One that can't be told (no reading, no clock) counts as holding. Switching it on by hand stops the timer until it is switched off.</p>
    <${se} items=${e.conditions||[]} max=${3} addLabel="condition" onChange=${a=>r({conditions:a})}
      make=${()=>({sun_below:{degrees:-6}})}
      render=${(a,s)=>d`<${ln} value=${a} devices=${i} onChange=${s} />`} />`}var Ws="Switches an output on and off in time windows: by the clock, relative to the sun, and off early when it gets bright. Only the start and the end switch, so switching it off by hand in between sticks. Sun times use the location on the Gateway page.",mo=()=>({start:{sun:{event:"civil_dusk",offset_min:-30}},end:[{at:{clock:{hour:23,minute:0}}}],days:127});function Ks({value:e,onChange:t,devices:n}){let i=!!e.bright;return d`<span class="end">
    <select value=${i?"bright":"at"} onChange=${o=>t(o.target.value==="bright"?{bright:{sensor:{type:0,id:1},lux:200,for_min:5}}:{at:{clock:{hour:8,minute:0}}})}>
      <option value="at">At</option>
      <option value="bright">When bright</option>
    </select>
    ${i?d`<input type="number" class="short" min="0" value=${e.bright.lux} onInput=${o=>t({bright:{...e.bright,lux:+o.target.value}})} /><small>lx for</small>
          <input type="number" class="short" min="0" max="600" value=${e.bright.for_min} onInput=${o=>t({bright:{...e.bright,for_min:+o.target.value}})} /><small>min at</small>
          <${ae} value=${e.bright.sensor.type?e.bright.sensor:null} devices=${n} onChange=${o=>t({bright:{...e.bright,sensor:o}})} />`:d`<${Ne} value=${e.at} onChange=${o=>t({at:o})} />`}
  </span>`}function Gs({w:e,set:t,devices:n}){let i=o=>t({...e,...o});return d`<div class="window">
    <div class="row">
      <${T} label="On at"><${Ne} value=${e.start} onChange=${o=>i({start:o})} /><//>
      <div class="field"><span>Days</span>
        <div class="days">
          ${po.map((o,r)=>d`<label class=${"lamp"+(e.days&1<<r?" on":"")} key=${o}>
              <input type="checkbox" checked=${!!(e.days&1<<r)} onChange=${()=>i({days:e.days^1<<r})} />${o}
            </label>`)}
        </div>
      </div>
    </div>
    <div class="row tight">
      <label class="check"><input type="checkbox" checked=${!!e.only_if} onChange=${o=>{let{only_if:r,...a}=e;t(o.target.checked?{...a,only_if:{sun_below:{degrees:-6}}}:a)}} /> Only if, at the start:</label>
      ${e.only_if&&d`<${ln} value=${e.only_if} devices=${n} onChange=${o=>i({only_if:o})} />`}
    </div>
    <span class="label">Off at the first of</span>
    <${se} items=${e.end} max=${3} addLabel="end" onChange=${o=>i({end:o})}
      make=${()=>({at:{clock:{hour:8,minute:0}}})}
      render=${(o,r)=>d`<${Ks} value=${o} devices=${n} onChange=${r} />`} />
  </div>`}function Vs({s:e,set:t,outputs:n,devices:i}){return d`
    <div class="row">
      <${T} label="Switches" hint="On at its last level"><${ho} value=${e.output} outputs=${n} onChange=${o=>t({...e,output:o})} /><//>
    </div>
    <h3>Time windows</h3>
    <p class="muted">Only the start and the end switch: switching it off by hand in between sticks. Nothing switches while the clock isn't set.</p>
    <${se} items=${e.windows} max=${4} addLabel="time window" onChange=${o=>t({...e,windows:o})}
      make=${mo}
      render=${(o,r)=>d`<${Gs} w=${o} set=${r} devices=${i} />`} />`}function Qs(e,t){let n=e.days===127?"":` (${po.filter((r,a)=>e.days&1<<a).join(" ")})`,i=e.only_if?` if ${sn(e.only_if,t)}`:"",o=e.end.map(r=>r.at?Ie(r.at):`\u2265 ${r.bright.lux} lx`).join(" / ");return`${Ie(e.start)}${i} \u2192 ${o}${n}`}var Xs={idle:["Waiting","muted"],auto:["On by motion","ok"],manual:["On by hand","warn"],lockout:["Locked","muted"],running:["Running","ok"]};function $o({kind:e,title:t,items:n,outputs:i,reload:o,empty:r}){let a=ve(),s=vt(),[l,u]=_(null),p=e==="motion"?A.motion:A.schedules,[c,f]=_({}),h=async m=>{let g=m?await E(()=>p.get(m)):e==="motion"?Bs(i):{output:i[0]?i[0].name:"",windows:[mo()]};g&&u({oldName:m,initial:g})},$=async m=>{await E(()=>p.setEnabled(m.name,!m.enabled),`${m.name} ${m.enabled?"disabled":"enabled"}`),setTimeout(o,300)},y=async m=>{confirm(`Delete ${m}?`)&&await E(()=>p.remove(m),`${m} deleted`)!==void 0&&setTimeout(o,300)},v=async m=>{if(c[m])return f({...c,[m]:void 0});let g=await E(()=>p.get(m));g&&f({...c,[m]:g})};return l?d`<${Us} title=${t} ...${l} api=${p} intro=${e==="motion"?js:Ws}
      done=${m=>{u(null),m&&setTimeout(o,300)}}>
      ${(m,g)=>e==="motion"?d`<${qs} m=${m} set=${g} outputs=${i} devices=${a} features=${s} />`:d`<${Vs} s=${m} set=${g} outputs=${i} devices=${a} />`}
    <//>`:d`<${F} title=${t+"s"} aside=${d`<button class="primary" onClick=${()=>h()}>+ New ${t.toLowerCase()}</button>`}>
    ${n?n.length===0?d`<p class="muted">${r}</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>State</th><th>Enabled</th><th></th></tr></thead>
            <tbody>
              ${n.map(m=>{let[g,B]=Xs[m.state]||[m.state,"muted"],x=c[m.name];return d`<tr key=${m.name}>
                    <td><a href="#" onClick=${O=>(O.preventDefault(),v(m.name))}><strong>${m.name}</strong></a></td>
                    <td><span class=${"badge "+(m.enabled?B:"muted")}>${g}</span>${m.remaining_s!==void 0?d` <small class="muted">${Math.ceil(m.remaining_s/60)} min</small>`:""}</td>
                    <td><label class="switch"><input type="checkbox" checked=${m.enabled} onChange=${()=>$(m)} /><span></span></label></td>
                    <td class="actions">
                      <button onClick=${()=>h(m.name)}>Edit</button>
                      <button class="danger" onClick=${()=>y(m.name)}>Delete</button>
                    </td>
                  </tr>
                  ${x&&d`<tr class="details"><td colspan="4">
                    ${e==="motion"?`${x.output}${(x.levels||[]).length?" ("+x.levels.map(O=>`from ${Ie(O.from)} ${O.level?"level "+O.level:"at least "+O.min}`).join(", ")+")":""}; off ${x.timeout_s/60} min after the last motion at ${x.detectors.map(O=>Z(a,O)).join(", ")}; locked ${x.lockout_s} s${(x.conditions||[]).length?"; only if "+x.conditions.map(O=>sn(O,a)).join(" and "):""}`:d`${x.output}: ${x.windows.map(O=>d`<div>${Qs(O,a)}</div>`)}`}
                  </td></tr>`}`})}
            </tbody>
          </table></div>`:d`<${U} />`}
  <//>`}var vo=({motion:e,outputs:t,reload:n})=>d`<${$o} kind="motion" title="Motion light" items=${e} outputs=${fo(t)} reload=${n}
  empty="None yet. A motion light switches an output on by motion and off after a while without it; it can be bound to a button (three times down: off) and switched in Home Assistant." />`,go=({schedules:e,outputs:t,reload:n})=>d`<${$o} kind="schedule" title="Schedule" items=${e} outputs=${fo(t)} reload=${n}
  empty="None yet. A schedule switches an output in time windows: by the clock, relative to the sun, and off when it gets bright." />`;var zs=[3],Js=8,_o=15,dn=e=>Object.keys(e)[0],Zs=e=>(cn.find(([t])=>t===e)||[e,e])[1],bo={light:()=>({light:{groups:[{device:{type:3,id:1},mask:1}],levels:[[40],[80],[127]],default_level:2}}),dimmer:()=>({dimmer:{lamps:{device:{type:3,id:1},mask:1},default_value:127}}),relay:()=>({relay:{device:{type:5,id:1},channel:0,bank:0}}),shutter:()=>({shutter:{device:{type:5,id:1},channel:0,bank:0,travel_ms:2e4,up:1}}),group:()=>({group:{members:[]}})};function el(e,t){let n=dn(e),i=e[n];switch(n){case"light":return`${i.levels.length} levels, ${i.groups.length} lamp group${i.groups.length>1?"s":""} on ${[...new Set(i.groups.map(o=>Z(t,o.device)))].join(", ")}`;case"dimmer":return`${Z(t,i.lamps.device)}, mask 0x${i.lamps.mask.toString(16)}`;case"relay":return`${Z(t,i.device)}, channel ${i.channel}`;case"shutter":return`${Z(t,i.device)}, shutter ${i.channel}, ${i.travel_ms/1e3} s`;case"group":return i.members.join(", ")}return""}function tl(e){let[t,n]=_([]),i=e?`${e.type}:${e.id}`:"",o=()=>e&&A.devices.get(e).then(r=>n(r.lamps||[]),()=>n([]));return X(()=>{o()},[i]),[t,o]}function wo({value:e,onChange:t,lit:n,onPick:i,names:o=[]}){return d`<div class="lamps named">
    ${Array.from({length:24},(r,a)=>23-a).map(r=>{let a=e>>>r&1,s=()=>i?i(r):t((e^1<<r)>>>0);return d`<label key=${r} title=${o[r]||`Lamp ${r}`} class=${"lamp"+(a?" on":"")+(r===n?" lit":"")}>
        <input type="checkbox" checked=${!!a} onChange=${s} /><b>${r}</b>${o[r]&&d`<small>${o[r]}</small>`}
      </label>`})}
  </div>`}var yo=127;function nl({group:e,onChange:t,devices:n,names:i,reloadNames:o}){let[r,a]=_(null),[s,l]=_(""),u=an(n,e.device),p=e.bank??0,c=(m,g)=>E(()=>j.lamps(u,p,m,g)),f=async m=>{r!==null&&r!==m&&await c(0,1<<r),await c(yo,1<<m),a(m),l(i[m]||"")},h=async()=>{let m=await E(()=>A.devices.get(e.device));if(!m)return;let g=Array.from({length:24},(B,x)=>(m.lamps||[])[x]||"");for(g[r]=s.trim().slice(0,16);g.length&&!g[g.length-1];)g.pop();await E(()=>A.devices.put(e.device,{...m,lamps:g}),`Lamp ${r} named`)!==void 0&&o()},$=async()=>{r!==null&&await c(0,1<<r),a(null)},y=()=>t({...e,mask:(e.mask^1<<r)>>>0}),v=r!==null&&e.mask>>>r&1;return d`<div class="explore">
    <p class="muted">Click a lamp: it lights up in the room (the one before goes off). The controller takes about one change per second. Give it a name while it's lit: the name is kept with the controller and shown everywhere.</p>
    <${wo} value=${e.mask} lit=${r} onPick=${f} names=${i} />
    ${r!==null&&d`<div class="row tight">
      <input aria-label=${`Name of lamp ${r}`} placeholder=${`Name of lamp ${r}, e.g. \u201Cliving white 2\u201D`} maxlength="16" value=${s} onInput=${m=>l(m.target.value)} />
      <button onClick=${h}>Save name</button>
    </div>`}
    <div class="buttons">
      <button class="primary" disabled=${r===null} onClick=${y}>
        ${r===null?"Click a lamp first":v?`Remove lamp ${r} from the group`:`Add lamp ${r} to the group`}
      </button>
      <button disabled=${!e.mask} onClick=${()=>c(yo,e.mask)}>Light the whole group</button>
      <button onClick=${$}>Done: switch off</button>
    </div>
  </div>`}function ko({value:e,onChange:t,devices:n}){let[i,o]=_(!1),[r,a]=tl(e.device);return d`<div class="row">
    <${T} label="Lamp controller">
      <${ae} value=${e.device} devices=${n} types=${zs} onChange=${s=>t({...e,device:s})} />
    <//>
    <${T} label="Bank" hint="Empty: the controller's only one">
      <input type="number" min="0" max="255" value=${e.bank??""} onInput=${s=>{let{bank:l,...u}=e;t(s.target.value===""?u:{...u,bank:+s.target.value})}} />
    <//>
    <div class="field wide">
      <span>Lamps (mask 0x${e.mask.toString(16).padStart(6,"0")})
        <button class="link" onClick=${()=>o(!i)}>${i?"Close":"Find a lamp\u2026"}</button></span>
      ${i?d`<${nl} group=${e} devices=${n} onChange=${t} names=${r} reloadNames=${a} />`:d`<${wo} value=${e.mask} names=${r} onChange=${s=>t({...e,mask:s})} />`}
    </div>
  </div>`}function il(e,t,n,i,o){return Array.from({length:e},(r,a)=>{let s=Math.round(n+(i-n)*Math.pow((a+1)/e,o));return Array(t).fill(Math.max(1,Math.min(255,s)))})}function ol({value:e,onChange:t,devices:n}){let[i,o]=_(127),r=e.groups,a=p=>{let c=e.levels.map(f=>p.map((h,$)=>$<f.length?f[$]:f[f.length-1]??0));t({...e,groups:p,levels:c})},s=(p,c,f)=>t({...e,levels:e.levels.map((h,$)=>$===p?h.map((y,v)=>v===c?f:y):h)}),l=async p=>{for(let[c,f]of r.entries())await E(()=>j.lamps(an(n,f.device),f.bank??0,p?p[c]:0,f.mask))},u=p=>{let c=e.levels.slice(0,p);for(;c.length<p;)c.push([...c[c.length-1]||r.map(()=>0)]);t({...e,levels:c,default_level:Math.min(e.default_level,p)})};return d`
    <h3>Lamp groups</h3>
    <p class="muted">Lamps that always have the same value in every level form a group. A light may span several controllers.</p>
    <${se} items=${r} max=${Js} addLabel="lamp group" onChange=${a}
      make=${()=>({device:r.length?r[r.length-1].device:{type:3,id:1},mask:1})}
      render=${(p,c)=>d`<${ko} value=${p} devices=${n} onChange=${c} />`} />

    <h3>Levels</h3>
    <p class="muted">The value (0–255) of each lamp group per level; level 0 is off. The controllers fade by themselves and take one change per second.</p>
    <div class="table-wrap"><table class="levels">
      <thead><tr><th>Level</th>${r.map((p,c)=>d`<th>Group ${c+1}</th>`)}<th><button class="link" onClick=${()=>l(null)}>All off</button></th></tr></thead>
      <tbody>
        ${e.levels.map((p,c)=>d`<tr key=${c}>
            <td>${c+1}${c+1===e.default_level&&d` <span class="badge muted">default</span>`}</td>
            ${p.map((f,h)=>d`<td><input type="number" class="short" min="0" max="255" aria-label=${`Level ${c+1}, group ${h+1}`} value=${f} onInput=${$=>s(c,h,+$.target.value)} /></td>`)}
            <td><button onClick=${()=>l(p)} title="Show this level on the lamps">Try</button></td>
          </tr>`)}
      </tbody>
    </table></div>
    <div class="row">
      <${T} label="Levels">
        <input type="number" min="1" max=${_o} value=${e.levels.length} onInput=${p=>p.target.value&&u(Math.max(1,Math.min(_o,+p.target.value)))} />
      <//>
      <${T} label="Default level" hint="What “on” switches to the first time">
        <select value=${e.default_level} onChange=${p=>t({...e,default_level:+p.target.value})}>
          ${e.levels.map((p,c)=>d`<option value=${c+1}>${c+1}</option>`)}
        </select>
      <//>
      <${T} label="Ramp up to" hint="Fills every level, all groups alike">
        <input type="number" min="1" max="255" value=${i} onInput=${p=>o(+p.target.value)} />
      <//>
      <button onClick=${()=>t({...e,levels:il(e.levels.length,r.length,2,i,3)})}>Fill ramp</button>
    </div>`}var De=(e,t,n,i={},o)=>d`<${T} label=${e} hint=${o}>
  <input type="number" value=${t} ...${i} onInput=${r=>n(+r.target.value)} />
<//>`;function rl({output:e,onChange:t,devices:n,names:i,kinds:o={}}){let r=dn(e),a=u=>o[u],s=e[r],l=u=>t({[r]:{...s,...u}});switch(r){case"light":return d`<${ol} value=${s} devices=${n} onChange=${u=>t({light:u})} />`;case"dimmer":return d`<${ko} value=${s.lamps} devices=${n} onChange=${u=>l({lamps:u})} />
        <div class="row">${De("Default value",s.default_value,u=>l({default_value:u}),{min:1,max:255},"What \u201Con\u201D switches to the first time")}</div>`;case"relay":return d`<div class="row">
        <${T} label="Relay node"><${ae} value=${s.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${De("Channel",s.channel,u=>l({channel:u}),{min:0,max:255})}
        ${De("Bank",s.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>`;case"shutter":return d`<div class="row">
        <${T} label="Shutter node"><${ae} value=${s.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${De("Shutter",s.channel,u=>l({channel:u}),{min:0,max:255})}
        ${De("Bank",s.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>
      <div class="row">
        ${De("Travel time (s)",s.travel_ms/1e3,u=>l({travel_ms:Math.round(u*1e3)}),{min:1,max:600,step:.5},"A full move; sent with up and down")}
        <${T} label="Up is" hint="Depends on the wiring: swap it if up and down are the wrong way round">
          <select value=${s.up} onChange=${u=>l({up:+u.target.value})}>
            <option value="1">Direction 1</option>
            <option value="2">Direction 2</option>
          </select>
        <//>
      </div>`;case"group":return d`<p class="muted">Switched together, e.g. “all lights” for one button that switches everything off. Up to every other output; groups can't contain groups.</p>
        <div class="buttons">
          <button onClick=${()=>l({members:i})}>All</button>
          <button onClick=${()=>l({members:i.filter(u=>a(u)==="light"||a(u)==="dimmer")})}>All lights</button>
          <button onClick=${()=>l({members:[]})}>None</button>
        </div>
        <div class="checks">
          ${i.map(u=>d`<label class="check" key=${u}>
              <input type="checkbox" checked=${s.members.includes(u)} onChange=${p=>l({members:p.target.checked?[...s.members,u]:s.members.filter(c=>c!==u)})} /> ${u}
            </label>`)}
        </div>`}return null}var al={light:"A room light in levels: lamp groups on one or more lamp controllers, and the value of each group per level. \u201COn\u201D goes back to the level it had last.",dimmer:"One lamp group switched with a value 0\u2013255, without a level table.",relay:"A relay channel of a relay node: on and off.",shutter:"A roller shutter on a relay node: up, down and stop. Pressing up while it moves up stops it.",group:"Outputs switched together: on, off, toggle, and up/down for the shutters in it."};function sl({original:e,name:t,outputs:n,devices:i,done:o}){let[r,a]=_(t||""),[s,l]=_(e||bo.light()),[u,p]=_(""),c=dn(s),f=n.filter($=>$.kind!=="group"&&$.name!==t).map($=>$.name),h=async $=>{if(!/^[A-Za-z0-9_-]{1,20}$/.test(r))return p("Name: 1\u201320 letters, digits, - and _");try{await A.outputs.put(r,$||s),t&&t!==r&&await A.outputs.remove(t),M(`${r} saved`),o(!0)}catch(y){p(Re(y))}};return d`<${Me} title=${t?`Output ${t}`:"New output"} onSave=${h} onCancel=${()=>o(!1)} error=${u}
    value=${s} onText=${l} intro=${al[c]}>
    <div class="row">
      <${T} label="Name" hint=${t&&r!==t?"Renaming: bindings and automations that use the old name stop working":"Letters, digits, - and _"}>
        <input value=${r} maxlength="20" onInput=${$=>a($.target.value.trim())} />
      <//>
      <${T} label="Kind">
        <select value=${c} disabled=${!!t} onChange=${$=>l(bo[$.target.value]())}>
          ${cn.map(([$,y])=>d`<option value=${$}>${y}</option>`)}
        </select>
      <//>
    </div>
    <${rl} output=${s} onChange=${l} devices=${i} names=${f}
      kinds=${Object.fromEntries(n.map($=>[$.name,$.kind]))} />
  <//>`}function xo({outputs:e,reload:t}){let n=ve(),[i,o]=_(null),[r,a]=_({}),[s,l]=_(0),u=(e||[]).map(f=>f.name).join(",");X(()=>{let f=!1;return(async()=>{let h={};for(let $ of u?u.split(","):[]){try{h[$]=await A.outputs.get($)}catch{}if(f)return}a(h)})(),()=>f=!0},[u,s]);let p=async f=>{let h=f?await E(()=>A.outputs.get(f)):void 0;f&&!h||o({name:f,original:h})},c=async f=>{confirm(`Delete the output ${f}? Bindings and automations that use it stop working.`)&&await E(()=>A.outputs.remove(f),`${f} deleted`)!==void 0&&t()};return i?d`<${sl} ...${i} outputs=${e||[]} devices=${n}
      done=${f=>{o(null),f&&(l(h=>h+1),setTimeout(t,300))}} />`:d`<${F} title="Outputs" aside=${d`<button class="primary" onClick=${()=>p()}>+ New output</button>`}>
    ${e?e.length===0?d`<p class="muted">Nothing yet. An output is what the automation switches: a room light with its levels, a dimmer, a relay, a roller shutter, or a group of them (“all lights”).</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Kind</th><th>What</th><th></th></tr></thead>
            <tbody>
              ${e.map(f=>d`<tr key=${f.name}>
                  <td><strong>${f.name}</strong></td>
                  <td>${Zs(f.kind)}</td>
                  <td class="muted-cell">${r[f.name]?el(r[f.name],n):""}</td>
                  <td class="actions">
                    <button onClick=${()=>p(f.name)}>Edit</button>
                    <button class="danger" onClick=${()=>c(f.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${U} />`}
  <//>`}var yt=[["single","Once","Pressed once"],["double","Twice","Pressed twice"],["triple","3 times","Pressed three times"],["hold","Held","Held: repeats every 0.5 s"],["released","Let go","Let go after holding"]],wt=e=>(yt.find(([t])=>t===e)||[e,e,e])[2],Pe=8,ll=4,Co=8,cl=/^[A-Za-z0-9_-]{1,20}$/,So=[4],fn=()=>Array.from({length:Pe},()=>({})),ul=e=>Object.fromEntries((e||[]).map(t=>[t.event,t.actions])),pn=e=>({events:yt.map(([t])=>t).filter(t=>(e[t]||[]).length).map(t=>({event:t,actions:e[t]}))});function hn(e){let t={};return e.buttons.forEach((n,i)=>{let o=Object.fromEntries(Object.entries(n).filter(([,r])=>r&&r.length));Object.keys(o).length&&(t[i]=o)}),{switches:e.switches,buttons:t}}function kt(e){let t=fn();for(let[n,i]of Object.entries(e.buttons||{}))+n>=0&&+n<Pe&&(t[+n]={...i});return{switches:e.switches||[],buttons:t}}async function mn(e,t){let n=await A.switches.get(e),i=fn();for(let o=0;o<Pe;o++)t&1<<o&&(i[o]=ul((await A.switches.button(e,o)).events));return{switches:n.switches,buttons:i}}async function $n(e,t,n){await A.switches.put(e,{switches:t.switches});for(let i=0;i<Pe;i++){let o=JSON.stringify(pn(t.buttons[i])),r=n?JSON.stringify(pn(n.buttons[i])):'{"events":[]}';o!==r&&await A.switches.putButton(e,i,pn(t.buttons[i]))}}function dl(e,t,n){return e.output?`${e.output.name}: ${co(e.output.op,n[e.output.name]).toLowerCase()}`:e.automation?`${e.automation.name}: ${e.automation.switch}`:e.nightlight?`night light ${Z(t,e.nightlight.device)}: ${e.nightlight.value}`:"?"}function pl({value:e,onChange:t,devices:n,features:i,outputs:o,automations:r}){let a=Object.keys(e)[0],s=e[a],l=Object.fromEntries(o.map(p=>[p.name,p.kind])),u=p=>{p==="output"&&t({output:{name:o[0]?o[0].name:"",op:"toggle"}}),p==="automation"&&t({automation:{name:r[0]||"",switch:"toggle"}}),p==="nightlight"&&t({nightlight:{device:{type:4,id:1},value:0}})};return d`<span class="action">
    <select value=${a} onChange=${p=>u(p.target.value)} aria-label="Kind of action">
      <option value="output">Output</option>
      <option value="automation">Motion light / schedule</option>
      <option value="nightlight">Night light</option>
    </select>
    ${a==="output"&&d`<select value=${s.name} aria-label="Output" onChange=${p=>t({output:{name:p.target.value,op:"toggle"}})}>
        ${!o.some(p=>p.name===s.name)&&d`<option value=${s.name}>${s.name||"Choose\u2026"}</option>`}
        ${o.map(p=>d`<option value=${p.name}>${p.name}</option>`)}
      </select>
      <${uo} value=${s.op} kind=${l[s.name]} onChange=${p=>t({output:{...s,op:p}})} />`}
    ${a==="automation"&&d`<select value=${s.name} aria-label="Motion light or schedule" onChange=${p=>t({automation:{...s,name:p.target.value}})}>
        ${!r.includes(s.name)&&d`<option value=${s.name}>${s.name||"Choose\u2026"}</option>`}
        ${r.map(p=>d`<option value=${p}>${p}</option>`)}
      </select>
      <select value=${s.switch} aria-label="Switch it" onChange=${p=>t({automation:{...s,switch:p.target.value}})}>
        <option value="toggle">Toggle</option>
        <option value="enable">Enable</option>
        <option value="disable">Disable</option>
      </select>`}
    ${a==="nightlight"&&d`<${ae} value=${s.device} devices=${gt(n,i,"nightlight")} types=${So}
        onChange=${p=>t({nightlight:{...s,device:p}})} />
      <input type="number" class="short" min="0" max="255" aria-label="Brightness 0–255" value=${s.value}
        onInput=${p=>t({nightlight:{...s,value:+p.target.value}})} />`}
  </span>`}function Ao({onLearn:e,label:t="Learn: press a button"}){let[n,i]=_(!1),o=Ce(!1);return X(()=>()=>o.current=!0,[]),n?d`<button class="learning" onClick=${()=>o.current=!0}>Press the button on the wall now… (cancel)</button>`:d`<button onClick=${async()=>{i(!0),o.current=!1;let a=Date.now();for(;!o.current&&Date.now()<a+3e4;){try{let s=await A.status();if(s.last_button&&s.last_button.age_s+1<=(Date.now()-a)/1e3){e(s.last_button.trigger);break}}catch{}await new Promise(s=>setTimeout(s,700))}i(!1)}}>${t}</button>`}function fl(e,t){let n=i=>[{output:{name:t,op:i}}];return e==="shutter"?[{single:n("up"),hold:n("up_hold"),released:n("stop")},{single:n("down"),hold:n("down_hold"),released:n("stop")}]:e==="relay"||e==="group"?[{single:n("on")},{single:n("off")}]:[{single:n("on"),double:n("max"),hold:n("inc")},{single:n("off"),hold:n("dec")}]}function hl({outputs:e,onApply:t,buttons:n}){let[i,o]=_(0),[r,a]=_(e[0]?e[0].name:""),s=(e.find(l=>l.name===r)||{}).kind;return d`<div class="template">
    <span class="label">Quick fill:</span>
    <select value=${i} aria-label="Buttons" onChange=${l=>o(+l.target.value)}>
      ${Array.from({length:n/2},(l,u)=>d`<option value=${u}>buttons ${2*u} (up) and ${2*u+1} (down)</option>`)}
    </select>
    <span class="label">as a rocker for</span>
    <select value=${r} aria-label="Output" onChange=${l=>a(l.target.value)}>
      ${e.map(l=>d`<option value=${l.name}>${l.name}</option>`)}
    </select>
    <button disabled=${!r} onClick=${()=>t(2*i,fl(s,r))}>Fill</button>
    <small class="muted">${s==="shutter"?"Up/down, held: moves, let go: stops":s==="light"||s==="dimmer"?"Up: on, twice: brightest, held: brighter; down: off, held: darker":"Up: on, down: off"}</small>
  </div>`}function ml({name:e,original:t,devices:n,features:i,outputs:o,automations:r,done:a,learned:s}){let[l,u]=_(e||""),[p,c]=_(t||{switches:s?[s.device]:[],buttons:fn()}),[f,h]=_(s?[s.button,s.event]:[0,"single"]),[$,y]=_(""),v=Object.fromEntries(o.map(w=>[w.name,w.kind])),m=p.switches.some(w=>ro(i,w,"extension"))||p.buttons.slice(4).some(w=>Object.keys(w).length),[g,B]=_(!1),x=m||g||f[0]>=4?Pe:4,[O,R]=f,k=p.buttons[O][R]||[],S=w=>c({...p,buttons:p.buttons.map((I,P)=>P===O?{...I,[R]:w}:I)}),b=w=>{!p.switches.some(P=>re(P)===re(w.device))&&p.switches.length<Co&&c(P=>({...P,switches:[...P.switches,w.device]})),h([w.button,w.event]),M(`Button ${w.button}, ${wt(w.event).toLowerCase()}`)},N=async w=>{let I=w?kt(w):p;if(!cl.test(l))return y("Name: 1\u201320 letters, digits, - and _");if(!I.switches.length)return y("Add at least one switch, or learn it");try{let P=e&&e!==l;await $n(l,I,P?void 0:t),P&&await A.switches.remove(e),M(`${l} saved`),a(!0)}catch(P){y(Re(P))}};return d`<${Me} title=${e?`Switch ${e}`:"New switch configuration"} onSave=${N} onCancel=${()=>a(!1)} error=${$}
    value=${hn(p)} onText=${w=>c(kt(w))}
    intro="What each button does. Several switches can share one configuration (both bedroom switches): they all do the same.">
    <div class="row">
      <${T} label="Name" hint="Letters, digits, - and _">
        <input value=${l} maxlength="20" onInput=${w=>u(w.target.value.trim())} />
      <//>
      <div class="field grow"><span>Switches</span>
        <${se} items=${p.switches} max=${Co} addLabel="switch" onChange=${w=>c({...p,switches:w})}
          make=${()=>null}
          render=${(w,I)=>d`<${ae} value=${w} devices=${n} types=${So} onChange=${I} />`} />
      </div>
    </div>
    <div class="row tight">
      <${Ao} onLearn=${b} label="Learn: press a button on the wall" />
      <small class="muted">Adds the switch and picks the button and kind of press.</small>
    </div>

    <h3>Buttons</h3>
    <div class="table-wrap"><table class="grid">
      <thead><tr><th>Button</th>${yt.map(([w,I,P])=>d`<th title=${P}>${I}</th>`)}</tr></thead>
      <tbody>
        ${Array.from({length:x},(w,I)=>d`<tr key=${I}>
          <th scope="row">${I}${I>=4?d` <small class="muted">ext.</small>`:""}</th>
          ${yt.map(([P])=>{let ge=p.buttons[I][P]||[],Cn=O===I&&R===P;return d`<td key=${P}><button class=${"cell"+(Cn?" active":"")+(ge.length?" used":"")}
              aria-pressed=${Cn} onClick=${()=>h([I,P])}>
              ${ge.length?ge.map(qo=>dl(qo,n,v)).join(", "):"\u2014"}
            </button></td>`})}
        </tr>`)}
      </tbody>
    </table></div>
    ${!m&&x===4&&d`<button class="link" onClick=${()=>B(!0)}>Show buttons 4–7 (extension board)</button>`}

    <div class="cell-edit">
      <h3>Button ${O}, ${wt(R).toLowerCase()}</h3>
      <${se} items=${k} max=${ll} addLabel="action" onChange=${S}
        make=${()=>({output:{name:o[0]?o[0].name:"",op:"toggle"}})}
        render=${(w,I)=>d`<${pl} value=${w} onChange=${I} devices=${n} features=${i} outputs=${o} automations=${r} />`} />
      ${k.length===0&&d`<p class="muted">Does nothing. Add an action, or fill a rocker below.</p>`}
    </div>
    ${o.length>0&&d`<${hl} outputs=${o} buttons=${x}
      onApply=${(w,I)=>{c({...p,buttons:p.buttons.map((P,ge)=>ge===w||ge===w+1?{...P,...I[ge-w]}:P)}),h([w,"single"])}} />`}
  <//>`}function To({outputs:e,motion:t,schedules:n}){let i=ve(),o=vt(),[r,a]=_(),[s,l]=_(),[u,p]=_(null),c=async()=>{try{a(await A.switches.list())}catch(v){l(v)}};X(()=>{c()},[]);let f=[...t||[],...n||[]].map(v=>v.name),h=async v=>{let m=await E(()=>mn(v.name,v.buttons));m&&p({name:v.name,original:m})},$=v=>{let m=(r||[]).find(g=>g.switches.some(B=>re(B)===re(v.device)));m?h(m):p({learned:v})},y=async v=>{confirm(`Delete the switch configuration ${v}? Its buttons stop doing anything.`)&&await E(()=>A.switches.remove(v),`${v} deleted`)!==void 0&&c()};return u?d`<${ml} ...${u} devices=${i} features=${o} outputs=${e||[]} automations=${f}
      done=${v=>{p(null),v&&c()}} />`:d`<${F} title="Switches" aside=${d`<div class="buttons">
      <${Ao} onLearn=${$} label="Which switch is this?" />
      <button class="primary" onClick=${()=>p({})}>+ New</button>
    </div>`}>
    <p class="muted">A configuration says what each button of a switch does when pressed once, twice, three times, held or let go. Switches that do the same share one.</p>
    ${r?r.length===0?d`<p>No switch does anything yet. Press <em>Which switch is this?</em> and a button on the wall to start with that switch.</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Switches</th><th>Buttons</th><th></th></tr></thead>
            <tbody>
              ${r.map(v=>d`<tr key=${v.name}>
                  <td><strong>${v.name}</strong></td>
                  <td class="wrap">${v.switches.map(m=>Z(i,m)).join(", ")}</td>
                  <td><span class="chips">${Array.from({length:Pe},(m,g)=>g).filter(m=>v.buttons&1<<m).map(m=>d`<span class="chip">${m}</span>`)}</span></td>
                  <td class="actions">
                    <button onClick=${()=>h(v)}>Edit</button>
                    <button class="danger" onClick=${()=>y(v.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${U} error=${s} />`}
  <//>`}var $l=[["","Overview"],["switches","Switches"],["outputs","Outputs"],["motion","Motion lights"],["schedules","Schedules"],["backup","Backup"]];async function vl(){let e=await A.status(),t=await A.outputs.list(),n=await A.motion.list(),i=await A.schedules.list();return{status:e,outputs:t,motion:n,schedules:i}}function gn({tab:e=""}){let{data:t,error:n,reload:i}=K(vl,e===""?2500:0),o=t||{};return d`
    <nav class="tabs">
      ${$l.map(([r,a])=>d`<${Q} href=${"/automation"+(r?"/"+r:"")} class=${r===e?"active":""}>${a}<//>`)}
    </nav>
    ${!t&&d`<${U} error=${n} />`}
    ${t&&e===""&&d`<${bl} ...${o} reload=${i} />`}
    ${t&&e==="switches"&&d`<${To} outputs=${o.outputs} motion=${o.motion} schedules=${o.schedules} />`}
    ${t&&e==="outputs"&&d`<${xo} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="motion"&&d`<${vo} motion=${o.motion} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="schedules"&&d`<${go} schedules=${o.schedules} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="backup"&&d`<${wl} ...${o} reload=${i} />`}
    ${n&&t&&d`<p class="error">${n.message}</p>`}`}function Fo(e,t){let[n,i]=_(null),o=async(r,a)=>{i(a),await E(()=>A.outputs.command(e.name,r)),setTimeout(async()=>{await t(),i(null)},600)};return[n===null?e.level:n,o]}function gl({o:e,reload:t}){let[n,i]=Fo(e,t),o=e.kind==="light"?e.top:255,r=e.kind==="light"?1:25,a=s=>i({set:s},Math.max(0,Math.min(o,s)));return d`<div class="stepper">
      <button aria-label="Darker" disabled=${n<=0} onClick=${()=>i("dec",Math.max(0,n-r))}>−</button>
      ${e.kind==="light"?d`<select aria-label="Level" value=${n} onChange=${s=>a(+s.target.value)}>
            ${Array.from({length:o+1},(s,l)=>d`<option value=${l}>${l===0?"off":`level ${l}`}</option>`)}
          </select>`:d`<input type="number" aria-label="Value 0–255" min="0" max="255" value=${n} onChange=${s=>a(+s.target.value)} />`}
      <button aria-label="Brighter" disabled=${n>=o} onClick=${()=>i("inc",Math.min(o,n+r))}>+</button>
    </div>
    <div class="buttons fixed"><button onClick=${()=>i("on",n||1)}>On</button><button onClick=${()=>i("off",0)}>Off</button></div>`}function Eo({o:e,reload:t}){let[,n]=Fo(e,t),i,o;switch(e.kind){case"light":case"dimmer":i=e.level>0?e.kind==="light"?`level ${e.level} of ${e.top}`:`${Math.round(e.level/255*100)} %`:"off",o=d`<${gl} o=${e} reload=${t} />`;break;case"relay":i=e.level>0?"on":"off",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",1)}>On</button><button onClick=${()=>n("off",0)}>Off</button></div>`;break;case"shutter":i={up:"moving up",down:"moving down",stopped:"stopped"}[e.movement],o=d`<div class="buttons fixed">
        <button aria-label="Up" onClick=${()=>n("up",e.level)}>▲</button>
        <button aria-label="Stop" onClick=${()=>n("stop",e.level)}>■</button>
        <button aria-label="Down" onClick=${()=>n("down",e.level)}>▼</button>
      </div>`;break;default:i="group",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",0)}>All on</button><button onClick=${()=>n("off",0)}>All off</button></div>`}let r=e.level>0||e.kind==="shutter"&&e.movement!=="stopped";return d`<div class=${"tile"+(r?" lit":"")}>
    <div class="tile-head"><strong>${e.name}</strong></div>
    <div class="tile-state">${i}</div>
    ${o}
  </div>`}var _l={idle:"waiting",auto:"on by motion",manual:"on by hand",lockout:"locked",running:"in a time window"};function bl({status:e,outputs:t,motion:n,schedules:i,reload:o}){let r=ve(),a=async f=>{await E(()=>A.setEnabled(f),f?"Automation on":"Automation off"),o()},s=(f,h)=>async()=>{await E(()=>f.setEnabled(h.name,!h.enabled),`${h.name} ${h.enabled?"disabled":"enabled"}`),setTimeout(o,400)},l=e.last_button,u=!t.length&&!n.length&&!i.length,p=t.filter(f=>f.kind==="group"),c=t.filter(f=>f.kind!=="group");return d`
    <${F} title="Automation" aside=${d`<label class="switch big" title="The master switch">
      <input type="checkbox" checked=${e.enabled} onChange=${f=>a(f.target.checked)} /><span></span>
      ${e.enabled?"On":"Off"}
    </label>`}>
      <p class="muted">
        Switches, motion lights and schedules run on the gateway itself: they keep working without the network, MQTT or Home Assistant.
        This page is for testing and watching them.
        ${!e.enabled&&d` <strong>Switched off:</strong> nothing switches by itself; outputs can still be switched here.`}
      </p>
      <dl class="facts">
        <div><dt>Switch configurations</dt><dd><${Q} href="/automation/switches">${e.switches}<//></dd></div>
        <div><dt>Outputs</dt><dd><${Q} href="/automation/outputs">${e.outputs}<//></dd></div>
        <div><dt>Motion lights</dt><dd><${Q} href="/automation/motion">${e.motion}<//></dd></div>
        <div><dt>Schedules</dt><dd><${Q} href="/automation/schedules">${e.schedules}<//></dd></div>
        <div><dt>Last button pressed</dt>
        <dd>${l?`${Z(r,l.trigger.device)}, button ${l.trigger.button}, ${wt(l.trigger.event).toLowerCase()} (${l.age_s} s ago)`:"\u2014"}</dd></div>
      </dl>
      ${u&&d`<ol class="steps">
        <li>Create the <${Q} href="/automation/outputs">outputs<//>: the lights, relays and shutters the automation switches.</li>
        <li>Tell the <${Q} href="/automation/switches">switches<//> what their buttons do.</li>
        <li>Add <${Q} href="/automation/motion">motion lights<//> and <${Q} href="/automation/schedules">schedules<//>.</li>
        <li>Or restore a <${Q} href="/automation/backup">backup<//>.</li>
      </ol>`}
    <//>
    ${p.length>0&&d`<${F} title="Groups">
      <div class="tiles">${p.map(f=>d`<${Eo} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${c.length>0&&d`<${F} title="Outputs">
      <div class="tiles">${c.map(f=>d`<${Eo} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${n.length+i.length>0&&d`<${F} title="Motion lights and schedules">
      <div class="tiles">
        ${[...n.map(f=>[f,A.motion]),...i.map(f=>[f,A.schedules])].map(([f,h])=>d`<div class=${"tile"+(f.enabled&&f.state!=="idle"?" lit":"")} key=${f.name}>
            <div class="tile-head"><strong>${f.name}</strong></div>
            <div class="tile-state">${f.enabled?_l[f.state]:"disabled"}${f.enabled&&f.remaining_s!==void 0?` \xB7 ${f.remaining_s} s`:""}</div>
            <label class="switch"><input type="checkbox" checked=${f.enabled} onChange=${s(h,f)} /><span></span>${f.enabled?"Enabled":"Disabled"}</label>
          </div>`)}
      </div>
    <//>`}`}var Io="gateway-automation",vn=2,yl=e=>new Promise(t=>setTimeout(t,e));async function Lo(e,t,n,i){let o={format:Io,version:vn,enabled:e.enabled,outputs:[],switches:[],motion:[],schedules:[],devices:[]};for(let r of t)o.outputs.push({name:r.name,output:await A.outputs.get(r.name)});for(let r of await A.switches.list())o.switches.push({name:r.name,...hn(await mn(r.name,r.buttons))});for(let r of n)o.motion.push({name:r.name,enabled:r.enabled,config:await A.motion.get(r.name)});for(let r of i)o.schedules.push({name:r.name,enabled:r.enabled,config:await A.schedules.get(r.name)});for(let r of await A.devices.list())o.devices.push({device:r.device,...await A.devices.get(r.device)});return o}function Oo(e,t,n){let i=document.createElement("a");i.href=URL.createObjectURL(new Blob([e],{type:n})),i.download=t,i.click(),URL.revokeObjectURL(i.href)}function wl({status:e,outputs:t,motion:n,schedules:i,reload:o}){let[r,a]=_([]),[s,l]=_(!1),[u,p]=_(!1),[c,f]=_(null),h=x=>a(O=>[...O,x]),$=async x=>{l(!0),a([]);try{let O=await Lo(e,t,n,i),R=new Date().toISOString().slice(0,10);x?Oo(_t(O),`automation-${R}.yaml`,"application/yaml"):Oo(JSON.stringify(O,null,2),`automation-${R}.json`,"application/json"),h(`Exported ${O.outputs.length} outputs, ${O.switches.length} switch configurations, ${O.motion.length} motion lights, ${O.schedules.length} schedules.`)}catch(O){h(`Failed: ${O.message}`)}l(!1)},y=async()=>{l(!0);try{f(_t(await Lo(e,t,n,i)))}catch(x){M(x.message,"error")}l(!1)},v=async(x,O)=>{try{await O(),h(`\u2713 ${x}`)}catch(R){h(`\u2717 ${x}: ${R.field?R.field+": ":""}${R.message}`)}},m=async x=>{if(!x||x.format!==Io)return M("Not an automation backup","error");if(x.version!==vn)return M(`Version ${x.version} isn't supported (this page writes ${vn})`,"error");if(u&&!confirm("Delete every output, switch configuration, motion light and schedule on the gateway first?"))return;if(l(!0),a([]),u){for(let b of await A.switches.list())await v(`delete switch ${b.name}`,()=>A.switches.remove(b.name));for(let b of n)await v(`delete ${b.name}`,()=>A.motion.remove(b.name));for(let b of i)await v(`delete ${b.name}`,()=>A.schedules.remove(b.name));let S=[...t].sort((b,N)=>(N.kind==="group")-(b.kind==="group"));for(let b of S)await v(`delete ${b.name}`,()=>A.outputs.remove(b.name))}let O=S=>Object.keys(S.output)[0]==="group",R=x.outputs||[];for(let S of[...R.filter(b=>!O(b)),...R.filter(O)])await v(`output ${S.name}`,()=>A.outputs.put(S.name,S.output));for(let S of x.motion||[])await v(`motion light ${S.name}`,()=>A.motion.put(S.name,S.config));for(let S of x.schedules||[])await v(`schedule ${S.name}`,()=>A.schedules.put(S.name,S.config));for(let S of x.switches||[])await v(`switch ${S.name}`,()=>$n(S.name,kt(S)));for(let S of x.devices||[])await v(`device notes ${Z([],S.device)}`,()=>A.devices.put(S.device,{features:S.features||[],lamps:S.lamps||[]}));let k=[...(x.motion||[]).map(S=>[S,A.motion]),...(x.schedules||[]).map(S=>[S,A.schedules])].filter(([S])=>S.enabled===!1);k.length&&await yl(1e3);for(let[S,b]of k)await v(`disable ${S.name}`,()=>b.setEnabled(S.name,!1));typeof x.enabled=="boolean"&&x.enabled!==e.enabled&&await v(`master switch ${x.enabled?"on":"off"}`,()=>A.setEnabled(x.enabled)),h("Done."),l(!1),o()},g=async x=>{let O=x.target.files[0];if(x.target.value="",!!O)try{await m(bt(await O.text()))}catch(R){M(`${O.name}: ${R.message}`,"error")}},B=async()=>{let x;try{x=bt(c)}catch(O){return M(O.message,"error")}await m(x),f(null)};return d`<${F} title="Backup">
    <p class="muted">The whole configuration as one file (YAML or JSON): to keep, to edit, to write by hand, or to move to another gateway. Devices are stored by type and id.</p>
    <div class="buttons">
      <button class="primary" disabled=${s} onClick=${()=>$(!0)}>Export YAML</button>
      <button disabled=${s} onClick=${()=>$(!1)}>Export JSON</button>
      <label class=${"button"+(s?" disabled":"")}>Import…<input type="file" accept=".json,.yaml,.yml,application/json,application/yaml" hidden disabled=${s} onChange=${g} /></label>
      <button disabled=${s||c!==null} onClick=${y}>Edit everything as YAML</button>
      <label class="check"><input type="checkbox" checked=${u} onChange=${x=>p(x.target.checked)} /> Delete everything first</label>
    </div>
    ${c!==null&&d`<div class="text-all">
      <textarea class="code" rows="28" spellcheck="false" value=${c} onInput=${x=>f(x.target.value)} />
      <div class="buttons">
        <button class="primary" disabled=${s} onClick=${B}>Apply</button>
        <button onClick=${()=>f(null)}>Cancel</button>
        <small class="muted">Applying stores every item as written; with “Delete everything first”, what isn't in the text is removed.</small>
      </div>
    </div>`}
    ${r.length>0&&d`<pre class="log">${r.join(`
`)}</pre>`}
  <//>`}function xt({target:e,label:t,others:n=[],onDone:i}){let[o,r]=_(null),[a,s]=_(null),[l,u]=_(""),[p,c]=_(null),f=Ce(null);X(()=>()=>clearInterval(f.current),[]);let h=()=>{clearInterval(f.current),f.current=setInterval(async()=>{try{c(await jt.job())}catch{}},1500)},$=async(g,B)=>{u(g),s(0),B!=="gateway"&&h();try{let x=await o.arrayBuffer();return await jt.upload(B,x,s)||{}}finally{clearInterval(f.current),s(null)}},y=async g=>{if(!o)return;let B=0;for(let{name:x,target:O}of g)try{let R=await $(x,O);B+=1,R.restarting&&M("Firmware installed, the gateway restarts\u2026")}catch(R){M(`${x}: ${R.message}`,"error");break}B===g.length&&g[0].target!=="gateway"&&M(B===1?"Firmware sent; the device restarts into it":`Firmware sent to ${B} devices`),u(""),c(null),i&&i()},v=a!==null,m=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${g=>r(g.target.files[0]||null)} />
      <${L} onClick=${()=>y([{name:t||"device",target:e}])} disabled=${!o||v}>${t||"Upload"}<//>
      ${n.length>0&&d`<${L} onClick=${()=>y([{name:"this device",target:e},...n])} disabled=${!o||v}>Send to all ${n.length+1} of this type<//>`}
      ${v&&d`<progress max="1" value=${a}></progress>`}
      ${v&&d`<p class="muted wide">${l}${m?" \u2014 "+m:""}</p>`}
    </div>`}var kl={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},No={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},_n=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],xl={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},He=e=>xl[e]||e;function Ct(e,t=5e3){let n=K(()=>pe.list(e),t),i=[...new Set((n.data||[]).map(r=>r.device))];return{...n,ask:async()=>{for(let r of e?[e]:i)await E(()=>pe.refresh(r));setTimeout(n.reload,1500)}}}function Cl({s:e,device:t,reload:n}){let[i,o]=_(!1),[r,a]=_(e.name||""),[s,l]=_(e.role||"none"),u=async()=>{let p={};if(r!==(e.name||"")&&(p.name=r),s!==(e.role||"none")&&(p.role=s),Object.keys(p).length===0)return o(!1);await E(()=>pe.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${Q} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${i?d`<input class="inline" maxlength="7" placeholder="name" value=${r} onInput=${p=>a(p.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${kl[e.kind]||e.kind}</td>
    <td>${i?d`<select value=${s} onChange=${p=>l(p.target.value)}>${_n.map(p=>d`<option value=${p}>${He(p)}</option>`)}</select>`:e.role&&e.role!=="none"?He(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind in No?e.value.toFixed(No[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ye(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":i?d`<${L} kind="primary" onClick=${u}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function bn({device:e}){let{data:t,error:n,reload:i,ask:o}=Ct(e);if(!t)return d`<${U} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let r=t.some(a=>a.named_by_node&&a.slot===null);return d`
    ${r&&d`<p class="muted">The names and roles of some sensors are not known yet. <${L} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(a=>d`<${Cl} key=${a.device_key+a.kind+a.sensor_id} s=${a} device=${e} reload=${i} />`)}
      </tbody>
    </table></div>`}function Mo(){let{ask:e}=Ct(void 0,0);return d`<${F} title="Sensors" aside=${d`<${L} onClick=${e}>Reload names and roles<//>`}>
    <${bn} />
  <//>`}var Sl=[2,5,8,9],Al=[7],Tl=[3],El=3,yn=[9],Ll=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],Ol=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Po({device:e}){let{data:t,error:n,reload:i}=K(()=>j.get(e),5e3);return t?d`
    <${Nl} d=${t} reload=${i} />
    ${Sl.includes(t.device_type)&&d`<${Ro} d=${t} kind="relay" />`}
    ${Al.includes(t.device_type)&&d`<${Ro} d=${t} kind="rollershutter" />`}
    ${Tl.includes(t.device_type)&&d`<${Do} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===El&&d`<${Do} d=${t} firstBank=${1} />`}
    ${yn.includes(t.device_type)&&d`<${Ml} d=${t} />`}
    ${yn.includes(t.device_type)&&d`<${Dl} d=${t} />`}
    ${yn.includes(t.device_type)&&d`<${Pl} d=${t} />`}
    <${F} title="Sensors"><${bn} device=${t.name||t.key} /><//>
    <${Fl} d=${t} />
    <${Hl} d=${t} reload=${i} />
    <${Il} d=${t} />`:d`<${U} error=${n} />`}function Fl({d:e}){let t={type:e.device_type,id:e.device_id},{data:n,error:i,reload:o}=K(()=>A.devices.get(t)),[r,a]=_(!1);if(!n)return d`<${F} title="On board"><${U} error=${i} /><//>`;let s=async l=>{let u=n.features.includes(l)?n.features.filter(p=>p!==l):[...n.features,l];a(!0),await E(()=>A.devices.put(t,{...n,features:u}),"Saved")!==void 0&&(io(),await o()),a(!1)};return d`<${F} title="On board">
    <p class="muted">What this device has, for the automation: it offers motion detectors, brightness sensors and night lights only where they are.</p>
    <div class="checks">
      ${oo.map(([l,u])=>d`<label class="check" key=${l}>
          <input type="checkbox" disabled=${r} checked=${n.features.includes(l)} onChange=${()=>s(l)} /> ${u}
        </label>`)}
    </div>
  <//>`}function Il({d:e}){let t=e.name||e.key,{data:n}=K(j.list),i=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${F} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${xt} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${i} />
    <//>`}function Nl({d:e,reload:t}){let n=e.name||e.key,i=(o,r)=>async()=>{await E(()=>j.action(n,o),r),setTimeout(t,1500)};return d`
    <${F} title=${n}
      aside=${d`<span class="buttons">
        <${L} onClick=${i("ping","Ping sent")}>Ping<//>
        <${L} onClick=${i("refresh","Refresh requested")}>Refresh<//>
        <${L} kind="danger" onClick=${i("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ye(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Ro({d:e,kind:t}){let n=e.name||e.key,[i,o]=_(1),[r,a]=_(0),s=t==="rollershutter",l=u=>()=>E(()=>j[t](n,i,u,Math.round(r*1e3)),`${s?"Rollershutter":"Relay"} ${i}: ${u}`);return d`
    <${F} title=${s?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${T} label="Number"><input type="number" min="1" max="16" value=${i} onInput=${u=>o(+u.target.value)} /><//>
        <${T} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${r} onInput=${u=>a(+u.target.value)} /><//>
      </div>
      <div class="buttons">
        ${s?d`<${L} onClick=${l("up")}>Up<//><${L} onClick=${l("down")}>Down<//><${L} onClick=${l("off")}>Stop<//>`:d`<${L} kind="primary" onClick=${l("on")}>On<//><${L} onClick=${l("off")}>Off<//>`}
      </div>
    <//>`}function Do({d:e,firstBank:t=0}){let n=e.name||e.key,[i,o]=_(t),[r,a]=_(255),[s,l]=_(Array(24).fill(!1)),u=s.reduce((p,c,f)=>c?p|1<<23-f:p,0);return d`
    <${F} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${T} label="Bank"><input type="number" min=${t} max="255" value=${i} onInput=${p=>o(+p.target.value)} /><//>
        <${T} label="Value (0-255)"><input type="number" min="0" max="255" value=${r} onInput=${p=>a(+p.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((p,c)=>d`<label key=${c} class=${"lamp"+(p?" on":"")}>
            <input type="checkbox" checked=${p} onChange=${()=>l(s.map((f,h)=>h===c?!f:f))} />${23-c}
          </label>`)}
      </div>
      <${L} kind="primary" onClick=${()=>E(()=>j.lamps(n,i,r,u),"Lamps set")}>Send<//>
    <//>`}function Ml({d:e}){let t=e.name||e.key,[n,i]=_(45),[o,r]=_(!1),[a,s]=_(0),[l,u]=_(!1),[p,c]=_(0),[f,h]=_(55);return d`
    <${F} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${T} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${$=>i(+$.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${$=>r($.target.checked)} /> from the tank</label>
        <${L} onClick=${()=>E(()=>j.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${T} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${a} onInput=${$=>s(+$.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${l} onChange=${$=>u($.target.checked)} /> rod released</label>
        <${L} onClick=${()=>E(()=>j.heating(t,"energy",{power_w:a,rod_enabled:l}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${T} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${$=>c(+$.target.value)} /><//>
        <${T} label="Tank (°C)"><input type="number" step="0.5" value=${f} onInput=${$=>h(+$.target.value)} /><//>
        <${L} kind="danger" onClick=${()=>E(()=>j.heating(t,"emergency",{stage:p,tank_c:f}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var Rl=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function Dl({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o,ask:r}=Ct(t);if(!n)return d`<${F} title="Sensor assignment"><${U} error=${i} /><//>`;let a=n.filter(c=>c.kind==="temperature"),s=c=>a.find(f=>f.role===c),l=c=>c.name?`${c.name} (${c.sensor_id})`:c.sensor_id,u=a.every(c=>c.slot!==null),p=c=>async f=>{let h=f.target.value,$;if(h===""){let y=s(c);if(!y)return;$=await E(()=>pe.update(t,y.slot,{role:"none"}),`${He(c)} cleared`)}else{let y=a.find(v=>v.sensor_id===h);$=await E(()=>pe.update(t,y.slot,{role:c}),`${l(y)} is ${He(c)} now`)}$&&setTimeout(o,1500)};return d`
    <${F} title="Sensor assignment" aside=${d`<${L} onClick=${r}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!u&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${_n.filter(c=>c!=="none").map(c=>d`<label key=${c} class="field">
            <span>${He(c)}</span>
            <select value=${(s(c)||{}).sensor_id||""} onChange=${p(c)} disabled=${!u}>
              <option value="">(none)</option>
              ${a.map(f=>d`<option value=${f.sensor_id}>${l(f)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Pl({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o}=K(()=>j.heatingManualState(t),3e3),r=!!(n&&n.enabled),a=p=>!!(n&&n.relays.includes(p)),s=async()=>{let p=!r;await E(()=>j.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},l=p=>async()=>{await E(()=>j.heatingManual(t,!0,p,!a(p)),`Relay ${p} ${a(p)?"off":"on"}`)&&setTimeout(o,800)},u=p=>p===8&&a(9)||p===9&&a(8);return d`
    <${F} title="Manual mode"
      aside=${d`<${L} kind=${r?"danger":""} disabled=${!n} onClick=${s}>${r?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${i&&d`<p class="error">The controller does not answer: ${i.message}</p>`}
      ${r&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${Rl.map(([p,c])=>d`<button key=${p} class=${a(p)?"primary":""} disabled=${!r||u(p)} onClick=${l(p)}>
            <span>${c}</span><small>relay ${p}: ${a(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Hl({d:e,reload:t}){let n=e.name||e.key,[i,o]=_({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[r,a]=_(!1),s=u=>p=>o({...i,[u]:p.target.value}),l=async()=>{let u={};if(i.custom_string!==e.name&&(u.custom_string=i.custom_string),+i.hwrev!==e.hwrev&&(u.hwrev=+i.hwrev),i.relais_mode&&(u.relais_mode=i.relais_mode),i.extension_mode&&(u.extension_mode=i.extension_mode),Object.keys(u).length===0)return M("Nothing changed");await E(()=>j.update(n,u),"Settings sent")&&setTimeout(t,1500)};return d`
    <${F} title="Settings">
      <div class="row">
        <${T} label="Name" hint="up to 8 characters"><input maxlength="8" value=${i.custom_string} onInput=${s("custom_string")} /><//>
        <${T} label="Hardware revision"><input type="number" min="0" max="255" value=${i.hwrev} onInput=${s("hwrev")} /><//>
        <${T} label="Relay mode"><select value=${i.relais_mode} onChange=${s("relais_mode")}>
          <option value="">(unchanged)</option>${Ll.map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${T} label="Extension mode"><select value=${i.extension_mode} onChange=${s("extension_mode")}>
          <option value="">(unchanged)</option>${Ol.map(u=>d`<option>${u}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${L} kind="primary" onClick=${l}>Save<//>
        <${L} onClick=${async()=>{await E(()=>j.silence(n,!r),r?"Device may talk again":"Device silenced"),a(!r)}}>${r?"End silence":"Silence"}<//>
        <${L} onClick=${()=>E(()=>j.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Ho(){let{data:e,error:t,reload:n}=K(j.list,5e3),[i,o]=_(""),r=(u,p)=>async()=>{await E(u,p),setTimeout(n,1500)},a=async()=>{let u=i.trim();u&&await E(()=>j.action(u,"ping"),`Ping sent to ${u}`)},s=async()=>{confirm("Restart every device on the bus?")&&await r(()=>Te.action("restart"),"Restart sent to every device")()},l=r(()=>Te.action("discover"),"Scanning: every device was asked to announce itself");return d`
    <${F} title="Devices">
      <div class="toolbar">
        <${L} onClick=${n}>Refresh<//>
        <${L} onClick=${r(()=>Te.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${L} onClick=${r(()=>Te.silence(!0),"Every device is silenced")}>Silence on<//>
        <${L} onClick=${r(()=>Te.silence(!1),"Every device may talk again")}>Silence off<//>
        <${L} kind="danger" onClick=${s}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${i} onInput=${u=>o(u.target.value)} onKeyDown=${u=>u.key==="Enter"&&a()} />
        <${L} onClick=${a}>Ping<//>
        <${L} onClick=${l}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(u=>d`<tr key=${u.key}>
                    <td><${Q} href=${"/devices/"+encodeURIComponent(u.name||u.key)}>${u.name||u.key}<//></td>
                    <td><code>${qt(u.device_id)}</code></td>
                    <td>${u.type_name} <code>${qt(u.device_type)}</code></td>
                    <td>${u.version}</td>
                    <td>${ye(u.last_seen_minutes_ago)}</td>
                    <td>${u.uptime?ye(Math.floor(u.uptime/60)):""}</td>
                    <td>${u.error?d`<span class="badge bad">error ${u.error}</span>`:u.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${U} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function Uo(){let e=K(Ht.get,5e3);return d`<${Ul} ...${e} /><${Bl} ...${e} /><${jl} /><${ql} /><${Wl} />`}function Ul({data:e,error:t}){return d`
    <${F} title="Gateway" aside=${d`<${L} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await E(Ht.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${fi(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${U} error=${t} />`}
    <//>`}function Bl({data:e,error:t}){if(!e)return d`<${F} title="Network"><${U} error=${t} /><//>`;let n=e.network;if(!n)return d`<${F} title="Network"><p>No Ethernet.</p><//>`;let i=r=>r.map(a=>d`<div>${a.address} <span class="muted">(${a.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${F} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?i(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?i(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function jl(){let{data:e,error:t,reload:n}=K(Ut.get),[i,o]=_({});if(!e)return d`<${U} error=${t} />`;let r=l=>l in i?i[l]:e[l],a=(l,u)=>p=>o({...i,[l]:u?+p.target.value:p.target.value}),s=async()=>{let l={...i};if(l.web_password||delete l.web_password,Object.keys(l).length===0)return M("Nothing changed");let u=await E(()=>Ut.update(l),"Saved");u&&(u.restart_required&&M("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${F} title="Settings">
      <div class="row">
        <${T} label="Hostname"><input value=${r("hostname")} onInput=${a("hostname")} /><//>
        <${T} label="CAN bitrate"><select value=${r("can_bitrate")} onChange=${a("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${T} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${r("update_delay_ms")} onInput=${a("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${T} label="User name"><input value=${r("web_username")} onInput=${a("web_username")} autocomplete="off" /><//>
        <${T} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${i.web_password||""} onInput=${a("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${L} kind="primary" onClick=${s}>Save<//></div>
    <//>`}var Yl=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function ql(){let{data:e,error:t,reload:n}=K(Bt.get),[i,o]=_({});if(!e)return d`<${F} title="Location and time"><${U} error=${t} /><//>`;let r=c=>c in i?i[c]:e[c]??"",a=c=>f=>o({...i,[c]:f.target.value}),s=async()=>{let c={};if(("latitude"in i||"longitude"in i)&&(c.latitude=parseFloat(r("latitude")),c.longitude=parseFloat(r("longitude")),Number.isNaN(c.latitude)||Number.isNaN(c.longitude)))return M("Latitude and longitude are numbers");if("timezone"in i&&(c.timezone=i.timezone.trim()),Object.keys(c).length===0)return M("Nothing changed");await E(()=>Bt.update(c),"Saved")&&(o({}),n())},l=()=>{if(!navigator.geolocation)return M("This browser has no location","error");navigator.geolocation.getCurrentPosition(c=>o({...i,latitude:c.coords.latitude.toFixed(4),longitude:c.coords.longitude.toFixed(4)}),c=>M(`No location: ${c.message}`,"error"),{timeout:15e3})},u=e.utc_offset_minutes,p=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return d`
    <${F} title="Location and time">
      <p class="muted">
        For switching by local time and by the sun (schedules, motion light levels). Two decimals (about 1 km) are plenty.
        Take this browser's location, or look the place up on a map: in OpenStreetMap or Google Maps a right click on the house shows
        latitude and longitude. Save, then check today's sunrise and sunset below.
      </p>
      <div class="row">
        <${T} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${r("latitude")} onInput=${a("latitude")} /><//>
        <${T} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${r("longitude")} onInput=${a("longitude")} /><//>
        <${T} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${r("timezone")} onInput=${a("timezone")} /><//>
      </div>
      <div class="buttons"><${L} kind="primary" onClick=${s}>Save<//><button onClick=${l}>Use this browser's location</button></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${p})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?Yl.map(([c,f])=>d`<div><dt>${f}</dt><dd>${e.sun[c]||d`<span class="muted">not today</span>`}</dd></div>`):d`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function Wl(){return d`
    <${F} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${xt} target="gateway" label="Install and restart" />
    <//>`}var Kl=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],Gl={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Vl={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},he=async(e,t)=>await E(e,t)!==void 0,wn=e=>e?new Date(e).toLocaleString():"\u2014";function kn({label:e,accept:t,send:n,success:i,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async a=>{let s=a.target.files[0];if(a.target.value="",!s)return;let l=await s.text();await he(()=>n(l),i)&&o&&o()}} hidden /></label>`}function Bo(){let{data:e,error:t,reload:n}=K(ee.get,1e4);return e?d`
    <${Ql} d=${e} />
    <${Xl} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${zl} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${Jl} reload=${n} />`}
    ${e.mode==="est"&&d`<${Zl} d=${e} reload=${n} />`}
    <${ec} d=${e} reload=${n} />
    <${tc} d=${e} reload=${n} />`:d`<${U} error=${t} />`}function xn({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${wn(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${wn(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function Ql({d:e}){let t=e.certificate,[n,i]=t?Gl[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${F} title="Certificate" aside=${d`<span class=${"badge "+i}>${n}</span>`}>
      ${t?d`<${xn} c=${t} />
            <p class="muted">Made: ${Vl[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&d`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Xl({d:e,reload:t}){let[n,i]=_(e.fqdn),[o,r]=_(e.mode),a=async()=>{let s={};if(n!==e.fqdn&&(s.fqdn=n.trim()),o!==e.mode&&(s.mode=o),Object.keys(s).length===0)return M("Nothing changed");await he(()=>ee.update(s),"Saved")&&t()};return d`
    <${F} title="HTTPS settings">
      <div class="row">
        <${T} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${s=>i(s.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${Kl.map(([s,l,u])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${s} checked=${o===s} onChange=${()=>r(s)} />
          <span><strong>${l}</strong><small class="muted">${u}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${L} kind="primary" onClick=${a}>Save<//></div>
    <//>`}function zl({d:e,reload:t}){let[n,i]=_(e.validity_years);return d`
    <${F} title="Self-signed certificate">
      <div class="row">
        <${T} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${r=>i(+r.target.value)} /><//>
      </div>
      <div class="buttons"><${L} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await he(()=>ee.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function Jl({reload:e}){return d`
    <${F} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${ee.csrUrl()} download="gateway.csr">Download CSR</a>
        <${kn} label="Upload certificate" send=${ee.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function Zl({d:e,reload:t}){let n=e.est,[i,o]=_(n.url),[r,a]=_(n.auto_renew),s=async()=>{await he(()=>ee.update({est_url:i.trim(),est_auto_renew:r}),"Saved")&&t()},l=async()=>{await he(ee.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${F} title="EST">
      <div class="row">
        <${T} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${i} onInput=${u=>o(u.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${r} onChange=${u=>a(u.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${wn(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${xn} c=${n.identity} />`}
      <div class="buttons">
        <${kn} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${ee.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${L} kind="danger" onClick=${async()=>await he(ee.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${L} kind="primary" onClick=${s}>Save<//>
        <${L} onClick=${l}>Enroll / renew now<//>
      </div>
    <//>`}function ec({d:e,reload:t}){let n=e.trust_anchor,i=async o=>{await he(()=>ee.update({built_in_roots:o}),o?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return d`
    <${F} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${o=>i(o.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?d`<${xn} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${kn} label=${n?"Replace":"Upload"} send=${ee.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&d`<${L} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await he(ee.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function tc({d:e,reload:t}){let[n,i]=_(e.ntp_server),o=async()=>{await he(()=>ee.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${F} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${T} label="NTP server"><input value=${n} placeholder="automatic" onInput=${r=>i(r.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&d`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?d` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${L} onClick=${o}>Save<//></div>
    <//>`}var nc={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Yo(){let{data:e,error:t,reload:n}=K(be.all,5e3);return e?d`
    <${jo} slot="primary" b=${e.primary} reload=${n} />
    <${jo} slot="secondary" b=${e.secondary} reload=${n} />
    <${ic} on=${e.home_assistant} reload=${n} />`:d`<${U} error=${t} />`}function ic({on:e,reload:t}){return d`
    <${F} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async i=>{let o=i.target.checked;await E(()=>be.updateAll({home_assistant:o}),o?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}var oc={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function jo({slot:e,b:t,reload:n}){let[i,o]=_({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[r,a]=_(null),s=i.uri.startsWith("mqtts://"),l=c=>f=>o({...i,[c]:f.target.type==="checkbox"?f.target.checked:f.target.value}),u=async()=>{let c={uri:i.uri,user:i.user,enabled:i.enabled,tls_insecure:i.tls_insecure};i.password&&(c.password=i.password),await E(()=>be.update(e,c),`${e} broker saved, reconnecting`)&&(o({...i,password:""}),setTimeout(n,2500))},p=async()=>{let c=await E(()=>be.certificate(e));c&&a(c)};return d`
    <${F}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${nc[e]}</p>
      <div class="row">
        <${T} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${i.uri} onInput=${l("uri")} /><//>
        <${T} label="User"><input value=${i.user} onInput=${l("user")} autocomplete="off" /><//>
        <${T} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${i.password} onInput=${l("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${i.enabled} onChange=${l("enabled")} /> Connect to this broker</label>
      ${s&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${oc[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${i.tls_insecure} onChange=${l("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${L} onClick=${async()=>{await E(()=>be.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${L} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${L} kind="danger" onClick=${async()=>{await E(()=>be.forget(e),"Certificate forgotten"),a(null),n()}}>Forget<//>`}
          </div>
          ${r&&d`<p>${r.pinned?d`SHA-256 <code>${r.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${L} kind="primary" onClick=${u}>Save<//></div>
    <//>`}var rc=[{path:"/",title:"Devices",page:Ho},{path:"/devices/:device",title:"Device",page:Po},{path:"/sensors",title:"Sensors",page:Mo},{path:"/automation",title:"Automation",page:gn},{path:"/automation/:tab",title:"Automation",page:gn},{path:"/mqtt",title:"MQTT",page:Yo},{path:"/gateway",title:"Gateway",page:Uo},{path:"/https",title:"HTTPS",page:Bo}],ac=[["/","Devices"],["/sensors","Sensors"],["/automation","Automation"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function sc(){let e=si(),t=li(rc,e),n=t?t.route.page:null,i=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${ac.map(([o,r])=>d`<${Q} href=${o} class=${i(o)?"active":""}>${r}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${Q} href="/">Devices<//></p>`}
    </main>
    <${pi} />`}jn(d`<${sc} />`,document.getElementById("app"));
