var At=Object.create;var Me=Object.defineProperty;var Ht=Object.getOwnPropertyDescriptor;var It=Object.getOwnPropertyNames;var Mt=Object.getPrototypeOf,Ut=Object.prototype.hasOwnProperty;var Pt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Nt=(e,t,n,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of It(t))!Ut.call(e,a)&&a!==n&&Me(e,a,{get:()=>t[a],enumerable:!(r=Ht(t,a))||r.enumerable});return e};var Dt=(e,t,n)=>(n=e!=null?At(Mt(e)):{},Nt(t||!e||!e.__esModule?Me(n,"default",{value:e,enumerable:!0}):n,e));var dt=Pt(Ee=>{var _t;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Ee=="object"?e(Ee):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(_t={}):e(_t={})})(function(e){e.version="1.2.2";function t(){for(var d=0,L=new Array(256),m=0;m!=256;++m)d=m,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,L[m]=d;return typeof Int32Array<"u"?new Int32Array(L):L}var n=t();function r(d){var L=0,m=0,g=0,v=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(g=0;g!=256;++g)v[g]=d[g];for(g=0;g!=256;++g)for(m=d[g],L=256+g;L<4096;L+=256)m=v[L]=m>>>8^d[m&255];var x=[];for(g=1;g!=16;++g)x[g-1]=typeof Int32Array<"u"?v.subarray(g*256,g*256+256):v.slice(g*256,g*256+256);return x}var a=r(n),o=a[0],s=a[1],u=a[2],l=a[3],c=a[4],p=a[5],i=a[6],f=a[7],h=a[8],y=a[9],I=a[10],F=a[11],w=a[12],k=a[13],W=a[14];function P(d,L){for(var m=L^-1,g=0,v=d.length;g<v;)m=m>>>8^n[(m^d.charCodeAt(g++))&255];return~m}function Q(d,L){for(var m=L^-1,g=d.length-15,v=0;v<g;)m=W[d[v++]^m&255]^k[d[v++]^m>>8&255]^w[d[v++]^m>>16&255]^F[d[v++]^m>>>24]^I[d[v++]]^y[d[v++]]^h[d[v++]]^f[d[v++]]^i[d[v++]]^p[d[v++]]^c[d[v++]]^l[d[v++]]^u[d[v++]]^s[d[v++]]^o[d[v++]]^n[d[v++]];for(g+=15;v<g;)m=m>>>8^n[(m^d[v++])&255];return~m}function V(d,L){for(var m=L^-1,g=0,v=d.length,x=0,$e=0;g<v;)x=d.charCodeAt(g++),x<128?m=m>>>8^n[(m^x)&255]:x<2048?(m=m>>>8^n[(m^(192|x>>6&31))&255],m=m>>>8^n[(m^(128|x&63))&255]):x>=55296&&x<57344?(x=(x&1023)+64,$e=d.charCodeAt(g++)&1023,m=m>>>8^n[(m^(240|x>>8&7))&255],m=m>>>8^n[(m^(128|x>>2&63))&255],m=m>>>8^n[(m^(128|$e>>6&15|(x&3)<<4))&255],m=m>>>8^n[(m^(128|$e&63))&255]):(m=m>>>8^n[(m^(224|x>>12&15))&255],m=m>>>8^n[(m^(128|x>>6&63))&255],m=m>>>8^n[(m^(128|x&63))&255]);return~m}e.table=n,e.bstr=P,e.buf=Q,e.str=V})});var _e,S,Oe,Ot,j,Ue,qe,We,Ve,be,ge,ye,qt,te={},je=[],Wt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,de=Array.isArray;function O(e,t){for(var n in t)e[n]=t[n];return e}function we(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ne(e,t,n){var r,a,o,s={};for(o in t)o=="key"?r=t[o]:o=="ref"?a=t[o]:s[o]=t[o];if(arguments.length>2&&(s.children=arguments.length>3?_e.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(o in e.defaultProps)s[o]===void 0&&(s[o]=e.defaultProps[o]);return ce(e,s,r,a,null)}function ce(e,t,n,r,a){var o={type:e,props:t,key:n,ref:r,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:a??++Oe,__i:-1,__u:0};return a==null&&S.vnode!=null&&S.vnode(o),o}function pe(e){return e.children}function le(e,t){this.props=e,this.context=t}function X(e,t){if(t==null)return e.__?X(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?X(e):null}function Ge(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Ge(e)}}function Pe(e){(!e.__d&&(e.__d=!0)&&j.push(e)&&!ue.__r++||Ue!=S.debounceRendering)&&((Ue=S.debounceRendering)||qe)(ue)}function ue(){for(var e,t,n,r,a,o,s,u=1;j.length;)j.length>u&&j.sort(We),e=j.shift(),u=j.length,e.__d&&(n=void 0,a=(r=(t=e).__v).__e,o=[],s=[],t.__P&&((n=O({},r)).__v=r.__v+1,S.vnode&&S.vnode(n),ke(t.__P,n,r,t.__n,t.__P.namespaceURI,32&r.__u?[a]:null,o,a??X(r),!!(32&r.__u),s),n.__v=r.__v,n.__.__k[n.__i]=n,Je(o,n,s),n.__e!=a&&Ge(n)));ue.__r=0}function Ke(e,t,n,r,a,o,s,u,l,c,p){var i,f,h,y,I,F,w=r&&r.__k||je,k=t.length;for(l=Vt(n,t,w,l,k),i=0;i<k;i++)(h=n.__k[i])!=null&&(f=h.__i==-1?te:w[h.__i]||te,h.__i=i,F=ke(e,h,f,a,o,s,u,l,c,p),y=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&Se(f.ref,null,h),p.push(h.ref,h.__c||y,h)),I==null&&y!=null&&(I=y),4&h.__u||f.__k===h.__k?l=Be(h,l,e):typeof h.type=="function"&&F!==void 0?l=F:y&&(l=y.nextSibling),h.__u&=-7);return n.__e=I,l}function Vt(e,t,n,r,a){var o,s,u,l,c,p=n.length,i=p,f=0;for(e.__k=new Array(a),o=0;o<a;o++)(s=t[o])!=null&&typeof s!="boolean"&&typeof s!="function"?(l=o+f,(s=e.__k[o]=typeof s=="string"||typeof s=="number"||typeof s=="bigint"||s.constructor==String?ce(null,s,null,null,null):de(s)?ce(pe,{children:s},null,null,null):s.constructor==null&&s.__b>0?ce(s.type,s.props,s.key,s.ref?s.ref:null,s.__v):s).__=e,s.__b=e.__b+1,u=null,(c=s.__i=jt(s,n,l,i))!=-1&&(i--,(u=n[c])&&(u.__u|=2)),u==null||u.__v==null?(c==-1&&(a>p?f--:a<p&&f++),typeof s.type!="function"&&(s.__u|=4)):c!=l&&(c==l-1?f--:c==l+1?f++:(c>l?f--:f++,s.__u|=4))):e.__k[o]=null;if(i)for(o=0;o<p;o++)(u=n[o])!=null&&(2&u.__u)==0&&(u.__e==r&&(r=X(u)),Qe(u,u));return r}function Be(e,t,n){var r,a;if(typeof e.type=="function"){for(r=e.__k,a=0;r&&a<r.length;a++)r[a]&&(r[a].__=e,t=Be(r[a],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=X(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function jt(e,t,n,r){var a,o,s=e.key,u=e.type,l=t[n];if(l===null&&e.key==null||l&&s==l.key&&u==l.type&&(2&l.__u)==0)return n;if(r>(l!=null&&(2&l.__u)==0?1:0))for(a=n-1,o=n+1;a>=0||o<t.length;){if(a>=0){if((l=t[a])&&(2&l.__u)==0&&s==l.key&&u==l.type)return a;a--}if(o<t.length){if((l=t[o])&&(2&l.__u)==0&&s==l.key&&u==l.type)return o;o++}}return-1}function Ne(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Wt.test(t)?n:n+"px"}function se(e,t,n,r,a){var o,s;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof r=="string"&&(e.style.cssText=r=""),r)for(t in r)n&&t in n||Ne(e.style,t,"");if(n)for(t in n)r&&n[t]==r[t]||Ne(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")o=t!=(t=t.replace(Ve,"$1")),s=t.toLowerCase(),t=s in e||t=="onFocusOut"||t=="onFocusIn"?s.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+o]=n,n?r?n.u=r.u:(n.u=be,e.addEventListener(t,o?ye:ge,o)):e.removeEventListener(t,o?ye:ge,o);else{if(a=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function De(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=be++;else if(t.t<n.u)return;return n(S.event?S.event(t):t)}}}function ke(e,t,n,r,a,o,s,u,l,c){var p,i,f,h,y,I,F,w,k,W,P,Q,V,d,L,m,g,v=t.type;if(t.constructor!=null)return null;128&n.__u&&(l=!!(32&n.__u),o=[u=t.__e=n.__e]),(p=S.__b)&&p(t);e:if(typeof v=="function")try{if(w=t.props,k="prototype"in v&&v.prototype.render,W=(p=v.contextType)&&r[p.__c],P=p?W?W.props.value:p.__:r,n.__c?F=(i=t.__c=n.__c).__=i.__E:(k?t.__c=i=new v(w,P):(t.__c=i=new le(w,P),i.constructor=v,i.render=Kt),W&&W.sub(i),i.props=w,i.state||(i.state={}),i.context=P,i.__n=r,f=i.__d=!0,i.__h=[],i._sb=[]),k&&i.__s==null&&(i.__s=i.state),k&&v.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=O({},i.__s)),O(i.__s,v.getDerivedStateFromProps(w,i.__s))),h=i.props,y=i.state,i.__v=t,f)k&&v.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),k&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(k&&v.getDerivedStateFromProps==null&&w!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(w,P),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(w,i.__s,P)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=w,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(x){x&&(x.__=t)}),Q=0;Q<i._sb.length;Q++)i.__h.push(i._sb[Q]);i._sb=[],i.__h.length&&s.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(w,i.__s,P),k&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,y,I)})}if(i.context=P,i.props=w,i.__P=e,i.__e=!1,V=S.__r,d=0,k){for(i.state=i.__s,i.__d=!1,V&&V(t),p=i.render(i.props,i.state,i.context),L=0;L<i._sb.length;L++)i.__h.push(i._sb[L]);i._sb=[]}else do i.__d=!1,V&&V(t),p=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++d<25);i.state=i.__s,i.getChildContext!=null&&(r=O(O({},r),i.getChildContext())),k&&!f&&i.getSnapshotBeforeUpdate!=null&&(I=i.getSnapshotBeforeUpdate(h,y)),m=p,p!=null&&p.type===pe&&p.key==null&&(m=ze(p.props.children)),u=Ke(e,de(m)?m:[m],t,n,r,a,o,s,u,l,c),i.base=t.__e,t.__u&=-161,i.__h.length&&s.push(i),F&&(i.__E=i.__=null)}catch(x){if(t.__v=null,l||o!=null)if(x.then){for(t.__u|=l?160:128;u&&u.nodeType==8&&u.nextSibling;)u=u.nextSibling;o[o.indexOf(u)]=null,t.__e=u}else for(g=o.length;g--;)we(o[g]);else t.__e=n.__e,t.__k=n.__k;S.__e(x,t,n)}else o==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):u=t.__e=Gt(n.__e,t,n,r,a,o,s,l,c);return(p=S.diffed)&&p(t),128&t.__u?void 0:u}function Je(e,t,n){for(var r=0;r<n.length;r++)Se(n[r],n[++r],n[++r]);S.__c&&S.__c(t,e),e.some(function(a){try{e=a.__h,a.__h=[],e.some(function(o){o.call(a)})}catch(o){S.__e(o,a.__v)}})}function ze(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:de(e)?e.map(ze):O({},e)}function Gt(e,t,n,r,a,o,s,u,l){var c,p,i,f,h,y,I,F=n.props,w=t.props,k=t.type;if(k=="svg"?a="http://www.w3.org/2000/svg":k=="math"?a="http://www.w3.org/1998/Math/MathML":a||(a="http://www.w3.org/1999/xhtml"),o!=null){for(c=0;c<o.length;c++)if((h=o[c])&&"setAttribute"in h==!!k&&(k?h.localName==k:h.nodeType==3)){e=h,o[c]=null;break}}if(e==null){if(k==null)return document.createTextNode(w);e=document.createElementNS(a,k,w.is&&w),u&&(S.__m&&S.__m(t,o),u=!1),o=null}if(k==null)F===w||u&&e.data==w||(e.data=w);else{if(o=o&&_e.call(e.childNodes),F=n.props||te,!u&&o!=null)for(F={},c=0;c<e.attributes.length;c++)F[(h=e.attributes[c]).name]=h.value;for(c in F)if(h=F[c],c!="children"){if(c=="dangerouslySetInnerHTML")i=h;else if(!(c in w)){if(c=="value"&&"defaultValue"in w||c=="checked"&&"defaultChecked"in w)continue;se(e,c,null,h,a)}}for(c in w)h=w[c],c=="children"?f=h:c=="dangerouslySetInnerHTML"?p=h:c=="value"?y=h:c=="checked"?I=h:u&&typeof h!="function"||F[c]===h||se(e,c,h,F[c],a);if(p)u||i&&(p.__html==i.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(i&&(e.innerHTML=""),Ke(t.type=="template"?e.content:e,de(f)?f:[f],t,n,r,k=="foreignObject"?"http://www.w3.org/1999/xhtml":a,o,s,o?o[0]:n.__k&&X(n,0),u,l),o!=null)for(c=o.length;c--;)we(o[c]);u||(c="value",k=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[c]||k=="progress"&&!y||k=="option"&&y!=F[c])&&se(e,c,y,F[c],a),c="checked",I!=null&&I!=e[c]&&se(e,c,I,F[c],a))}return e}function Se(e,t,n){try{if(typeof e=="function"){var r=typeof e.__u=="function";r&&e.__u(),r&&t==null||(e.__u=e(t))}else e.current=t}catch(a){S.__e(a,n)}}function Qe(e,t,n){var r,a;if(S.unmount&&S.unmount(e),(r=e.ref)&&(r.current&&r.current!=e.__e||Se(r,null,t)),(r=e.__c)!=null){if(r.componentWillUnmount)try{r.componentWillUnmount()}catch(o){S.__e(o,t)}r.base=r.__P=null}if(r=e.__k)for(a=0;a<r.length;a++)r[a]&&Qe(r[a],t,n||typeof e.type!="function");n||we(e.__e),e.__c=e.__=e.__e=void 0}function Kt(e,t,n){return this.constructor(e,n)}function Xe(e,t,n){var r,a,o,s;t==document&&(t=document.documentElement),S.__&&S.__(e,t),a=(r=typeof n=="function")?null:n&&n.__k||t.__k,o=[],s=[],ke(t,e=(!r&&n||t).__k=ne(pe,null,[e]),a||te,te,t.namespaceURI,!r&&n?[n]:a?null:t.firstChild?_e.call(t.childNodes):null,o,!r&&n?n:a?a.__e:t.firstChild,r,s),Je(o,e,s)}_e=je.slice,S={__e:function(e,t,n,r){for(var a,o,s;t=t.__;)if((a=t.__c)&&!a.__)try{if((o=a.constructor)&&o.getDerivedStateFromError!=null&&(a.setState(o.getDerivedStateFromError(e)),s=a.__d),a.componentDidCatch!=null&&(a.componentDidCatch(e,r||{}),s=a.__d),s)return a.__E=a}catch(u){e=u}throw e}},Oe=0,Ot=function(e){return e!=null&&e.constructor==null},le.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=O({},this.state),typeof e=="function"&&(e=e(O({},n),this.props)),e&&O(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Pe(this))},le.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Pe(this))},le.prototype.render=pe,j=[],qe=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,We=function(e,t){return e.__v.__b-t.__v.__b},ue.__r=0,Ve=/(PointerCapture)$|Capture$/i,be=0,ge=De(!1),ye=De(!0),qt=0;var re,E,xe,Ye,oe=0,it=[],R=S,Ze=R.__b,et=R.__r,tt=R.diffed,nt=R.__c,rt=R.unmount,ot=R.__;function Te(e,t){R.__h&&R.__h(E,e,oe||t),oe=0;var n=E.__H||(E.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function b(e){return oe=1,Bt(ut,e)}function Bt(e,t,n){var r=Te(re++,2);if(r.t=e,!r.__c&&(r.__=[n?n(t):ut(void 0,t),function(u){var l=r.__N?r.__N[0]:r.__[0],c=r.t(l,u);l!==c&&(r.__N=[c,r.__[1]],r.__c.setState({}))}],r.__c=E,!E.__f)){var a=function(u,l,c){if(!r.__c.__H)return!0;var p=r.__c.__H.__.filter(function(f){return!!f.__c});if(p.every(function(f){return!f.__N}))return!o||o.call(this,u,l,c);var i=r.__c.props!==u;return p.forEach(function(f){if(f.__N){var h=f.__[0];f.__=f.__N,f.__N=void 0,h!==f.__[0]&&(i=!0)}}),o&&o.call(this,u,l,c)||i};E.__f=!0;var o=E.shouldComponentUpdate,s=E.componentWillUpdate;E.componentWillUpdate=function(u,l,c){if(this.__e){var p=o;o=void 0,a(u,l,c),o=p}s&&s.call(this,u,l,c)},E.shouldComponentUpdate=a}return r.__N||r.__}function G(e,t){var n=Te(re++,3);!R.__s&&lt(n.__H,t)&&(n.__=e,n.u=t,E.__H.__h.push(n))}function me(e){return oe=5,st(function(){return{current:e}},[])}function st(e,t){var n=Te(re++,7);return lt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function ct(e,t){return oe=8,st(function(){return e},t)}function Jt(){for(var e;e=it.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(fe),e.__H.__h.forEach(Ce),e.__H.__h=[]}catch(t){e.__H.__h=[],R.__e(t,e.__v)}}R.__b=function(e){E=null,Ze&&Ze(e)},R.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),ot&&ot(e,t)},R.__r=function(e){et&&et(e),re=0;var t=(E=e.__c).__H;t&&(xe===E?(t.__h=[],E.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(fe),t.__h.forEach(Ce),t.__h=[],re=0)),xe=E},R.diffed=function(e){tt&&tt(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(it.push(t)!==1&&Ye===R.requestAnimationFrame||((Ye=R.requestAnimationFrame)||zt)(Jt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),xe=E=null},R.__c=function(e,t){t.some(function(n){try{n.__h.forEach(fe),n.__h=n.__h.filter(function(r){return!r.__||Ce(r)})}catch(r){t.some(function(a){a.__h&&(a.__h=[])}),t=[],R.__e(r,n.__v)}}),nt&&nt(e,t)},R.unmount=function(e){rt&&rt(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(r){try{fe(r)}catch(a){t=a}}),n.__H=void 0,t&&R.__e(t,n.__v))};var at=typeof requestAnimationFrame=="function";function zt(e){var t,n=function(){clearTimeout(r),at&&cancelAnimationFrame(t),setTimeout(e)},r=setTimeout(n,35);at&&(t=requestAnimationFrame(n))}function fe(e){var t=E,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),E=t}function Ce(e){var t=E;e.__c=e.__(),E=t}function lt(e,t){return!e||e.length!==t.length||t.some(function(n,r){return n!==e[r]})}function ut(e,t){return typeof t=="function"?t(e):t}var pt=Dt(dt()),ft="/api/v1",Y=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},Qt=e=>new Promise(t=>setTimeout(t,e));async function ie(e,t,n){for(let r=1;;r++){let a;try{a=await fetch(ft+t,{method:e,headers:n===void 0?{}:{"Content-Type":"application/json"},body:n===void 0?void 0:JSON.stringify(n)})}catch{if(r>=4)throw new Y(0,{message:"gateway unreachable"});await Qt(250*r);continue}let o=await a.text(),s=null;try{s=o?JSON.parse(o):null}catch{s={message:o}}if(!a.ok)throw new Y(a.status,s);return s}}var q=e=>ie("GET",e),ae=(e,t)=>ie("POST",e,t),K=(e,t)=>ie("PUT",e,t),Fe=(e,t)=>ie("PATCH",e,t),Xt=e=>ie("DELETE",e),N=encodeURIComponent,Re={get:()=>q("/system"),restart:()=>ae("/system/restart")},Le={get:()=>q("/config"),update:e=>Fe("/config",e)},Z={all:()=>q("/mqtt"),update:(e,t)=>Fe(`/mqtt/${e}`,t),trust:e=>ae(`/mqtt/${e}/trust`),certificate:e=>q(`/mqtt/${e}/certificate`),forget:e=>Xt(`/mqtt/${e}/certificate`)},H={async list(){let e=[];for(;;){let t=await q(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>q(`/devices/${N(e)}`),update:(e,t)=>Fe(`/devices/${N(e)}`,t),action:(e,t)=>ae(`/devices/${N(e)}/${t}`),silence:(e,t)=>K(`/devices/${N(e)}/silence`,{on:t}),relay:(e,t,n,r)=>K(`/devices/${N(e)}/relays/${t}`,{state:n,duration_ms:r}),rollershutter:(e,t,n,r)=>K(`/devices/${N(e)}/rollershutters/${t}`,{state:n,duration_ms:r}),lamps:(e,t,n,r)=>K(`/devices/${N(e)}/lamps/${t}`,{value:n,bitmask:r}),heating:(e,t,n)=>K(`/devices/${N(e)}/heating/${t}`,n),heatingManual:(e,t,n,r)=>K(`/devices/${N(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:r})},mt={async list(e){let t=[];for(;;){let n=e?`&device=${N(e)}`:"",r=await q(`/sensors?offset=${t.length}${n}`);if(t.push(...r.sensors),r.sensors.length===0||t.length>=r.total)return t}}},B={action:e=>ae(`/bus/${e}`),silence:e=>K("/bus/silence",{on:e}),typeAction:(e,t)=>ae(`/device-types/${e}/${t}`)},ht={job:()=>q("/firmware/job"),upload(e,t,n){let r=pt.default.buf(new Uint8Array(t))>>>0,a=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((o,s)=>{let u=new XMLHttpRequest;u.open("PUT",`${ft}${a}?crc32=${r}`),u.setRequestHeader("Content-Type","application/octet-stream"),u.upload.onprogress=l=>l.lengthComputable&&n&&n(l.loaded/l.total),u.onload=()=>{let l=null;try{l=JSON.parse(u.responseText)}catch{}u.status>=200&&u.status<300?o(l):s(new Y(u.status,l))},u.onerror=()=>s(new Y(0,{message:"upload failed"})),u.send(t)})}};var $t=function(e,t,n,r){var a;t[0]=0;for(var o=1;o<t.length;o++){var s=t[o++],u=t[o]?(t[0]|=s?1:2,n[t[o++]]):t[++o];s===3?r[0]=u:s===4?r[1]=Object.assign(r[1]||{},u):s===5?(r[1]=r[1]||{})[t[++o]]=u:s===6?r[1][t[++o]]+=u+"":s?(a=e.apply(u,$t(e,u,n,["",null])),r.push(a),u[0]?t[0]|=2:(t[o-2]=0,t[o]=a)):r.push(u)}return r},vt=new Map;function gt(e){var t=vt.get(this);return t||(t=new Map,vt.set(this,t)),(t=$t(this,t.get(e)||(t.set(e,t=function(n){for(var r,a,o=1,s="",u="",l=[0],c=function(f){o===1&&(f||(s=s.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?l.push(0,f,s):o===3&&(f||s)?(l.push(3,f,s),o=2):o===2&&s==="..."&&f?l.push(4,f,0):o===2&&s&&!f?l.push(5,0,!0,s):o>=5&&((s||!f&&o===5)&&(l.push(o,0,s,a),o=6),f&&(l.push(o,f,0,a),o=6)),s=""},p=0;p<n.length;p++){p&&(o===1&&c(),c(p));for(var i=0;i<n[p].length;i++)r=n[p][i],o===1?r==="<"?(c(),l=[l],o=3):s+=r:o===4?s==="--"&&r===">"?(o=1,s=""):s=r+s[0]:u?r===u?u="":s+=r:r==='"'||r==="'"?u=r:r===">"?(c(),o=1):o&&(r==="="?(o=5,a=s,s=""):r==="/"&&(o<5||n[p][i+1]===">")?(c(),o===3&&(l=l[0]),o=l,(l=l[0]).push(2,0,o),o=0):r===" "||r==="	"||r===`
`||r==="\r"?(c(),o=2):s+=r),o===3&&s==="!--"&&(o=4,l=l[0])}return c(),l}(e)),t),arguments,[])).length>1?t:t[0]}var _=gt.bind(ne),Ae=()=>{};function D(e,t="ok"){Ae(e,t)}function yt(){let[e,t]=b([]);return G(()=>{let n=0;return Ae=(r,a)=>{let o={id:++n,message:r,kind:a};t(s=>[...s,o]),setTimeout(()=>t(s=>s.filter(u=>u!==o)),a==="error"?8e3:3e3)},()=>Ae=()=>{}},[]),_`<div class="toasts">
    ${e.map(n=>_`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function C(e,t){try{let n=await e();return t&&D(t),n}catch(n){D(n.message,"error");return}}function M(e,t){let[n,r]=b({data:void 0,error:void 0}),a=me(e);a.current=e;let o=ct(async()=>{try{r({data:await a.current(),error:void 0})}catch(s){r(u=>({data:u.data,error:s}))}},[]);return G(()=>{let s=!1,u,l=async()=>{await o(),t&&!s&&(u=setTimeout(l,t))};return l(),()=>{s=!0,clearTimeout(u)}},[t,o]),{...n,reload:o}}var A=({title:e,children:t,aside:n})=>_`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,U=({error:e})=>e?_`<p class="error">${e.message}</p>`:_`<p class="muted">Loading…</p>`,T=({label:e,hint:t,children:n})=>_`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&_`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:r})=>{let[a,o]=b(!1);return _`<button class=${t||""} disabled=${r||a} onClick=${async u=>{o(!0);try{await n(u)}finally{o(!1)}}}>${e}</button>`},He=e=>"0x"+e.toString(16).padStart(2,"0");function J(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function bt(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),r=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${r} min`:`${r} min`}function he({target:e,label:t,onDone:n}){let[r,a]=b(null),[o,s]=b(null);return _`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${l=>a(l.target.files[0]||null)} />
      <${$} onClick=${async()=>{if(r){s(0);try{let l=await r.arrayBuffer(),c=await ht.upload(e,l,s);D(c&&c.restarting?"Firmware installed, the gateway restarts\u2026":"Firmware sent"),n&&n(c)}catch(l){D(l.message,"error")}s(null)}}} disabled=${!r||o!==null}>${t||"Upload"}<//>
      ${o!==null&&_`<progress max="1" value=${o}></progress>`}
    </div>`}var ve=new Set;function Yt(e){e!==location.pathname&&history.pushState(null,"",e),ve.forEach(t=>t())}addEventListener("popstate",()=>ve.forEach(e=>e()));function wt(){let[e,t]=b(location.pathname);return G(()=>{let n=()=>t(location.pathname);return ve.add(n),()=>ve.delete(n)},[]),e}function kt(e,t){let n=t.split("/").filter(Boolean);for(let r of e){let a=r.path.split("/").filter(Boolean);if(a.length!==n.length)continue;let o={};if(a.every((u,l)=>u.startsWith(":")?(o[u.slice(1)]=decodeURIComponent(n[l]),!0):u===n[l]))return{route:r,params:o}}return null}function z({href:e,children:t,...n}){return ne("a",{href:e,onClick:a=>{a.metaKey||a.ctrlKey||a.shiftKey||a.button!==0||(a.preventDefault(),Yt(e))},...n},t)}var Zt={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"};function Ie({device:e}){let{data:t,error:n}=M(()=>mt.list(e),5e3);return t?t.length===0?_`<p class="muted">No sensor reading seen yet.</p>`:_`<div class="table-wrap"><table>
    <thead><tr>${!e&&_`<th>Device</th>`}<th>Kind</th><th>Sensor</th><th>Value</th><th>Seen</th></tr></thead>
    <tbody>
      ${t.map(r=>_`<tr key=${r.device_key+r.kind+r.sensor_id}>
          ${!e&&_`<td><${z} href=${"/devices/"+encodeURIComponent(r.device)}>${r.device}<//></td>`}
          <td>${Zt[r.kind]||r.kind}</td>
          <td><code>${r.sensor_id}</code></td>
          <td>${r.kind==="temperature"?r.value.toFixed(2):r.value} ${r.unit}</td>
          <td>${r.age_s<60?`${r.age_s} s`:J(Math.floor(r.age_s/60))}</td>
        </tr>`)}
    </tbody>
  </table></div>`:_`<${U} error=${n} />`}function St(){return _`<${A} title="Sensors"><${Ie} /><//>`}var en=[2,5,8,9],tn=[7],nn=[3],xt=[9],rn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],on=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Tt({device:e}){let{data:t,error:n,reload:r}=M(()=>H.get(e),5e3);return t?_`
    <${an} d=${t} reload=${r} />
    ${en.includes(t.device_type)&&_`<${Ct} d=${t} kind="relay" />`}
    ${tn.includes(t.device_type)&&_`<${Ct} d=${t} kind="rollershutter" />`}
    ${nn.includes(t.device_type)&&_`<${sn} d=${t} />`}
    ${xt.includes(t.device_type)&&_`<${cn} d=${t} />`}
    ${xt.includes(t.device_type)&&_`<${_n} d=${t} />`}
    <${A} title="Sensors"><${Ie} device=${t.name||t.key} /><//>
    <${dn} d=${t} reload=${r} />
    <${A} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus. It takes a few minutes.</p>
      <${he} target=${"devices/"+encodeURIComponent(t.name||t.key)} label="Send to device" />
    <//>`:_`<${U} error=${n} />`}function an({d:e,reload:t}){let n=e.name||e.key,r=(a,o)=>async()=>{await C(()=>H.action(n,a),o),setTimeout(t,1500)};return _`
    <${A} title=${n}
      aside=${_`<span class="buttons">
        <${$} onClick=${r("ping","Ping sent")}>Ping<//>
        <${$} onClick=${r("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${r("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${J(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Ct({d:e,kind:t}){let n=e.name||e.key,[r,a]=b(1),[o,s]=b(0),u=t==="rollershutter",l=c=>()=>C(()=>H[t](n,r,c,Math.round(o*1e3)),`${u?"Rollershutter":"Relay"} ${r}: ${c}`);return _`
    <${A} title=${u?"Rollershutter":"Relays"}>
      ${e.device_type===9&&_`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${T} label="Number"><input type="number" min="1" max="16" value=${r} onInput=${c=>a(+c.target.value)} /><//>
        <${T} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${o} onInput=${c=>s(+c.target.value)} /><//>
      </div>
      <div class="buttons">
        ${u?_`<${$} onClick=${l("up")}>Up<//><${$} onClick=${l("down")}>Down<//><${$} onClick=${l("off")}>Stop<//>`:_`<${$} kind="primary" onClick=${l("on")}>On<//><${$} onClick=${l("off")}>Off<//>`}
      </div>
    <//>`}function sn({d:e}){let t=e.name||e.key,[n,r]=b(0),[a,o]=b(255),[s,u]=b(Array(24).fill(!1)),l=s.reduce((c,p,i)=>p?c|1<<23-i:c,0);return _`
    <${A} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${T} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${c=>r(+c.target.value)} /><//>
        <${T} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${c=>o(+c.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((c,p)=>_`<label key=${p} class=${"lamp"+(c?" on":"")}>
            <input type="checkbox" checked=${c} onChange=${()=>u(s.map((i,f)=>f===p?!i:i))} />${23-p}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>C(()=>H.lamps(t,n,a,l),"Lamps set")}>Send<//>
    <//>`}function cn({d:e}){let t=e.name||e.key,[n,r]=b(45),[a,o]=b(!1),[s,u]=b(0),[l,c]=b(!1),[p,i]=b(0),[f,h]=b(55);return _`
    <${A} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${T} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>r(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${a} onChange=${y=>o(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>C(()=>H.heating(t,"target",{flow_c:n,tank:a}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${T} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${s} onInput=${y=>u(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${l} onChange=${y=>c(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>C(()=>H.heating(t,"energy",{power_w:s,rod_enabled:l}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${T} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>i(+y.target.value)} /><//>
        <${T} label="Tank (°C)"><input type="number" step="0.5" value=${f} onInput=${y=>h(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>C(()=>H.heating(t,"emergency",{stage:p,tank_c:f}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var ln=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]],un=600*1e3;function _n({d:e}){let t=e.name||e.key,[n,r]=b(!1),[a,o]=b({}),s=me(null),u=()=>{clearTimeout(s.current),s.current=setTimeout(()=>{r(!1),o({})},un)};G(()=>()=>clearTimeout(s.current),[]);let l=async()=>{let i=!n;await C(()=>H.heatingManual(t,i),i?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&(r(i),o({}),i?u():clearTimeout(s.current))},c=i=>async()=>{let f=!a[i];await C(()=>H.heatingManual(t,!0,i,f),`Relay ${i} ${f?"on":"off"}`)&&(o({...a,[i]:f}),u())},p=i=>i===8&&a[9]||i===9&&a[8];return _`
    <${A} title="Manual mode"
      aside=${_`<${$} kind=${n?"danger":""} onClick=${l}>${n?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. The heating rod is never switchable here. It ends by itself after 10 minutes without a switch, and the controller then has them back.</p>
      <div class="manual">
        ${ln.map(([i,f])=>_`<button key=${i} class=${a[i]?"primary":""} disabled=${!n||p(i)} onClick=${c(i)}>
            <span>${f}</span><small>relay ${i}: ${a[i]?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function dn({d:e,reload:t}){let n=e.name||e.key,[r,a]=b({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[o,s]=b(!1),u=c=>p=>a({...r,[c]:p.target.value}),l=async()=>{let c={};if(r.custom_string!==e.name&&(c.custom_string=r.custom_string),+r.hwrev!==e.hwrev&&(c.hwrev=+r.hwrev),r.relais_mode&&(c.relais_mode=r.relais_mode),r.extension_mode&&(c.extension_mode=r.extension_mode),Object.keys(c).length===0)return D("Nothing changed");await C(()=>H.update(n,c),"Settings sent")&&setTimeout(t,1500)};return _`
    <${A} title="Settings">
      <div class="row">
        <${T} label="Name" hint="up to 8 characters"><input maxlength="8" value=${r.custom_string} onInput=${u("custom_string")} /><//>
        <${T} label="Hardware revision"><input type="number" min="0" max="255" value=${r.hwrev} onInput=${u("hwrev")} /><//>
        <${T} label="Relay mode"><select value=${r.relais_mode} onChange=${u("relais_mode")}>
          <option value="">(unchanged)</option>${rn.map(c=>_`<option>${c}</option>`)}
        </select><//>
        <${T} label="Extension mode"><select value=${r.extension_mode} onChange=${u("extension_mode")}>
          <option value="">(unchanged)</option>${on.map(c=>_`<option>${c}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${l}>Save<//>
        <${$} onClick=${async()=>{await C(()=>H.silence(n,!o),o?"Device may talk again":"Device silenced"),s(!o)}}>${o?"End silence":"Silence"}<//>
        <${$} onClick=${()=>C(()=>H.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Et(){let{data:e,error:t,reload:n}=M(H.list,5e3),[r,a]=b(""),o=(c,p)=>async()=>{await C(c,p),setTimeout(n,1500)},s=async()=>{let c=r.trim();c&&await C(()=>H.action(c,"ping"),`Ping sent to ${c}`)},u=async()=>{confirm("Restart every device on the bus?")&&await o(()=>B.action("restart"),"Restart sent to every device")()},l=o(async()=>{await B.action("ping"),await B.action("refresh")},"Scanning: every device was asked to announce itself");return _`
    <${A} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${o(()=>B.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${o(()=>B.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${o(()=>B.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${u}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${r} onInput=${c=>a(c.target.value)} onKeyDown=${c=>c.key==="Enter"&&s()} />
        <${$} onClick=${s}>Ping<//>
        <${$} onClick=${l}>Scan<//>
      </div>
      ${e?e.length===0?_`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:_`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(c=>_`<tr key=${c.key}>
                    <td><${z} href=${"/devices/"+encodeURIComponent(c.name||c.key)}>${c.name||c.key}<//></td>
                    <td><code>${He(c.device_id)}</code></td>
                    <td>${c.type_name} <code>${He(c.device_type)}</code></td>
                    <td>${c.version}</td>
                    <td>${J(c.last_seen_minutes_ago)}</td>
                    <td>${c.uptime?J(Math.floor(c.uptime/60)):""}</td>
                    <td>${c.error?_`<span class="badge bad">error ${c.error}</span>`:c.last_seen_minutes_ago>10?_`<span class="badge warn">silent</span>`:_`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:_`<${U} error=${t} />`}
      ${t&&e&&_`<p class="error">${t.message}</p>`}
    <//>`}function Ft(){return _`<${pn} /><${fn} /><${mn} />`}function pn(){let{data:e,error:t}=M(Re.get,5e3);return _`
    <${A} title="Gateway" aside=${_`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await C(Re.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?_`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${bt(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:_`<${U} error=${t} />`}
    <//>`}function fn(){let{data:e,error:t,reload:n}=M(Le.get),[r,a]=b({});if(!e)return _`<${U} error=${t} />`;let o=l=>l in r?r[l]:e[l],s=(l,c)=>p=>a({...r,[l]:c?+p.target.value:p.target.value}),u=async()=>{let l={...r};if(l.web_password||delete l.web_password,Object.keys(l).length===0)return D("Nothing changed");let c=await C(()=>Le.update(l),"Saved");c&&(c.restart_required&&D("Restart the gateway to apply the hostname or bitrate."),a({}),n())};return _`
    <${A} title="Settings">
      <div class="row">
        <${T} label="Hostname"><input value=${o("hostname")} onInput=${s("hostname")} /><//>
        <${T} label="CAN bitrate"><select value=${o("can_bitrate")} onChange=${s("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(l=>_`<option>${l}</option>`)}
        </select><//>
        <${T} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${o("update_delay_ms")} onInput=${s("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${T} label="User name"><input value=${o("web_username")} onInput=${s("web_username")} autocomplete="off" /><//>
        <${T} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${r.web_password||""} onInput=${s("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${u}>Save<//></div>
    <//>`}function mn(){return _`
    <${A} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${he} target="gateway" label="Install and restart" />
    <//>`}var hn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Lt(){let{data:e,error:t,reload:n}=M(Z.all,5e3);return e?_`
    <${Rt} slot="primary" b=${e.primary} reload=${n} />
    <${Rt} slot="secondary" b=${e.secondary} reload=${n} />`:_`<${U} error=${t} />`}function Rt({slot:e,b:t,reload:n}){let[r,a]=b({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[o,s]=b(null),u=r.uri.startsWith("mqtts://"),l=i=>f=>a({...r,[i]:f.target.type==="checkbox"?f.target.checked:f.target.value}),c=async()=>{let i={uri:r.uri,user:r.user,enabled:r.enabled,tls_insecure:r.tls_insecure};r.password&&(i.password=r.password),await C(()=>Z.update(e,i),`${e} broker saved, reconnecting`)&&(a({...r,password:""}),setTimeout(n,2500))},p=async()=>{let i=await C(()=>Z.certificate(e));i&&s(i)};return _`
    <${A}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${_`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${hn[e]}</p>
      <div class="row">
        <${T} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${r.uri} onInput=${l("uri")} /><//>
        <${T} label="User"><input value=${r.user} onInput=${l("user")} autocomplete="off" /><//>
        <${T} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${r.password} onInput=${l("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${r.enabled} onChange=${l("enabled")} /> Connect to this broker</label>
      ${u&&_`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${r.tls_insecure} onChange=${l("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await C(()=>Z.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&_`<${$} kind="danger" onClick=${async()=>{await C(()=>Z.forget(e),"Certificate forgotten"),s(null),n()}}>Forget<//>`}
          </div>
          ${o&&_`<p>${o.pinned?_`SHA-256 <code>${o.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}var vn=[{path:"/",title:"Devices",page:Et},{path:"/devices/:device",title:"Device",page:Tt},{path:"/sensors",title:"Sensors",page:St},{path:"/mqtt",title:"MQTT",page:Lt},{path:"/gateway",title:"Gateway",page:Ft}],$n=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"]];function gn(){let e=wt(),t=kt(vn,e),n=t?t.route.page:null,r=a=>a==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(a);return _`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${$n.map(([a,o])=>_`<${z} href=${a} class=${r(a)?"active":""}>${o}<//>`)}</nav>
    </header>
    <main>
      ${n?_`<${n} key=${e} ...${t.params} />`:_`<p class="error">No such page. <${z} href="/">Devices<//></p>`}
    </main>
    <${yt} />`}Xe(_`<${gn} />`,document.getElementById("app"));
