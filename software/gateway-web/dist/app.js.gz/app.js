var Wt=Object.create;var Qe=Object.defineProperty;var jt=Object.getOwnPropertyDescriptor;var Vt=Object.getOwnPropertyNames;var Bt=Object.getPrototypeOf,Gt=Object.prototype.hasOwnProperty;var Kt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Qt=(e,t,n,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Vt(t))!Gt.call(e,s)&&s!==n&&Qe(e,s,{get:()=>t[s],enumerable:!(a=jt(t,s))||a.enumerable});return e};var Jt=(e,t,n)=>(n=e!=null?Wt(Bt(e)):{},Qt(t||!e||!e.__esModule?Qe(n,"default",{value:e,enumerable:!0}):n,e));var Tt=Kt(Ne=>{var St;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Ne=="object"?e(Ne):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(St={}):e(St={})})(function(e){e.version="1.2.2";function t(){for(var f=0,A=new Array(256),m=0;m!=256;++m)f=m,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,A[m]=f;return typeof Int32Array<"u"?new Int32Array(A):A}var n=t();function a(f){var A=0,m=0,b=0,g=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(b=0;b!=256;++b)g[b]=f[b];for(b=0;b!=256;++b)for(m=f[b],A=256+b;A<4096;A+=256)m=g[A]=m>>>8^f[m&255];var R=[];for(b=1;b!=16;++b)R[b-1]=typeof Int32Array<"u"?g.subarray(b*256,b*256+256):g.slice(b*256,b*256+256);return R}var s=a(n),o=s[0],r=s[1],c=s[2],u=s[3],l=s[4],_=s[5],i=s[6],p=s[7],h=s[8],y=s[9],F=s[10],x=s[11],k=s[12],w=s[13],H=s[14];function M(f,A){for(var m=A^-1,b=0,g=f.length;b<g;)m=m>>>8^n[(m^f.charCodeAt(b++))&255];return~m}function B(f,A){for(var m=A^-1,b=f.length-15,g=0;g<b;)m=H[f[g++]^m&255]^w[f[g++]^m>>8&255]^k[f[g++]^m>>16&255]^x[f[g++]^m>>>24]^F[f[g++]]^y[f[g++]]^h[f[g++]]^p[f[g++]]^i[f[g++]]^_[f[g++]]^l[f[g++]]^u[f[g++]]^c[f[g++]]^r[f[g++]]^o[f[g++]]^n[f[g++]];for(b+=15;g<b;)m=m>>>8^n[(m^f[g++])&255];return~m}function W(f,A){for(var m=A^-1,b=0,g=f.length,R=0,Se=0;b<g;)R=f.charCodeAt(b++),R<128?m=m>>>8^n[(m^R)&255]:R<2048?(m=m>>>8^n[(m^(192|R>>6&31))&255],m=m>>>8^n[(m^(128|R&63))&255]):R>=55296&&R<57344?(R=(R&1023)+64,Se=f.charCodeAt(b++)&1023,m=m>>>8^n[(m^(240|R>>8&7))&255],m=m>>>8^n[(m^(128|R>>2&63))&255],m=m>>>8^n[(m^(128|Se>>6&15|(R&3)<<4))&255],m=m>>>8^n[(m^(128|Se&63))&255]):(m=m>>>8^n[(m^(224|R>>12&15))&255],m=m>>>8^n[(m^(128|R>>6&63))&255],m=m>>>8^n[(m^(128|R&63))&255]);return~m}e.table=n,e.bstr=M,e.buf=B,e.str=W})});var me,E,Ze,Yt,J,Je,et,tt,nt,xe,Te,Ce,zt,re={},at=[],Xt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,he=Array.isArray;function G(e,t){for(var n in t)e[n]=t[n];return e}function Ee(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ie(e,t,n){var a,s,o,r={};for(o in t)o=="key"?a=t[o]:o=="ref"?s=t[o]:r[o]=t[o];if(arguments.length>2&&(r.children=arguments.length>3?me.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(o in e.defaultProps)r[o]===void 0&&(r[o]=e.defaultProps[o]);return _e(e,r,a,s,null)}function _e(e,t,n,a,s){var o={type:e,props:t,key:n,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:s??++Ze,__i:-1,__u:0};return s==null&&E.vnode!=null&&E.vnode(o),o}function $e(e){return e.children}function pe(e,t){this.props=e,this.context=t}function ne(e,t){if(t==null)return e.__?ne(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?ne(e):null}function ot(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return ot(e)}}function Ye(e){(!e.__d&&(e.__d=!0)&&J.push(e)&&!fe.__r++||Je!=E.debounceRendering)&&((Je=E.debounceRendering)||et)(fe)}function fe(){for(var e,t,n,a,s,o,r,c=1;J.length;)J.length>c&&J.sort(tt),e=J.shift(),c=J.length,e.__d&&(n=void 0,s=(a=(t=e).__v).__e,o=[],r=[],t.__P&&((n=G({},a)).__v=a.__v+1,E.vnode&&E.vnode(n),Re(t.__P,n,a,t.__n,t.__P.namespaceURI,32&a.__u?[s]:null,o,s??ne(a),!!(32&a.__u),r),n.__v=a.__v,n.__.__k[n.__i]=n,it(o,n,r),n.__e!=s&&ot(n)));fe.__r=0}function st(e,t,n,a,s,o,r,c,u,l,_){var i,p,h,y,F,x,k=a&&a.__k||at,w=t.length;for(u=Zt(n,t,k,u,w),i=0;i<w;i++)(h=n.__k[i])!=null&&(p=h.__i==-1?re:k[h.__i]||re,h.__i=i,x=Re(e,h,p,s,o,r,c,u,l,_),y=h.__e,h.ref&&p.ref!=h.ref&&(p.ref&&Fe(p.ref,null,h),_.push(h.ref,h.__c||y,h)),F==null&&y!=null&&(F=y),4&h.__u||p.__k===h.__k?u=rt(h,u,e):typeof h.type=="function"&&x!==void 0?u=x:y&&(u=y.nextSibling),h.__u&=-7);return n.__e=F,u}function Zt(e,t,n,a,s){var o,r,c,u,l,_=n.length,i=_,p=0;for(e.__k=new Array(s),o=0;o<s;o++)(r=t[o])!=null&&typeof r!="boolean"&&typeof r!="function"?(u=o+p,(r=e.__k[o]=typeof r=="string"||typeof r=="number"||typeof r=="bigint"||r.constructor==String?_e(null,r,null,null,null):he(r)?_e($e,{children:r},null,null,null):r.constructor==null&&r.__b>0?_e(r.type,r.props,r.key,r.ref?r.ref:null,r.__v):r).__=e,r.__b=e.__b+1,c=null,(l=r.__i=en(r,n,u,i))!=-1&&(i--,(c=n[l])&&(c.__u|=2)),c==null||c.__v==null?(l==-1&&(s>_?p--:s<_&&p++),typeof r.type!="function"&&(r.__u|=4)):l!=u&&(l==u-1?p--:l==u+1?p++:(l>u?p--:p++,r.__u|=4))):e.__k[o]=null;if(i)for(o=0;o<_;o++)(c=n[o])!=null&&(2&c.__u)==0&&(c.__e==a&&(a=ne(c)),ct(c,c));return a}function rt(e,t,n){var a,s;if(typeof e.type=="function"){for(a=e.__k,s=0;a&&s<a.length;s++)a[s]&&(a[s].__=e,t=rt(a[s],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=ne(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function en(e,t,n,a){var s,o,r=e.key,c=e.type,u=t[n];if(u===null&&e.key==null||u&&r==u.key&&c==u.type&&(2&u.__u)==0)return n;if(a>(u!=null&&(2&u.__u)==0?1:0))for(s=n-1,o=n+1;s>=0||o<t.length;){if(s>=0){if((u=t[s])&&(2&u.__u)==0&&r==u.key&&c==u.type)return s;s--}if(o<t.length){if((u=t[o])&&(2&u.__u)==0&&r==u.key&&c==u.type)return o;o++}}return-1}function ze(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Xt.test(t)?n:n+"px"}function ue(e,t,n,a,s){var o,r;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof a=="string"&&(e.style.cssText=a=""),a)for(t in a)n&&t in n||ze(e.style,t,"");if(n)for(t in n)a&&n[t]==a[t]||ze(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")o=t!=(t=t.replace(nt,"$1")),r=t.toLowerCase(),t=r in e||t=="onFocusOut"||t=="onFocusIn"?r.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+o]=n,n?a?n.u=a.u:(n.u=xe,e.addEventListener(t,o?Ce:Te,o)):e.removeEventListener(t,o?Ce:Te,o);else{if(s=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Xe(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=xe++;else if(t.t<n.u)return;return n(E.event?E.event(t):t)}}}function Re(e,t,n,a,s,o,r,c,u,l){var _,i,p,h,y,F,x,k,w,H,M,B,W,f,A,m,b,g=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),o=[c=t.__e=n.__e]),(_=E.__b)&&_(t);e:if(typeof g=="function")try{if(k=t.props,w="prototype"in g&&g.prototype.render,H=(_=g.contextType)&&a[_.__c],M=_?H?H.props.value:_.__:a,n.__c?x=(i=t.__c=n.__c).__=i.__E:(w?t.__c=i=new g(k,M):(t.__c=i=new pe(k,M),i.constructor=g,i.render=nn),H&&H.sub(i),i.props=k,i.state||(i.state={}),i.context=M,i.__n=a,p=i.__d=!0,i.__h=[],i._sb=[]),w&&i.__s==null&&(i.__s=i.state),w&&g.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=G({},i.__s)),G(i.__s,g.getDerivedStateFromProps(k,i.__s))),h=i.props,y=i.state,i.__v=t,p)w&&g.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),w&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(w&&g.getDerivedStateFromProps==null&&k!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(k,M),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(k,i.__s,M)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=k,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(R){R&&(R.__=t)}),B=0;B<i._sb.length;B++)i.__h.push(i._sb[B]);i._sb=[],i.__h.length&&r.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(k,i.__s,M),w&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,y,F)})}if(i.context=M,i.props=k,i.__P=e,i.__e=!1,W=E.__r,f=0,w){for(i.state=i.__s,i.__d=!1,W&&W(t),_=i.render(i.props,i.state,i.context),A=0;A<i._sb.length;A++)i.__h.push(i._sb[A]);i._sb=[]}else do i.__d=!1,W&&W(t),_=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++f<25);i.state=i.__s,i.getChildContext!=null&&(a=G(G({},a),i.getChildContext())),w&&!p&&i.getSnapshotBeforeUpdate!=null&&(F=i.getSnapshotBeforeUpdate(h,y)),m=_,_!=null&&_.type===$e&&_.key==null&&(m=lt(_.props.children)),c=st(e,he(m)?m:[m],t,n,a,s,o,r,c,u,l),i.base=t.__e,t.__u&=-161,i.__h.length&&r.push(i),x&&(i.__E=i.__=null)}catch(R){if(t.__v=null,u||o!=null)if(R.then){for(t.__u|=u?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;o[o.indexOf(c)]=null,t.__e=c}else for(b=o.length;b--;)Ee(o[b]);else t.__e=n.__e,t.__k=n.__k;E.__e(R,t,n)}else o==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):c=t.__e=tn(n.__e,t,n,a,s,o,r,u,l);return(_=E.diffed)&&_(t),128&t.__u?void 0:c}function it(e,t,n){for(var a=0;a<n.length;a++)Fe(n[a],n[++a],n[++a]);E.__c&&E.__c(t,e),e.some(function(s){try{e=s.__h,s.__h=[],e.some(function(o){o.call(s)})}catch(o){E.__e(o,s.__v)}})}function lt(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:he(e)?e.map(lt):G({},e)}function tn(e,t,n,a,s,o,r,c,u){var l,_,i,p,h,y,F,x=n.props,k=t.props,w=t.type;if(w=="svg"?s="http://www.w3.org/2000/svg":w=="math"?s="http://www.w3.org/1998/Math/MathML":s||(s="http://www.w3.org/1999/xhtml"),o!=null){for(l=0;l<o.length;l++)if((h=o[l])&&"setAttribute"in h==!!w&&(w?h.localName==w:h.nodeType==3)){e=h,o[l]=null;break}}if(e==null){if(w==null)return document.createTextNode(k);e=document.createElementNS(s,w,k.is&&k),c&&(E.__m&&E.__m(t,o),c=!1),o=null}if(w==null)x===k||c&&e.data==k||(e.data=k);else{if(o=o&&me.call(e.childNodes),x=n.props||re,!c&&o!=null)for(x={},l=0;l<e.attributes.length;l++)x[(h=e.attributes[l]).name]=h.value;for(l in x)if(h=x[l],l!="children"){if(l=="dangerouslySetInnerHTML")i=h;else if(!(l in k)){if(l=="value"&&"defaultValue"in k||l=="checked"&&"defaultChecked"in k)continue;ue(e,l,null,h,s)}}for(l in k)h=k[l],l=="children"?p=h:l=="dangerouslySetInnerHTML"?_=h:l=="value"?y=h:l=="checked"?F=h:c&&typeof h!="function"||x[l]===h||ue(e,l,h,x[l],s);if(_)c||i&&(_.__html==i.__html||_.__html==e.innerHTML)||(e.innerHTML=_.__html),t.__k=[];else if(i&&(e.innerHTML=""),st(t.type=="template"?e.content:e,he(p)?p:[p],t,n,a,w=="foreignObject"?"http://www.w3.org/1999/xhtml":s,o,r,o?o[0]:n.__k&&ne(n,0),c,u),o!=null)for(l=o.length;l--;)Ee(o[l]);c||(l="value",w=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[l]||w=="progress"&&!y||w=="option"&&y!=x[l])&&ue(e,l,y,x[l],s),l="checked",F!=null&&F!=e[l]&&ue(e,l,F,x[l],s))}return e}function Fe(e,t,n){try{if(typeof e=="function"){var a=typeof e.__u=="function";a&&e.__u(),a&&t==null||(e.__u=e(t))}else e.current=t}catch(s){E.__e(s,n)}}function ct(e,t,n){var a,s;if(E.unmount&&E.unmount(e),(a=e.ref)&&(a.current&&a.current!=e.__e||Fe(a,null,t)),(a=e.__c)!=null){if(a.componentWillUnmount)try{a.componentWillUnmount()}catch(o){E.__e(o,t)}a.base=a.__P=null}if(a=e.__k)for(s=0;s<a.length;s++)a[s]&&ct(a[s],t,n||typeof e.type!="function");n||Ee(e.__e),e.__c=e.__=e.__e=void 0}function nn(e,t,n){return this.constructor(e,n)}function dt(e,t,n){var a,s,o,r;t==document&&(t=document.documentElement),E.__&&E.__(e,t),s=(a=typeof n=="function")?null:n&&n.__k||t.__k,o=[],r=[],Re(t,e=(!a&&n||t).__k=ie($e,null,[e]),s||re,re,t.namespaceURI,!a&&n?[n]:s?null:t.firstChild?me.call(t.childNodes):null,o,!a&&n?n:s?s.__e:t.firstChild,a,r),it(o,e,r)}me=at.slice,E={__e:function(e,t,n,a){for(var s,o,r;t=t.__;)if((s=t.__c)&&!s.__)try{if((o=s.constructor)&&o.getDerivedStateFromError!=null&&(s.setState(o.getDerivedStateFromError(e)),r=s.__d),s.componentDidCatch!=null&&(s.componentDidCatch(e,a||{}),r=s.__d),r)return s.__E=s}catch(c){e=c}throw e}},Ze=0,Yt=function(e){return e!=null&&e.constructor==null},pe.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=G({},this.state),typeof e=="function"&&(e=e(G({},n),this.props)),e&&G(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Ye(this))},pe.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Ye(this))},pe.prototype.render=$e,J=[],et=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,tt=function(e,t){return e.__v.__b-t.__v.__b},fe.__r=0,nt=/(PointerCapture)$|Capture$/i,xe=0,Te=Xe(!1),Ce=Xe(!0),zt=0;var le,I,Ie,ut,ce=0,gt=[],L=E,_t=L.__b,pt=L.__r,ft=L.diffed,mt=L.__c,ht=L.unmount,$t=L.__;function Ae(e,t){L.__h&&L.__h(I,e,ce||t),ce=0;var n=I.__H||(I.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function v(e){return ce=1,an(kt,e)}function an(e,t,n){var a=Ae(le++,2);if(a.t=e,!a.__c&&(a.__=[n?n(t):kt(void 0,t),function(c){var u=a.__N?a.__N[0]:a.__[0],l=a.t(u,c);u!==l&&(a.__N=[l,a.__[1]],a.__c.setState({}))}],a.__c=I,!I.__f)){var s=function(c,u,l){if(!a.__c.__H)return!0;var _=a.__c.__H.__.filter(function(p){return!!p.__c});if(_.every(function(p){return!p.__N}))return!o||o.call(this,c,u,l);var i=a.__c.props!==c;return _.forEach(function(p){if(p.__N){var h=p.__[0];p.__=p.__N,p.__N=void 0,h!==p.__[0]&&(i=!0)}}),o&&o.call(this,c,u,l)||i};I.__f=!0;var o=I.shouldComponentUpdate,r=I.componentWillUpdate;I.componentWillUpdate=function(c,u,l){if(this.__e){var _=o;o=void 0,s(c,u,l),o=_}r&&r.call(this,c,u,l)},I.shouldComponentUpdate=s}return a.__N||a.__}function Y(e,t){var n=Ae(le++,3);!L.__s&&bt(n.__H,t)&&(n.__=e,n.u=t,I.__H.__h.push(n))}function ge(e){return ce=5,yt(function(){return{current:e}},[])}function yt(e,t){var n=Ae(le++,7);return bt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function wt(e,t){return ce=8,yt(function(){return e},t)}function on(){for(var e;e=gt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ve),e.__H.__h.forEach(Le),e.__H.__h=[]}catch(t){e.__H.__h=[],L.__e(t,e.__v)}}L.__b=function(e){I=null,_t&&_t(e)},L.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),$t&&$t(e,t)},L.__r=function(e){pt&&pt(e),le=0;var t=(I=e.__c).__H;t&&(Ie===I?(t.__h=[],I.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ve),t.__h.forEach(Le),t.__h=[],le=0)),Ie=I},L.diffed=function(e){ft&&ft(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(gt.push(t)!==1&&ut===L.requestAnimationFrame||((ut=L.requestAnimationFrame)||sn)(on)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ie=I=null},L.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ve),n.__h=n.__h.filter(function(a){return!a.__||Le(a)})}catch(a){t.some(function(s){s.__h&&(s.__h=[])}),t=[],L.__e(a,n.__v)}}),mt&&mt(e,t)},L.unmount=function(e){ht&&ht(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(a){try{ve(a)}catch(s){t=s}}),n.__H=void 0,t&&L.__e(t,n.__v))};var vt=typeof requestAnimationFrame=="function";function sn(e){var t,n=function(){clearTimeout(a),vt&&cancelAnimationFrame(t),setTimeout(e)},a=setTimeout(n,35);vt&&(t=requestAnimationFrame(n))}function ve(e){var t=I,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),I=t}function Le(e){var t=I;e.__c=e.__(),I=t}function bt(e,t){return!e||e.length!==t.length||t.some(function(n,a){return n!==e[a]})}function kt(e,t){return typeof t=="function"?t(e):t}var Ct=Jt(Tt()),Me="/api/v1",ae=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},rn=e=>new Promise(t=>setTimeout(t,e));async function de(e,t,n){let a=typeof n=="string";for(let s=1;;s++){let o;try{o=await fetch(Me+t,{method:e,headers:n===void 0?{}:{"Content-Type":a?"application/x-pem-file":"application/json"},body:n===void 0?void 0:a?n:JSON.stringify(n)})}catch{if(s>=4)throw new ae(0,{message:"gateway unreachable"});await rn(250*s);continue}let r=await o.text(),c=null;try{c=r?JSON.parse(r):null}catch{c={message:r}}if(!o.ok)throw new ae(o.status,c);return c}}var V=e=>de("GET",e),K=(e,t)=>de("POST",e,t),j=(e,t)=>de("PUT",e,t),ye=(e,t)=>de("PATCH",e,t),He=e=>de("DELETE",e),U=encodeURIComponent,Pe={get:()=>V("/system"),restart:()=>K("/system/restart")},Ue={get:()=>V("/config"),update:e=>ye("/config",e)},oe={all:()=>V("/mqtt"),update:(e,t)=>ye(`/mqtt/${e}`,t),trust:e=>K(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>He(`/mqtt/${e}/certificate`)},q={get:()=>V("/tls"),update:e=>ye("/tls",e),selfSigned:e=>K("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Me}/tls/csr`,installCertificate:e=>j("/tls/certificate",e),setTrustAnchor:e=>j("/tls/trust-anchor",e),removeTrustAnchor:()=>He("/tls/trust-anchor"),setIdentity:e=>j("/tls/est/identity",e),removeIdentity:()=>He("/tls/est/identity"),enroll:()=>K("/tls/est/enroll")},N={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${U(e)}`),update:(e,t)=>ye(`/devices/${U(e)}`,t),action:(e,t)=>K(`/devices/${U(e)}/${t}`),silence:(e,t)=>j(`/devices/${U(e)}/silence`,{on:t}),relay:(e,t,n,a)=>j(`/devices/${U(e)}/relays/${t}`,{state:n,duration_ms:a}),rollershutter:(e,t,n,a)=>j(`/devices/${U(e)}/rollershutters/${t}`,{state:n,duration_ms:a}),lamps:(e,t,n,a)=>j(`/devices/${U(e)}/lamps/${t}`,{value:n,bitmask:a}),heating:(e,t,n)=>j(`/devices/${U(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${U(e)}/heating/manual`),heatingManual:(e,t,n,a)=>j(`/devices/${U(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:a})},z={update:(e,t,n)=>j(`/devices/${U(e)}/sensors/${t}`,n),refresh:e=>K(`/devices/${U(e)}/sensors/refresh`),forget:e=>K(`/devices/${U(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${U(e)}`:"",a=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...a.sensors),a.sensors.length===0||t.length>=a.total)return t}}},X={action:e=>K(`/bus/${e}`),silence:e=>j("/bus/silence",{on:e}),typeAction:(e,t)=>K(`/device-types/${e}/${t}`)},De={job:()=>V("/firmware/job"),upload(e,t,n){let a=Ct.default.buf(new Uint8Array(t))>>>0,s=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((o,r)=>{let c=new XMLHttpRequest;c.open("PUT",`${Me}${s}?crc32=${a}`),c.setRequestHeader("Content-Type","application/octet-stream"),c.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),c.onload=()=>{let u=null;try{u=JSON.parse(c.responseText)}catch{}c.status>=200&&c.status<300?o(u):r(new ae(c.status,u))},c.onerror=()=>r(new ae(0,{message:"upload failed"})),c.send(t)})}};var Et=function(e,t,n,a){var s;t[0]=0;for(var o=1;o<t.length;o++){var r=t[o++],c=t[o]?(t[0]|=r?1:2,n[t[o++]]):t[++o];r===3?a[0]=c:r===4?a[1]=Object.assign(a[1]||{},c):r===5?(a[1]=a[1]||{})[t[++o]]=c:r===6?a[1][t[++o]]+=c+"":r?(s=e.apply(c,Et(e,c,n,["",null])),a.push(s),c[0]?t[0]|=2:(t[o-2]=0,t[o]=s)):a.push(c)}return a},xt=new Map;function Rt(e){var t=xt.get(this);return t||(t=new Map,xt.set(this,t)),(t=Et(this,t.get(e)||(t.set(e,t=function(n){for(var a,s,o=1,r="",c="",u=[0],l=function(p){o===1&&(p||(r=r.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,p,r):o===3&&(p||r)?(u.push(3,p,r),o=2):o===2&&r==="..."&&p?u.push(4,p,0):o===2&&r&&!p?u.push(5,0,!0,r):o>=5&&((r||!p&&o===5)&&(u.push(o,0,r,s),o=6),p&&(u.push(o,p,0,s),o=6)),r=""},_=0;_<n.length;_++){_&&(o===1&&l(),l(_));for(var i=0;i<n[_].length;i++)a=n[_][i],o===1?a==="<"?(l(),u=[u],o=3):r+=a:o===4?r==="--"&&a===">"?(o=1,r=""):r=a+r[0]:c?a===c?c="":r+=a:a==='"'||a==="'"?c=a:a===">"?(l(),o=1):o&&(a==="="?(o=5,s=r,r=""):a==="/"&&(o<5||n[_][i+1]===">")?(l(),o===3&&(u=u[0]),o=u,(u=u[0]).push(2,0,o),o=0):a===" "||a==="	"||a===`
`||a==="\r"?(l(),o=2):r+=a),o===3&&r==="!--"&&(o=4,u=u[0])}return l(),u}(e)),t),arguments,[])).length>1?t:t[0]}var d=Rt.bind(ie),qe=()=>{};function O(e,t="ok"){qe(e,t)}function Ft(){let[e,t]=v([]);return Y(()=>{let n=0;return qe=(a,s)=>{let o={id:++n,message:a,kind:s};t(r=>[...r,o]),setTimeout(()=>t(r=>r.filter(c=>c!==o)),s==="error"?8e3:3e3)},()=>qe=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function S(e,t){try{let n=await e();return t&&O(t),n}catch(n){O(n.message,"error");return}}function P(e,t){let[n,a]=v({data:void 0,error:void 0}),s=ge(e);s.current=e;let o=wt(async()=>{try{a({data:await s.current(),error:void 0})}catch(r){a(c=>({data:c.data,error:r}))}},[]);return Y(()=>{let r=!1,c,u=async()=>{await o(),t&&!r&&(c=setTimeout(u,t))};return u(),()=>{r=!0,clearTimeout(c)}},[t,o]),{...n,reload:o}}var T=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,D=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:a})=>{let[s,o]=v(!1);return d`<button class=${t||""} disabled=${a||s} onClick=${async c=>{o(!0);try{await n(c)}finally{o(!1)}}}>${e}</button>`},Oe=e=>"0x"+e.toString(16).padStart(2,"0");function ee(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function It(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),a=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${a} min`:`${a} min`}function we({target:e,label:t,others:n=[],onDone:a}){let[s,o]=v(null),[r,c]=v(null),[u,l]=v(""),[_,i]=v(null),p=ge(null);Y(()=>()=>clearInterval(p.current),[]);let h=()=>{clearInterval(p.current),p.current=setInterval(async()=>{try{i(await De.job())}catch{}},1500)},y=async(w,H)=>{l(w),c(0),H!=="gateway"&&h();try{let M=await s.arrayBuffer();return await De.upload(H,M,c)||{}}finally{clearInterval(p.current),c(null)}},F=async w=>{if(!s)return;let H=0;for(let{name:M,target:B}of w)try{let W=await y(M,B);H+=1,W.restarting&&O("Firmware installed, the gateway restarts\u2026")}catch(W){O(`${M}: ${W.message}`,"error");break}H===w.length&&w[0].target!=="gateway"&&O(H===1?"Firmware sent; the device restarts into it":`Firmware sent to ${H} devices`),l(""),i(null),a&&a()},x=r!==null,k=_&&_.state==="running"?`${_.sent} of ${_.total} bytes acknowledged${_.protocol?` (${_.protocol})`:""}${_.retries?`, ${_.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>o(w.target.files[0]||null)} />
      <${$} onClick=${()=>F([{name:t||"device",target:e}])} disabled=${!s||x}>${t||"Upload"}<//>
      ${n.length>0&&d`<${$} onClick=${()=>F([{name:"this device",target:e},...n])} disabled=${!s||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&d`<progress max="1" value=${r}></progress>`}
      ${x&&d`<p class="muted wide">${u}${k?" \u2014 "+k:""}</p>`}
    </div>`}var be=new Set;function ln(e){e!==location.pathname&&history.pushState(null,"",e),be.forEach(t=>t())}addEventListener("popstate",()=>be.forEach(e=>e()));function Lt(){let[e,t]=v(location.pathname);return Y(()=>{let n=()=>t(location.pathname);return be.add(n),()=>be.delete(n)},[]),e}function At(e,t){let n=t.split("/").filter(Boolean);for(let a of e){let s=a.path.split("/").filter(Boolean);if(s.length!==n.length)continue;let o={};if(s.every((c,u)=>c.startsWith(":")?(o[c.slice(1)]=decodeURIComponent(n[u]),!0):c===n[u]))return{route:a,params:o}}return null}function te({href:e,children:t,...n}){return ie("a",{href:e,onClick:s=>{s.metaKey||s.ctrlKey||s.shiftKey||s.button!==0||(s.preventDefault(),ln(e))},...n},t)}var cn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"},We=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],dn={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},se=e=>dn[e]||e;function ke(e,t=5e3){let n=P(()=>z.list(e),t),a=[...new Set((n.data||[]).map(o=>o.device))];return{...n,ask:async()=>{for(let o of e?[e]:a)await S(()=>z.refresh(o));setTimeout(n.reload,1500)}}}function un({s:e,device:t,reload:n}){let[a,s]=v(!1),[o,r]=v(e.name||""),[c,u]=v(e.role||"none"),l=async()=>{let _={};if(o!==(e.name||"")&&(_.name=o),c!==(e.role||"none")&&(_.role=c),Object.keys(_).length===0)return s(!1);await S(()=>z.update(e.device,e.slot,_),"Sent to the device")&&(s(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${te} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${a?d`<input class="inline" maxlength="7" placeholder="name" value=${o} onInput=${_=>r(_.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${cn[e.kind]||e.kind}</td>
    <td>${a?d`<select value=${c} onChange=${_=>u(_.target.value)}>${We.map(_=>d`<option value=${_}>${se(_)}</option>`)}</select>`:e.role&&e.role!=="none"?se(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind==="temperature"?e.value.toFixed(2):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ee(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":a?d`<${$} kind="primary" onClick=${l}>Save<//> <button onClick=${()=>s(!1)}>Cancel</button>`:d`<button onClick=${()=>s(!0)}>Edit</button>`}</td>
  </tr>`}function je({device:e}){let{data:t,error:n,reload:a,ask:s}=ke(e);if(!t)return d`<${D} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let o=t.some(r=>r.slot===null);return d`
    ${o&&d`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${s}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(r=>d`<${un} key=${r.device_key+r.kind+r.sensor_id} s=${r} device=${e} reload=${a} />`)}
      </tbody>
    </table></div>`}function Nt(){let{ask:e}=ke(void 0,0);return d`<${T} title="Sensors" aside=${d`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${je} />
  <//>`}var _n=[2,5,8,9],pn=[7],fn=[3],Ve=[9],mn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],hn=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Mt({device:e}){let{data:t,error:n,reload:a}=P(()=>N.get(e),5e3);return t?d`
    <${vn} d=${t} reload=${a} />
    ${_n.includes(t.device_type)&&d`<${Ht} d=${t} kind="relay" />`}
    ${pn.includes(t.device_type)&&d`<${Ht} d=${t} kind="rollershutter" />`}
    ${fn.includes(t.device_type)&&d`<${gn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${yn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${bn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${kn} d=${t} />`}
    <${T} title="Sensors"><${je} device=${t.name||t.key} /><//>
    <${Sn} d=${t} reload=${a} />
    <${$n} d=${t} />`:d`<${D} error=${n} />`}function $n({d:e}){let t=e.name||e.key,{data:n}=P(N.list),a=(n||[]).filter(s=>s.device_type===e.device_type&&s.key!==e.key).map(s=>({name:s.name||s.key,target:"devices/"+encodeURIComponent(s.name||s.key)}));return d`
    <${T} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${we} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${a} />
    <//>`}function vn({d:e,reload:t}){let n=e.name||e.key,a=(s,o)=>async()=>{await S(()=>N.action(n,s),o),setTimeout(t,1500)};return d`
    <${T} title=${n}
      aside=${d`<span class="buttons">
        <${$} onClick=${a("ping","Ping sent")}>Ping<//>
        <${$} onClick=${a("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${a("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ee(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Ht({d:e,kind:t}){let n=e.name||e.key,[a,s]=v(1),[o,r]=v(0),c=t==="rollershutter",u=l=>()=>S(()=>N[t](n,a,l,Math.round(o*1e3)),`${c?"Rollershutter":"Relay"} ${a}: ${l}`);return d`
    <${T} title=${c?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${a} onInput=${l=>s(+l.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${o} onInput=${l=>r(+l.target.value)} /><//>
      </div>
      <div class="buttons">
        ${c?d`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:d`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function gn({d:e}){let t=e.name||e.key,[n,a]=v(0),[s,o]=v(255),[r,c]=v(Array(24).fill(!1)),u=r.reduce((l,_,i)=>_?l|1<<23-i:l,0);return d`
    <${T} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${l=>a(+l.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${s} onInput=${l=>o(+l.target.value)} /><//>
      </div>
      <div class="lamps">
        ${r.map((l,_)=>d`<label key=${_} class=${"lamp"+(l?" on":"")}>
            <input type="checkbox" checked=${l} onChange=${()=>c(r.map((i,p)=>p===_?!i:i))} />${23-_}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>S(()=>N.lamps(t,n,s,u),"Lamps set")}>Send<//>
    <//>`}function yn({d:e}){let t=e.name||e.key,[n,a]=v(45),[s,o]=v(!1),[r,c]=v(0),[u,l]=v(!1),[_,i]=v(0),[p,h]=v(55);return d`
    <${T} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>a(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${s} onChange=${y=>o(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>S(()=>N.heating(t,"target",{flow_c:n,tank:s}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${r} onInput=${y=>c(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${y=>l(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>S(()=>N.heating(t,"energy",{power_w:r,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${_} onInput=${y=>i(+y.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${p} onInput=${y=>h(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>S(()=>N.heating(t,"emergency",{stage:_,tank_c:p}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var wn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function bn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:s,ask:o}=ke(t);if(!n)return d`<${T} title="Sensor assignment"><${D} error=${a} /><//>`;let r=n.filter(i=>i.kind==="temperature"),c=i=>r.find(p=>p.role===i),u=i=>i.name?`${i.name} (${i.sensor_id})`:i.sensor_id,l=r.every(i=>i.slot!==null),_=i=>async p=>{let h=p.target.value,y;if(h===""){let F=c(i);if(!F)return;y=await S(()=>z.update(t,F.slot,{role:"none"}),`${se(i)} cleared`)}else{let F=r.find(x=>x.sensor_id===h);y=await S(()=>z.update(t,F.slot,{role:i}),`${u(F)} is ${se(i)} now`)}y&&setTimeout(s,1500)};return d`
    <${T} title="Sensor assignment" aside=${d`<${$} onClick=${o}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!l&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${We.filter(i=>i!=="none").map(i=>d`<label key=${i} class="field">
            <span>${se(i)}</span>
            <select value=${(c(i)||{}).sensor_id||""} onChange=${_(i)} disabled=${!l}>
              <option value="">(none)</option>
              ${r.map(p=>d`<option value=${p.sensor_id}>${u(p)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function kn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:s}=P(()=>N.heatingManualState(t),3e3),o=!!(n&&n.enabled),r=_=>!!(n&&n.relays.includes(_)),c=async()=>{let _=!o;await S(()=>N.heatingManual(t,_),_?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(s,800)},u=_=>async()=>{await S(()=>N.heatingManual(t,!0,_,!r(_)),`Relay ${_} ${r(_)?"off":"on"}`)&&setTimeout(s,800)},l=_=>_===8&&r(9)||_===9&&r(8);return d`
    <${T} title="Manual mode"
      aside=${d`<${$} kind=${o?"danger":""} disabled=${!n} onClick=${c}>${o?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${a&&d`<p class="error">The controller does not answer: ${a.message}</p>`}
      ${o&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${wn.map(([_,i])=>d`<button key=${_} class=${r(_)?"primary":""} disabled=${!o||l(_)} onClick=${u(_)}>
            <span>${i}</span><small>relay ${_}: ${r(_)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Sn({d:e,reload:t}){let n=e.name||e.key,[a,s]=v({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[o,r]=v(!1),c=l=>_=>s({...a,[l]:_.target.value}),u=async()=>{let l={};if(a.custom_string!==e.name&&(l.custom_string=a.custom_string),+a.hwrev!==e.hwrev&&(l.hwrev=+a.hwrev),a.relais_mode&&(l.relais_mode=a.relais_mode),a.extension_mode&&(l.extension_mode=a.extension_mode),Object.keys(l).length===0)return O("Nothing changed");await S(()=>N.update(n,l),"Settings sent")&&setTimeout(t,1500)};return d`
    <${T} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${a.custom_string} onInput=${c("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${a.hwrev} onInput=${c("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${a.relais_mode} onChange=${c("relais_mode")}>
          <option value="">(unchanged)</option>${mn.map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${a.extension_mode} onChange=${c("extension_mode")}>
          <option value="">(unchanged)</option>${hn.map(l=>d`<option>${l}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await S(()=>N.silence(n,!o),o?"Device may talk again":"Device silenced"),r(!o)}}>${o?"End silence":"Silence"}<//>
        <${$} onClick=${()=>S(()=>N.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Pt(){let{data:e,error:t,reload:n}=P(N.list,5e3),[a,s]=v(""),o=(l,_)=>async()=>{await S(l,_),setTimeout(n,1500)},r=async()=>{let l=a.trim();l&&await S(()=>N.action(l,"ping"),`Ping sent to ${l}`)},c=async()=>{confirm("Restart every device on the bus?")&&await o(()=>X.action("restart"),"Restart sent to every device")()},u=o(async()=>{await X.action("ping"),await X.action("refresh")},"Scanning: every device was asked to announce itself");return d`
    <${T} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${o(()=>X.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${o(()=>X.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${o(()=>X.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${c}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${a} onInput=${l=>s(l.target.value)} onKeyDown=${l=>l.key==="Enter"&&r()} />
        <${$} onClick=${r}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(l=>d`<tr key=${l.key}>
                    <td><${te} href=${"/devices/"+encodeURIComponent(l.name||l.key)}>${l.name||l.key}<//></td>
                    <td><code>${Oe(l.device_id)}</code></td>
                    <td>${l.type_name} <code>${Oe(l.device_type)}</code></td>
                    <td>${l.version}</td>
                    <td>${ee(l.last_seen_minutes_ago)}</td>
                    <td>${l.uptime?ee(Math.floor(l.uptime/60)):""}</td>
                    <td>${l.error?d`<span class="badge bad">error ${l.error}</span>`:l.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${D} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function Ut(){return d`<${Tn} /><${Cn} /><${xn} />`}function Tn(){let{data:e,error:t}=P(Pe.get,5e3);return d`
    <${T} title="Gateway" aside=${d`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await S(Pe.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${It(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:d`<${D} error=${t} />`}
    <//>`}function Cn(){let{data:e,error:t,reload:n}=P(Ue.get),[a,s]=v({});if(!e)return d`<${D} error=${t} />`;let o=u=>u in a?a[u]:e[u],r=(u,l)=>_=>s({...a,[u]:l?+_.target.value:_.target.value}),c=async()=>{let u={...a};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return O("Nothing changed");let l=await S(()=>Ue.update(u),"Saved");l&&(l.restart_required&&O("Restart the gateway to apply the hostname or bitrate."),s({}),n())};return d`
    <${T} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${o("hostname")} onInput=${r("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${o("can_bitrate")} onChange=${r("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${o("update_delay_ms")} onInput=${r("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${o("web_username")} onInput=${r("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${a.web_password||""} onInput=${r("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}function xn(){return d`
    <${T} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${we} target="gateway" label="Install and restart" />
    <//>`}var En=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],Rn={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Fn={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},Q=async(e,t)=>await S(e,t)!==void 0,Be=e=>e?new Date(e).toLocaleString():"\u2014";function Ge({label:e,accept:t,send:n,success:a,after:s}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async r=>{let c=r.target.files[0];if(r.target.value="",!c)return;let u=await c.text();await Q(()=>n(u),a)&&s&&s()}} hidden /></label>`}function Dt(){let{data:e,error:t,reload:n}=P(q.get,1e4);return e?d`
    <${In} d=${e} />
    <${Ln} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${An} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${Nn} reload=${n} />`}
    ${e.mode==="est"&&d`<${Hn} d=${e} reload=${n} />`}
    <${Mn} d=${e} reload=${n} />
    <${Pn} d=${e} reload=${n} />`:d`<${D} error=${t} />`}function Ke({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Be(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Be(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function In({d:e}){let t=e.certificate,[n,a]=t?Rn[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${T} title="Certificate" aside=${d`<span class=${"badge "+a}>${n}</span>`}>
      ${t?d`<${Ke} c=${t} />
            <p class="muted">Made: ${Fn[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Ln({d:e,reload:t}){let[n,a]=v(e.fqdn),[s,o]=v(e.mode),r=async()=>{let c={};if(n!==e.fqdn&&(c.fqdn=n.trim()),s!==e.mode&&(c.mode=s),Object.keys(c).length===0)return O("Nothing changed");await Q(()=>q.update(c),"Saved")&&t()};return d`
    <${T} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${c=>a(c.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${En.map(([c,u,l])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${c} checked=${s===c} onChange=${()=>o(c)} />
          <span><strong>${u}</strong><small class="muted">${l}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${$} kind="primary" onClick=${r}>Save<//></div>
    <//>`}function An({d:e,reload:t}){let[n,a]=v(e.validity_years);return d`
    <${T} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${o=>a(+o.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await Q(()=>q.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function Nn({reload:e}){return d`
    <${T} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${q.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Ge} label="Upload certificate" send=${q.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function Hn({d:e,reload:t}){let n=e.est,[a,s]=v(n.url),[o,r]=v(n.auto_renew),c=async()=>{await Q(()=>q.update({est_url:a.trim(),est_auto_renew:o}),"Saved")&&t()},u=async()=>{await Q(q.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${T} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]"><input value=${a} onInput=${l=>s(l.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${o} onChange=${l=>r(l.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Be(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${Ke} c=${n.identity} />`}
      <div class="buttons">
        <${Ge} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${q.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${$} kind="danger" onClick=${async()=>await Q(q.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${c}>Save<//>
        <${$} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function Mn({d:e,reload:t}){let n=e.trust_anchor;return d`
    <${T} title="Trust anchor (CA)">
      <p class="muted">The CA the EST server's certificate has to chain to. TLS to the EST server is always verified against it.</p>
      ${n?d`<${Ke} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${Ge} label=${n?"Replace":"Upload"} send=${q.setTrustAnchor} success="Trust anchor installed" after=${t} />
        ${n&&d`<${$} kind="danger" onClick=${async()=>confirm("Remove the trust anchor?")&&await Q(q.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function Pn({d:e,reload:t}){let[n,a]=v(e.ntp_server),s=async()=>{await Q(()=>q.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${T} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates and EST need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} onInput=${o=>a(o.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${s}>Save<//></div>
    <//>`}var Un={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Ot(){let{data:e,error:t,reload:n}=P(oe.all,5e3);return e?d`
    <${qt} slot="primary" b=${e.primary} reload=${n} />
    <${qt} slot="secondary" b=${e.secondary} reload=${n} />`:d`<${D} error=${t} />`}function qt({slot:e,b:t,reload:n}){let[a,s]=v({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[o,r]=v(null),c=a.uri.startsWith("mqtts://"),u=i=>p=>s({...a,[i]:p.target.type==="checkbox"?p.target.checked:p.target.value}),l=async()=>{let i={uri:a.uri,user:a.user,enabled:a.enabled,tls_insecure:a.tls_insecure};a.password&&(i.password=a.password),await S(()=>oe.update(e,i),`${e} broker saved, reconnecting`)&&(s({...a,password:""}),setTimeout(n,2500))},_=async()=>{let i=await S(()=>oe.certificate(e));i&&r(i)};return d`
    <${T}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${Un[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${a.uri} onInput=${u("uri")} /><//>
        <${C} label="User"><input value=${a.user} onInput=${u("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${a.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${c&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${a.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await S(()=>oe.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),_()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${_}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${$} kind="danger" onClick=${async()=>{await S(()=>oe.forget(e),"Certificate forgotten"),r(null),n()}}>Forget<//>`}
          </div>
          ${o&&d`<p>${o.pinned?d`SHA-256 <code>${o.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var Dn=[{path:"/",title:"Devices",page:Pt},{path:"/devices/:device",title:"Device",page:Mt},{path:"/sensors",title:"Sensors",page:Nt},{path:"/mqtt",title:"MQTT",page:Ot},{path:"/gateway",title:"Gateway",page:Ut},{path:"/https",title:"HTTPS",page:Dt}],qn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function On(){let e=Lt(),t=At(Dn,e),n=t?t.route.page:null,a=s=>s==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(s);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${qn.map(([s,o])=>d`<${te} href=${s} class=${a(s)?"active":""}>${o}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${te} href="/">Devices<//></p>`}
    </main>
    <${Ft} />`}dt(d`<${On} />`,document.getElementById("app"));
