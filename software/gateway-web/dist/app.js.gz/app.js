var jt=Object.create;var Qe=Object.defineProperty;var Bt=Object.getOwnPropertyDescriptor;var Vt=Object.getOwnPropertyNames;var Kt=Object.getPrototypeOf,Gt=Object.prototype.hasOwnProperty;var zt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Qt=(e,t,n,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Vt(t))!Gt.call(e,o)&&o!==n&&Qe(e,o,{get:()=>t[o],enumerable:!(a=Bt(t,o))||a.enumerable});return e};var Jt=(e,t,n)=>(n=e!=null?jt(Kt(e)):{},Qt(t||!e||!e.__esModule?Qe(n,"default",{value:e,enumerable:!0}):n,e));var Ct=zt(Le=>{var Tt;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Le=="object"?e(Le):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(Tt={}):e(Tt={})})(function(e){e.version="1.2.2";function t(){for(var f=0,A=new Array(256),h=0;h!=256;++h)f=h,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,A[h]=f;return typeof Int32Array<"u"?new Int32Array(A):A}var n=t();function a(f){var A=0,h=0,k=0,g=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(k=0;k!=256;++k)g[k]=f[k];for(k=0;k!=256;++k)for(h=f[k],A=256+k;A<4096;A+=256)h=g[A]=h>>>8^f[h&255];var F=[];for(k=1;k!=16;++k)F[k-1]=typeof Int32Array<"u"?g.subarray(k*256,k*256+256):g.slice(k*256,k*256+256);return F}var o=a(n),s=o[0],i=o[1],c=o[2],u=o[3],l=o[4],p=o[5],r=o[6],_=o[7],m=o[8],y=o[9],R=o[10],x=o[11],S=o[12],w=o[13],H=o[14];function D(f,A){for(var h=A^-1,k=0,g=f.length;k<g;)h=h>>>8^n[(h^f.charCodeAt(k++))&255];return~h}function V(f,A){for(var h=A^-1,k=f.length-15,g=0;g<k;)h=H[f[g++]^h&255]^w[f[g++]^h>>8&255]^S[f[g++]^h>>16&255]^x[f[g++]^h>>>24]^R[f[g++]]^y[f[g++]]^m[f[g++]]^_[f[g++]]^r[f[g++]]^p[f[g++]]^l[f[g++]]^u[f[g++]]^c[f[g++]]^i[f[g++]]^s[f[g++]]^n[f[g++]];for(k+=15;g<k;)h=h>>>8^n[(h^f[g++])&255];return~h}function W(f,A){for(var h=A^-1,k=0,g=f.length,F=0,Se=0;k<g;)F=f.charCodeAt(k++),F<128?h=h>>>8^n[(h^F)&255]:F<2048?(h=h>>>8^n[(h^(192|F>>6&31))&255],h=h>>>8^n[(h^(128|F&63))&255]):F>=55296&&F<57344?(F=(F&1023)+64,Se=f.charCodeAt(k++)&1023,h=h>>>8^n[(h^(240|F>>8&7))&255],h=h>>>8^n[(h^(128|F>>2&63))&255],h=h>>>8^n[(h^(128|Se>>6&15|(F&3)<<4))&255],h=h>>>8^n[(h^(128|Se&63))&255]):(h=h>>>8^n[(h^(224|F>>12&15))&255],h=h>>>8^n[(h^(128|F>>6&63))&255],h=h>>>8^n[(h^(128|F&63))&255]);return~h}e.table=n,e.bstr=D,e.buf=V,e.str=W})});var me,E,et,Xt,Q,Je,tt,nt,at,xe,Te,Ce,Yt,ie={},st=[],Zt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,$e=Array.isArray;function K(e,t){for(var n in t)e[n]=t[n];return e}function Ee(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function re(e,t,n){var a,o,s,i={};for(s in t)s=="key"?a=t[s]:s=="ref"?o=t[s]:i[s]=t[s];if(arguments.length>2&&(i.children=arguments.length>3?me.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(s in e.defaultProps)i[s]===void 0&&(i[s]=e.defaultProps[s]);return _e(e,i,a,o,null)}function _e(e,t,n,a,o){var s={type:e,props:t,key:n,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++et,__i:-1,__u:0};return o==null&&E.vnode!=null&&E.vnode(s),s}function ve(e){return e.children}function fe(e,t){this.props=e,this.context=t}function ne(e,t){if(t==null)return e.__?ne(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?ne(e):null}function ot(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return ot(e)}}function Xe(e){(!e.__d&&(e.__d=!0)&&Q.push(e)&&!he.__r++||Je!=E.debounceRendering)&&((Je=E.debounceRendering)||tt)(he)}function he(){for(var e,t,n,a,o,s,i,c=1;Q.length;)Q.length>c&&Q.sort(nt),e=Q.shift(),c=Q.length,e.__d&&(n=void 0,o=(a=(t=e).__v).__e,s=[],i=[],t.__P&&((n=K({},a)).__v=a.__v+1,E.vnode&&E.vnode(n),Fe(t.__P,n,a,t.__n,t.__P.namespaceURI,32&a.__u?[o]:null,s,o??ne(a),!!(32&a.__u),i),n.__v=a.__v,n.__.__k[n.__i]=n,lt(s,n,i),n.__e!=o&&ot(n)));he.__r=0}function it(e,t,n,a,o,s,i,c,u,l,p){var r,_,m,y,R,x,S=a&&a.__k||st,w=t.length;for(u=en(n,t,S,u,w),r=0;r<w;r++)(m=n.__k[r])!=null&&(_=m.__i==-1?ie:S[m.__i]||ie,m.__i=r,x=Fe(e,m,_,o,s,i,c,u,l,p),y=m.__e,m.ref&&_.ref!=m.ref&&(_.ref&&Re(_.ref,null,m),p.push(m.ref,m.__c||y,m)),R==null&&y!=null&&(R=y),4&m.__u||_.__k===m.__k?u=rt(m,u,e):typeof m.type=="function"&&x!==void 0?u=x:y&&(u=y.nextSibling),m.__u&=-7);return n.__e=R,u}function en(e,t,n,a,o){var s,i,c,u,l,p=n.length,r=p,_=0;for(e.__k=new Array(o),s=0;s<o;s++)(i=t[s])!=null&&typeof i!="boolean"&&typeof i!="function"?(u=s+_,(i=e.__k[s]=typeof i=="string"||typeof i=="number"||typeof i=="bigint"||i.constructor==String?_e(null,i,null,null,null):$e(i)?_e(ve,{children:i},null,null,null):i.constructor==null&&i.__b>0?_e(i.type,i.props,i.key,i.ref?i.ref:null,i.__v):i).__=e,i.__b=e.__b+1,c=null,(l=i.__i=tn(i,n,u,r))!=-1&&(r--,(c=n[l])&&(c.__u|=2)),c==null||c.__v==null?(l==-1&&(o>p?_--:o<p&&_++),typeof i.type!="function"&&(i.__u|=4)):l!=u&&(l==u-1?_--:l==u+1?_++:(l>u?_--:_++,i.__u|=4))):e.__k[s]=null;if(r)for(s=0;s<p;s++)(c=n[s])!=null&&(2&c.__u)==0&&(c.__e==a&&(a=ne(c)),dt(c,c));return a}function rt(e,t,n){var a,o;if(typeof e.type=="function"){for(a=e.__k,o=0;a&&o<a.length;o++)a[o]&&(a[o].__=e,t=rt(a[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=ne(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function tn(e,t,n,a){var o,s,i=e.key,c=e.type,u=t[n];if(u===null&&e.key==null||u&&i==u.key&&c==u.type&&(2&u.__u)==0)return n;if(a>(u!=null&&(2&u.__u)==0?1:0))for(o=n-1,s=n+1;o>=0||s<t.length;){if(o>=0){if((u=t[o])&&(2&u.__u)==0&&i==u.key&&c==u.type)return o;o--}if(s<t.length){if((u=t[s])&&(2&u.__u)==0&&i==u.key&&c==u.type)return s;s++}}return-1}function Ye(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Zt.test(t)?n:n+"px"}function pe(e,t,n,a,o){var s,i;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof a=="string"&&(e.style.cssText=a=""),a)for(t in a)n&&t in n||Ye(e.style,t,"");if(n)for(t in n)a&&n[t]==a[t]||Ye(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")s=t!=(t=t.replace(at,"$1")),i=t.toLowerCase(),t=i in e||t=="onFocusOut"||t=="onFocusIn"?i.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+s]=n,n?a?n.u=a.u:(n.u=xe,e.addEventListener(t,s?Ce:Te,s)):e.removeEventListener(t,s?Ce:Te,s);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ze(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=xe++;else if(t.t<n.u)return;return n(E.event?E.event(t):t)}}}function Fe(e,t,n,a,o,s,i,c,u,l){var p,r,_,m,y,R,x,S,w,H,D,V,W,f,A,h,k,g=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),s=[c=t.__e=n.__e]),(p=E.__b)&&p(t);e:if(typeof g=="function")try{if(S=t.props,w="prototype"in g&&g.prototype.render,H=(p=g.contextType)&&a[p.__c],D=p?H?H.props.value:p.__:a,n.__c?x=(r=t.__c=n.__c).__=r.__E:(w?t.__c=r=new g(S,D):(t.__c=r=new fe(S,D),r.constructor=g,r.render=an),H&&H.sub(r),r.props=S,r.state||(r.state={}),r.context=D,r.__n=a,_=r.__d=!0,r.__h=[],r._sb=[]),w&&r.__s==null&&(r.__s=r.state),w&&g.getDerivedStateFromProps!=null&&(r.__s==r.state&&(r.__s=K({},r.__s)),K(r.__s,g.getDerivedStateFromProps(S,r.__s))),m=r.props,y=r.state,r.__v=t,_)w&&g.getDerivedStateFromProps==null&&r.componentWillMount!=null&&r.componentWillMount(),w&&r.componentDidMount!=null&&r.__h.push(r.componentDidMount);else{if(w&&g.getDerivedStateFromProps==null&&S!==m&&r.componentWillReceiveProps!=null&&r.componentWillReceiveProps(S,D),!r.__e&&r.shouldComponentUpdate!=null&&r.shouldComponentUpdate(S,r.__s,D)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(r.props=S,r.state=r.__s,r.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(F){F&&(F.__=t)}),V=0;V<r._sb.length;V++)r.__h.push(r._sb[V]);r._sb=[],r.__h.length&&i.push(r);break e}r.componentWillUpdate!=null&&r.componentWillUpdate(S,r.__s,D),w&&r.componentDidUpdate!=null&&r.__h.push(function(){r.componentDidUpdate(m,y,R)})}if(r.context=D,r.props=S,r.__P=e,r.__e=!1,W=E.__r,f=0,w){for(r.state=r.__s,r.__d=!1,W&&W(t),p=r.render(r.props,r.state,r.context),A=0;A<r._sb.length;A++)r.__h.push(r._sb[A]);r._sb=[]}else do r.__d=!1,W&&W(t),p=r.render(r.props,r.state,r.context),r.state=r.__s;while(r.__d&&++f<25);r.state=r.__s,r.getChildContext!=null&&(a=K(K({},a),r.getChildContext())),w&&!_&&r.getSnapshotBeforeUpdate!=null&&(R=r.getSnapshotBeforeUpdate(m,y)),h=p,p!=null&&p.type===ve&&p.key==null&&(h=ct(p.props.children)),c=it(e,$e(h)?h:[h],t,n,a,o,s,i,c,u,l),r.base=t.__e,t.__u&=-161,r.__h.length&&i.push(r),x&&(r.__E=r.__=null)}catch(F){if(t.__v=null,u||s!=null)if(F.then){for(t.__u|=u?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;s[s.indexOf(c)]=null,t.__e=c}else for(k=s.length;k--;)Ee(s[k]);else t.__e=n.__e,t.__k=n.__k;E.__e(F,t,n)}else s==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):c=t.__e=nn(n.__e,t,n,a,o,s,i,u,l);return(p=E.diffed)&&p(t),128&t.__u?void 0:c}function lt(e,t,n){for(var a=0;a<n.length;a++)Re(n[a],n[++a],n[++a]);E.__c&&E.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(s){s.call(o)})}catch(s){E.__e(s,o.__v)}})}function ct(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:$e(e)?e.map(ct):K({},e)}function nn(e,t,n,a,o,s,i,c,u){var l,p,r,_,m,y,R,x=n.props,S=t.props,w=t.type;if(w=="svg"?o="http://www.w3.org/2000/svg":w=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),s!=null){for(l=0;l<s.length;l++)if((m=s[l])&&"setAttribute"in m==!!w&&(w?m.localName==w:m.nodeType==3)){e=m,s[l]=null;break}}if(e==null){if(w==null)return document.createTextNode(S);e=document.createElementNS(o,w,S.is&&S),c&&(E.__m&&E.__m(t,s),c=!1),s=null}if(w==null)x===S||c&&e.data==S||(e.data=S);else{if(s=s&&me.call(e.childNodes),x=n.props||ie,!c&&s!=null)for(x={},l=0;l<e.attributes.length;l++)x[(m=e.attributes[l]).name]=m.value;for(l in x)if(m=x[l],l!="children"){if(l=="dangerouslySetInnerHTML")r=m;else if(!(l in S)){if(l=="value"&&"defaultValue"in S||l=="checked"&&"defaultChecked"in S)continue;pe(e,l,null,m,o)}}for(l in S)m=S[l],l=="children"?_=m:l=="dangerouslySetInnerHTML"?p=m:l=="value"?y=m:l=="checked"?R=m:c&&typeof m!="function"||x[l]===m||pe(e,l,m,x[l],o);if(p)c||r&&(p.__html==r.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(r&&(e.innerHTML=""),it(t.type=="template"?e.content:e,$e(_)?_:[_],t,n,a,w=="foreignObject"?"http://www.w3.org/1999/xhtml":o,s,i,s?s[0]:n.__k&&ne(n,0),c,u),s!=null)for(l=s.length;l--;)Ee(s[l]);c||(l="value",w=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[l]||w=="progress"&&!y||w=="option"&&y!=x[l])&&pe(e,l,y,x[l],o),l="checked",R!=null&&R!=e[l]&&pe(e,l,R,x[l],o))}return e}function Re(e,t,n){try{if(typeof e=="function"){var a=typeof e.__u=="function";a&&e.__u(),a&&t==null||(e.__u=e(t))}else e.current=t}catch(o){E.__e(o,n)}}function dt(e,t,n){var a,o;if(E.unmount&&E.unmount(e),(a=e.ref)&&(a.current&&a.current!=e.__e||Re(a,null,t)),(a=e.__c)!=null){if(a.componentWillUnmount)try{a.componentWillUnmount()}catch(s){E.__e(s,t)}a.base=a.__P=null}if(a=e.__k)for(o=0;o<a.length;o++)a[o]&&dt(a[o],t,n||typeof e.type!="function");n||Ee(e.__e),e.__c=e.__=e.__e=void 0}function an(e,t,n){return this.constructor(e,n)}function ut(e,t,n){var a,o,s,i;t==document&&(t=document.documentElement),E.__&&E.__(e,t),o=(a=typeof n=="function")?null:n&&n.__k||t.__k,s=[],i=[],Fe(t,e=(!a&&n||t).__k=re(ve,null,[e]),o||ie,ie,t.namespaceURI,!a&&n?[n]:o?null:t.firstChild?me.call(t.childNodes):null,s,!a&&n?n:o?o.__e:t.firstChild,a,i),lt(s,e,i)}me=st.slice,E={__e:function(e,t,n,a){for(var o,s,i;t=t.__;)if((o=t.__c)&&!o.__)try{if((s=o.constructor)&&s.getDerivedStateFromError!=null&&(o.setState(s.getDerivedStateFromError(e)),i=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,a||{}),i=o.__d),i)return o.__E=o}catch(c){e=c}throw e}},et=0,Xt=function(e){return e!=null&&e.constructor==null},fe.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=K({},this.state),typeof e=="function"&&(e=e(K({},n),this.props)),e&&K(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Xe(this))},fe.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Xe(this))},fe.prototype.render=ve,Q=[],tt=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,nt=function(e,t){return e.__v.__b-t.__v.__b},he.__r=0,at=/(PointerCapture)$|Capture$/i,xe=0,Te=Ze(!1),Ce=Ze(!0),Yt=0;var le,N,Ne,pt,ce=0,yt=[],I=E,_t=I.__b,ft=I.__r,ht=I.diffed,mt=I.__c,$t=I.unmount,vt=I.__;function Ae(e,t){I.__h&&I.__h(N,e,ce||t),ce=0;var n=N.__H||(N.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function v(e){return ce=1,sn(St,e)}function sn(e,t,n){var a=Ae(le++,2);if(a.t=e,!a.__c&&(a.__=[n?n(t):St(void 0,t),function(c){var u=a.__N?a.__N[0]:a.__[0],l=a.t(u,c);u!==l&&(a.__N=[l,a.__[1]],a.__c.setState({}))}],a.__c=N,!N.__f)){var o=function(c,u,l){if(!a.__c.__H)return!0;var p=a.__c.__H.__.filter(function(_){return!!_.__c});if(p.every(function(_){return!_.__N}))return!s||s.call(this,c,u,l);var r=a.__c.props!==c;return p.forEach(function(_){if(_.__N){var m=_.__[0];_.__=_.__N,_.__N=void 0,m!==_.__[0]&&(r=!0)}}),s&&s.call(this,c,u,l)||r};N.__f=!0;var s=N.shouldComponentUpdate,i=N.componentWillUpdate;N.componentWillUpdate=function(c,u,l){if(this.__e){var p=s;s=void 0,o(c,u,l),s=p}i&&i.call(this,c,u,l)},N.shouldComponentUpdate=o}return a.__N||a.__}function J(e,t){var n=Ae(le++,3);!I.__s&&kt(n.__H,t)&&(n.__=e,n.u=t,N.__H.__h.push(n))}function ye(e){return ce=5,wt(function(){return{current:e}},[])}function wt(e,t){var n=Ae(le++,7);return kt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function bt(e,t){return ce=8,wt(function(){return e},t)}function on(){for(var e;e=yt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ge),e.__H.__h.forEach(Ie),e.__H.__h=[]}catch(t){e.__H.__h=[],I.__e(t,e.__v)}}I.__b=function(e){N=null,_t&&_t(e)},I.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),vt&&vt(e,t)},I.__r=function(e){ft&&ft(e),le=0;var t=(N=e.__c).__H;t&&(Ne===N?(t.__h=[],N.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ge),t.__h.forEach(Ie),t.__h=[],le=0)),Ne=N},I.diffed=function(e){ht&&ht(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(yt.push(t)!==1&&pt===I.requestAnimationFrame||((pt=I.requestAnimationFrame)||rn)(on)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ne=N=null},I.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ge),n.__h=n.__h.filter(function(a){return!a.__||Ie(a)})}catch(a){t.some(function(o){o.__h&&(o.__h=[])}),t=[],I.__e(a,n.__v)}}),mt&&mt(e,t)},I.unmount=function(e){$t&&$t(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(a){try{ge(a)}catch(o){t=o}}),n.__H=void 0,t&&I.__e(t,n.__v))};var gt=typeof requestAnimationFrame=="function";function rn(e){var t,n=function(){clearTimeout(a),gt&&cancelAnimationFrame(t),setTimeout(e)},a=setTimeout(n,35);gt&&(t=requestAnimationFrame(n))}function ge(e){var t=N,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),N=t}function Ie(e){var t=N;e.__c=e.__(),N=t}function kt(e,t){return!e||e.length!==t.length||t.some(function(n,a){return n!==e[a]})}function St(e,t){return typeof t=="function"?t(e):t}var xt=Jt(Ct()),Pe="/api/v1",ae=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},ln=e=>new Promise(t=>setTimeout(t,e));async function de(e,t,n){let a=typeof n=="string";for(let o=1;;o++){let s;try{s=await fetch(Pe+t,{method:e,headers:n===void 0?{}:{"Content-Type":a?"application/x-pem-file":"application/json"},body:n===void 0?void 0:a?n:JSON.stringify(n)})}catch{if(o>=4)throw new ae(0,{message:"gateway unreachable"});await ln(250*o);continue}let i=await s.text(),c=null;try{c=i?JSON.parse(i):null}catch{c={message:i}}if(!s.ok)throw new ae(s.status,c);return c}}var B=e=>de("GET",e),G=(e,t)=>de("POST",e,t),j=(e,t)=>de("PUT",e,t),ue=(e,t)=>de("PATCH",e,t),Me=e=>de("DELETE",e),O=encodeURIComponent,He={get:()=>B("/system"),restart:()=>G("/system/restart")},De={get:()=>B("/config"),update:e=>ue("/config",e)},Ue={get:()=>B("/location"),update:e=>ue("/location",e)},se={all:()=>B("/mqtt"),update:(e,t)=>ue(`/mqtt/${e}`,t),trust:e=>G(`/mqtt/${e}/trust`),certificate:e=>B(`/mqtt/${e}/certificate`),forget:e=>Me(`/mqtt/${e}/certificate`)},q={get:()=>B("/tls"),update:e=>ue("/tls",e),selfSigned:e=>G("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Pe}/tls/csr`,installCertificate:e=>j("/tls/certificate",e),setTrustAnchor:e=>j("/tls/trust-anchor",e),removeTrustAnchor:()=>Me("/tls/trust-anchor"),setIdentity:e=>j("/tls/est/identity",e),removeIdentity:()=>Me("/tls/est/identity"),enroll:()=>G("/tls/est/enroll")},L={async list(){let e=[];for(;;){let t=await B(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>B(`/devices/${O(e)}`),update:(e,t)=>ue(`/devices/${O(e)}`,t),action:(e,t)=>G(`/devices/${O(e)}/${t}`),silence:(e,t)=>j(`/devices/${O(e)}/silence`,{on:t}),relay:(e,t,n,a)=>j(`/devices/${O(e)}/relays/${t}`,{state:n,duration_ms:a}),rollershutter:(e,t,n,a)=>j(`/devices/${O(e)}/rollershutters/${t}`,{state:n,duration_ms:a}),lamps:(e,t,n,a)=>j(`/devices/${O(e)}/lamps/${t}`,{value:n,bitmask:a}),heating:(e,t,n)=>j(`/devices/${O(e)}/heating/${t}`,n),heatingManualState:e=>B(`/devices/${O(e)}/heating/manual`),heatingManual:(e,t,n,a)=>j(`/devices/${O(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:a})},X={update:(e,t,n)=>j(`/devices/${O(e)}/sensors/${t}`,n),refresh:e=>G(`/devices/${O(e)}/sensors/refresh`),forget:e=>G(`/devices/${O(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${O(e)}`:"",a=await B(`/sensors?offset=${t.length}${n}`);if(t.push(...a.sensors),a.sensors.length===0||t.length>=a.total)return t}}},Y={action:e=>G(`/bus/${e}`),silence:e=>j("/bus/silence",{on:e}),typeAction:(e,t)=>G(`/device-types/${e}/${t}`)},Oe={job:()=>B("/firmware/job"),upload(e,t,n){let a=xt.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((s,i)=>{let c=new XMLHttpRequest;c.open("PUT",`${Pe}${o}?crc32=${a}`),c.setRequestHeader("Content-Type","application/octet-stream"),c.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),c.onload=()=>{let u=null;try{u=JSON.parse(c.responseText)}catch{}c.status>=200&&c.status<300?s(u):i(new ae(c.status,u))},c.onerror=()=>i(new ae(0,{message:"upload failed"})),c.send(t)})}};var Ft=function(e,t,n,a){var o;t[0]=0;for(var s=1;s<t.length;s++){var i=t[s++],c=t[s]?(t[0]|=i?1:2,n[t[s++]]):t[++s];i===3?a[0]=c:i===4?a[1]=Object.assign(a[1]||{},c):i===5?(a[1]=a[1]||{})[t[++s]]=c:i===6?a[1][t[++s]]+=c+"":i?(o=e.apply(c,Ft(e,c,n,["",null])),a.push(o),c[0]?t[0]|=2:(t[s-2]=0,t[s]=o)):a.push(c)}return a},Et=new Map;function Rt(e){var t=Et.get(this);return t||(t=new Map,Et.set(this,t)),(t=Ft(this,t.get(e)||(t.set(e,t=function(n){for(var a,o,s=1,i="",c="",u=[0],l=function(_){s===1&&(_||(i=i.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,_,i):s===3&&(_||i)?(u.push(3,_,i),s=2):s===2&&i==="..."&&_?u.push(4,_,0):s===2&&i&&!_?u.push(5,0,!0,i):s>=5&&((i||!_&&s===5)&&(u.push(s,0,i,o),s=6),_&&(u.push(s,_,0,o),s=6)),i=""},p=0;p<n.length;p++){p&&(s===1&&l(),l(p));for(var r=0;r<n[p].length;r++)a=n[p][r],s===1?a==="<"?(l(),u=[u],s=3):i+=a:s===4?i==="--"&&a===">"?(s=1,i=""):i=a+i[0]:c?a===c?c="":i+=a:a==='"'||a==="'"?c=a:a===">"?(l(),s=1):s&&(a==="="?(s=5,o=i,i=""):a==="/"&&(s<5||n[p][r+1]===">")?(l(),s===3&&(u=u[0]),s=u,(u=u[0]).push(2,0,s),s=0):a===" "||a==="	"||a===`
`||a==="\r"?(l(),s=2):i+=a),s===3&&i==="!--"&&(s=4,u=u[0])}return l(),u}(e)),t),arguments,[])).length>1?t:t[0]}var d=Rt.bind(re),qe=()=>{};function U(e,t="ok"){qe(e,t)}function Nt(){let[e,t]=v([]);return J(()=>{let n=0;return qe=(a,o)=>{let s={id:++n,message:a,kind:o};t(i=>[...i,s]),setTimeout(()=>t(i=>i.filter(c=>c!==s)),o==="error"?8e3:3e3)},()=>qe=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function T(e,t){try{let n=await e();return t&&U(t),n}catch(n){U(n.message,"error");return}}function M(e,t){let[n,a]=v({data:void 0,error:void 0}),o=ye(e);o.current=e;let s=bt(async()=>{try{a({data:await o.current(),error:void 0})}catch(i){a(c=>({data:c.data,error:i}))}},[]);return J(()=>{let i=!1,c,u=async()=>{await s(),t&&!i&&(c=setTimeout(u,t))};return u(),()=>{i=!0,clearTimeout(c)}},[t,s]),{...n,reload:s}}var b=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,P=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:a})=>{let[o,s]=v(!1);return d`<button class=${t||""} disabled=${a||o} onClick=${async c=>{s(!0);try{await n(c)}finally{s(!1)}}}>${e}</button>`},We=e=>"0x"+e.toString(16).padStart(2,"0");function ee(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function It(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),a=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${a} min`:`${a} min`}function we({target:e,label:t,others:n=[],onDone:a}){let[o,s]=v(null),[i,c]=v(null),[u,l]=v(""),[p,r]=v(null),_=ye(null);J(()=>()=>clearInterval(_.current),[]);let m=()=>{clearInterval(_.current),_.current=setInterval(async()=>{try{r(await Oe.job())}catch{}},1500)},y=async(w,H)=>{l(w),c(0),H!=="gateway"&&m();try{let D=await o.arrayBuffer();return await Oe.upload(H,D,c)||{}}finally{clearInterval(_.current),c(null)}},R=async w=>{if(!o)return;let H=0;for(let{name:D,target:V}of w)try{let W=await y(D,V);H+=1,W.restarting&&U("Firmware installed, the gateway restarts\u2026")}catch(W){U(`${D}: ${W.message}`,"error");break}H===w.length&&w[0].target!=="gateway"&&U(H===1?"Firmware sent; the device restarts into it":`Firmware sent to ${H} devices`),l(""),r(null),a&&a()},x=i!==null,S=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>s(w.target.files[0]||null)} />
      <${$} onClick=${()=>R([{name:t||"device",target:e}])} disabled=${!o||x}>${t||"Upload"}<//>
      ${n.length>0&&d`<${$} onClick=${()=>R([{name:"this device",target:e},...n])} disabled=${!o||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&d`<progress max="1" value=${i}></progress>`}
      ${x&&d`<p class="muted wide">${u}${S?" \u2014 "+S:""}</p>`}
    </div>`}var be=new Set;function cn(e){e!==location.pathname&&history.pushState(null,"",e),be.forEach(t=>t())}addEventListener("popstate",()=>be.forEach(e=>e()));function At(){let[e,t]=v(location.pathname);return J(()=>{let n=()=>t(location.pathname);return be.add(n),()=>be.delete(n)},[]),e}function Lt(e,t){let n=t.split("/").filter(Boolean);for(let a of e){let o=a.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let s={};if(o.every((c,u)=>c.startsWith(":")?(s[c.slice(1)]=decodeURIComponent(n[u]),!0):c===n[u]))return{route:a,params:s}}return null}function te({href:e,children:t,...n}){return re("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),cn(e))},...n},t)}var dn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"},je=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],un={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},oe=e=>un[e]||e;function ke(e,t=5e3){let n=M(()=>X.list(e),t),a=[...new Set((n.data||[]).map(s=>s.device))];return{...n,ask:async()=>{for(let s of e?[e]:a)await T(()=>X.refresh(s));setTimeout(n.reload,1500)}}}function pn({s:e,device:t,reload:n}){let[a,o]=v(!1),[s,i]=v(e.name||""),[c,u]=v(e.role||"none"),l=async()=>{let p={};if(s!==(e.name||"")&&(p.name=s),c!==(e.role||"none")&&(p.role=c),Object.keys(p).length===0)return o(!1);await T(()=>X.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${te} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${a?d`<input class="inline" maxlength="7" placeholder="name" value=${s} onInput=${p=>i(p.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${dn[e.kind]||e.kind}</td>
    <td>${a?d`<select value=${c} onChange=${p=>u(p.target.value)}>${je.map(p=>d`<option value=${p}>${oe(p)}</option>`)}</select>`:e.role&&e.role!=="none"?oe(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind==="temperature"?e.value.toFixed(2):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ee(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":a?d`<${$} kind="primary" onClick=${l}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function Be({device:e}){let{data:t,error:n,reload:a,ask:o}=ke(e);if(!t)return d`<${P} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let s=t.some(i=>i.slot===null);return d`
    ${s&&d`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(i=>d`<${pn} key=${i.device_key+i.kind+i.sensor_id} s=${i} device=${e} reload=${a} />`)}
      </tbody>
    </table></div>`}function Mt(){let{ask:e}=ke(void 0,0);return d`<${b} title="Sensors" aside=${d`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${Be} />
  <//>`}var _n=[2,5,8,9],fn=[7],hn=[3],Ve=[9],mn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],$n=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ht({device:e}){let{data:t,error:n,reload:a}=M(()=>L.get(e),5e3);return t?d`
    <${gn} d=${t} reload=${a} />
    ${_n.includes(t.device_type)&&d`<${Pt} d=${t} kind="relay" />`}
    ${fn.includes(t.device_type)&&d`<${Pt} d=${t} kind="rollershutter" />`}
    ${hn.includes(t.device_type)&&d`<${yn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${wn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${kn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${Sn} d=${t} />`}
    <${b} title="Sensors"><${Be} device=${t.name||t.key} /><//>
    <${Tn} d=${t} reload=${a} />
    <${vn} d=${t} />`:d`<${P} error=${n} />`}function vn({d:e}){let t=e.name||e.key,{data:n}=M(L.list),a=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${b} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${we} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${a} />
    <//>`}function gn({d:e,reload:t}){let n=e.name||e.key,a=(o,s)=>async()=>{await T(()=>L.action(n,o),s),setTimeout(t,1500)};return d`
    <${b} title=${n}
      aside=${d`<span class="buttons">
        <${$} onClick=${a("ping","Ping sent")}>Ping<//>
        <${$} onClick=${a("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${a("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ee(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Pt({d:e,kind:t}){let n=e.name||e.key,[a,o]=v(1),[s,i]=v(0),c=t==="rollershutter",u=l=>()=>T(()=>L[t](n,a,l,Math.round(s*1e3)),`${c?"Rollershutter":"Relay"} ${a}: ${l}`);return d`
    <${b} title=${c?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${a} onInput=${l=>o(+l.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${s} onInput=${l=>i(+l.target.value)} /><//>
      </div>
      <div class="buttons">
        ${c?d`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:d`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function yn({d:e}){let t=e.name||e.key,[n,a]=v(0),[o,s]=v(255),[i,c]=v(Array(24).fill(!1)),u=i.reduce((l,p,r)=>p?l|1<<23-r:l,0);return d`
    <${b} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${l=>a(+l.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${o} onInput=${l=>s(+l.target.value)} /><//>
      </div>
      <div class="lamps">
        ${i.map((l,p)=>d`<label key=${p} class=${"lamp"+(l?" on":"")}>
            <input type="checkbox" checked=${l} onChange=${()=>c(i.map((r,_)=>_===p?!r:r))} />${23-p}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>T(()=>L.lamps(t,n,o,u),"Lamps set")}>Send<//>
    <//>`}function wn({d:e}){let t=e.name||e.key,[n,a]=v(45),[o,s]=v(!1),[i,c]=v(0),[u,l]=v(!1),[p,r]=v(0),[_,m]=v(55);return d`
    <${b} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>a(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${y=>s(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>T(()=>L.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${i} onInput=${y=>c(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${y=>l(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>T(()=>L.heating(t,"energy",{power_w:i,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>r(+y.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${_} onInput=${y=>m(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>T(()=>L.heating(t,"emergency",{stage:p,tank_c:_}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var bn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function kn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o,ask:s}=ke(t);if(!n)return d`<${b} title="Sensor assignment"><${P} error=${a} /><//>`;let i=n.filter(r=>r.kind==="temperature"),c=r=>i.find(_=>_.role===r),u=r=>r.name?`${r.name} (${r.sensor_id})`:r.sensor_id,l=i.every(r=>r.slot!==null),p=r=>async _=>{let m=_.target.value,y;if(m===""){let R=c(r);if(!R)return;y=await T(()=>X.update(t,R.slot,{role:"none"}),`${oe(r)} cleared`)}else{let R=i.find(x=>x.sensor_id===m);y=await T(()=>X.update(t,R.slot,{role:r}),`${u(R)} is ${oe(r)} now`)}y&&setTimeout(o,1500)};return d`
    <${b} title="Sensor assignment" aside=${d`<${$} onClick=${s}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!l&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${je.filter(r=>r!=="none").map(r=>d`<label key=${r} class="field">
            <span>${oe(r)}</span>
            <select value=${(c(r)||{}).sensor_id||""} onChange=${p(r)} disabled=${!l}>
              <option value="">(none)</option>
              ${i.map(_=>d`<option value=${_.sensor_id}>${u(_)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Sn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o}=M(()=>L.heatingManualState(t),3e3),s=!!(n&&n.enabled),i=p=>!!(n&&n.relays.includes(p)),c=async()=>{let p=!s;await T(()=>L.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},u=p=>async()=>{await T(()=>L.heatingManual(t,!0,p,!i(p)),`Relay ${p} ${i(p)?"off":"on"}`)&&setTimeout(o,800)},l=p=>p===8&&i(9)||p===9&&i(8);return d`
    <${b} title="Manual mode"
      aside=${d`<${$} kind=${s?"danger":""} disabled=${!n} onClick=${c}>${s?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${a&&d`<p class="error">The controller does not answer: ${a.message}</p>`}
      ${s&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${bn.map(([p,r])=>d`<button key=${p} class=${i(p)?"primary":""} disabled=${!s||l(p)} onClick=${u(p)}>
            <span>${r}</span><small>relay ${p}: ${i(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Tn({d:e,reload:t}){let n=e.name||e.key,[a,o]=v({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[s,i]=v(!1),c=l=>p=>o({...a,[l]:p.target.value}),u=async()=>{let l={};if(a.custom_string!==e.name&&(l.custom_string=a.custom_string),+a.hwrev!==e.hwrev&&(l.hwrev=+a.hwrev),a.relais_mode&&(l.relais_mode=a.relais_mode),a.extension_mode&&(l.extension_mode=a.extension_mode),Object.keys(l).length===0)return U("Nothing changed");await T(()=>L.update(n,l),"Settings sent")&&setTimeout(t,1500)};return d`
    <${b} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${a.custom_string} onInput=${c("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${a.hwrev} onInput=${c("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${a.relais_mode} onChange=${c("relais_mode")}>
          <option value="">(unchanged)</option>${mn.map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${a.extension_mode} onChange=${c("extension_mode")}>
          <option value="">(unchanged)</option>${$n.map(l=>d`<option>${l}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await T(()=>L.silence(n,!s),s?"Device may talk again":"Device silenced"),i(!s)}}>${s?"End silence":"Silence"}<//>
        <${$} onClick=${()=>T(()=>L.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Dt(){let{data:e,error:t,reload:n}=M(L.list,5e3),[a,o]=v(""),s=(l,p)=>async()=>{await T(l,p),setTimeout(n,1500)},i=async()=>{let l=a.trim();l&&await T(()=>L.action(l,"ping"),`Ping sent to ${l}`)},c=async()=>{confirm("Restart every device on the bus?")&&await s(()=>Y.action("restart"),"Restart sent to every device")()},u=s(async()=>{await Y.action("ping"),await Y.action("refresh")},"Scanning: every device was asked to announce itself");return d`
    <${b} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${s(()=>Y.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${s(()=>Y.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${s(()=>Y.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${c}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${a} onInput=${l=>o(l.target.value)} onKeyDown=${l=>l.key==="Enter"&&i()} />
        <${$} onClick=${i}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(l=>d`<tr key=${l.key}>
                    <td><${te} href=${"/devices/"+encodeURIComponent(l.name||l.key)}>${l.name||l.key}<//></td>
                    <td><code>${We(l.device_id)}</code></td>
                    <td>${l.type_name} <code>${We(l.device_type)}</code></td>
                    <td>${l.version}</td>
                    <td>${ee(l.last_seen_minutes_ago)}</td>
                    <td>${l.uptime?ee(Math.floor(l.uptime/60)):""}</td>
                    <td>${l.error?d`<span class="badge bad">error ${l.error}</span>`:l.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${P} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function Ut(){let e=M(He.get,5e3);return d`<${Cn} ...${e} /><${xn} ...${e} /><${En} /><${Rn} /><${Nn} />`}function Cn({data:e,error:t}){return d`
    <${b} title="Gateway" aside=${d`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await T(He.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${It(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${P} error=${t} />`}
    <//>`}function xn({data:e,error:t}){if(!e)return d`<${b} title="Network"><${P} error=${t} /><//>`;let n=e.network;if(!n)return d`<${b} title="Network"><p>No Ethernet.</p><//>`;let a=s=>s.map(i=>d`<div>${i.address} <span class="muted">(${i.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${b} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?a(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?a(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function En(){let{data:e,error:t,reload:n}=M(De.get),[a,o]=v({});if(!e)return d`<${P} error=${t} />`;let s=u=>u in a?a[u]:e[u],i=(u,l)=>p=>o({...a,[u]:l?+p.target.value:p.target.value}),c=async()=>{let u={...a};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return U("Nothing changed");let l=await T(()=>De.update(u),"Saved");l&&(l.restart_required&&U("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${b} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${s("hostname")} onInput=${i("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${s("can_bitrate")} onChange=${i("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${s("update_delay_ms")} onInput=${i("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${s("web_username")} onInput=${i("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${a.web_password||""} onInput=${i("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}var Fn=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function Rn(){let{data:e,error:t,reload:n}=M(Ue.get),[a,o]=v({});if(!e)return d`<${b} title="Location and time"><${P} error=${t} /><//>`;let s=p=>p in a?a[p]:e[p]??"",i=p=>r=>o({...a,[p]:r.target.value}),c=async()=>{let p={};if(("latitude"in a||"longitude"in a)&&(p.latitude=parseFloat(s("latitude")),p.longitude=parseFloat(s("longitude")),Number.isNaN(p.latitude)||Number.isNaN(p.longitude)))return U("Latitude and longitude are numbers");if("timezone"in a&&(p.timezone=a.timezone.trim()),Object.keys(p).length===0)return U("Nothing changed");await T(()=>Ue.update(p),"Saved")&&(o({}),n())},u=e.utc_offset_minutes,l=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return d`
    <${b} title="Location and time">
      <p class="muted">For switching by local time and by the sun.</p>
      <div class="row">
        <${C} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${s("latitude")} onInput=${i("latitude")} /><//>
        <${C} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${s("longitude")} onInput=${i("longitude")} /><//>
        <${C} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${s("timezone")} onInput=${i("timezone")} /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${l})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?Fn.map(([p,r])=>d`<div><dt>${r}</dt><dd>${e.sun[p]||d`<span class="muted">not today</span>`}</dd></div>`):d`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function Nn(){return d`
    <${b} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${we} target="gateway" label="Install and restart" />
    <//>`}var In=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],An={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Ln={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},z=async(e,t)=>await T(e,t)!==void 0,Ke=e=>e?new Date(e).toLocaleString():"\u2014";function Ge({label:e,accept:t,send:n,success:a,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async i=>{let c=i.target.files[0];if(i.target.value="",!c)return;let u=await c.text();await z(()=>n(u),a)&&o&&o()}} hidden /></label>`}function Ot(){let{data:e,error:t,reload:n}=M(q.get,1e4);return e?d`
    <${Mn} d=${e} />
    <${Pn} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${Hn} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${Dn} reload=${n} />`}
    ${e.mode==="est"&&d`<${Un} d=${e} reload=${n} />`}
    <${On} d=${e} reload=${n} />
    <${qn} d=${e} reload=${n} />`:d`<${P} error=${t} />`}function ze({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Ke(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Ke(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function Mn({d:e}){let t=e.certificate,[n,a]=t?An[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${b} title="Certificate" aside=${d`<span class=${"badge "+a}>${n}</span>`}>
      ${t?d`<${ze} c=${t} />
            <p class="muted">Made: ${Ln[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&d`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Pn({d:e,reload:t}){let[n,a]=v(e.fqdn),[o,s]=v(e.mode),i=async()=>{let c={};if(n!==e.fqdn&&(c.fqdn=n.trim()),o!==e.mode&&(c.mode=o),Object.keys(c).length===0)return U("Nothing changed");await z(()=>q.update(c),"Saved")&&t()};return d`
    <${b} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${c=>a(c.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${In.map(([c,u,l])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${c} checked=${o===c} onChange=${()=>s(c)} />
          <span><strong>${u}</strong><small class="muted">${l}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${$} kind="primary" onClick=${i}>Save<//></div>
    <//>`}function Hn({d:e,reload:t}){let[n,a]=v(e.validity_years);return d`
    <${b} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${s=>a(+s.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await z(()=>q.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function Dn({reload:e}){return d`
    <${b} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${q.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Ge} label="Upload certificate" send=${q.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function Un({d:e,reload:t}){let n=e.est,[a,o]=v(n.url),[s,i]=v(n.auto_renew),c=async()=>{await z(()=>q.update({est_url:a.trim(),est_auto_renew:s}),"Saved")&&t()},u=async()=>{await z(q.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${b} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${a} onInput=${l=>o(l.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${s} onChange=${l=>i(l.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Ke(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${ze} c=${n.identity} />`}
      <div class="buttons">
        <${Ge} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${q.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${$} kind="danger" onClick=${async()=>await z(q.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${c}>Save<//>
        <${$} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function On({d:e,reload:t}){let n=e.trust_anchor,a=async o=>{await z(()=>q.update({built_in_roots:o}),o?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return d`
    <${b} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${o=>a(o.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?d`<${ze} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${Ge} label=${n?"Replace":"Upload"} send=${q.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&d`<${$} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await z(q.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function qn({d:e,reload:t}){let[n,a]=v(e.ntp_server),o=async()=>{await z(()=>q.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${b} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} placeholder="automatic" onInput=${s=>a(s.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&d`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?d` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${$} onClick=${o}>Save<//></div>
    <//>`}var Wn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Wt(){let{data:e,error:t,reload:n}=M(se.all,5e3);return e?d`
    <${qt} slot="primary" b=${e.primary} reload=${n} />
    <${qt} slot="secondary" b=${e.secondary} reload=${n} />`:d`<${P} error=${t} />`}var jn={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function qt({slot:e,b:t,reload:n}){let[a,o]=v({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[s,i]=v(null),c=a.uri.startsWith("mqtts://"),u=r=>_=>o({...a,[r]:_.target.type==="checkbox"?_.target.checked:_.target.value}),l=async()=>{let r={uri:a.uri,user:a.user,enabled:a.enabled,tls_insecure:a.tls_insecure};a.password&&(r.password=a.password),await T(()=>se.update(e,r),`${e} broker saved, reconnecting`)&&(o({...a,password:""}),setTimeout(n,2500))},p=async()=>{let r=await T(()=>se.certificate(e));r&&i(r)};return d`
    <${b}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${Wn[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${a.uri} onInput=${u("uri")} /><//>
        <${C} label="User"><input value=${a.user} onInput=${u("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${a.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${c&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${jn[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${a.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await T(()=>se.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${$} kind="danger" onClick=${async()=>{await T(()=>se.forget(e),"Certificate forgotten"),i(null),n()}}>Forget<//>`}
          </div>
          ${s&&d`<p>${s.pinned?d`SHA-256 <code>${s.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var Bn=[{path:"/",title:"Devices",page:Dt},{path:"/devices/:device",title:"Device",page:Ht},{path:"/sensors",title:"Sensors",page:Mt},{path:"/mqtt",title:"MQTT",page:Wt},{path:"/gateway",title:"Gateway",page:Ut},{path:"/https",title:"HTTPS",page:Ot}],Vn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function Kn(){let e=At(),t=Lt(Bn,e),n=t?t.route.page:null,a=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${Vn.map(([o,s])=>d`<${te} href=${o} class=${a(o)?"active":""}>${s}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${te} href="/">Devices<//></p>`}
    </main>
    <${Nt} />`}ut(d`<${Kn} />`,document.getElementById("app"));
