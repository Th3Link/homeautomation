var Tt=Object.create;var He=Object.defineProperty;var Et=Object.getOwnPropertyDescriptor;var Ft=Object.getOwnPropertyNames;var Rt=Object.getPrototypeOf,Ht=Object.prototype.hasOwnProperty;var Lt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var It=(e,t,n,r)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Ft(t))!Ht.call(e,o)&&o!==n&&He(e,o,{get:()=>t[o],enumerable:!(r=Et(t,o))||r.enumerable});return e};var At=(e,t,n)=>(n=e!=null?Tt(Rt(e)):{},It(t||!e||!e.__esModule?He(n,"default",{value:e,enumerable:!0}):n,e));var lt=Lt(Ce=>{var ct;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Ce=="object"?e(Ce):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(ct={}):e(ct={})})(function(e){e.version="1.2.2";function t(){for(var u=0,H=new Array(256),d=0;d!=256;++d)u=d,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,u=u&1?-306674912^u>>>1:u>>>1,H[d]=u;return typeof Int32Array<"u"?new Int32Array(H):H}var n=t();function r(u){var H=0,d=0,$=0,v=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for($=0;$!=256;++$)v[$]=u[$];for($=0;$!=256;++$)for(d=u[$],H=256+$;H<4096;H+=256)d=v[H]=d>>>8^u[d&255];var S=[];for($=1;$!=16;++$)S[$-1]=typeof Int32Array<"u"?v.subarray($*256,$*256+256):v.slice($*256,$*256+256);return S}var o=r(n),a=o[0],i=o[1],l=o[2],c=o[3],_=o[4],f=o[5],s=o[6],m=o[7],h=o[8],g=o[9],I=o[10],E=o[11],b=o[12],w=o[13],q=o[14];function P(u,H){for(var d=H^-1,$=0,v=u.length;$<v;)d=d>>>8^n[(d^u.charCodeAt($++))&255];return~d}function V(u,H){for(var d=H^-1,$=u.length-15,v=0;v<$;)d=q[u[v++]^d&255]^w[u[v++]^d>>8&255]^b[u[v++]^d>>16&255]^E[u[v++]^d>>>24]^I[u[v++]]^g[u[v++]]^h[u[v++]]^m[u[v++]]^s[u[v++]]^f[u[v++]]^_[u[v++]]^c[u[v++]]^l[u[v++]]^i[u[v++]]^a[u[v++]]^n[u[v++]];for($+=15;v<$;)d=d>>>8^n[(d^u[v++])&255];return~d}function W(u,H){for(var d=H^-1,$=0,v=u.length,S=0,he=0;$<v;)S=u.charCodeAt($++),S<128?d=d>>>8^n[(d^S)&255]:S<2048?(d=d>>>8^n[(d^(192|S>>6&31))&255],d=d>>>8^n[(d^(128|S&63))&255]):S>=55296&&S<57344?(S=(S&1023)+64,he=u.charCodeAt($++)&1023,d=d>>>8^n[(d^(240|S>>8&7))&255],d=d>>>8^n[(d^(128|S>>2&63))&255],d=d>>>8^n[(d^(128|he>>6&15|(S&3)<<4))&255],d=d>>>8^n[(d^(128|he&63))&255]):(d=d>>>8^n[(d^(224|S>>12&15))&255],d=d>>>8^n[(d^(128|S>>6&63))&255],d=d>>>8^n[(d^(128|S&63))&255]);return~d}e.table=n,e.bstr=P,e.buf=V,e.str=W})});var _e,x,Ue,Pt,j,Le,Ne,De,Me,ge,ve,$e,Ut,z={},Oe=[],Nt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,ue=Array.isArray;function N(e,t){for(var n in t)e[n]=t[n];return e}function ye(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function Q(e,t,n){var r,o,a,i={};for(a in t)a=="key"?r=t[a]:a=="ref"?o=t[a]:i[a]=t[a];if(arguments.length>2&&(i.children=arguments.length>3?_e.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(a in e.defaultProps)i[a]===void 0&&(i[a]=e.defaultProps[a]);return se(e,i,r,o,null)}function se(e,t,n,r,o){var a={type:e,props:t,key:n,ref:r,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++Ue,__i:-1,__u:0};return o==null&&x.vnode!=null&&x.vnode(a),a}function pe(e){return e.children}function ce(e,t){this.props=e,this.context=t}function B(e,t){if(t==null)return e.__?B(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?B(e):null}function qe(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return qe(e)}}function Ie(e){(!e.__d&&(e.__d=!0)&&j.push(e)&&!le.__r++||Le!=x.debounceRendering)&&((Le=x.debounceRendering)||Ne)(le)}function le(){for(var e,t,n,r,o,a,i,l=1;j.length;)j.length>l&&j.sort(De),e=j.shift(),l=j.length,e.__d&&(n=void 0,o=(r=(t=e).__v).__e,a=[],i=[],t.__P&&((n=N({},r)).__v=r.__v+1,x.vnode&&x.vnode(n),be(t.__P,n,r,t.__n,t.__P.namespaceURI,32&r.__u?[o]:null,a,o??B(r),!!(32&r.__u),i),n.__v=r.__v,n.__.__k[n.__i]=n,Ge(a,n,i),n.__e!=o&&qe(n)));le.__r=0}function We(e,t,n,r,o,a,i,l,c,_,f){var s,m,h,g,I,E,b=r&&r.__k||Oe,w=t.length;for(c=Dt(n,t,b,c,w),s=0;s<w;s++)(h=n.__k[s])!=null&&(m=h.__i==-1?z:b[h.__i]||z,h.__i=s,E=be(e,h,m,o,a,i,l,c,_,f),g=h.__e,h.ref&&m.ref!=h.ref&&(m.ref&&we(m.ref,null,h),f.push(h.ref,h.__c||g,h)),I==null&&g!=null&&(I=g),4&h.__u||m.__k===h.__k?c=je(h,c,e):typeof h.type=="function"&&E!==void 0?c=E:g&&(c=g.nextSibling),h.__u&=-7);return n.__e=I,c}function Dt(e,t,n,r,o){var a,i,l,c,_,f=n.length,s=f,m=0;for(e.__k=new Array(o),a=0;a<o;a++)(i=t[a])!=null&&typeof i!="boolean"&&typeof i!="function"?(c=a+m,(i=e.__k[a]=typeof i=="string"||typeof i=="number"||typeof i=="bigint"||i.constructor==String?se(null,i,null,null,null):ue(i)?se(pe,{children:i},null,null,null):i.constructor==null&&i.__b>0?se(i.type,i.props,i.key,i.ref?i.ref:null,i.__v):i).__=e,i.__b=e.__b+1,l=null,(_=i.__i=Mt(i,n,c,s))!=-1&&(s--,(l=n[_])&&(l.__u|=2)),l==null||l.__v==null?(_==-1&&(o>f?m--:o<f&&m++),typeof i.type!="function"&&(i.__u|=4)):_!=c&&(_==c-1?m--:_==c+1?m++:(_>c?m--:m++,i.__u|=4))):e.__k[a]=null;if(s)for(a=0;a<f;a++)(l=n[a])!=null&&(2&l.__u)==0&&(l.__e==r&&(r=B(l)),Be(l,l));return r}function je(e,t,n){var r,o;if(typeof e.type=="function"){for(r=e.__k,o=0;r&&o<r.length;o++)r[o]&&(r[o].__=e,t=je(r[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=B(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function Mt(e,t,n,r){var o,a,i=e.key,l=e.type,c=t[n];if(c===null&&e.key==null||c&&i==c.key&&l==c.type&&(2&c.__u)==0)return n;if(r>(c!=null&&(2&c.__u)==0?1:0))for(o=n-1,a=n+1;o>=0||a<t.length;){if(o>=0){if((c=t[o])&&(2&c.__u)==0&&i==c.key&&l==c.type)return o;o--}if(a<t.length){if((c=t[a])&&(2&c.__u)==0&&i==c.key&&l==c.type)return a;a++}}return-1}function Ae(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Nt.test(t)?n:n+"px"}function ie(e,t,n,r,o){var a,i;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof r=="string"&&(e.style.cssText=r=""),r)for(t in r)n&&t in n||Ae(e.style,t,"");if(n)for(t in n)r&&n[t]==r[t]||Ae(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")a=t!=(t=t.replace(Me,"$1")),i=t.toLowerCase(),t=i in e||t=="onFocusOut"||t=="onFocusIn"?i.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+a]=n,n?r?n.u=r.u:(n.u=ge,e.addEventListener(t,a?$e:ve,a)):e.removeEventListener(t,a?$e:ve,a);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Pe(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=ge++;else if(t.t<n.u)return;return n(x.event?x.event(t):t)}}}function be(e,t,n,r,o,a,i,l,c,_){var f,s,m,h,g,I,E,b,w,q,P,V,W,u,H,d,$,v=t.type;if(t.constructor!=null)return null;128&n.__u&&(c=!!(32&n.__u),a=[l=t.__e=n.__e]),(f=x.__b)&&f(t);e:if(typeof v=="function")try{if(b=t.props,w="prototype"in v&&v.prototype.render,q=(f=v.contextType)&&r[f.__c],P=f?q?q.props.value:f.__:r,n.__c?E=(s=t.__c=n.__c).__=s.__E:(w?t.__c=s=new v(b,P):(t.__c=s=new ce(b,P),s.constructor=v,s.render=qt),q&&q.sub(s),s.props=b,s.state||(s.state={}),s.context=P,s.__n=r,m=s.__d=!0,s.__h=[],s._sb=[]),w&&s.__s==null&&(s.__s=s.state),w&&v.getDerivedStateFromProps!=null&&(s.__s==s.state&&(s.__s=N({},s.__s)),N(s.__s,v.getDerivedStateFromProps(b,s.__s))),h=s.props,g=s.state,s.__v=t,m)w&&v.getDerivedStateFromProps==null&&s.componentWillMount!=null&&s.componentWillMount(),w&&s.componentDidMount!=null&&s.__h.push(s.componentDidMount);else{if(w&&v.getDerivedStateFromProps==null&&b!==h&&s.componentWillReceiveProps!=null&&s.componentWillReceiveProps(b,P),!s.__e&&s.shouldComponentUpdate!=null&&s.shouldComponentUpdate(b,s.__s,P)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(s.props=b,s.state=s.__s,s.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(S){S&&(S.__=t)}),V=0;V<s._sb.length;V++)s.__h.push(s._sb[V]);s._sb=[],s.__h.length&&i.push(s);break e}s.componentWillUpdate!=null&&s.componentWillUpdate(b,s.__s,P),w&&s.componentDidUpdate!=null&&s.__h.push(function(){s.componentDidUpdate(h,g,I)})}if(s.context=P,s.props=b,s.__P=e,s.__e=!1,W=x.__r,u=0,w){for(s.state=s.__s,s.__d=!1,W&&W(t),f=s.render(s.props,s.state,s.context),H=0;H<s._sb.length;H++)s.__h.push(s._sb[H]);s._sb=[]}else do s.__d=!1,W&&W(t),f=s.render(s.props,s.state,s.context),s.state=s.__s;while(s.__d&&++u<25);s.state=s.__s,s.getChildContext!=null&&(r=N(N({},r),s.getChildContext())),w&&!m&&s.getSnapshotBeforeUpdate!=null&&(I=s.getSnapshotBeforeUpdate(h,g)),d=f,f!=null&&f.type===pe&&f.key==null&&(d=Ve(f.props.children)),l=We(e,ue(d)?d:[d],t,n,r,o,a,i,l,c,_),s.base=t.__e,t.__u&=-161,s.__h.length&&i.push(s),E&&(s.__E=s.__=null)}catch(S){if(t.__v=null,c||a!=null)if(S.then){for(t.__u|=c?160:128;l&&l.nodeType==8&&l.nextSibling;)l=l.nextSibling;a[a.indexOf(l)]=null,t.__e=l}else for($=a.length;$--;)ye(a[$]);else t.__e=n.__e,t.__k=n.__k;x.__e(S,t,n)}else a==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):l=t.__e=Ot(n.__e,t,n,r,o,a,i,c,_);return(f=x.diffed)&&f(t),128&t.__u?void 0:l}function Ge(e,t,n){for(var r=0;r<n.length;r++)we(n[r],n[++r],n[++r]);x.__c&&x.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(a){a.call(o)})}catch(a){x.__e(a,o.__v)}})}function Ve(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:ue(e)?e.map(Ve):N({},e)}function Ot(e,t,n,r,o,a,i,l,c){var _,f,s,m,h,g,I,E=n.props,b=t.props,w=t.type;if(w=="svg"?o="http://www.w3.org/2000/svg":w=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),a!=null){for(_=0;_<a.length;_++)if((h=a[_])&&"setAttribute"in h==!!w&&(w?h.localName==w:h.nodeType==3)){e=h,a[_]=null;break}}if(e==null){if(w==null)return document.createTextNode(b);e=document.createElementNS(o,w,b.is&&b),l&&(x.__m&&x.__m(t,a),l=!1),a=null}if(w==null)E===b||l&&e.data==b||(e.data=b);else{if(a=a&&_e.call(e.childNodes),E=n.props||z,!l&&a!=null)for(E={},_=0;_<e.attributes.length;_++)E[(h=e.attributes[_]).name]=h.value;for(_ in E)if(h=E[_],_!="children"){if(_=="dangerouslySetInnerHTML")s=h;else if(!(_ in b)){if(_=="value"&&"defaultValue"in b||_=="checked"&&"defaultChecked"in b)continue;ie(e,_,null,h,o)}}for(_ in b)h=b[_],_=="children"?m=h:_=="dangerouslySetInnerHTML"?f=h:_=="value"?g=h:_=="checked"?I=h:l&&typeof h!="function"||E[_]===h||ie(e,_,h,E[_],o);if(f)l||s&&(f.__html==s.__html||f.__html==e.innerHTML)||(e.innerHTML=f.__html),t.__k=[];else if(s&&(e.innerHTML=""),We(t.type=="template"?e.content:e,ue(m)?m:[m],t,n,r,w=="foreignObject"?"http://www.w3.org/1999/xhtml":o,a,i,a?a[0]:n.__k&&B(n,0),l,c),a!=null)for(_=a.length;_--;)ye(a[_]);l||(_="value",w=="progress"&&g==null?e.removeAttribute("value"):g!=null&&(g!==e[_]||w=="progress"&&!g||w=="option"&&g!=E[_])&&ie(e,_,g,E[_],o),_="checked",I!=null&&I!=e[_]&&ie(e,_,I,E[_],o))}return e}function we(e,t,n){try{if(typeof e=="function"){var r=typeof e.__u=="function";r&&e.__u(),r&&t==null||(e.__u=e(t))}else e.current=t}catch(o){x.__e(o,n)}}function Be(e,t,n){var r,o;if(x.unmount&&x.unmount(e),(r=e.ref)&&(r.current&&r.current!=e.__e||we(r,null,t)),(r=e.__c)!=null){if(r.componentWillUnmount)try{r.componentWillUnmount()}catch(a){x.__e(a,t)}r.base=r.__P=null}if(r=e.__k)for(o=0;o<r.length;o++)r[o]&&Be(r[o],t,n||typeof e.type!="function");n||ye(e.__e),e.__c=e.__=e.__e=void 0}function qt(e,t,n){return this.constructor(e,n)}function Ke(e,t,n){var r,o,a,i;t==document&&(t=document.documentElement),x.__&&x.__(e,t),o=(r=typeof n=="function")?null:n&&n.__k||t.__k,a=[],i=[],be(t,e=(!r&&n||t).__k=Q(pe,null,[e]),o||z,z,t.namespaceURI,!r&&n?[n]:o?null:t.firstChild?_e.call(t.childNodes):null,a,!r&&n?n:o?o.__e:t.firstChild,r,i),Ge(a,e,i)}_e=Oe.slice,x={__e:function(e,t,n,r){for(var o,a,i;t=t.__;)if((o=t.__c)&&!o.__)try{if((a=o.constructor)&&a.getDerivedStateFromError!=null&&(o.setState(a.getDerivedStateFromError(e)),i=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,r||{}),i=o.__d),i)return o.__E=o}catch(l){e=l}throw e}},Ue=0,Pt=function(e){return e!=null&&e.constructor==null},ce.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=N({},this.state),typeof e=="function"&&(e=e(N({},n),this.props)),e&&N(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Ie(this))},ce.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Ie(this))},ce.prototype.render=pe,j=[],Ne=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,De=function(e,t){return e.__v.__b-t.__v.__b},le.__r=0,Me=/(PointerCapture)$|Capture$/i,ge=0,ve=Pe(!1),$e=Pe(!0),Ut=0;var X,T,ke,Je,Y=0,nt=[],F=x,ze=F.__b,Qe=F.__r,Xe=F.diffed,Ye=F.__c,Ze=F.unmount,et=F.__;function Se(e,t){F.__h&&F.__h(T,e,Y||t),Y=0;var n=T.__H||(T.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function k(e){return Y=1,Wt(st,e)}function Wt(e,t,n){var r=Se(X++,2);if(r.t=e,!r.__c&&(r.__=[n?n(t):st(void 0,t),function(l){var c=r.__N?r.__N[0]:r.__[0],_=r.t(c,l);c!==_&&(r.__N=[_,r.__[1]],r.__c.setState({}))}],r.__c=T,!T.__f)){var o=function(l,c,_){if(!r.__c.__H)return!0;var f=r.__c.__H.__.filter(function(m){return!!m.__c});if(f.every(function(m){return!m.__N}))return!a||a.call(this,l,c,_);var s=r.__c.props!==l;return f.forEach(function(m){if(m.__N){var h=m.__[0];m.__=m.__N,m.__N=void 0,h!==m.__[0]&&(s=!0)}}),a&&a.call(this,l,c,_)||s};T.__f=!0;var a=T.shouldComponentUpdate,i=T.componentWillUpdate;T.componentWillUpdate=function(l,c,_){if(this.__e){var f=a;a=void 0,o(l,c,_),a=f}i&&i.call(this,l,c,_)},T.shouldComponentUpdate=o}return r.__N||r.__}function Z(e,t){var n=Se(X++,3);!F.__s&&it(n.__H,t)&&(n.__=e,n.u=t,T.__H.__h.push(n))}function rt(e){return Y=5,ot(function(){return{current:e}},[])}function ot(e,t){var n=Se(X++,7);return it(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function at(e,t){return Y=8,ot(function(){return e},t)}function jt(){for(var e;e=nt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(de),e.__H.__h.forEach(xe),e.__H.__h=[]}catch(t){e.__H.__h=[],F.__e(t,e.__v)}}F.__b=function(e){T=null,ze&&ze(e)},F.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),et&&et(e,t)},F.__r=function(e){Qe&&Qe(e),X=0;var t=(T=e.__c).__H;t&&(ke===T?(t.__h=[],T.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(de),t.__h.forEach(xe),t.__h=[],X=0)),ke=T},F.diffed=function(e){Xe&&Xe(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(nt.push(t)!==1&&Je===F.requestAnimationFrame||((Je=F.requestAnimationFrame)||Gt)(jt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),ke=T=null},F.__c=function(e,t){t.some(function(n){try{n.__h.forEach(de),n.__h=n.__h.filter(function(r){return!r.__||xe(r)})}catch(r){t.some(function(o){o.__h&&(o.__h=[])}),t=[],F.__e(r,n.__v)}}),Ye&&Ye(e,t)},F.unmount=function(e){Ze&&Ze(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(r){try{de(r)}catch(o){t=o}}),n.__H=void 0,t&&F.__e(t,n.__v))};var tt=typeof requestAnimationFrame=="function";function Gt(e){var t,n=function(){clearTimeout(r),tt&&cancelAnimationFrame(t),setTimeout(e)},r=setTimeout(n,35);tt&&(t=requestAnimationFrame(n))}function de(e){var t=T,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),T=t}function xe(e){var t=T;e.__c=e.__(),T=t}function it(e,t){return!e||e.length!==t.length||t.some(function(n,r){return n!==e[r]})}function st(e,t){return typeof t=="function"?t(e):t}var _t=At(lt()),ut="/api/v1",K=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},Vt=e=>new Promise(t=>setTimeout(t,e));async function ne(e,t,n){for(let r=1;;r++){let o;try{o=await fetch(ut+t,{method:e,headers:n===void 0?{}:{"Content-Type":"application/json"},body:n===void 0?void 0:JSON.stringify(n)})}catch{if(r>=4)throw new K(0,{message:"gateway unreachable"});await Vt(250*r);continue}let a=await o.text(),i=null;try{i=a?JSON.parse(a):null}catch{i={message:a}}if(!o.ok)throw new K(o.status,i);return i}}var G=e=>ne("GET",e),te=(e,t)=>ne("POST",e,t),ee=(e,t)=>ne("PUT",e,t),Te=(e,t)=>ne("PATCH",e,t),Bt=e=>ne("DELETE",e),O=encodeURIComponent,Ee={get:()=>G("/system"),restart:()=>te("/system/restart")},Fe={get:()=>G("/config"),update:e=>Te("/config",e)},J={all:()=>G("/mqtt"),update:(e,t)=>Te(`/mqtt/${e}`,t),trust:e=>te(`/mqtt/${e}/trust`),certificate:e=>G(`/mqtt/${e}/certificate`),forget:e=>Bt(`/mqtt/${e}/certificate`)},A={async list(){let e=[];for(;;){let t=await G(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>G(`/devices/${O(e)}`),update:(e,t)=>Te(`/devices/${O(e)}`,t),action:(e,t)=>te(`/devices/${O(e)}/${t}`),silence:(e,t)=>ee(`/devices/${O(e)}/silence`,{on:t}),relay:(e,t,n,r)=>ee(`/devices/${O(e)}/relays/${t}`,{state:n,duration_ms:r}),rollershutter:(e,t,n,r)=>ee(`/devices/${O(e)}/rollershutters/${t}`,{state:n,duration_ms:r}),lamps:(e,t,n,r)=>ee(`/devices/${O(e)}/lamps/${t}`,{value:n,bitmask:r}),heating:(e,t,n)=>ee(`/devices/${O(e)}/heating/${t}`,n)},pt={action:e=>te(`/bus/${e}`),typeAction:(e,t)=>te(`/device-types/${e}/${t}`)},dt={job:()=>G("/firmware/job"),upload(e,t,n){let r=_t.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((a,i)=>{let l=new XMLHttpRequest;l.open("PUT",`${ut}${o}?crc32=${r}`),l.setRequestHeader("Content-Type","application/octet-stream"),l.upload.onprogress=c=>c.lengthComputable&&n&&n(c.loaded/c.total),l.onload=()=>{let c=null;try{c=JSON.parse(l.responseText)}catch{}l.status>=200&&l.status<300?a(c):i(new K(l.status,c))},l.onerror=()=>i(new K(0,{message:"upload failed"})),l.send(t)})}};var mt=function(e,t,n,r){var o;t[0]=0;for(var a=1;a<t.length;a++){var i=t[a++],l=t[a]?(t[0]|=i?1:2,n[t[a++]]):t[++a];i===3?r[0]=l:i===4?r[1]=Object.assign(r[1]||{},l):i===5?(r[1]=r[1]||{})[t[++a]]=l:i===6?r[1][t[++a]]+=l+"":i?(o=e.apply(l,mt(e,l,n,["",null])),r.push(o),l[0]?t[0]|=2:(t[a-2]=0,t[a]=o)):r.push(l)}return r},ft=new Map;function ht(e){var t=ft.get(this);return t||(t=new Map,ft.set(this,t)),(t=mt(this,t.get(e)||(t.set(e,t=function(n){for(var r,o,a=1,i="",l="",c=[0],_=function(m){a===1&&(m||(i=i.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?c.push(0,m,i):a===3&&(m||i)?(c.push(3,m,i),a=2):a===2&&i==="..."&&m?c.push(4,m,0):a===2&&i&&!m?c.push(5,0,!0,i):a>=5&&((i||!m&&a===5)&&(c.push(a,0,i,o),a=6),m&&(c.push(a,m,0,o),a=6)),i=""},f=0;f<n.length;f++){f&&(a===1&&_(),_(f));for(var s=0;s<n[f].length;s++)r=n[f][s],a===1?r==="<"?(_(),c=[c],a=3):i+=r:a===4?i==="--"&&r===">"?(a=1,i=""):i=r+i[0]:l?r===l?l="":i+=r:r==='"'||r==="'"?l=r:r===">"?(_(),a=1):a&&(r==="="?(a=5,o=i,i=""):r==="/"&&(a<5||n[f][s+1]===">")?(_(),a===3&&(c=c[0]),a=c,(c=c[0]).push(2,0,a),a=0):r===" "||r==="	"||r===`
`||r==="\r"?(_(),a=2):i+=r),a===3&&i==="!--"&&(a=4,c=c[0])}return _(),c}(e)),t),arguments,[])).length>1?t:t[0]}var p=ht.bind(Q),Re=()=>{};function U(e,t="ok"){Re(e,t)}function vt(){let[e,t]=k([]);return Z(()=>{let n=0;return Re=(r,o)=>{let a={id:++n,message:r,kind:o};t(i=>[...i,a]),setTimeout(()=>t(i=>i.filter(l=>l!==a)),o==="error"?8e3:3e3)},()=>Re=()=>{}},[]),p`<div class="toasts">
    ${e.map(n=>p`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function R(e,t){try{let n=await e();return t&&U(t),n}catch(n){U(n.message,"error");return}}function D(e,t){let[n,r]=k({data:void 0,error:void 0}),o=rt(e);o.current=e;let a=at(async()=>{try{r({data:await o.current(),error:void 0})}catch(i){r(l=>({data:l.data,error:i}))}},[]);return Z(()=>{let i=!1,l,c=async()=>{await a(),t&&!i&&(l=setTimeout(c,t))};return c(),()=>{i=!0,clearTimeout(l)}},[t,a]),{...n,reload:a}}var L=({title:e,children:t,aside:n})=>p`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,M=({error:e})=>e?p`<p class="error">${e.message}</p>`:p`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>p`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&p`<small>${t}</small>`}
  </label>`,y=({children:e,kind:t,onClick:n,disabled:r})=>{let[o,a]=k(!1);return p`<button class=${t||""} disabled=${r||o} onClick=${async l=>{a(!0);try{await n(l)}finally{a(!1)}}}>${e}</button>`};function oe(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function $t(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),r=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${r} min`:`${r} min`}function fe({target:e,label:t,onDone:n}){let[r,o]=k(null),[a,i]=k(null);return p`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${c=>o(c.target.files[0]||null)} />
      <${y} onClick=${async()=>{if(r){i(0);try{let c=await r.arrayBuffer(),_=await dt.upload(e,c,i);U(_&&_.restarting?"Firmware installed, the gateway restarts\u2026":"Firmware sent"),n&&n(_)}catch(c){U(c.message,"error")}i(null)}}} disabled=${!r||a!==null}>${t||"Upload"}<//>
      ${a!==null&&p`<progress max="1" value=${a}></progress>`}
    </div>`}var Kt=[2,5,8,9],Jt=[7],zt=[3],Qt=[9],Xt=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],Yt=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function yt({device:e}){let{data:t,error:n,reload:r}=D(()=>A.get(e),5e3);return t?p`
    <${Zt} d=${t} reload=${r} />
    ${Kt.includes(t.device_type)&&p`<${gt} d=${t} kind="relay" />`}
    ${Jt.includes(t.device_type)&&p`<${gt} d=${t} kind="rollershutter" />`}
    ${zt.includes(t.device_type)&&p`<${en} d=${t} />`}
    ${Qt.includes(t.device_type)&&p`<${tn} d=${t} />`}
    <${nn} d=${t} reload=${r} />
    <${L} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus. It takes a few minutes.</p>
      <${fe} target=${"devices/"+encodeURIComponent(t.name||t.key)} label="Send to device" />
    <//>`:p`<${M} error=${n} />`}function Zt({d:e,reload:t}){let n=e.name||e.key,r=(o,a)=>async()=>{await R(()=>A.action(n,o),a),setTimeout(t,1500)};return p`
    <${L} title=${n}
      aside=${p`<span class="buttons">
        <${y} onClick=${r("ping","Ping sent")}>Ping<//>
        <${y} onClick=${r("refresh","Refresh requested")}>Refresh<//>
        <${y} kind="danger" onClick=${r("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${oe(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function gt({d:e,kind:t}){let n=e.name||e.key,[r,o]=k(1),[a,i]=k(0),l=t==="rollershutter",c=_=>()=>R(()=>A[t](n,r,_,Math.round(a*1e3)),`${l?"Rollershutter":"Relay"} ${r}: ${_}`);return p`
    <${L} title=${l?"Rollershutter":"Relays"}>
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${r} onInput=${_=>o(+_.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${a} onInput=${_=>i(+_.target.value)} /><//>
      </div>
      <div class="buttons">
        ${l?p`<${y} onClick=${c("up")}>Up<//><${y} onClick=${c("down")}>Down<//><${y} onClick=${c("off")}>Stop<//>`:p`<${y} kind="primary" onClick=${c("on")}>On<//><${y} onClick=${c("off")}>Off<//>`}
      </div>
    <//>`}function en({d:e}){let t=e.name||e.key,[n,r]=k(0),[o,a]=k(255),[i,l]=k(Array(24).fill(!1)),c=i.reduce((_,f,s)=>f?_|1<<23-s:_,0);return p`
    <${L} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${_=>r(+_.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${o} onInput=${_=>a(+_.target.value)} /><//>
      </div>
      <div class="lamps">
        ${i.map((_,f)=>p`<label key=${f} class=${"lamp"+(_?" on":"")}>
            <input type="checkbox" checked=${_} onChange=${()=>l(i.map((s,m)=>m===f?!s:s))} />${23-f}
          </label>`)}
      </div>
      <${y} kind="primary" onClick=${()=>R(()=>A.lamps(t,n,o,c),"Lamps set")}>Send<//>
    <//>`}function tn({d:e}){let t=e.name||e.key,[n,r]=k(45),[o,a]=k(!1),[i,l]=k(0),[c,_]=k(!1),[f,s]=k(0),[m,h]=k(55);return p`
    <${L} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${g=>r(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${g=>a(g.target.checked)} /> from the tank</label>
        <${y} onClick=${()=>R(()=>A.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${i} onInput=${g=>l(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${c} onChange=${g=>_(g.target.checked)} /> rod released</label>
        <${y} onClick=${()=>R(()=>A.heating(t,"energy",{power_w:i,rod_enabled:c}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${f} onInput=${g=>s(+g.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${m} onInput=${g=>h(+g.target.value)} /><//>
        <${y} kind="danger" onClick=${()=>R(()=>A.heating(t,"emergency",{stage:f,tank_c:m}),"Emergency sent")}>Send<//>
      </div>
    <//>`}function nn({d:e,reload:t}){let n=e.name||e.key,[r,o]=k({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[a,i]=k(!1),l=_=>f=>o({...r,[_]:f.target.value}),c=async()=>{let _={};if(r.custom_string!==e.name&&(_.custom_string=r.custom_string),+r.hwrev!==e.hwrev&&(_.hwrev=+r.hwrev),r.relais_mode&&(_.relais_mode=r.relais_mode),r.extension_mode&&(_.extension_mode=r.extension_mode),Object.keys(_).length===0)return U("Nothing changed");await R(()=>A.update(n,_),"Settings sent")&&setTimeout(t,1500)};return p`
    <${L} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${r.custom_string} onInput=${l("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${r.hwrev} onInput=${l("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${r.relais_mode} onChange=${l("relais_mode")}>
          <option value="">(unchanged)</option>${Xt.map(_=>p`<option>${_}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${r.extension_mode} onChange=${l("extension_mode")}>
          <option value="">(unchanged)</option>${Yt.map(_=>p`<option>${_}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${y} kind="primary" onClick=${c}>Save<//>
        <${y} onClick=${async()=>{await R(()=>A.silence(n,!a),a?"Device may talk again":"Device silenced"),i(!a)}}>${a?"End silence":"Silence"}<//>
        <${y} onClick=${()=>R(()=>A.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}var me=new Set;function rn(e){e!==location.pathname&&history.pushState(null,"",e),me.forEach(t=>t())}addEventListener("popstate",()=>me.forEach(e=>e()));function bt(){let[e,t]=k(location.pathname);return Z(()=>{let n=()=>t(location.pathname);return me.add(n),()=>me.delete(n)},[]),e}function wt(e,t){let n=t.split("/").filter(Boolean);for(let r of e){let o=r.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let a={};if(o.every((l,c)=>l.startsWith(":")?(a[l.slice(1)]=decodeURIComponent(n[c]),!0):l===n[c]))return{route:r,params:a}}return null}function ae({href:e,children:t,...n}){return Q("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),rn(e))},...n},t)}function kt(){let{data:e,error:t,reload:n}=D(A.list,5e3),r=o=>async()=>{await R(()=>pt.action(o),`${o} sent to every device`),setTimeout(n,1500)};return p`
    <${L}
      title="Devices"
      aside=${p`<span class="buttons">
        <${y} onClick=${r("ping")}>Ping all<//>
        <${y} onClick=${r("refresh")}>Refresh all<//>
      </span>`}
    >
      ${e?e.length===0?p`<p class="muted">No device seen on the bus yet.</p>`:p`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>Type</th><th>ID</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(o=>p`<tr key=${o.key}>
                    <td><${ae} href=${"/devices/"+encodeURIComponent(o.name||o.key)}>${o.name||o.key}<//></td>
                    <td>${o.type_name}</td>
                    <td>${o.device_id}</td>
                    <td>${o.version}</td>
                    <td>${oe(o.last_seen_minutes_ago)}</td>
                    <td>${o.uptime?oe(Math.floor(o.uptime/60)):""}</td>
                    <td>${o.error?p`<span class="badge bad">error ${o.error}</span>`:o.last_seen_minutes_ago>10?p`<span class="badge warn">silent</span>`:p`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:p`<${M} error=${t} />`}
      ${t&&e&&p`<p class="error">${t.message}</p>`}
    <//>`}function xt(){return p`<${on} /><${an} /><${sn} />`}function on(){let{data:e,error:t}=D(Ee.get,5e3);return p`
    <${L} title="Gateway" aside=${p`<${y} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await R(Ee.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?p`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${$t(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:p`<${M} error=${t} />`}
    <//>`}function an(){let{data:e,error:t,reload:n}=D(Fe.get),[r,o]=k({});if(!e)return p`<${M} error=${t} />`;let a=c=>c in r?r[c]:e[c],i=(c,_)=>f=>o({...r,[c]:_?+f.target.value:f.target.value}),l=async()=>{let c={...r};if(c.web_password||delete c.web_password,Object.keys(c).length===0)return U("Nothing changed");let _=await R(()=>Fe.update(c),"Saved");_&&(_.restart_required&&U("Restart the gateway to apply the hostname, bitrate or clock pin."),o({}),n())};return p`
    <${L} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${a("hostname")} onInput=${i("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${a("can_bitrate")} onChange=${i("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(c=>p`<option>${c}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${a("update_delay_ms")} onInput=${i("update_delay_ms",!0)} /><//>
        <${C} label="Ethernet clock pin" hint="GPIO 17 on rev. 1 boards, 16 on rev. 2"><select value=${a("eth_clock")} onChange=${i("eth_clock",!0)}>
          <option>16</option><option>17</option>
        </select><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${a("web_username")} onInput=${i("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${r.web_password||""} onInput=${i("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${y} kind="primary" onClick=${l}>Save<//></div>
    <//>`}function sn(){return p`
    <${L} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${fe} target="gateway" label="Install and restart" />
    <//>`}var cn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Ct(){let{data:e,error:t,reload:n}=D(J.all,5e3);return e?p`
    <${St} slot="primary" b=${e.primary} reload=${n} />
    <${St} slot="secondary" b=${e.secondary} reload=${n} />`:p`<${M} error=${t} />`}function St({slot:e,b:t,reload:n}){let[r,o]=k({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[a,i]=k(null),l=r.uri.startsWith("mqtts://"),c=s=>m=>o({...r,[s]:m.target.type==="checkbox"?m.target.checked:m.target.value}),_=async()=>{let s={uri:r.uri,user:r.user,enabled:r.enabled,tls_insecure:r.tls_insecure};r.password&&(s.password=r.password),await R(()=>J.update(e,s),`${e} broker saved, reconnecting`)&&(o({...r,password:""}),setTimeout(n,2500))},f=async()=>{let s=await R(()=>J.certificate(e));s&&i(s)};return p`
    <${L}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${p`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${cn[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${r.uri} onInput=${c("uri")} /><//>
        <${C} label="User"><input value=${r.user} onInput=${c("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${r.password} onInput=${c("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${r.enabled} onChange=${c("enabled")} /> Connect to this broker</label>
      ${l&&p`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${r.tls_insecure} onChange=${c("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${y} onClick=${async()=>{await R(()=>J.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),f()},4e3)}}>Trust the broker's certificate now<//>
            <${y} onClick=${f}>Show pinned certificate<//>
            ${t.certificate_pinned&&p`<${y} kind="danger" onClick=${async()=>{await R(()=>J.forget(e),"Certificate forgotten"),i(null),n()}}>Forget<//>`}
          </div>
          ${a&&p`<p>${a.pinned?p`SHA-256 <code>${a.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${y} kind="primary" onClick=${_}>Save<//></div>
    <//>`}var ln=[{path:"/",title:"Devices",page:kt},{path:"/devices/:device",title:"Device",page:yt},{path:"/mqtt",title:"MQTT",page:Ct},{path:"/gateway",title:"Gateway",page:xt}],_n=[["/","Devices"],["/mqtt","MQTT"],["/gateway","Gateway"]];function un(){let e=bt(),t=wt(ln,e),n=t?t.route.page:null,r=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return p`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${_n.map(([o,a])=>p`<${ae} href=${o} class=${r(o)?"active":""}>${a}<//>`)}</nav>
    </header>
    <main>
      ${n?p`<${n} key=${e} ...${t.params} />`:p`<p class="error">No such page. <${ae} href="/">Devices<//></p>`}
    </main>
    <${vt} />`}Ke(p`<${un} />`,document.getElementById("app"));
