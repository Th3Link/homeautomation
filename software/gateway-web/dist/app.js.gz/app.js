var Mt=Object.create;var qe=Object.defineProperty;var Ut=Object.getOwnPropertyDescriptor;var Nt=Object.getOwnPropertyNames;var Pt=Object.getPrototypeOf,Dt=Object.prototype.hasOwnProperty;var Ot=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var qt=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Nt(t))!Dt.call(e,a)&&a!==n&&qe(e,a,{get:()=>t[a],enumerable:!(o=Ut(t,a))||o.enumerable});return e};var Wt=(e,t,n)=>(n=e!=null?Mt(Pt(e)):{},qt(t||!e||!e.__esModule?qe(n,"default",{value:e,enumerable:!0}):n,e));var vt=Ot(Le=>{var $t;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Le=="object"?e(Le):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e($t={}):e($t={})})(function(e){e.version="1.2.2";function t(){for(var f=0,A=new Array(256),m=0;m!=256;++m)f=m,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,A[m]=f;return typeof Int32Array<"u"?new Int32Array(A):A}var n=t();function o(f){var A=0,m=0,k=0,v=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(k=0;k!=256;++k)v[k]=f[k];for(k=0;k!=256;++k)for(m=f[k],A=256+k;A<4096;A+=256)m=v[A]=m>>>8^f[m&255];var T=[];for(k=1;k!=16;++k)T[k-1]=typeof Int32Array<"u"?v.subarray(k*256,k*256+256):v.slice(k*256,k*256+256);return T}var a=o(n),r=a[0],s=a[1],c=a[2],u=a[3],l=a[4],_=a[5],i=a[6],p=a[7],h=a[8],g=a[9],R=a[10],x=a[11],w=a[12],y=a[13],M=a[14];function U(f,A){for(var m=A^-1,k=0,v=f.length;k<v;)m=m>>>8^n[(m^f.charCodeAt(k++))&255];return~m}function W(f,A){for(var m=A^-1,k=f.length-15,v=0;v<k;)m=M[f[v++]^m&255]^y[f[v++]^m>>8&255]^w[f[v++]^m>>16&255]^x[f[v++]^m>>>24]^R[f[v++]]^g[f[v++]]^h[f[v++]]^p[f[v++]]^i[f[v++]]^_[f[v++]]^l[f[v++]]^u[f[v++]]^c[f[v++]]^s[f[v++]]^r[f[v++]]^n[f[v++]];for(k+=15;v<k;)m=m>>>8^n[(m^f[v++])&255];return~m}function O(f,A){for(var m=A^-1,k=0,v=f.length,T=0,be=0;k<v;)T=f.charCodeAt(k++),T<128?m=m>>>8^n[(m^T)&255]:T<2048?(m=m>>>8^n[(m^(192|T>>6&31))&255],m=m>>>8^n[(m^(128|T&63))&255]):T>=55296&&T<57344?(T=(T&1023)+64,be=f.charCodeAt(k++)&1023,m=m>>>8^n[(m^(240|T>>8&7))&255],m=m>>>8^n[(m^(128|T>>2&63))&255],m=m>>>8^n[(m^(128|be>>6&15|(T&3)<<4))&255],m=m>>>8^n[(m^(128|be&63))&255]):(m=m>>>8^n[(m^(224|T>>12&15))&255],m=m>>>8^n[(m^(128|T>>6&63))&255],m=m>>>8^n[(m^(128|T&63))&255]);return~m}e.table=n,e.bstr=U,e.buf=W,e.str=O})});var pe,C,Ge,jt,G,We,Ke,Je,Qe,Se,ke,we,Vt,re={},ze=[],Bt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,fe=Array.isArray;function j(e,t){for(var n in t)e[n]=t[n];return e}function xe(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ae(e,t,n){var o,a,r,s={};for(r in t)r=="key"?o=t[r]:r=="ref"?a=t[r]:s[r]=t[r];if(arguments.length>2&&(s.children=arguments.length>3?pe.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)s[r]===void 0&&(s[r]=e.defaultProps[r]);return ue(e,s,o,a,null)}function ue(e,t,n,o,a){var r={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:a??++Ge,__i:-1,__u:0};return a==null&&C.vnode!=null&&C.vnode(r),r}function me(e){return e.children}function _e(e,t){this.props=e,this.context=t}function Z(e,t){if(t==null)return e.__?Z(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?Z(e):null}function Xe(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Xe(e)}}function je(e){(!e.__d&&(e.__d=!0)&&G.push(e)&&!de.__r++||We!=C.debounceRendering)&&((We=C.debounceRendering)||Ke)(de)}function de(){for(var e,t,n,o,a,r,s,c=1;G.length;)G.length>c&&G.sort(Je),e=G.shift(),c=G.length,e.__d&&(n=void 0,a=(o=(t=e).__v).__e,r=[],s=[],t.__P&&((n=j({},o)).__v=o.__v+1,C.vnode&&C.vnode(n),Ce(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[a]:null,r,a??Z(o),!!(32&o.__u),s),n.__v=o.__v,n.__.__k[n.__i]=n,et(r,n,s),n.__e!=a&&Xe(n)));de.__r=0}function Ye(e,t,n,o,a,r,s,c,u,l,_){var i,p,h,g,R,x,w=o&&o.__k||ze,y=t.length;for(u=Gt(n,t,w,u,y),i=0;i<y;i++)(h=n.__k[i])!=null&&(p=h.__i==-1?re:w[h.__i]||re,h.__i=i,x=Ce(e,h,p,a,r,s,c,u,l,_),g=h.__e,h.ref&&p.ref!=h.ref&&(p.ref&&Te(p.ref,null,h),_.push(h.ref,h.__c||g,h)),R==null&&g!=null&&(R=g),4&h.__u||p.__k===h.__k?u=Ze(h,u,e):typeof h.type=="function"&&x!==void 0?u=x:g&&(u=g.nextSibling),h.__u&=-7);return n.__e=R,u}function Gt(e,t,n,o,a){var r,s,c,u,l,_=n.length,i=_,p=0;for(e.__k=new Array(a),r=0;r<a;r++)(s=t[r])!=null&&typeof s!="boolean"&&typeof s!="function"?(u=r+p,(s=e.__k[r]=typeof s=="string"||typeof s=="number"||typeof s=="bigint"||s.constructor==String?ue(null,s,null,null,null):fe(s)?ue(me,{children:s},null,null,null):s.constructor==null&&s.__b>0?ue(s.type,s.props,s.key,s.ref?s.ref:null,s.__v):s).__=e,s.__b=e.__b+1,c=null,(l=s.__i=Kt(s,n,u,i))!=-1&&(i--,(c=n[l])&&(c.__u|=2)),c==null||c.__v==null?(l==-1&&(a>_?p--:a<_&&p++),typeof s.type!="function"&&(s.__u|=4)):l!=u&&(l==u-1?p--:l==u+1?p++:(l>u?p--:p++,s.__u|=4))):e.__k[r]=null;if(i)for(r=0;r<_;r++)(c=n[r])!=null&&(2&c.__u)==0&&(c.__e==o&&(o=Z(c)),nt(c,c));return o}function Ze(e,t,n){var o,a;if(typeof e.type=="function"){for(o=e.__k,a=0;o&&a<o.length;a++)o[a]&&(o[a].__=e,t=Ze(o[a],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=Z(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function Kt(e,t,n,o){var a,r,s=e.key,c=e.type,u=t[n];if(u===null&&e.key==null||u&&s==u.key&&c==u.type&&(2&u.__u)==0)return n;if(o>(u!=null&&(2&u.__u)==0?1:0))for(a=n-1,r=n+1;a>=0||r<t.length;){if(a>=0){if((u=t[a])&&(2&u.__u)==0&&s==u.key&&c==u.type)return a;a--}if(r<t.length){if((u=t[r])&&(2&u.__u)==0&&s==u.key&&c==u.type)return r;r++}}return-1}function Ve(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Bt.test(t)?n:n+"px"}function ce(e,t,n,o,a){var r,s;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||Ve(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||Ve(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Qe,"$1")),s=t.toLowerCase(),t=s in e||t=="onFocusOut"||t=="onFocusIn"?s.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?o?n.u=o.u:(n.u=Se,e.addEventListener(t,r?we:ke,r)):e.removeEventListener(t,r?we:ke,r);else{if(a=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Be(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=Se++;else if(t.t<n.u)return;return n(C.event?C.event(t):t)}}}function Ce(e,t,n,o,a,r,s,c,u,l){var _,i,p,h,g,R,x,w,y,M,U,W,O,f,A,m,k,v=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),r=[c=t.__e=n.__e]),(_=C.__b)&&_(t);e:if(typeof v=="function")try{if(w=t.props,y="prototype"in v&&v.prototype.render,M=(_=v.contextType)&&o[_.__c],U=_?M?M.props.value:_.__:o,n.__c?x=(i=t.__c=n.__c).__=i.__E:(y?t.__c=i=new v(w,U):(t.__c=i=new _e(w,U),i.constructor=v,i.render=Qt),M&&M.sub(i),i.props=w,i.state||(i.state={}),i.context=U,i.__n=o,p=i.__d=!0,i.__h=[],i._sb=[]),y&&i.__s==null&&(i.__s=i.state),y&&v.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=j({},i.__s)),j(i.__s,v.getDerivedStateFromProps(w,i.__s))),h=i.props,g=i.state,i.__v=t,p)y&&v.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),y&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(y&&v.getDerivedStateFromProps==null&&w!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(w,U),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(w,i.__s,U)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=w,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(T){T&&(T.__=t)}),W=0;W<i._sb.length;W++)i.__h.push(i._sb[W]);i._sb=[],i.__h.length&&s.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(w,i.__s,U),y&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,g,R)})}if(i.context=U,i.props=w,i.__P=e,i.__e=!1,O=C.__r,f=0,y){for(i.state=i.__s,i.__d=!1,O&&O(t),_=i.render(i.props,i.state,i.context),A=0;A<i._sb.length;A++)i.__h.push(i._sb[A]);i._sb=[]}else do i.__d=!1,O&&O(t),_=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++f<25);i.state=i.__s,i.getChildContext!=null&&(o=j(j({},o),i.getChildContext())),y&&!p&&i.getSnapshotBeforeUpdate!=null&&(R=i.getSnapshotBeforeUpdate(h,g)),m=_,_!=null&&_.type===me&&_.key==null&&(m=tt(_.props.children)),c=Ye(e,fe(m)?m:[m],t,n,o,a,r,s,c,u,l),i.base=t.__e,t.__u&=-161,i.__h.length&&s.push(i),x&&(i.__E=i.__=null)}catch(T){if(t.__v=null,u||r!=null)if(T.then){for(t.__u|=u?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;r[r.indexOf(c)]=null,t.__e=c}else for(k=r.length;k--;)xe(r[k]);else t.__e=n.__e,t.__k=n.__k;C.__e(T,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):c=t.__e=Jt(n.__e,t,n,o,a,r,s,u,l);return(_=C.diffed)&&_(t),128&t.__u?void 0:c}function et(e,t,n){for(var o=0;o<n.length;o++)Te(n[o],n[++o],n[++o]);C.__c&&C.__c(t,e),e.some(function(a){try{e=a.__h,a.__h=[],e.some(function(r){r.call(a)})}catch(r){C.__e(r,a.__v)}})}function tt(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:fe(e)?e.map(tt):j({},e)}function Jt(e,t,n,o,a,r,s,c,u){var l,_,i,p,h,g,R,x=n.props,w=t.props,y=t.type;if(y=="svg"?a="http://www.w3.org/2000/svg":y=="math"?a="http://www.w3.org/1998/Math/MathML":a||(a="http://www.w3.org/1999/xhtml"),r!=null){for(l=0;l<r.length;l++)if((h=r[l])&&"setAttribute"in h==!!y&&(y?h.localName==y:h.nodeType==3)){e=h,r[l]=null;break}}if(e==null){if(y==null)return document.createTextNode(w);e=document.createElementNS(a,y,w.is&&w),c&&(C.__m&&C.__m(t,r),c=!1),r=null}if(y==null)x===w||c&&e.data==w||(e.data=w);else{if(r=r&&pe.call(e.childNodes),x=n.props||re,!c&&r!=null)for(x={},l=0;l<e.attributes.length;l++)x[(h=e.attributes[l]).name]=h.value;for(l in x)if(h=x[l],l!="children"){if(l=="dangerouslySetInnerHTML")i=h;else if(!(l in w)){if(l=="value"&&"defaultValue"in w||l=="checked"&&"defaultChecked"in w)continue;ce(e,l,null,h,a)}}for(l in w)h=w[l],l=="children"?p=h:l=="dangerouslySetInnerHTML"?_=h:l=="value"?g=h:l=="checked"?R=h:c&&typeof h!="function"||x[l]===h||ce(e,l,h,x[l],a);if(_)c||i&&(_.__html==i.__html||_.__html==e.innerHTML)||(e.innerHTML=_.__html),t.__k=[];else if(i&&(e.innerHTML=""),Ye(t.type=="template"?e.content:e,fe(p)?p:[p],t,n,o,y=="foreignObject"?"http://www.w3.org/1999/xhtml":a,r,s,r?r[0]:n.__k&&Z(n,0),c,u),r!=null)for(l=r.length;l--;)xe(r[l]);c||(l="value",y=="progress"&&g==null?e.removeAttribute("value"):g!=null&&(g!==e[l]||y=="progress"&&!g||y=="option"&&g!=x[l])&&ce(e,l,g,x[l],a),l="checked",R!=null&&R!=e[l]&&ce(e,l,R,x[l],a))}return e}function Te(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(a){C.__e(a,n)}}function nt(e,t,n){var o,a;if(C.unmount&&C.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||Te(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(r){C.__e(r,t)}o.base=o.__P=null}if(o=e.__k)for(a=0;a<o.length;a++)o[a]&&nt(o[a],t,n||typeof e.type!="function");n||xe(e.__e),e.__c=e.__=e.__e=void 0}function Qt(e,t,n){return this.constructor(e,n)}function ot(e,t,n){var o,a,r,s;t==document&&(t=document.documentElement),C.__&&C.__(e,t),a=(o=typeof n=="function")?null:n&&n.__k||t.__k,r=[],s=[],Ce(t,e=(!o&&n||t).__k=ae(me,null,[e]),a||re,re,t.namespaceURI,!o&&n?[n]:a?null:t.firstChild?pe.call(t.childNodes):null,r,!o&&n?n:a?a.__e:t.firstChild,o,s),et(r,e,s)}pe=ze.slice,C={__e:function(e,t,n,o){for(var a,r,s;t=t.__;)if((a=t.__c)&&!a.__)try{if((r=a.constructor)&&r.getDerivedStateFromError!=null&&(a.setState(r.getDerivedStateFromError(e)),s=a.__d),a.componentDidCatch!=null&&(a.componentDidCatch(e,o||{}),s=a.__d),s)return a.__E=a}catch(c){e=c}throw e}},Ge=0,jt=function(e){return e!=null&&e.constructor==null},_e.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=j({},this.state),typeof e=="function"&&(e=e(j({},n),this.props)),e&&j(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),je(this))},_e.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),je(this))},_e.prototype.render=me,G=[],Ke=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Je=function(e,t){return e.__v.__b-t.__v.__b},de.__r=0,Qe=/(PointerCapture)$|Capture$/i,Se=0,ke=Be(!1),we=Be(!0),Vt=0;var se,F,Ee,rt,ie=0,dt=[],I=C,at=I.__b,st=I.__r,it=I.diffed,lt=I.__c,ct=I.unmount,ut=I.__;function Fe(e,t){I.__h&&I.__h(F,e,ie||t),ie=0;var n=F.__H||(F.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function b(e){return ie=1,zt(ht,e)}function zt(e,t,n){var o=Fe(se++,2);if(o.t=e,!o.__c&&(o.__=[n?n(t):ht(void 0,t),function(c){var u=o.__N?o.__N[0]:o.__[0],l=o.t(u,c);u!==l&&(o.__N=[l,o.__[1]],o.__c.setState({}))}],o.__c=F,!F.__f)){var a=function(c,u,l){if(!o.__c.__H)return!0;var _=o.__c.__H.__.filter(function(p){return!!p.__c});if(_.every(function(p){return!p.__N}))return!r||r.call(this,c,u,l);var i=o.__c.props!==c;return _.forEach(function(p){if(p.__N){var h=p.__[0];p.__=p.__N,p.__N=void 0,h!==p.__[0]&&(i=!0)}}),r&&r.call(this,c,u,l)||i};F.__f=!0;var r=F.shouldComponentUpdate,s=F.componentWillUpdate;F.componentWillUpdate=function(c,u,l){if(this.__e){var _=r;r=void 0,a(c,u,l),r=_}s&&s.call(this,c,u,l)},F.shouldComponentUpdate=a}return o.__N||o.__}function K(e,t){var n=Fe(se++,3);!I.__s&&mt(n.__H,t)&&(n.__=e,n.u=t,F.__H.__h.push(n))}function $e(e){return ie=5,pt(function(){return{current:e}},[])}function pt(e,t){var n=Fe(se++,7);return mt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function ft(e,t){return ie=8,pt(function(){return e},t)}function Xt(){for(var e;e=dt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(he),e.__H.__h.forEach(Re),e.__H.__h=[]}catch(t){e.__H.__h=[],I.__e(t,e.__v)}}I.__b=function(e){F=null,at&&at(e)},I.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),ut&&ut(e,t)},I.__r=function(e){st&&st(e),se=0;var t=(F=e.__c).__H;t&&(Ee===F?(t.__h=[],F.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(he),t.__h.forEach(Re),t.__h=[],se=0)),Ee=F},I.diffed=function(e){it&&it(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(dt.push(t)!==1&&rt===I.requestAnimationFrame||((rt=I.requestAnimationFrame)||Yt)(Xt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ee=F=null},I.__c=function(e,t){t.some(function(n){try{n.__h.forEach(he),n.__h=n.__h.filter(function(o){return!o.__||Re(o)})}catch(o){t.some(function(a){a.__h&&(a.__h=[])}),t=[],I.__e(o,n.__v)}}),lt&&lt(e,t)},I.unmount=function(e){ct&&ct(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{he(o)}catch(a){t=a}}),n.__H=void 0,t&&I.__e(t,n.__v))};var _t=typeof requestAnimationFrame=="function";function Yt(e){var t,n=function(){clearTimeout(o),_t&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);_t&&(t=requestAnimationFrame(n))}function he(e){var t=F,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),F=t}function Re(e){var t=F;e.__c=e.__(),F=t}function mt(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function ht(e,t){return typeof t=="function"?t(e):t}var gt=Wt(vt()),yt="/api/v1",ee=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},Zt=e=>new Promise(t=>setTimeout(t,e));async function le(e,t,n){for(let o=1;;o++){let a;try{a=await fetch(yt+t,{method:e,headers:n===void 0?{}:{"Content-Type":"application/json"},body:n===void 0?void 0:JSON.stringify(n)})}catch{if(o>=4)throw new ee(0,{message:"gateway unreachable"});await Zt(250*o);continue}let r=await a.text(),s=null;try{s=r?JSON.parse(r):null}catch{s={message:r}}if(!a.ok)throw new ee(a.status,s);return s}}var V=e=>le("GET",e),J=(e,t)=>le("POST",e,t),B=(e,t)=>le("PUT",e,t),Ie=(e,t)=>le("PATCH",e,t),en=e=>le("DELETE",e),N=encodeURIComponent,Ae={get:()=>V("/system"),restart:()=>J("/system/restart")},He={get:()=>V("/config"),update:e=>Ie("/config",e)},te={all:()=>V("/mqtt"),update:(e,t)=>Ie(`/mqtt/${e}`,t),trust:e=>J(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>en(`/mqtt/${e}/certificate`)},H={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${N(e)}`),update:(e,t)=>Ie(`/devices/${N(e)}`,t),action:(e,t)=>J(`/devices/${N(e)}/${t}`),silence:(e,t)=>B(`/devices/${N(e)}/silence`,{on:t}),relay:(e,t,n,o)=>B(`/devices/${N(e)}/relays/${t}`,{state:n,duration_ms:o}),rollershutter:(e,t,n,o)=>B(`/devices/${N(e)}/rollershutters/${t}`,{state:n,duration_ms:o}),lamps:(e,t,n,o)=>B(`/devices/${N(e)}/lamps/${t}`,{value:n,bitmask:o}),heating:(e,t,n)=>B(`/devices/${N(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${N(e)}/heating/manual`),heatingManual:(e,t,n,o)=>B(`/devices/${N(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:o})},Q={update:(e,t,n)=>B(`/devices/${N(e)}/sensors/${t}`,n),refresh:e=>J(`/devices/${N(e)}/sensors/refresh`),forget:e=>J(`/devices/${N(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${N(e)}`:"",o=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...o.sensors),o.sensors.length===0||t.length>=o.total)return t}}},z={action:e=>J(`/bus/${e}`),silence:e=>B("/bus/silence",{on:e}),typeAction:(e,t)=>J(`/device-types/${e}/${t}`)},Me={job:()=>V("/firmware/job"),upload(e,t,n){let o=gt.default.buf(new Uint8Array(t))>>>0,a=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((r,s)=>{let c=new XMLHttpRequest;c.open("PUT",`${yt}${a}?crc32=${o}`),c.setRequestHeader("Content-Type","application/octet-stream"),c.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),c.onload=()=>{let u=null;try{u=JSON.parse(c.responseText)}catch{}c.status>=200&&c.status<300?r(u):s(new ee(c.status,u))},c.onerror=()=>s(new ee(0,{message:"upload failed"})),c.send(t)})}};var kt=function(e,t,n,o){var a;t[0]=0;for(var r=1;r<t.length;r++){var s=t[r++],c=t[r]?(t[0]|=s?1:2,n[t[r++]]):t[++r];s===3?o[0]=c:s===4?o[1]=Object.assign(o[1]||{},c):s===5?(o[1]=o[1]||{})[t[++r]]=c:s===6?o[1][t[++r]]+=c+"":s?(a=e.apply(c,kt(e,c,n,["",null])),o.push(a),c[0]?t[0]|=2:(t[r-2]=0,t[r]=a)):o.push(c)}return o},bt=new Map;function wt(e){var t=bt.get(this);return t||(t=new Map,bt.set(this,t)),(t=kt(this,t.get(e)||(t.set(e,t=function(n){for(var o,a,r=1,s="",c="",u=[0],l=function(p){r===1&&(p||(s=s.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,p,s):r===3&&(p||s)?(u.push(3,p,s),r=2):r===2&&s==="..."&&p?u.push(4,p,0):r===2&&s&&!p?u.push(5,0,!0,s):r>=5&&((s||!p&&r===5)&&(u.push(r,0,s,a),r=6),p&&(u.push(r,p,0,a),r=6)),s=""},_=0;_<n.length;_++){_&&(r===1&&l(),l(_));for(var i=0;i<n[_].length;i++)o=n[_][i],r===1?o==="<"?(l(),u=[u],r=3):s+=o:r===4?s==="--"&&o===">"?(r=1,s=""):s=o+s[0]:c?o===c?c="":s+=o:o==='"'||o==="'"?c=o:o===">"?(l(),r=1):r&&(o==="="?(r=5,a=s,s=""):o==="/"&&(r<5||n[_][i+1]===">")?(l(),r===3&&(u=u[0]),r=u,(u=u[0]).push(2,0,r),r=0):o===" "||o==="	"||o===`
`||o==="\r"?(l(),r=2):s+=o),r===3&&s==="!--"&&(r=4,u=u[0])}return l(),u}(e)),t),arguments,[])).length>1?t:t[0]}var d=wt.bind(ae),Ue=()=>{};function q(e,t="ok"){Ue(e,t)}function St(){let[e,t]=b([]);return K(()=>{let n=0;return Ue=(o,a)=>{let r={id:++n,message:o,kind:a};t(s=>[...s,r]),setTimeout(()=>t(s=>s.filter(c=>c!==r)),a==="error"?8e3:3e3)},()=>Ue=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function S(e,t){try{let n=await e();return t&&q(t),n}catch(n){q(n.message,"error");return}}function P(e,t){let[n,o]=b({data:void 0,error:void 0}),a=$e(e);a.current=e;let r=ft(async()=>{try{o({data:await a.current(),error:void 0})}catch(s){o(c=>({data:c.data,error:s}))}},[]);return K(()=>{let s=!1,c,u=async()=>{await r(),t&&!s&&(c=setTimeout(u,t))};return u(),()=>{s=!0,clearTimeout(c)}},[t,r]),{...n,reload:r}}var L=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,D=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,E=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:o})=>{let[a,r]=b(!1);return d`<button class=${t||""} disabled=${o||a} onClick=${async c=>{r(!0);try{await n(c)}finally{r(!1)}}}>${e}</button>`},Ne=e=>"0x"+e.toString(16).padStart(2,"0");function X(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function xt(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),o=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${o} min`:`${o} min`}function ve({target:e,label:t,others:n=[],onDone:o}){let[a,r]=b(null),[s,c]=b(null),[u,l]=b(""),[_,i]=b(null),p=$e(null);K(()=>()=>clearInterval(p.current),[]);let h=()=>{clearInterval(p.current),p.current=setInterval(async()=>{try{i(await Me.job())}catch{}},1500)},g=async(y,M)=>{l(y),c(0),M!=="gateway"&&h();try{let U=await a.arrayBuffer();return await Me.upload(M,U,c)||{}}finally{clearInterval(p.current),c(null)}},R=async y=>{if(!a)return;let M=0;for(let{name:U,target:W}of y)try{let O=await g(U,W);M+=1,O.restarting&&q("Firmware installed, the gateway restarts\u2026")}catch(O){q(`${U}: ${O.message}`,"error");break}M===y.length&&y[0].target!=="gateway"&&q(M===1?"Firmware sent; the device restarts into it":`Firmware sent to ${M} devices`),l(""),i(null),o&&o()},x=s!==null,w=_&&_.state==="running"?`${_.sent} of ${_.total} bytes acknowledged${_.protocol?` (${_.protocol})`:""}${_.retries?`, ${_.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${y=>r(y.target.files[0]||null)} />
      <${$} onClick=${()=>R([{name:t||"device",target:e}])} disabled=${!a||x}>${t||"Upload"}<//>
      ${n.length>0&&d`<${$} onClick=${()=>R([{name:"this device",target:e},...n])} disabled=${!a||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&d`<progress max="1" value=${s}></progress>`}
      ${x&&d`<p class="muted wide">${u}${w?" \u2014 "+w:""}</p>`}
    </div>`}var ge=new Set;function tn(e){e!==location.pathname&&history.pushState(null,"",e),ge.forEach(t=>t())}addEventListener("popstate",()=>ge.forEach(e=>e()));function Ct(){let[e,t]=b(location.pathname);return K(()=>{let n=()=>t(location.pathname);return ge.add(n),()=>ge.delete(n)},[]),e}function Tt(e,t){let n=t.split("/").filter(Boolean);for(let o of e){let a=o.path.split("/").filter(Boolean);if(a.length!==n.length)continue;let r={};if(a.every((c,u)=>c.startsWith(":")?(r[c.slice(1)]=decodeURIComponent(n[u]),!0):c===n[u]))return{route:o,params:r}}return null}function Y({href:e,children:t,...n}){return ae("a",{href:e,onClick:a=>{a.metaKey||a.ctrlKey||a.shiftKey||a.button!==0||(a.preventDefault(),tn(e))},...n},t)}var nn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"},Pe=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],on={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},oe=e=>on[e]||e;function ye(e,t=5e3){let n=P(()=>Q.list(e),t),o=[...new Set((n.data||[]).map(r=>r.device))];return{...n,ask:async()=>{for(let r of e?[e]:o)await S(()=>Q.refresh(r));setTimeout(n.reload,1500)}}}function rn({s:e,device:t,reload:n}){let[o,a]=b(!1),[r,s]=b(e.name||""),[c,u]=b(e.role||"none"),l=async()=>{let _={};if(r!==(e.name||"")&&(_.name=r),c!==(e.role||"none")&&(_.role=c),Object.keys(_).length===0)return a(!1);await S(()=>Q.update(e.device,e.slot,_),"Sent to the device")&&(a(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${Y} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${o?d`<input class="inline" maxlength="7" placeholder="name" value=${r} onInput=${_=>s(_.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${nn[e.kind]||e.kind}</td>
    <td>${o?d`<select value=${c} onChange=${_=>u(_.target.value)}>${Pe.map(_=>d`<option value=${_}>${oe(_)}</option>`)}</select>`:e.role&&e.role!=="none"?oe(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind==="temperature"?e.value.toFixed(2):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:X(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":o?d`<${$} kind="primary" onClick=${l}>Save<//> <button onClick=${()=>a(!1)}>Cancel</button>`:d`<button onClick=${()=>a(!0)}>Edit</button>`}</td>
  </tr>`}function De({device:e}){let{data:t,error:n,reload:o,ask:a}=ye(e);if(!t)return d`<${D} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let r=t.some(s=>s.slot===null);return d`
    ${r&&d`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${a}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(s=>d`<${rn} key=${s.device_key+s.kind+s.sensor_id} s=${s} device=${e} reload=${o} />`)}
      </tbody>
    </table></div>`}function Et(){let{ask:e}=ye(void 0,0);return d`<${L} title="Sensors" aside=${d`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${De} />
  <//>`}var an=[2,5,8,9],sn=[7],ln=[3],Oe=[9],cn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],un=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ft({device:e}){let{data:t,error:n,reload:o}=P(()=>H.get(e),5e3);return t?d`
    <${dn} d=${t} reload=${o} />
    ${an.includes(t.device_type)&&d`<${Rt} d=${t} kind="relay" />`}
    ${sn.includes(t.device_type)&&d`<${Rt} d=${t} kind="rollershutter" />`}
    ${ln.includes(t.device_type)&&d`<${pn} d=${t} />`}
    ${Oe.includes(t.device_type)&&d`<${fn} d=${t} />`}
    ${Oe.includes(t.device_type)&&d`<${hn} d=${t} />`}
    ${Oe.includes(t.device_type)&&d`<${$n} d=${t} />`}
    <${L} title="Sensors"><${De} device=${t.name||t.key} /><//>
    <${vn} d=${t} reload=${o} />
    <${_n} d=${t} />`:d`<${D} error=${n} />`}function _n({d:e}){let t=e.name||e.key,{data:n}=P(H.list),o=(n||[]).filter(a=>a.device_type===e.device_type&&a.key!==e.key).map(a=>({name:a.name||a.key,target:"devices/"+encodeURIComponent(a.name||a.key)}));return d`
    <${L} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${ve} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${o} />
    <//>`}function dn({d:e,reload:t}){let n=e.name||e.key,o=(a,r)=>async()=>{await S(()=>H.action(n,a),r),setTimeout(t,1500)};return d`
    <${L} title=${n}
      aside=${d`<span class="buttons">
        <${$} onClick=${o("ping","Ping sent")}>Ping<//>
        <${$} onClick=${o("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${o("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${X(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Rt({d:e,kind:t}){let n=e.name||e.key,[o,a]=b(1),[r,s]=b(0),c=t==="rollershutter",u=l=>()=>S(()=>H[t](n,o,l,Math.round(r*1e3)),`${c?"Rollershutter":"Relay"} ${o}: ${l}`);return d`
    <${L} title=${c?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${E} label="Number"><input type="number" min="1" max="16" value=${o} onInput=${l=>a(+l.target.value)} /><//>
        <${E} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${r} onInput=${l=>s(+l.target.value)} /><//>
      </div>
      <div class="buttons">
        ${c?d`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:d`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function pn({d:e}){let t=e.name||e.key,[n,o]=b(0),[a,r]=b(255),[s,c]=b(Array(24).fill(!1)),u=s.reduce((l,_,i)=>_?l|1<<23-i:l,0);return d`
    <${L} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${E} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${l=>o(+l.target.value)} /><//>
        <${E} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${l=>r(+l.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((l,_)=>d`<label key=${_} class=${"lamp"+(l?" on":"")}>
            <input type="checkbox" checked=${l} onChange=${()=>c(s.map((i,p)=>p===_?!i:i))} />${23-_}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>S(()=>H.lamps(t,n,a,u),"Lamps set")}>Send<//>
    <//>`}function fn({d:e}){let t=e.name||e.key,[n,o]=b(45),[a,r]=b(!1),[s,c]=b(0),[u,l]=b(!1),[_,i]=b(0),[p,h]=b(55);return d`
    <${L} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${E} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${g=>o(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${a} onChange=${g=>r(g.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>S(()=>H.heating(t,"target",{flow_c:n,tank:a}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${E} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${s} onInput=${g=>c(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${g=>l(g.target.checked)} /> rod released</label>
        <${$} onClick=${()=>S(()=>H.heating(t,"energy",{power_w:s,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${E} label="Stage (0-3)"><input type="number" min="0" max="3" value=${_} onInput=${g=>i(+g.target.value)} /><//>
        <${E} label="Tank (°C)"><input type="number" step="0.5" value=${p} onInput=${g=>h(+g.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>S(()=>H.heating(t,"emergency",{stage:_,tank_c:p}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var mn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function hn({d:e}){let t=e.name||e.key,{data:n,error:o,reload:a,ask:r}=ye(t);if(!n)return d`<${L} title="Sensor assignment"><${D} error=${o} /><//>`;let s=n.filter(i=>i.kind==="temperature"),c=i=>s.find(p=>p.role===i),u=i=>i.name?`${i.name} (${i.sensor_id})`:i.sensor_id,l=s.every(i=>i.slot!==null),_=i=>async p=>{let h=p.target.value,g;if(h===""){let R=c(i);if(!R)return;g=await S(()=>Q.update(t,R.slot,{role:"none"}),`${oe(i)} cleared`)}else{let R=s.find(x=>x.sensor_id===h);g=await S(()=>Q.update(t,R.slot,{role:i}),`${u(R)} is ${oe(i)} now`)}g&&setTimeout(a,1500)};return d`
    <${L} title="Sensor assignment" aside=${d`<${$} onClick=${r}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!l&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${Pe.filter(i=>i!=="none").map(i=>d`<label key=${i} class="field">
            <span>${oe(i)}</span>
            <select value=${(c(i)||{}).sensor_id||""} onChange=${_(i)} disabled=${!l}>
              <option value="">(none)</option>
              ${s.map(p=>d`<option value=${p.sensor_id}>${u(p)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function $n({d:e}){let t=e.name||e.key,{data:n,error:o,reload:a}=P(()=>H.heatingManualState(t),3e3),r=!!(n&&n.enabled),s=_=>!!(n&&n.relays.includes(_)),c=async()=>{let _=!r;await S(()=>H.heatingManual(t,_),_?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(a,800)},u=_=>async()=>{await S(()=>H.heatingManual(t,!0,_,!s(_)),`Relay ${_} ${s(_)?"off":"on"}`)&&setTimeout(a,800)},l=_=>_===8&&s(9)||_===9&&s(8);return d`
    <${L} title="Manual mode"
      aside=${d`<${$} kind=${r?"danger":""} disabled=${!n} onClick=${c}>${r?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${o&&d`<p class="error">The controller does not answer: ${o.message}</p>`}
      ${r&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${mn.map(([_,i])=>d`<button key=${_} class=${s(_)?"primary":""} disabled=${!r||l(_)} onClick=${u(_)}>
            <span>${i}</span><small>relay ${_}: ${s(_)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function vn({d:e,reload:t}){let n=e.name||e.key,[o,a]=b({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[r,s]=b(!1),c=l=>_=>a({...o,[l]:_.target.value}),u=async()=>{let l={};if(o.custom_string!==e.name&&(l.custom_string=o.custom_string),+o.hwrev!==e.hwrev&&(l.hwrev=+o.hwrev),o.relais_mode&&(l.relais_mode=o.relais_mode),o.extension_mode&&(l.extension_mode=o.extension_mode),Object.keys(l).length===0)return q("Nothing changed");await S(()=>H.update(n,l),"Settings sent")&&setTimeout(t,1500)};return d`
    <${L} title="Settings">
      <div class="row">
        <${E} label="Name" hint="up to 8 characters"><input maxlength="8" value=${o.custom_string} onInput=${c("custom_string")} /><//>
        <${E} label="Hardware revision"><input type="number" min="0" max="255" value=${o.hwrev} onInput=${c("hwrev")} /><//>
        <${E} label="Relay mode"><select value=${o.relais_mode} onChange=${c("relais_mode")}>
          <option value="">(unchanged)</option>${cn.map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${E} label="Extension mode"><select value=${o.extension_mode} onChange=${c("extension_mode")}>
          <option value="">(unchanged)</option>${un.map(l=>d`<option>${l}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await S(()=>H.silence(n,!r),r?"Device may talk again":"Device silenced"),s(!r)}}>${r?"End silence":"Silence"}<//>
        <${$} onClick=${()=>S(()=>H.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Lt(){let{data:e,error:t,reload:n}=P(H.list,5e3),[o,a]=b(""),r=(l,_)=>async()=>{await S(l,_),setTimeout(n,1500)},s=async()=>{let l=o.trim();l&&await S(()=>H.action(l,"ping"),`Ping sent to ${l}`)},c=async()=>{confirm("Restart every device on the bus?")&&await r(()=>z.action("restart"),"Restart sent to every device")()},u=r(async()=>{await z.action("ping"),await z.action("refresh")},"Scanning: every device was asked to announce itself");return d`
    <${L} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${r(()=>z.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${r(()=>z.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${r(()=>z.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${c}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${o} onInput=${l=>a(l.target.value)} onKeyDown=${l=>l.key==="Enter"&&s()} />
        <${$} onClick=${s}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(l=>d`<tr key=${l.key}>
                    <td><${Y} href=${"/devices/"+encodeURIComponent(l.name||l.key)}>${l.name||l.key}<//></td>
                    <td><code>${Ne(l.device_id)}</code></td>
                    <td>${l.type_name} <code>${Ne(l.device_type)}</code></td>
                    <td>${l.version}</td>
                    <td>${X(l.last_seen_minutes_ago)}</td>
                    <td>${l.uptime?X(Math.floor(l.uptime/60)):""}</td>
                    <td>${l.error?d`<span class="badge bad">error ${l.error}</span>`:l.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${D} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function It(){return d`<${gn} /><${yn} /><${bn} />`}function gn(){let{data:e,error:t}=P(Ae.get,5e3);return d`
    <${L} title="Gateway" aside=${d`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await S(Ae.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${xt(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:d`<${D} error=${t} />`}
    <//>`}function yn(){let{data:e,error:t,reload:n}=P(He.get),[o,a]=b({});if(!e)return d`<${D} error=${t} />`;let r=u=>u in o?o[u]:e[u],s=(u,l)=>_=>a({...o,[u]:l?+_.target.value:_.target.value}),c=async()=>{let u={...o};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return q("Nothing changed");let l=await S(()=>He.update(u),"Saved");l&&(l.restart_required&&q("Restart the gateway to apply the hostname or bitrate."),a({}),n())};return d`
    <${L} title="Settings">
      <div class="row">
        <${E} label="Hostname"><input value=${r("hostname")} onInput=${s("hostname")} /><//>
        <${E} label="CAN bitrate"><select value=${r("can_bitrate")} onChange=${s("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${E} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${r("update_delay_ms")} onInput=${s("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${E} label="User name"><input value=${r("web_username")} onInput=${s("web_username")} autocomplete="off" /><//>
        <${E} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${o.web_password||""} onInput=${s("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}function bn(){return d`
    <${L} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${ve} target="gateway" label="Install and restart" />
    <//>`}var kn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Ht(){let{data:e,error:t,reload:n}=P(te.all,5e3);return e?d`
    <${At} slot="primary" b=${e.primary} reload=${n} />
    <${At} slot="secondary" b=${e.secondary} reload=${n} />`:d`<${D} error=${t} />`}function At({slot:e,b:t,reload:n}){let[o,a]=b({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[r,s]=b(null),c=o.uri.startsWith("mqtts://"),u=i=>p=>a({...o,[i]:p.target.type==="checkbox"?p.target.checked:p.target.value}),l=async()=>{let i={uri:o.uri,user:o.user,enabled:o.enabled,tls_insecure:o.tls_insecure};o.password&&(i.password=o.password),await S(()=>te.update(e,i),`${e} broker saved, reconnecting`)&&(a({...o,password:""}),setTimeout(n,2500))},_=async()=>{let i=await S(()=>te.certificate(e));i&&s(i)};return d`
    <${L}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${kn[e]}</p>
      <div class="row">
        <${E} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${o.uri} onInput=${u("uri")} /><//>
        <${E} label="User"><input value=${o.user} onInput=${u("user")} autocomplete="off" /><//>
        <${E} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${o.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${o.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${c&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${o.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await S(()=>te.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),_()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${_}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${$} kind="danger" onClick=${async()=>{await S(()=>te.forget(e),"Certificate forgotten"),s(null),n()}}>Forget<//>`}
          </div>
          ${r&&d`<p>${r.pinned?d`SHA-256 <code>${r.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var wn=[{path:"/",title:"Devices",page:Lt},{path:"/devices/:device",title:"Device",page:Ft},{path:"/sensors",title:"Sensors",page:Et},{path:"/mqtt",title:"MQTT",page:Ht},{path:"/gateway",title:"Gateway",page:It}],Sn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"]];function xn(){let e=Ct(),t=Tt(wn,e),n=t?t.route.page:null,o=a=>a==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(a);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${Sn.map(([a,r])=>d`<${Y} href=${a} class=${o(a)?"active":""}>${r}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${Y} href="/">Devices<//></p>`}
    </main>
    <${St} />`}ot(d`<${xn} />`,document.getElementById("app"));
