var Go=Object.create;var An=Object.defineProperty;var Vo=Object.getOwnPropertyDescriptor;var Qo=Object.getOwnPropertyNames;var Xo=Object.getPrototypeOf,zo=Object.prototype.hasOwnProperty;var Jo=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Zo=(e,t,n,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Qo(t))!zo.call(e,o)&&o!==n&&An(e,o,{get:()=>t[o],enumerable:!(i=Vo(t,o))||i.enumerable});return e};var er=(e,t,n)=>(n=e!=null?Go(Xo(e)):{},Zo(t||!e||!e.__esModule?An(n,"default",{value:e,enumerable:!0}):n,e));var oi=Jo(Mt=>{var ii;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Mt=="object"?e(Mt):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(ii={}):e(ii={})})(function(e){e.version="1.2.2";function t(){for(var w=0,S=new Array(256),b=0;b!=256;++b)w=b,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,w=w&1?-306674912^w>>>1:w>>>1,S[b]=w;return typeof Int32Array<"u"?new Int32Array(S):S}var n=t();function i(w){var S=0,b=0,N=0,k=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(N=0;N!=256;++N)k[N]=w[N];for(N=0;N!=256;++N)for(b=w[N],S=256+N;S<4096;S+=256)b=k[S]=b>>>8^w[b&255];var I=[];for(N=1;N!=16;++N)I[N-1]=typeof Int32Array<"u"?k.subarray(N*256,N*256+256):k.slice(N*256,N*256+256);return I}var o=i(n),r=o[0],a=o[1],s=o[2],l=o[3],u=o[4],p=o[5],c=o[6],f=o[7],h=o[8],v=o[9],y=o[10],g=o[11],m=o[12],$=o[13],R=o[14];function x(w,S){for(var b=S^-1,N=0,k=w.length;N<k;)b=b>>>8^n[(b^w.charCodeAt(N++))&255];return~b}function A(w,S){for(var b=S^-1,N=w.length-15,k=0;k<N;)b=R[w[k++]^b&255]^$[w[k++]^b>>8&255]^m[w[k++]^b>>16&255]^g[w[k++]^b>>>24]^y[w[k++]]^v[w[k++]]^h[w[k++]]^f[w[k++]]^c[w[k++]]^p[w[k++]]^u[w[k++]]^l[w[k++]]^s[w[k++]]^a[w[k++]]^r[w[k++]]^n[w[k++]];for(N+=15;k<N;)b=b>>>8^n[(b^w[k++])&255];return~b}function M(w,S){for(var b=S^-1,N=0,k=w.length,I=0,H=0;N<k;)I=w.charCodeAt(N++),I<128?b=b>>>8^n[(b^I)&255]:I<2048?(b=b>>>8^n[(b^(192|I>>6&31))&255],b=b>>>8^n[(b^(128|I&63))&255]):I>=55296&&I<57344?(I=(I&1023)+64,H=w.charCodeAt(N++)&1023,b=b>>>8^n[(b^(240|I>>8&7))&255],b=b>>>8^n[(b^(128|I>>2&63))&255],b=b>>>8^n[(b^(128|H>>6&15|(I&3)<<4))&255],b=b>>>8^n[(b^(128|H&63))&255]):(b=b>>>8^n[(b^(224|I>>12&15))&255],b=b>>>8^n[(b^(128|I>>6&63))&255],b=b>>>8^n[(b^(128|I&63))&255]);return~b}e.table=n,e.bstr=x,e.buf=A,e.str=M})});var nt,P,Fn,tr,be,Tn,In,Nn,Mn,Tt,St,At,nr,Ue={},Rn=[],ir=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,it=Array.isArray;function pe(e,t){for(var n in t)e[n]=t[n];return e}function Et(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function je(e,t,n){var i,o,r,a={};for(r in t)r=="key"?i=t[r]:r=="ref"?o=t[r]:a[r]=t[r];if(arguments.length>2&&(a.children=arguments.length>3?nt.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)a[r]===void 0&&(a[r]=e.defaultProps[r]);return Ze(e,a,i,o,null)}function Ze(e,t,n,i,o){var r={type:e,props:t,key:n,ref:i,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++Fn,__i:-1,__u:0};return o==null&&P.vnode!=null&&P.vnode(r),r}function ot(e){return e.children}function et(e,t){this.props=e,this.context=t}function Ce(e,t){if(t==null)return e.__?Ce(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?Ce(e):null}function Dn(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Dn(e)}}function En(e){(!e.__d&&(e.__d=!0)&&be.push(e)&&!tt.__r++||Tn!=P.debounceRendering)&&((Tn=P.debounceRendering)||In)(tt)}function tt(){for(var e,t,n,i,o,r,a,s=1;be.length;)be.length>s&&be.sort(Nn),e=be.shift(),s=be.length,e.__d&&(n=void 0,o=(i=(t=e).__v).__e,r=[],a=[],t.__P&&((n=pe({},i)).__v=i.__v+1,P.vnode&&P.vnode(n),Lt(t.__P,n,i,t.__n,t.__P.namespaceURI,32&i.__u?[o]:null,r,o??Ce(i),!!(32&i.__u),a),n.__v=i.__v,n.__.__k[n.__i]=n,Un(r,n,a),n.__e!=o&&Dn(n)));tt.__r=0}function Pn(e,t,n,i,o,r,a,s,l,u,p){var c,f,h,v,y,g,m=i&&i.__k||Rn,$=t.length;for(l=or(n,t,m,l,$),c=0;c<$;c++)(h=n.__k[c])!=null&&(f=h.__i==-1?Ue:m[h.__i]||Ue,h.__i=c,g=Lt(e,h,f,o,r,a,s,l,u,p),v=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&Ot(f.ref,null,h),p.push(h.ref,h.__c||v,h)),y==null&&v!=null&&(y=v),4&h.__u||f.__k===h.__k?l=Hn(h,l,e):typeof h.type=="function"&&g!==void 0?l=g:v&&(l=v.nextSibling),h.__u&=-7);return n.__e=y,l}function or(e,t,n,i,o){var r,a,s,l,u,p=n.length,c=p,f=0;for(e.__k=new Array(o),r=0;r<o;r++)(a=t[r])!=null&&typeof a!="boolean"&&typeof a!="function"?(l=r+f,(a=e.__k[r]=typeof a=="string"||typeof a=="number"||typeof a=="bigint"||a.constructor==String?Ze(null,a,null,null,null):it(a)?Ze(ot,{children:a},null,null,null):a.constructor==null&&a.__b>0?Ze(a.type,a.props,a.key,a.ref?a.ref:null,a.__v):a).__=e,a.__b=e.__b+1,s=null,(u=a.__i=rr(a,n,l,c))!=-1&&(c--,(s=n[u])&&(s.__u|=2)),s==null||s.__v==null?(u==-1&&(o>p?f--:o<p&&f++),typeof a.type!="function"&&(a.__u|=4)):u!=l&&(u==l-1?f--:u==l+1?f++:(u>l?f--:f++,a.__u|=4))):e.__k[r]=null;if(c)for(r=0;r<p;r++)(s=n[r])!=null&&(2&s.__u)==0&&(s.__e==i&&(i=Ce(s)),Bn(s,s));return i}function Hn(e,t,n){var i,o;if(typeof e.type=="function"){for(i=e.__k,o=0;i&&o<i.length;o++)i[o]&&(i[o].__=e,t=Hn(i[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=Ce(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function rr(e,t,n,i){var o,r,a=e.key,s=e.type,l=t[n];if(l===null&&e.key==null||l&&a==l.key&&s==l.type&&(2&l.__u)==0)return n;if(i>(l!=null&&(2&l.__u)==0?1:0))for(o=n-1,r=n+1;o>=0||r<t.length;){if(o>=0){if((l=t[o])&&(2&l.__u)==0&&a==l.key&&s==l.type)return o;o--}if(r<t.length){if((l=t[r])&&(2&l.__u)==0&&a==l.key&&s==l.type)return r;r++}}return-1}function Ln(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||ir.test(t)?n:n+"px"}function Je(e,t,n,i,o){var r,a;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof i=="string"&&(e.style.cssText=i=""),i)for(t in i)n&&t in n||Ln(e.style,t,"");if(n)for(t in n)i&&n[t]==i[t]||Ln(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Mn,"$1")),a=t.toLowerCase(),t=a in e||t=="onFocusOut"||t=="onFocusIn"?a.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?i?n.u=i.u:(n.u=Tt,e.addEventListener(t,r?At:St,r)):e.removeEventListener(t,r?At:St,r);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function On(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=Tt++;else if(t.t<n.u)return;return n(P.event?P.event(t):t)}}}function Lt(e,t,n,i,o,r,a,s,l,u){var p,c,f,h,v,y,g,m,$,R,x,A,M,w,S,b,N,k=t.type;if(t.constructor!=null)return null;128&n.__u&&(l=!!(32&n.__u),r=[s=t.__e=n.__e]),(p=P.__b)&&p(t);e:if(typeof k=="function")try{if(m=t.props,$="prototype"in k&&k.prototype.render,R=(p=k.contextType)&&i[p.__c],x=p?R?R.props.value:p.__:i,n.__c?g=(c=t.__c=n.__c).__=c.__E:($?t.__c=c=new k(m,x):(t.__c=c=new et(m,x),c.constructor=k,c.render=sr),R&&R.sub(c),c.props=m,c.state||(c.state={}),c.context=x,c.__n=i,f=c.__d=!0,c.__h=[],c._sb=[]),$&&c.__s==null&&(c.__s=c.state),$&&k.getDerivedStateFromProps!=null&&(c.__s==c.state&&(c.__s=pe({},c.__s)),pe(c.__s,k.getDerivedStateFromProps(m,c.__s))),h=c.props,v=c.state,c.__v=t,f)$&&k.getDerivedStateFromProps==null&&c.componentWillMount!=null&&c.componentWillMount(),$&&c.componentDidMount!=null&&c.__h.push(c.componentDidMount);else{if($&&k.getDerivedStateFromProps==null&&m!==h&&c.componentWillReceiveProps!=null&&c.componentWillReceiveProps(m,x),!c.__e&&c.shouldComponentUpdate!=null&&c.shouldComponentUpdate(m,c.__s,x)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(c.props=m,c.state=c.__s,c.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(I){I&&(I.__=t)}),A=0;A<c._sb.length;A++)c.__h.push(c._sb[A]);c._sb=[],c.__h.length&&a.push(c);break e}c.componentWillUpdate!=null&&c.componentWillUpdate(m,c.__s,x),$&&c.componentDidUpdate!=null&&c.__h.push(function(){c.componentDidUpdate(h,v,y)})}if(c.context=x,c.props=m,c.__P=e,c.__e=!1,M=P.__r,w=0,$){for(c.state=c.__s,c.__d=!1,M&&M(t),p=c.render(c.props,c.state,c.context),S=0;S<c._sb.length;S++)c.__h.push(c._sb[S]);c._sb=[]}else do c.__d=!1,M&&M(t),p=c.render(c.props,c.state,c.context),c.state=c.__s;while(c.__d&&++w<25);c.state=c.__s,c.getChildContext!=null&&(i=pe(pe({},i),c.getChildContext())),$&&!f&&c.getSnapshotBeforeUpdate!=null&&(y=c.getSnapshotBeforeUpdate(h,v)),b=p,p!=null&&p.type===ot&&p.key==null&&(b=jn(p.props.children)),s=Pn(e,it(b)?b:[b],t,n,i,o,r,a,s,l,u),c.base=t.__e,t.__u&=-161,c.__h.length&&a.push(c),g&&(c.__E=c.__=null)}catch(I){if(t.__v=null,l||r!=null)if(I.then){for(t.__u|=l?160:128;s&&s.nodeType==8&&s.nextSibling;)s=s.nextSibling;r[r.indexOf(s)]=null,t.__e=s}else for(N=r.length;N--;)Et(r[N]);else t.__e=n.__e,t.__k=n.__k;P.__e(I,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):s=t.__e=ar(n.__e,t,n,i,o,r,a,l,u);return(p=P.diffed)&&p(t),128&t.__u?void 0:s}function Un(e,t,n){for(var i=0;i<n.length;i++)Ot(n[i],n[++i],n[++i]);P.__c&&P.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(r){r.call(o)})}catch(r){P.__e(r,o.__v)}})}function jn(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:it(e)?e.map(jn):pe({},e)}function ar(e,t,n,i,o,r,a,s,l){var u,p,c,f,h,v,y,g=n.props,m=t.props,$=t.type;if($=="svg"?o="http://www.w3.org/2000/svg":$=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),r!=null){for(u=0;u<r.length;u++)if((h=r[u])&&"setAttribute"in h==!!$&&($?h.localName==$:h.nodeType==3)){e=h,r[u]=null;break}}if(e==null){if($==null)return document.createTextNode(m);e=document.createElementNS(o,$,m.is&&m),s&&(P.__m&&P.__m(t,r),s=!1),r=null}if($==null)g===m||s&&e.data==m||(e.data=m);else{if(r=r&&nt.call(e.childNodes),g=n.props||Ue,!s&&r!=null)for(g={},u=0;u<e.attributes.length;u++)g[(h=e.attributes[u]).name]=h.value;for(u in g)if(h=g[u],u!="children"){if(u=="dangerouslySetInnerHTML")c=h;else if(!(u in m)){if(u=="value"&&"defaultValue"in m||u=="checked"&&"defaultChecked"in m)continue;Je(e,u,null,h,o)}}for(u in m)h=m[u],u=="children"?f=h:u=="dangerouslySetInnerHTML"?p=h:u=="value"?v=h:u=="checked"?y=h:s&&typeof h!="function"||g[u]===h||Je(e,u,h,g[u],o);if(p)s||c&&(p.__html==c.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(c&&(e.innerHTML=""),Pn(t.type=="template"?e.content:e,it(f)?f:[f],t,n,i,$=="foreignObject"?"http://www.w3.org/1999/xhtml":o,r,a,r?r[0]:n.__k&&Ce(n,0),s,l),r!=null)for(u=r.length;u--;)Et(r[u]);s||(u="value",$=="progress"&&v==null?e.removeAttribute("value"):v!=null&&(v!==e[u]||$=="progress"&&!v||$=="option"&&v!=g[u])&&Je(e,u,v,g[u],o),u="checked",y!=null&&y!=e[u]&&Je(e,u,y,g[u],o))}return e}function Ot(e,t,n){try{if(typeof e=="function"){var i=typeof e.__u=="function";i&&e.__u(),i&&t==null||(e.__u=e(t))}else e.current=t}catch(o){P.__e(o,n)}}function Bn(e,t,n){var i,o;if(P.unmount&&P.unmount(e),(i=e.ref)&&(i.current&&i.current!=e.__e||Ot(i,null,t)),(i=e.__c)!=null){if(i.componentWillUnmount)try{i.componentWillUnmount()}catch(r){P.__e(r,t)}i.base=i.__P=null}if(i=e.__k)for(o=0;o<i.length;o++)i[o]&&Bn(i[o],t,n||typeof e.type!="function");n||Et(e.__e),e.__c=e.__=e.__e=void 0}function sr(e,t,n){return this.constructor(e,n)}function qn(e,t,n){var i,o,r,a;t==document&&(t=document.documentElement),P.__&&P.__(e,t),o=(i=typeof n=="function")?null:n&&n.__k||t.__k,r=[],a=[],Lt(t,e=(!i&&n||t).__k=je(ot,null,[e]),o||Ue,Ue,t.namespaceURI,!i&&n?[n]:o?null:t.firstChild?nt.call(t.childNodes):null,r,!i&&n?n:o?o.__e:t.firstChild,i,a),Un(r,e,a)}nt=Rn.slice,P={__e:function(e,t,n,i){for(var o,r,a;t=t.__;)if((o=t.__c)&&!o.__)try{if((r=o.constructor)&&r.getDerivedStateFromError!=null&&(o.setState(r.getDerivedStateFromError(e)),a=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,i||{}),a=o.__d),a)return o.__E=o}catch(s){e=s}throw e}},Fn=0,tr=function(e){return e!=null&&e.constructor==null},et.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=pe({},this.state),typeof e=="function"&&(e=e(pe({},n),this.props)),e&&pe(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),En(this))},et.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),En(this))},et.prototype.render=ot,be=[],In=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Nn=function(e,t){return e.__v.__b-t.__v.__b},tt.__r=0,Mn=/(PointerCapture)$|Capture$/i,Tt=0,St=On(!1),At=On(!0),nr=0;var Be,q,Ft,Yn,qe=0,Jn=[],Y=P,Wn=Y.__b,Kn=Y.__r,Gn=Y.diffed,Vn=Y.__c,Qn=Y.unmount,Xn=Y.__;function Nt(e,t){Y.__h&&Y.__h(q,e,qe||t),qe=0;var n=q.__H||(q.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function _(e){return qe=1,lr(ni,e)}function lr(e,t,n){var i=Nt(Be++,2);if(i.t=e,!i.__c&&(i.__=[n?n(t):ni(void 0,t),function(s){var l=i.__N?i.__N[0]:i.__[0],u=i.t(l,s);l!==u&&(i.__N=[u,i.__[1]],i.__c.setState({}))}],i.__c=q,!q.__f)){var o=function(s,l,u){if(!i.__c.__H)return!0;var p=i.__c.__H.__.filter(function(f){return!!f.__c});if(p.every(function(f){return!f.__N}))return!r||r.call(this,s,l,u);var c=i.__c.props!==s;return p.forEach(function(f){if(f.__N){var h=f.__[0];f.__=f.__N,f.__N=void 0,h!==f.__[0]&&(c=!0)}}),r&&r.call(this,s,l,u)||c};q.__f=!0;var r=q.shouldComponentUpdate,a=q.componentWillUpdate;q.componentWillUpdate=function(s,l,u){if(this.__e){var p=r;r=void 0,o(s,l,u),r=p}a&&a.call(this,s,l,u)},q.shouldComponentUpdate=o}return i.__N||i.__}function W(e,t){var n=Nt(Be++,3);!Y.__s&&ti(n.__H,t)&&(n.__=e,n.u=t,q.__H.__h.push(n))}function re(e){return qe=5,Zn(function(){return{current:e}},[])}function Zn(e,t){var n=Nt(Be++,7);return ti(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function ei(e,t){return qe=8,Zn(function(){return e},t)}function cr(){for(var e;e=Jn.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(rt),e.__H.__h.forEach(It),e.__H.__h=[]}catch(t){e.__H.__h=[],Y.__e(t,e.__v)}}Y.__b=function(e){q=null,Wn&&Wn(e)},Y.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Xn&&Xn(e,t)},Y.__r=function(e){Kn&&Kn(e),Be=0;var t=(q=e.__c).__H;t&&(Ft===q?(t.__h=[],q.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(rt),t.__h.forEach(It),t.__h=[],Be=0)),Ft=q},Y.diffed=function(e){Gn&&Gn(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(Jn.push(t)!==1&&Yn===Y.requestAnimationFrame||((Yn=Y.requestAnimationFrame)||ur)(cr)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ft=q=null},Y.__c=function(e,t){t.some(function(n){try{n.__h.forEach(rt),n.__h=n.__h.filter(function(i){return!i.__||It(i)})}catch(i){t.some(function(o){o.__h&&(o.__h=[])}),t=[],Y.__e(i,n.__v)}}),Vn&&Vn(e,t)},Y.unmount=function(e){Qn&&Qn(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(i){try{rt(i)}catch(o){t=o}}),n.__H=void 0,t&&Y.__e(t,n.__v))};var zn=typeof requestAnimationFrame=="function";function ur(e){var t,n=function(){clearTimeout(i),zn&&cancelAnimationFrame(t),setTimeout(e)},i=setTimeout(n,35);zn&&(t=requestAnimationFrame(n))}function rt(e){var t=q,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),q=t}function It(e){var t=q;e.__c=e.__(),q=t}function ti(e,t){return!e||e.length!==t.length||t.some(function(n,i){return n!==e[i]})}function ni(e,t){return typeof t=="function"?t(e):t}var si=er(oi()),Pt="/api/v1",Se=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error,this.field=n&&n.field}},dr=e=>new Promise(t=>setTimeout(t,e));async function Ae(e,t,n,i=!1){for(let o=1;;o++){let r;try{r=await fetch(Pt+t,{method:e,headers:n===void 0?{}:{"Content-Type":i?"application/x-pem-file":"application/json"},body:n===void 0?void 0:i?n:JSON.stringify(n)})}catch{if(o>=4)throw new Se(0,{message:"gateway unreachable"});await dr(250*o);continue}let a=await r.text(),s=null;try{s=a?JSON.parse(a):null}catch{s={message:a}}if(!r.ok)throw new Se(r.status,s);return s}}var G=e=>Ae("GET",e),ue=(e,t)=>Ae("POST",e,t),oe=(e,t)=>Ae("PUT",e,t),Rt=(e,t)=>Ae("PUT",e,t,!0),ce=(e,t)=>Ae("PATCH",e,t),Ye=e=>Ae("DELETE",e),U=encodeURIComponent,Ht={get:()=>G("/system"),restart:()=>ue("/system/restart")},Ut={get:()=>G("/config"),update:e=>ce("/config",e)},jt={get:()=>G("/location"),update:e=>ce("/location",e)},ye={all:()=>G("/mqtt"),updateAll:e=>ce("/mqtt",e),update:(e,t)=>ce(`/mqtt/${e}`,t),trust:e=>ue(`/mqtt/${e}/trust`),certificate:e=>G(`/mqtt/${e}/certificate`),forget:e=>Ye(`/mqtt/${e}/certificate`)},ee={get:()=>G("/tls"),update:e=>ce("/tls",e),selfSigned:e=>ue("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Pt}/tls/csr`,installCertificate:e=>Rt("/tls/certificate",e),setTrustAnchor:e=>Rt("/tls/trust-anchor",e),removeTrustAnchor:()=>Ye("/tls/trust-anchor"),setIdentity:e=>Rt("/tls/est/identity",e),removeIdentity:()=>Ye("/tls/est/identity"),enroll:()=>ue("/tls/est/enroll")},B={async list(){let e=[];for(;;){let t=await G(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>G(`/devices/${U(e)}`),update:(e,t)=>ce(`/devices/${U(e)}`,t),action:(e,t)=>ue(`/devices/${U(e)}/${t}`),silence:(e,t)=>oe(`/devices/${U(e)}/silence`,{on:t}),relay:(e,t,n,i)=>oe(`/devices/${U(e)}/relays/${t}`,{state:n,duration_ms:i}),rollershutter:(e,t,n,i)=>oe(`/devices/${U(e)}/rollershutters/${t}`,{state:n,duration_ms:i}),lamps:(e,t,n,i)=>oe(`/devices/${U(e)}/lamps/${t}`,{value:n,bitmask:i}),heating:(e,t,n)=>oe(`/devices/${U(e)}/heating/${t}`,n),heatingManualState:e=>G(`/devices/${U(e)}/heating/manual`),heatingManual:(e,t,n,i)=>oe(`/devices/${U(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:i})},fe={update:(e,t,n)=>oe(`/devices/${U(e)}/sensors/${t}`,n),refresh:e=>ue(`/devices/${U(e)}/sensors/refresh`),forget:e=>ue(`/devices/${U(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${U(e)}`:"",i=await G(`/sensors?offset=${t.length}${n}`);if(t.push(...i.sensors),i.sensors.length===0||t.length>=i.total)return t}}},Te={action:e=>ue(`/bus/${e}`),silence:e=>oe("/bus/silence",{on:e}),typeAction:(e,t)=>ue(`/device-types/${e}/${t}`)},Bt={job:()=>G("/firmware/job"),upload(e,t,n){let i=si.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((r,a)=>{let s=new XMLHttpRequest;s.open("PUT",`${Pt}${o}?crc32=${i}`),s.setRequestHeader("Content-Type","application/octet-stream"),s.upload.onprogress=l=>l.lengthComputable&&n&&n(l.loaded/l.total),s.onload=()=>{let l=null;try{l=JSON.parse(s.responseText)}catch{}s.status>=200&&s.status<300?r(l):a(new Se(s.status,l))},s.onerror=()=>a(new Se(0,{message:"upload failed"})),s.send(t)})}},qt={read:e=>G(`/logs?from=${e}`),setCanToMqtt:e=>ce("/logs",{can_to_mqtt:e})},Dt=e=>({list:()=>G(`/automation/${e}`).then(t=>t.items),get:t=>G(`/automation/${e}/${U(t)}`),put:(t,n)=>oe(`/automation/${e}/${U(t)}`,n),remove:t=>Ye(`/automation/${e}/${U(t)}`)});async function ri(e){let t=[];for(;;){let n=await G(`${e}?offset=${t.length}`);if(t.push(...n.items),n.items.length===0||t.length>=n.total)return t}}var ai=e=>"0x"+(268435456+(e.type<<16)+(e.id<<8)).toString(16),E={status:()=>G("/automation"),setEnabled:e=>ce("/automation",{enabled:e}),outputs:{...Dt("outputs"),command:(e,t)=>ue(`/automation/outputs/${U(e)}/command`,t)},switches:{list:()=>ri("/automation/switches"),get:e=>G(`/automation/switches/${U(e)}`),put:(e,t)=>oe(`/automation/switches/${U(e)}`,t),remove:e=>Ye(`/automation/switches/${U(e)}`),button:(e,t)=>G(`/automation/switches/${U(e)}/${t}`),putButton:(e,t,n)=>oe(`/automation/switches/${U(e)}/${t}`,n)},motion:{...Dt("motion"),setEnabled:(e,t)=>ce(`/automation/motion/${U(e)}`,{enabled:t})},schedules:{...Dt("schedules"),setEnabled:(e,t)=>ce(`/automation/schedules/${U(e)}`,{enabled:t})},devices:{list:()=>ri("/automation/devices"),get:e=>G(`/automation/devices/${ai(e)}`),put:(e,t)=>oe(`/automation/devices/${ai(e)}`,t)}};var at=new Set;function pr(e){e!==location.pathname&&history.pushState(null,"",e),at.forEach(t=>t())}addEventListener("popstate",()=>at.forEach(e=>e()));function li(){let[e,t]=_(location.pathname);return W(()=>{let n=()=>t(location.pathname);return at.add(n),()=>at.delete(n)},[]),e}function ci(e,t){let n=t.split("/").filter(Boolean);for(let i of e){let o=i.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let r={};if(o.every((s,l)=>s.startsWith(":")?(r[s.slice(1)]=decodeURIComponent(n[l]),!0):s===n[l]))return{route:i,params:r}}return null}function X({href:e,children:t,...n}){return je("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),pr(e))},...n},t)}var di=function(e,t,n,i){var o;t[0]=0;for(var r=1;r<t.length;r++){var a=t[r++],s=t[r]?(t[0]|=a?1:2,n[t[r++]]):t[++r];a===3?i[0]=s:a===4?i[1]=Object.assign(i[1]||{},s):a===5?(i[1]=i[1]||{})[t[++r]]=s:a===6?i[1][t[++r]]+=s+"":a?(o=e.apply(s,di(e,s,n,["",null])),i.push(o),s[0]?t[0]|=2:(t[r-2]=0,t[r]=o)):i.push(s)}return i},ui=new Map;function pi(e){var t=ui.get(this);return t||(t=new Map,ui.set(this,t)),(t=di(this,t.get(e)||(t.set(e,t=function(n){for(var i,o,r=1,a="",s="",l=[0],u=function(f){r===1&&(f||(a=a.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?l.push(0,f,a):r===3&&(f||a)?(l.push(3,f,a),r=2):r===2&&a==="..."&&f?l.push(4,f,0):r===2&&a&&!f?l.push(5,0,!0,a):r>=5&&((a||!f&&r===5)&&(l.push(r,0,a,o),r=6),f&&(l.push(r,f,0,o),r=6)),a=""},p=0;p<n.length;p++){p&&(r===1&&u(),u(p));for(var c=0;c<n[p].length;c++)i=n[p][c],r===1?i==="<"?(u(),l=[l],r=3):a+=i:r===4?a==="--"&&i===">"?(r=1,a=""):a=i+a[0]:s?i===s?s="":a+=i:i==='"'||i==="'"?s=i:i===">"?(u(),r=1):r&&(i==="="?(r=5,o=a,a=""):i==="/"&&(r<5||n[p][c+1]===">")?(u(),r===3&&(l=l[0]),r=l,(l=l[0]).push(2,0,r),r=0):i===" "||i==="	"||i===`
`||i==="\r"?(u(),r=2):a+=i),r===3&&a==="!--"&&(r=4,l=l[0])}return u(),l}(e)),t),arguments,[])).length>1?t:t[0]}var d=pi.bind(je),Yt=()=>{};function D(e,t="ok"){Yt(e,t)}function fi(){let[e,t]=_([]);return W(()=>{let n=0;return Yt=(i,o)=>{let r={id:++n,message:i,kind:o};t(a=>[...a,r]),setTimeout(()=>t(a=>a.filter(s=>s!==r)),o==="error"?8e3:3e3)},()=>Yt=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function T(e,t){try{let n=await e();return t&&D(t),n}catch(n){D(n.message,"error");return}}function V(e,t){let[n,i]=_({data:void 0,error:void 0}),o=re(e);o.current=e;let r=ei(async()=>{try{i({data:await o.current(),error:void 0})}catch(a){i(s=>({data:s.data,error:a}))}},[]);return W(()=>{let a=!1,s,l=async()=>{await r(),t&&!a&&(s=setTimeout(l,t))};return l(),()=>{a=!0,clearTimeout(s)}},[t,r]),{...n,reload:r}}var O=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,j=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,L=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,F=({children:e,kind:t,onClick:n,disabled:i})=>{let[o,r]=_(!1);return d`<button class=${t||""} disabled=${i||o} onClick=${async s=>{r(!0);try{await n(s)}finally{r(!1)}}}>${e}</button>`},Wt=e=>"0x"+e.toString(16).padStart(2,"0");function we(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function hi(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),i=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${i} min`:`${i} min`}function Li(e){return typeof e>"u"||e===null}function fr(e){return typeof e=="object"&&e!==null}function hr(e){return Array.isArray(e)?e:Li(e)?[]:[e]}function mr(e,t){var n,i,o,r;if(t)for(r=Object.keys(t),n=0,i=r.length;n<i;n+=1)o=r[n],e[o]=t[o];return e}function $r(e,t){var n="",i;for(i=0;i<t;i+=1)n+=e;return n}function vr(e){return e===0&&Number.NEGATIVE_INFINITY===1/e}var gr=Li,_r=fr,br=hr,yr=$r,wr=vr,kr=mr,Q={isNothing:gr,isObject:_r,toArray:br,repeat:yr,isNegativeZero:wr,extend:kr};function Oi(e,t){var n="",i=e.reason||"(unknown reason)";return e.mark?(e.mark.name&&(n+='in "'+e.mark.name+'" '),n+="("+(e.mark.line+1)+":"+(e.mark.column+1)+")",!t&&e.mark.snippet&&(n+=`

`+e.mark.snippet),i+" "+n):i}function Ke(e,t){Error.call(this),this.name="YAMLException",this.reason=e,this.mark=t,this.message=Oi(this,!1),Error.captureStackTrace?Error.captureStackTrace(this,this.constructor):this.stack=new Error().stack||""}Ke.prototype=Object.create(Error.prototype);Ke.prototype.constructor=Ke;Ke.prototype.toString=function(t){return this.name+": "+Oi(this,t)};var te=Ke;function Kt(e,t,n,i,o){var r="",a="",s=Math.floor(o/2)-1;return i-t>s&&(r=" ... ",t=i-s+r.length),n-i>s&&(a=" ...",n=i+s-a.length),{str:r+e.slice(t,n).replace(/\t/g,"\u2192")+a,pos:i-t+r.length}}function Gt(e,t){return Q.repeat(" ",t-e.length)+e}function xr(e,t){if(t=Object.create(t||null),!e.buffer)return null;t.maxLength||(t.maxLength=79),typeof t.indent!="number"&&(t.indent=1),typeof t.linesBefore!="number"&&(t.linesBefore=3),typeof t.linesAfter!="number"&&(t.linesAfter=2);for(var n=/\r?\n|\r|\0/g,i=[0],o=[],r,a=-1;r=n.exec(e.buffer);)o.push(r.index),i.push(r.index+r[0].length),e.position<=r.index&&a<0&&(a=i.length-2);a<0&&(a=i.length-1);var s="",l,u,p=Math.min(e.line+t.linesAfter,o.length).toString().length,c=t.maxLength-(t.indent+p+3);for(l=1;l<=t.linesBefore&&!(a-l<0);l++)u=Kt(e.buffer,i[a-l],o[a-l],e.position-(i[a]-i[a-l]),c),s=Q.repeat(" ",t.indent)+Gt((e.line-l+1).toString(),p)+" | "+u.str+`
`+s;for(u=Kt(e.buffer,i[a],o[a],e.position,c),s+=Q.repeat(" ",t.indent)+Gt((e.line+1).toString(),p)+" | "+u.str+`
`,s+=Q.repeat("-",t.indent+p+3+u.pos)+`^
`,l=1;l<=t.linesAfter&&!(a+l>=o.length);l++)u=Kt(e.buffer,i[a+l],o[a+l],e.position-(i[a]-i[a+l]),c),s+=Q.repeat(" ",t.indent)+Gt((e.line+l+1).toString(),p)+" | "+u.str+`
`;return s.replace(/\n$/,"")}var Cr=xr,Sr=["kind","multi","resolve","construct","instanceOf","predicate","represent","representName","defaultStyle","styleAliases"],Ar=["scalar","sequence","mapping"];function Tr(e){var t={};return e!==null&&Object.keys(e).forEach(function(n){e[n].forEach(function(i){t[String(i)]=n})}),t}function Er(e,t){if(t=t||{},Object.keys(t).forEach(function(n){if(Sr.indexOf(n)===-1)throw new te('Unknown option "'+n+'" is met in definition of "'+e+'" YAML type.')}),this.options=t,this.tag=e,this.kind=t.kind||null,this.resolve=t.resolve||function(){return!0},this.construct=t.construct||function(n){return n},this.instanceOf=t.instanceOf||null,this.predicate=t.predicate||null,this.represent=t.represent||null,this.representName=t.representName||null,this.defaultStyle=t.defaultStyle||null,this.multi=t.multi||!1,this.styleAliases=Tr(t.styleAliases||null),Ar.indexOf(this.kind)===-1)throw new te('Unknown kind "'+this.kind+'" is specified for "'+e+'" YAML type.')}var z=Er;function mi(e,t){var n=[];return e[t].forEach(function(i){var o=n.length;n.forEach(function(r,a){r.tag===i.tag&&r.kind===i.kind&&r.multi===i.multi&&(o=a)}),n[o]=i}),n}function Lr(){var e={scalar:{},sequence:{},mapping:{},fallback:{},multi:{scalar:[],sequence:[],mapping:[],fallback:[]}},t,n;function i(o){o.multi?(e.multi[o.kind].push(o),e.multi.fallback.push(o)):e[o.kind][o.tag]=e.fallback[o.tag]=o}for(t=0,n=arguments.length;t<n;t+=1)arguments[t].forEach(i);return e}function Qt(e){return this.extend(e)}Qt.prototype.extend=function(t){var n=[],i=[];if(t instanceof z)i.push(t);else if(Array.isArray(t))i=i.concat(t);else if(t&&(Array.isArray(t.implicit)||Array.isArray(t.explicit)))t.implicit&&(n=n.concat(t.implicit)),t.explicit&&(i=i.concat(t.explicit));else throw new te("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");n.forEach(function(r){if(!(r instanceof z))throw new te("Specified list of YAML types (or a single Type object) contains a non-Type object.");if(r.loadKind&&r.loadKind!=="scalar")throw new te("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");if(r.multi)throw new te("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.")}),i.forEach(function(r){if(!(r instanceof z))throw new te("Specified list of YAML types (or a single Type object) contains a non-Type object.")});var o=Object.create(Qt.prototype);return o.implicit=(this.implicit||[]).concat(n),o.explicit=(this.explicit||[]).concat(i),o.compiledImplicit=mi(o,"implicit"),o.compiledExplicit=mi(o,"explicit"),o.compiledTypeMap=Lr(o.compiledImplicit,o.compiledExplicit),o};var Or=Qt,Fr=new z("tag:yaml.org,2002:str",{kind:"scalar",construct:function(e){return e!==null?e:""}}),Ir=new z("tag:yaml.org,2002:seq",{kind:"sequence",construct:function(e){return e!==null?e:[]}}),Nr=new z("tag:yaml.org,2002:map",{kind:"mapping",construct:function(e){return e!==null?e:{}}}),Mr=new Or({explicit:[Fr,Ir,Nr]});function Rr(e){if(e===null)return!0;var t=e.length;return t===1&&e==="~"||t===4&&(e==="null"||e==="Null"||e==="NULL")}function Dr(){return null}function Pr(e){return e===null}var Hr=new z("tag:yaml.org,2002:null",{kind:"scalar",resolve:Rr,construct:Dr,predicate:Pr,represent:{canonical:function(){return"~"},lowercase:function(){return"null"},uppercase:function(){return"NULL"},camelcase:function(){return"Null"},empty:function(){return""}},defaultStyle:"lowercase"});function Ur(e){if(e===null)return!1;var t=e.length;return t===4&&(e==="true"||e==="True"||e==="TRUE")||t===5&&(e==="false"||e==="False"||e==="FALSE")}function jr(e){return e==="true"||e==="True"||e==="TRUE"}function Br(e){return Object.prototype.toString.call(e)==="[object Boolean]"}var qr=new z("tag:yaml.org,2002:bool",{kind:"scalar",resolve:Ur,construct:jr,predicate:Br,represent:{lowercase:function(e){return e?"true":"false"},uppercase:function(e){return e?"TRUE":"FALSE"},camelcase:function(e){return e?"True":"False"}},defaultStyle:"lowercase"});function Yr(e){return 48<=e&&e<=57||65<=e&&e<=70||97<=e&&e<=102}function Wr(e){return 48<=e&&e<=55}function Kr(e){return 48<=e&&e<=57}function Gr(e){if(e===null)return!1;var t=e.length,n=0,i=!1,o;if(!t)return!1;if(o=e[n],(o==="-"||o==="+")&&(o=e[++n]),o==="0"){if(n+1===t)return!0;if(o=e[++n],o==="b"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(o!=="0"&&o!=="1")return!1;i=!0}return i&&o!=="_"}if(o==="x"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(!Yr(e.charCodeAt(n)))return!1;i=!0}return i&&o!=="_"}if(o==="o"){for(n++;n<t;n++)if(o=e[n],o!=="_"){if(!Wr(e.charCodeAt(n)))return!1;i=!0}return i&&o!=="_"}}if(o==="_")return!1;for(;n<t;n++)if(o=e[n],o!=="_"){if(!Kr(e.charCodeAt(n)))return!1;i=!0}return!(!i||o==="_")}function Vr(e){var t=e,n=1,i;if(t.indexOf("_")!==-1&&(t=t.replace(/_/g,"")),i=t[0],(i==="-"||i==="+")&&(i==="-"&&(n=-1),t=t.slice(1),i=t[0]),t==="0")return 0;if(i==="0"){if(t[1]==="b")return n*parseInt(t.slice(2),2);if(t[1]==="x")return n*parseInt(t.slice(2),16);if(t[1]==="o")return n*parseInt(t.slice(2),8)}return n*parseInt(t,10)}function Qr(e){return Object.prototype.toString.call(e)==="[object Number]"&&e%1===0&&!Q.isNegativeZero(e)}var Xr=new z("tag:yaml.org,2002:int",{kind:"scalar",resolve:Gr,construct:Vr,predicate:Qr,represent:{binary:function(e){return e>=0?"0b"+e.toString(2):"-0b"+e.toString(2).slice(1)},octal:function(e){return e>=0?"0o"+e.toString(8):"-0o"+e.toString(8).slice(1)},decimal:function(e){return e.toString(10)},hexadecimal:function(e){return e>=0?"0x"+e.toString(16).toUpperCase():"-0x"+e.toString(16).toUpperCase().slice(1)}},defaultStyle:"decimal",styleAliases:{binary:[2,"bin"],octal:[8,"oct"],decimal:[10,"dec"],hexadecimal:[16,"hex"]}}),zr=new RegExp("^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");function Jr(e){return!(e===null||!zr.test(e)||e[e.length-1]==="_")}function Zr(e){var t,n;return t=e.replace(/_/g,"").toLowerCase(),n=t[0]==="-"?-1:1,"+-".indexOf(t[0])>=0&&(t=t.slice(1)),t===".inf"?n===1?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY:t===".nan"?NaN:n*parseFloat(t,10)}var ea=/^[-+]?[0-9]+e/;function ta(e,t){var n;if(isNaN(e))switch(t){case"lowercase":return".nan";case"uppercase":return".NAN";case"camelcase":return".NaN"}else if(Number.POSITIVE_INFINITY===e)switch(t){case"lowercase":return".inf";case"uppercase":return".INF";case"camelcase":return".Inf"}else if(Number.NEGATIVE_INFINITY===e)switch(t){case"lowercase":return"-.inf";case"uppercase":return"-.INF";case"camelcase":return"-.Inf"}else if(Q.isNegativeZero(e))return"-0.0";return n=e.toString(10),ea.test(n)?n.replace("e",".e"):n}function na(e){return Object.prototype.toString.call(e)==="[object Number]"&&(e%1!==0||Q.isNegativeZero(e))}var ia=new z("tag:yaml.org,2002:float",{kind:"scalar",resolve:Jr,construct:Zr,predicate:na,represent:ta,defaultStyle:"lowercase"}),oa=Mr.extend({implicit:[Hr,qr,Xr,ia]}),ra=oa,Fi=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"),Ii=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");function aa(e){return e===null?!1:Fi.exec(e)!==null||Ii.exec(e)!==null}function sa(e){var t,n,i,o,r,a,s,l=0,u=null,p,c,f;if(t=Fi.exec(e),t===null&&(t=Ii.exec(e)),t===null)throw new Error("Date resolve error");if(n=+t[1],i=+t[2]-1,o=+t[3],!t[4])return new Date(Date.UTC(n,i,o));if(r=+t[4],a=+t[5],s=+t[6],t[7]){for(l=t[7].slice(0,3);l.length<3;)l+="0";l=+l}return t[9]&&(p=+t[10],c=+(t[11]||0),u=(p*60+c)*6e4,t[9]==="-"&&(u=-u)),f=new Date(Date.UTC(n,i,o,r,a,s,l)),u&&f.setTime(f.getTime()-u),f}function la(e){return e.toISOString()}var ca=new z("tag:yaml.org,2002:timestamp",{kind:"scalar",resolve:aa,construct:sa,instanceOf:Date,represent:la});function ua(e){return e==="<<"||e===null}var da=new z("tag:yaml.org,2002:merge",{kind:"scalar",resolve:ua}),en=`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;function pa(e){if(e===null)return!1;var t,n,i=0,o=e.length,r=en;for(n=0;n<o;n++)if(t=r.indexOf(e.charAt(n)),!(t>64)){if(t<0)return!1;i+=6}return i%8===0}function fa(e){var t,n,i=e.replace(/[\r\n=]/g,""),o=i.length,r=en,a=0,s=[];for(t=0;t<o;t++)t%4===0&&t&&(s.push(a>>16&255),s.push(a>>8&255),s.push(a&255)),a=a<<6|r.indexOf(i.charAt(t));return n=o%4*6,n===0?(s.push(a>>16&255),s.push(a>>8&255),s.push(a&255)):n===18?(s.push(a>>10&255),s.push(a>>2&255)):n===12&&s.push(a>>4&255),new Uint8Array(s)}function ha(e){var t="",n=0,i,o,r=e.length,a=en;for(i=0;i<r;i++)i%3===0&&i&&(t+=a[n>>18&63],t+=a[n>>12&63],t+=a[n>>6&63],t+=a[n&63]),n=(n<<8)+e[i];return o=r%3,o===0?(t+=a[n>>18&63],t+=a[n>>12&63],t+=a[n>>6&63],t+=a[n&63]):o===2?(t+=a[n>>10&63],t+=a[n>>4&63],t+=a[n<<2&63],t+=a[64]):o===1&&(t+=a[n>>2&63],t+=a[n<<4&63],t+=a[64],t+=a[64]),t}function ma(e){return Object.prototype.toString.call(e)==="[object Uint8Array]"}var $a=new z("tag:yaml.org,2002:binary",{kind:"scalar",resolve:pa,construct:fa,predicate:ma,represent:ha}),va=Object.prototype.hasOwnProperty,ga=Object.prototype.toString;function _a(e){if(e===null)return!0;var t=[],n,i,o,r,a,s=e;for(n=0,i=s.length;n<i;n+=1){if(o=s[n],a=!1,ga.call(o)!=="[object Object]")return!1;for(r in o)if(va.call(o,r))if(!a)a=!0;else return!1;if(!a)return!1;if(t.indexOf(r)===-1)t.push(r);else return!1}return!0}function ba(e){return e!==null?e:[]}var ya=new z("tag:yaml.org,2002:omap",{kind:"sequence",resolve:_a,construct:ba}),wa=Object.prototype.toString;function ka(e){if(e===null)return!0;var t,n,i,o,r,a=e;for(r=new Array(a.length),t=0,n=a.length;t<n;t+=1){if(i=a[t],wa.call(i)!=="[object Object]"||(o=Object.keys(i),o.length!==1))return!1;r[t]=[o[0],i[o[0]]]}return!0}function xa(e){if(e===null)return[];var t,n,i,o,r,a=e;for(r=new Array(a.length),t=0,n=a.length;t<n;t+=1)i=a[t],o=Object.keys(i),r[t]=[o[0],i[o[0]]];return r}var Ca=new z("tag:yaml.org,2002:pairs",{kind:"sequence",resolve:ka,construct:xa}),Sa=Object.prototype.hasOwnProperty;function Aa(e){if(e===null)return!0;var t,n=e;for(t in n)if(Sa.call(n,t)&&n[t]!==null)return!1;return!0}function Ta(e){return e!==null?e:{}}var Ea=new z("tag:yaml.org,2002:set",{kind:"mapping",resolve:Aa,construct:Ta}),Ni=ra.extend({implicit:[ca,da],explicit:[$a,ya,Ca,Ea]}),ve=Object.prototype.hasOwnProperty,st=1,Mi=2,Ri=3,lt=4,Vt=1,La=2,$i=3,Oa=/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/,Fa=/[\x85\u2028\u2029]/,Ia=/[,\[\]\{\}]/,Di=/^(?:!|!!|![a-z\-]+!)$/i,Pi=/^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;function vi(e){return Object.prototype.toString.call(e)}function de(e){return e===10||e===13}function xe(e){return e===9||e===32}function ne(e){return e===9||e===32||e===10||e===13}function Le(e){return e===44||e===91||e===93||e===123||e===125}function Na(e){var t;return 48<=e&&e<=57?e-48:(t=e|32,97<=t&&t<=102?t-97+10:-1)}function Ma(e){return e===120?2:e===117?4:e===85?8:0}function Ra(e){return 48<=e&&e<=57?e-48:-1}function gi(e){return e===48?"\0":e===97?"\x07":e===98?"\b":e===116||e===9?"	":e===110?`
`:e===118?"\v":e===102?"\f":e===114?"\r":e===101?"\x1B":e===32?" ":e===34?'"':e===47?"/":e===92?"\\":e===78?"\x85":e===95?"\xA0":e===76?"\u2028":e===80?"\u2029":""}function Da(e){return e<=65535?String.fromCharCode(e):String.fromCharCode((e-65536>>10)+55296,(e-65536&1023)+56320)}var Hi=new Array(256),Ui=new Array(256);for(ke=0;ke<256;ke++)Hi[ke]=gi(ke)?1:0,Ui[ke]=gi(ke);var ke;function Pa(e,t){this.input=e,this.filename=t.filename||null,this.schema=t.schema||Ni,this.onWarning=t.onWarning||null,this.legacy=t.legacy||!1,this.json=t.json||!1,this.listener=t.listener||null,this.implicitTypes=this.schema.compiledImplicit,this.typeMap=this.schema.compiledTypeMap,this.length=e.length,this.position=0,this.line=0,this.lineStart=0,this.lineIndent=0,this.firstTabInLine=-1,this.documents=[]}function ji(e,t){var n={name:e.filename,buffer:e.input.slice(0,-1),position:e.position,line:e.line,column:e.position-e.lineStart};return n.snippet=Cr(n),new te(t,n)}function C(e,t){throw ji(e,t)}function ct(e,t){e.onWarning&&e.onWarning.call(null,ji(e,t))}var _i={YAML:function(t,n,i){var o,r,a;t.version!==null&&C(t,"duplication of %YAML directive"),i.length!==1&&C(t,"YAML directive accepts exactly one argument"),o=/^([0-9]+)\.([0-9]+)$/.exec(i[0]),o===null&&C(t,"ill-formed argument of the YAML directive"),r=parseInt(o[1],10),a=parseInt(o[2],10),r!==1&&C(t,"unacceptable YAML version of the document"),t.version=i[0],t.checkLineBreaks=a<2,a!==1&&a!==2&&ct(t,"unsupported YAML version of the document")},TAG:function(t,n,i){var o,r;i.length!==2&&C(t,"TAG directive accepts exactly two arguments"),o=i[0],r=i[1],Di.test(o)||C(t,"ill-formed tag handle (first argument) of the TAG directive"),ve.call(t.tagMap,o)&&C(t,'there is a previously declared suffix for "'+o+'" tag handle'),Pi.test(r)||C(t,"ill-formed tag prefix (second argument) of the TAG directive");try{r=decodeURIComponent(r)}catch{C(t,"tag prefix is malformed: "+r)}t.tagMap[o]=r}};function $e(e,t,n,i){var o,r,a,s;if(t<n){if(s=e.input.slice(t,n),i)for(o=0,r=s.length;o<r;o+=1)a=s.charCodeAt(o),a===9||32<=a&&a<=1114111||C(e,"expected valid JSON character");else Oa.test(s)&&C(e,"the stream contains non-printable characters");e.result+=s}}function bi(e,t,n,i){var o,r,a,s;for(Q.isObject(n)||C(e,"cannot merge mappings; the provided source object is unacceptable"),o=Object.keys(n),a=0,s=o.length;a<s;a+=1)r=o[a],ve.call(t,r)||(t[r]=n[r],i[r]=!0)}function Oe(e,t,n,i,o,r,a,s,l){var u,p;if(Array.isArray(o))for(o=Array.prototype.slice.call(o),u=0,p=o.length;u<p;u+=1)Array.isArray(o[u])&&C(e,"nested arrays are not supported inside keys"),typeof o=="object"&&vi(o[u])==="[object Object]"&&(o[u]="[object Object]");if(typeof o=="object"&&vi(o)==="[object Object]"&&(o="[object Object]"),o=String(o),t===null&&(t={}),i==="tag:yaml.org,2002:merge")if(Array.isArray(r))for(u=0,p=r.length;u<p;u+=1)bi(e,t,r[u],n);else bi(e,t,r,n);else!e.json&&!ve.call(n,o)&&ve.call(t,o)&&(e.line=a||e.line,e.lineStart=s||e.lineStart,e.position=l||e.position,C(e,"duplicated mapping key")),o==="__proto__"?Object.defineProperty(t,o,{configurable:!0,enumerable:!0,writable:!0,value:r}):t[o]=r,delete n[o];return t}function tn(e){var t;t=e.input.charCodeAt(e.position),t===10?e.position++:t===13?(e.position++,e.input.charCodeAt(e.position)===10&&e.position++):C(e,"a line break is expected"),e.line+=1,e.lineStart=e.position,e.firstTabInLine=-1}function K(e,t,n){for(var i=0,o=e.input.charCodeAt(e.position);o!==0;){for(;xe(o);)o===9&&e.firstTabInLine===-1&&(e.firstTabInLine=e.position),o=e.input.charCodeAt(++e.position);if(t&&o===35)do o=e.input.charCodeAt(++e.position);while(o!==10&&o!==13&&o!==0);if(de(o))for(tn(e),o=e.input.charCodeAt(e.position),i++,e.lineIndent=0;o===32;)e.lineIndent++,o=e.input.charCodeAt(++e.position);else break}return n!==-1&&i!==0&&e.lineIndent<n&&ct(e,"deficient indentation"),i}function pt(e){var t=e.position,n;return n=e.input.charCodeAt(t),!!((n===45||n===46)&&n===e.input.charCodeAt(t+1)&&n===e.input.charCodeAt(t+2)&&(t+=3,n=e.input.charCodeAt(t),n===0||ne(n)))}function nn(e,t){t===1?e.result+=" ":t>1&&(e.result+=Q.repeat(`
`,t-1))}function Ha(e,t,n){var i,o,r,a,s,l,u,p,c=e.kind,f=e.result,h;if(h=e.input.charCodeAt(e.position),ne(h)||Le(h)||h===35||h===38||h===42||h===33||h===124||h===62||h===39||h===34||h===37||h===64||h===96||(h===63||h===45)&&(o=e.input.charCodeAt(e.position+1),ne(o)||n&&Le(o)))return!1;for(e.kind="scalar",e.result="",r=a=e.position,s=!1;h!==0;){if(h===58){if(o=e.input.charCodeAt(e.position+1),ne(o)||n&&Le(o))break}else if(h===35){if(i=e.input.charCodeAt(e.position-1),ne(i))break}else{if(e.position===e.lineStart&&pt(e)||n&&Le(h))break;if(de(h))if(l=e.line,u=e.lineStart,p=e.lineIndent,K(e,!1,-1),e.lineIndent>=t){s=!0,h=e.input.charCodeAt(e.position);continue}else{e.position=a,e.line=l,e.lineStart=u,e.lineIndent=p;break}}s&&($e(e,r,a,!1),nn(e,e.line-l),r=a=e.position,s=!1),xe(h)||(a=e.position+1),h=e.input.charCodeAt(++e.position)}return $e(e,r,a,!1),e.result?!0:(e.kind=c,e.result=f,!1)}function Ua(e,t){var n,i,o;if(n=e.input.charCodeAt(e.position),n!==39)return!1;for(e.kind="scalar",e.result="",e.position++,i=o=e.position;(n=e.input.charCodeAt(e.position))!==0;)if(n===39)if($e(e,i,e.position,!0),n=e.input.charCodeAt(++e.position),n===39)i=e.position,e.position++,o=e.position;else return!0;else de(n)?($e(e,i,o,!0),nn(e,K(e,!1,t)),i=o=e.position):e.position===e.lineStart&&pt(e)?C(e,"unexpected end of the document within a single quoted scalar"):(e.position++,o=e.position);C(e,"unexpected end of the stream within a single quoted scalar")}function ja(e,t){var n,i,o,r,a,s;if(s=e.input.charCodeAt(e.position),s!==34)return!1;for(e.kind="scalar",e.result="",e.position++,n=i=e.position;(s=e.input.charCodeAt(e.position))!==0;){if(s===34)return $e(e,n,e.position,!0),e.position++,!0;if(s===92){if($e(e,n,e.position,!0),s=e.input.charCodeAt(++e.position),de(s))K(e,!1,t);else if(s<256&&Hi[s])e.result+=Ui[s],e.position++;else if((a=Ma(s))>0){for(o=a,r=0;o>0;o--)s=e.input.charCodeAt(++e.position),(a=Na(s))>=0?r=(r<<4)+a:C(e,"expected hexadecimal character");e.result+=Da(r),e.position++}else C(e,"unknown escape sequence");n=i=e.position}else de(s)?($e(e,n,i,!0),nn(e,K(e,!1,t)),n=i=e.position):e.position===e.lineStart&&pt(e)?C(e,"unexpected end of the document within a double quoted scalar"):(e.position++,i=e.position)}C(e,"unexpected end of the stream within a double quoted scalar")}function Ba(e,t){var n=!0,i,o,r,a=e.tag,s,l=e.anchor,u,p,c,f,h,v=Object.create(null),y,g,m,$;if($=e.input.charCodeAt(e.position),$===91)p=93,h=!1,s=[];else if($===123)p=125,h=!0,s={};else return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=s),$=e.input.charCodeAt(++e.position);$!==0;){if(K(e,!0,t),$=e.input.charCodeAt(e.position),$===p)return e.position++,e.tag=a,e.anchor=l,e.kind=h?"mapping":"sequence",e.result=s,!0;n?$===44&&C(e,"expected the node content, but found ','"):C(e,"missed comma between flow collection entries"),g=y=m=null,c=f=!1,$===63&&(u=e.input.charCodeAt(e.position+1),ne(u)&&(c=f=!0,e.position++,K(e,!0,t))),i=e.line,o=e.lineStart,r=e.position,Fe(e,t,st,!1,!0),g=e.tag,y=e.result,K(e,!0,t),$=e.input.charCodeAt(e.position),(f||e.line===i)&&$===58&&(c=!0,$=e.input.charCodeAt(++e.position),K(e,!0,t),Fe(e,t,st,!1,!0),m=e.result),h?Oe(e,s,v,g,y,m,i,o,r):c?s.push(Oe(e,null,v,g,y,m,i,o,r)):s.push(y),K(e,!0,t),$=e.input.charCodeAt(e.position),$===44?(n=!0,$=e.input.charCodeAt(++e.position)):n=!1}C(e,"unexpected end of the stream within a flow collection")}function qa(e,t){var n,i,o=Vt,r=!1,a=!1,s=t,l=0,u=!1,p,c;if(c=e.input.charCodeAt(e.position),c===124)i=!1;else if(c===62)i=!0;else return!1;for(e.kind="scalar",e.result="";c!==0;)if(c=e.input.charCodeAt(++e.position),c===43||c===45)Vt===o?o=c===43?$i:La:C(e,"repeat of a chomping mode identifier");else if((p=Ra(c))>=0)p===0?C(e,"bad explicit indentation width of a block scalar; it cannot be less than one"):a?C(e,"repeat of an indentation width identifier"):(s=t+p-1,a=!0);else break;if(xe(c)){do c=e.input.charCodeAt(++e.position);while(xe(c));if(c===35)do c=e.input.charCodeAt(++e.position);while(!de(c)&&c!==0)}for(;c!==0;){for(tn(e),e.lineIndent=0,c=e.input.charCodeAt(e.position);(!a||e.lineIndent<s)&&c===32;)e.lineIndent++,c=e.input.charCodeAt(++e.position);if(!a&&e.lineIndent>s&&(s=e.lineIndent),de(c)){l++;continue}if(e.lineIndent<s){o===$i?e.result+=Q.repeat(`
`,r?1+l:l):o===Vt&&r&&(e.result+=`
`);break}for(i?xe(c)?(u=!0,e.result+=Q.repeat(`
`,r?1+l:l)):u?(u=!1,e.result+=Q.repeat(`
`,l+1)):l===0?r&&(e.result+=" "):e.result+=Q.repeat(`
`,l):e.result+=Q.repeat(`
`,r?1+l:l),r=!0,a=!0,l=0,n=e.position;!de(c)&&c!==0;)c=e.input.charCodeAt(++e.position);$e(e,n,e.position,!1)}return!0}function yi(e,t){var n,i=e.tag,o=e.anchor,r=[],a,s=!1,l;if(e.firstTabInLine!==-1)return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=r),l=e.input.charCodeAt(e.position);l!==0&&(e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,C(e,"tab characters must not be used in indentation")),!(l!==45||(a=e.input.charCodeAt(e.position+1),!ne(a))));){if(s=!0,e.position++,K(e,!0,-1)&&e.lineIndent<=t){r.push(null),l=e.input.charCodeAt(e.position);continue}if(n=e.line,Fe(e,t,Ri,!1,!0),r.push(e.result),K(e,!0,-1),l=e.input.charCodeAt(e.position),(e.line===n||e.lineIndent>t)&&l!==0)C(e,"bad indentation of a sequence entry");else if(e.lineIndent<t)break}return s?(e.tag=i,e.anchor=o,e.kind="sequence",e.result=r,!0):!1}function Ya(e,t,n){var i,o,r,a,s,l,u=e.tag,p=e.anchor,c={},f=Object.create(null),h=null,v=null,y=null,g=!1,m=!1,$;if(e.firstTabInLine!==-1)return!1;for(e.anchor!==null&&(e.anchorMap[e.anchor]=c),$=e.input.charCodeAt(e.position);$!==0;){if(!g&&e.firstTabInLine!==-1&&(e.position=e.firstTabInLine,C(e,"tab characters must not be used in indentation")),i=e.input.charCodeAt(e.position+1),r=e.line,($===63||$===58)&&ne(i))$===63?(g&&(Oe(e,c,f,h,v,null,a,s,l),h=v=y=null),m=!0,g=!0,o=!0):g?(g=!1,o=!0):C(e,"incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"),e.position+=1,$=i;else{if(a=e.line,s=e.lineStart,l=e.position,!Fe(e,n,Mi,!1,!0))break;if(e.line===r){for($=e.input.charCodeAt(e.position);xe($);)$=e.input.charCodeAt(++e.position);if($===58)$=e.input.charCodeAt(++e.position),ne($)||C(e,"a whitespace character is expected after the key-value separator within a block mapping"),g&&(Oe(e,c,f,h,v,null,a,s,l),h=v=y=null),m=!0,g=!1,o=!1,h=e.tag,v=e.result;else if(m)C(e,"can not read an implicit mapping pair; a colon is missed");else return e.tag=u,e.anchor=p,!0}else if(m)C(e,"can not read a block mapping entry; a multiline key may not be an implicit key");else return e.tag=u,e.anchor=p,!0}if((e.line===r||e.lineIndent>t)&&(g&&(a=e.line,s=e.lineStart,l=e.position),Fe(e,t,lt,!0,o)&&(g?v=e.result:y=e.result),g||(Oe(e,c,f,h,v,y,a,s,l),h=v=y=null),K(e,!0,-1),$=e.input.charCodeAt(e.position)),(e.line===r||e.lineIndent>t)&&$!==0)C(e,"bad indentation of a mapping entry");else if(e.lineIndent<t)break}return g&&Oe(e,c,f,h,v,null,a,s,l),m&&(e.tag=u,e.anchor=p,e.kind="mapping",e.result=c),m}function Wa(e){var t,n=!1,i=!1,o,r,a;if(a=e.input.charCodeAt(e.position),a!==33)return!1;if(e.tag!==null&&C(e,"duplication of a tag property"),a=e.input.charCodeAt(++e.position),a===60?(n=!0,a=e.input.charCodeAt(++e.position)):a===33?(i=!0,o="!!",a=e.input.charCodeAt(++e.position)):o="!",t=e.position,n){do a=e.input.charCodeAt(++e.position);while(a!==0&&a!==62);e.position<e.length?(r=e.input.slice(t,e.position),a=e.input.charCodeAt(++e.position)):C(e,"unexpected end of the stream within a verbatim tag")}else{for(;a!==0&&!ne(a);)a===33&&(i?C(e,"tag suffix cannot contain exclamation marks"):(o=e.input.slice(t-1,e.position+1),Di.test(o)||C(e,"named tag handle cannot contain such characters"),i=!0,t=e.position+1)),a=e.input.charCodeAt(++e.position);r=e.input.slice(t,e.position),Ia.test(r)&&C(e,"tag suffix cannot contain flow indicator characters")}r&&!Pi.test(r)&&C(e,"tag name cannot contain such characters: "+r);try{r=decodeURIComponent(r)}catch{C(e,"tag name is malformed: "+r)}return n?e.tag=r:ve.call(e.tagMap,o)?e.tag=e.tagMap[o]+r:o==="!"?e.tag="!"+r:o==="!!"?e.tag="tag:yaml.org,2002:"+r:C(e,'undeclared tag handle "'+o+'"'),!0}function Ka(e){var t,n;if(n=e.input.charCodeAt(e.position),n!==38)return!1;for(e.anchor!==null&&C(e,"duplication of an anchor property"),n=e.input.charCodeAt(++e.position),t=e.position;n!==0&&!ne(n)&&!Le(n);)n=e.input.charCodeAt(++e.position);return e.position===t&&C(e,"name of an anchor node must contain at least one character"),e.anchor=e.input.slice(t,e.position),!0}function Ga(e){var t,n,i;if(i=e.input.charCodeAt(e.position),i!==42)return!1;for(i=e.input.charCodeAt(++e.position),t=e.position;i!==0&&!ne(i)&&!Le(i);)i=e.input.charCodeAt(++e.position);return e.position===t&&C(e,"name of an alias node must contain at least one character"),n=e.input.slice(t,e.position),ve.call(e.anchorMap,n)||C(e,'unidentified alias "'+n+'"'),e.result=e.anchorMap[n],K(e,!0,-1),!0}function Fe(e,t,n,i,o){var r,a,s,l=1,u=!1,p=!1,c,f,h,v,y,g;if(e.listener!==null&&e.listener("open",e),e.tag=null,e.anchor=null,e.kind=null,e.result=null,r=a=s=lt===n||Ri===n,i&&K(e,!0,-1)&&(u=!0,e.lineIndent>t?l=1:e.lineIndent===t?l=0:e.lineIndent<t&&(l=-1)),l===1)for(;Wa(e)||Ka(e);)K(e,!0,-1)?(u=!0,s=r,e.lineIndent>t?l=1:e.lineIndent===t?l=0:e.lineIndent<t&&(l=-1)):s=!1;if(s&&(s=u||o),(l===1||lt===n)&&(st===n||Mi===n?y=t:y=t+1,g=e.position-e.lineStart,l===1?s&&(yi(e,g)||Ya(e,g,y))||Ba(e,y)?p=!0:(a&&qa(e,y)||Ua(e,y)||ja(e,y)?p=!0:Ga(e)?(p=!0,(e.tag!==null||e.anchor!==null)&&C(e,"alias node should not have any properties")):Ha(e,y,st===n)&&(p=!0,e.tag===null&&(e.tag="?")),e.anchor!==null&&(e.anchorMap[e.anchor]=e.result)):l===0&&(p=s&&yi(e,g))),e.tag===null)e.anchor!==null&&(e.anchorMap[e.anchor]=e.result);else if(e.tag==="?"){for(e.result!==null&&e.kind!=="scalar"&&C(e,'unacceptable node kind for !<?> tag; it should be "scalar", not "'+e.kind+'"'),c=0,f=e.implicitTypes.length;c<f;c+=1)if(v=e.implicitTypes[c],v.resolve(e.result)){e.result=v.construct(e.result),e.tag=v.tag,e.anchor!==null&&(e.anchorMap[e.anchor]=e.result);break}}else if(e.tag!=="!"){if(ve.call(e.typeMap[e.kind||"fallback"],e.tag))v=e.typeMap[e.kind||"fallback"][e.tag];else for(v=null,h=e.typeMap.multi[e.kind||"fallback"],c=0,f=h.length;c<f;c+=1)if(e.tag.slice(0,h[c].tag.length)===h[c].tag){v=h[c];break}v||C(e,"unknown tag !<"+e.tag+">"),e.result!==null&&v.kind!==e.kind&&C(e,"unacceptable node kind for !<"+e.tag+'> tag; it should be "'+v.kind+'", not "'+e.kind+'"'),v.resolve(e.result,e.tag)?(e.result=v.construct(e.result,e.tag),e.anchor!==null&&(e.anchorMap[e.anchor]=e.result)):C(e,"cannot resolve a node with !<"+e.tag+"> explicit tag")}return e.listener!==null&&e.listener("close",e),e.tag!==null||e.anchor!==null||p}function Va(e){var t=e.position,n,i,o,r=!1,a;for(e.version=null,e.checkLineBreaks=e.legacy,e.tagMap=Object.create(null),e.anchorMap=Object.create(null);(a=e.input.charCodeAt(e.position))!==0&&(K(e,!0,-1),a=e.input.charCodeAt(e.position),!(e.lineIndent>0||a!==37));){for(r=!0,a=e.input.charCodeAt(++e.position),n=e.position;a!==0&&!ne(a);)a=e.input.charCodeAt(++e.position);for(i=e.input.slice(n,e.position),o=[],i.length<1&&C(e,"directive name must not be less than one character in length");a!==0;){for(;xe(a);)a=e.input.charCodeAt(++e.position);if(a===35){do a=e.input.charCodeAt(++e.position);while(a!==0&&!de(a));break}if(de(a))break;for(n=e.position;a!==0&&!ne(a);)a=e.input.charCodeAt(++e.position);o.push(e.input.slice(n,e.position))}a!==0&&tn(e),ve.call(_i,i)?_i[i](e,i,o):ct(e,'unknown document directive "'+i+'"')}if(K(e,!0,-1),e.lineIndent===0&&e.input.charCodeAt(e.position)===45&&e.input.charCodeAt(e.position+1)===45&&e.input.charCodeAt(e.position+2)===45?(e.position+=3,K(e,!0,-1)):r&&C(e,"directives end mark is expected"),Fe(e,e.lineIndent-1,lt,!1,!0),K(e,!0,-1),e.checkLineBreaks&&Fa.test(e.input.slice(t,e.position))&&ct(e,"non-ASCII line breaks are interpreted as content"),e.documents.push(e.result),e.position===e.lineStart&&pt(e)){e.input.charCodeAt(e.position)===46&&(e.position+=3,K(e,!0,-1));return}if(e.position<e.length-1)C(e,"end of the stream or a document separator is expected");else return}function Bi(e,t){e=String(e),t=t||{},e.length!==0&&(e.charCodeAt(e.length-1)!==10&&e.charCodeAt(e.length-1)!==13&&(e+=`
`),e.charCodeAt(0)===65279&&(e=e.slice(1)));var n=new Pa(e,t),i=e.indexOf("\0");for(i!==-1&&(n.position=i,C(n,"null byte is not allowed in input")),n.input+="\0";n.input.charCodeAt(n.position)===32;)n.lineIndent+=1,n.position+=1;for(;n.position<n.length-1;)Va(n);return n.documents}function Qa(e,t,n){t!==null&&typeof t=="object"&&typeof n>"u"&&(n=t,t=null);var i=Bi(e,n);if(typeof t!="function")return i;for(var o=0,r=i.length;o<r;o+=1)t(i[o])}function Xa(e,t){var n=Bi(e,t);if(n.length!==0){if(n.length===1)return n[0];throw new te("expected a single document in the stream, but found more")}}var za=Qa,Ja=Xa,qi={loadAll:za,load:Ja},Yi=Object.prototype.toString,Wi=Object.prototype.hasOwnProperty,on=65279,Za=9,Ge=10,es=13,ts=32,ns=33,is=34,Xt=35,os=37,rs=38,as=39,ss=42,Ki=44,ls=45,ut=58,cs=61,us=62,ds=63,ps=64,Gi=91,Vi=93,fs=96,Qi=123,hs=124,Xi=125,J={};J[0]="\\0";J[7]="\\a";J[8]="\\b";J[9]="\\t";J[10]="\\n";J[11]="\\v";J[12]="\\f";J[13]="\\r";J[27]="\\e";J[34]='\\"';J[92]="\\\\";J[133]="\\N";J[160]="\\_";J[8232]="\\L";J[8233]="\\P";var ms=["y","Y","yes","Yes","YES","on","On","ON","n","N","no","No","NO","off","Off","OFF"],$s=/^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;function vs(e,t){var n,i,o,r,a,s,l;if(t===null)return{};for(n={},i=Object.keys(t),o=0,r=i.length;o<r;o+=1)a=i[o],s=String(t[a]),a.slice(0,2)==="!!"&&(a="tag:yaml.org,2002:"+a.slice(2)),l=e.compiledTypeMap.fallback[a],l&&Wi.call(l.styleAliases,s)&&(s=l.styleAliases[s]),n[a]=s;return n}function gs(e){var t,n,i;if(t=e.toString(16).toUpperCase(),e<=255)n="x",i=2;else if(e<=65535)n="u",i=4;else if(e<=4294967295)n="U",i=8;else throw new te("code point within a string may not be greater than 0xFFFFFFFF");return"\\"+n+Q.repeat("0",i-t.length)+t}var _s=1,Ve=2;function bs(e){this.schema=e.schema||Ni,this.indent=Math.max(1,e.indent||2),this.noArrayIndent=e.noArrayIndent||!1,this.skipInvalid=e.skipInvalid||!1,this.flowLevel=Q.isNothing(e.flowLevel)?-1:e.flowLevel,this.styleMap=vs(this.schema,e.styles||null),this.sortKeys=e.sortKeys||!1,this.lineWidth=e.lineWidth||80,this.noRefs=e.noRefs||!1,this.noCompatMode=e.noCompatMode||!1,this.condenseFlow=e.condenseFlow||!1,this.quotingType=e.quotingType==='"'?Ve:_s,this.forceQuotes=e.forceQuotes||!1,this.replacer=typeof e.replacer=="function"?e.replacer:null,this.implicitTypes=this.schema.compiledImplicit,this.explicitTypes=this.schema.compiledExplicit,this.tag=null,this.result="",this.duplicates=[],this.usedDuplicates=null}function wi(e,t){for(var n=Q.repeat(" ",t),i=0,o=-1,r="",a,s=e.length;i<s;)o=e.indexOf(`
`,i),o===-1?(a=e.slice(i),i=s):(a=e.slice(i,o+1),i=o+1),a.length&&a!==`
`&&(r+=n),r+=a;return r}function zt(e,t){return`
`+Q.repeat(" ",e.indent*t)}function ys(e,t){var n,i,o;for(n=0,i=e.implicitTypes.length;n<i;n+=1)if(o=e.implicitTypes[n],o.resolve(t))return!0;return!1}function dt(e){return e===ts||e===Za}function Qe(e){return 32<=e&&e<=126||161<=e&&e<=55295&&e!==8232&&e!==8233||57344<=e&&e<=65533&&e!==on||65536<=e&&e<=1114111}function ki(e){return Qe(e)&&e!==on&&e!==es&&e!==Ge}function xi(e,t,n){var i=ki(e),o=i&&!dt(e);return(n?i:i&&e!==Ki&&e!==Gi&&e!==Vi&&e!==Qi&&e!==Xi)&&e!==Xt&&!(t===ut&&!o)||ki(t)&&!dt(t)&&e===Xt||t===ut&&o}function ws(e){return Qe(e)&&e!==on&&!dt(e)&&e!==ls&&e!==ds&&e!==ut&&e!==Ki&&e!==Gi&&e!==Vi&&e!==Qi&&e!==Xi&&e!==Xt&&e!==rs&&e!==ss&&e!==ns&&e!==hs&&e!==cs&&e!==us&&e!==as&&e!==is&&e!==os&&e!==ps&&e!==fs}function ks(e){return!dt(e)&&e!==ut}function We(e,t){var n=e.charCodeAt(t),i;return n>=55296&&n<=56319&&t+1<e.length&&(i=e.charCodeAt(t+1),i>=56320&&i<=57343)?(n-55296)*1024+i-56320+65536:n}function zi(e){var t=/^\n* /;return t.test(e)}var Ji=1,Jt=2,Zi=3,eo=4,Ee=5;function xs(e,t,n,i,o,r,a,s){var l,u=0,p=null,c=!1,f=!1,h=i!==-1,v=-1,y=ws(We(e,0))&&ks(We(e,e.length-1));if(t||a)for(l=0;l<e.length;u>=65536?l+=2:l++){if(u=We(e,l),!Qe(u))return Ee;y=y&&xi(u,p,s),p=u}else{for(l=0;l<e.length;u>=65536?l+=2:l++){if(u=We(e,l),u===Ge)c=!0,h&&(f=f||l-v-1>i&&e[v+1]!==" ",v=l);else if(!Qe(u))return Ee;y=y&&xi(u,p,s),p=u}f=f||h&&l-v-1>i&&e[v+1]!==" "}return!c&&!f?y&&!a&&!o(e)?Ji:r===Ve?Ee:Jt:n>9&&zi(e)?Ee:a?r===Ve?Ee:Jt:f?eo:Zi}function Cs(e,t,n,i,o){e.dump=function(){if(t.length===0)return e.quotingType===Ve?'""':"''";if(!e.noCompatMode&&(ms.indexOf(t)!==-1||$s.test(t)))return e.quotingType===Ve?'"'+t+'"':"'"+t+"'";var r=e.indent*Math.max(1,n),a=e.lineWidth===-1?-1:Math.max(Math.min(e.lineWidth,40),e.lineWidth-r),s=i||e.flowLevel>-1&&n>=e.flowLevel;function l(u){return ys(e,u)}switch(xs(t,s,e.indent,a,l,e.quotingType,e.forceQuotes&&!i,o)){case Ji:return t;case Jt:return"'"+t.replace(/'/g,"''")+"'";case Zi:return"|"+Ci(t,e.indent)+Si(wi(t,r));case eo:return">"+Ci(t,e.indent)+Si(wi(Ss(t,a),r));case Ee:return'"'+As(t)+'"';default:throw new te("impossible error: invalid scalar style")}}()}function Ci(e,t){var n=zi(e)?String(t):"",i=e[e.length-1]===`
`,o=i&&(e[e.length-2]===`
`||e===`
`),r=o?"+":i?"":"-";return n+r+`
`}function Si(e){return e[e.length-1]===`
`?e.slice(0,-1):e}function Ss(e,t){for(var n=/(\n+)([^\n]*)/g,i=function(){var u=e.indexOf(`
`);return u=u!==-1?u:e.length,n.lastIndex=u,Ai(e.slice(0,u),t)}(),o=e[0]===`
`||e[0]===" ",r,a;a=n.exec(e);){var s=a[1],l=a[2];r=l[0]===" ",i+=s+(!o&&!r&&l!==""?`
`:"")+Ai(l,t),o=r}return i}function Ai(e,t){if(e===""||e[0]===" ")return e;for(var n=/ [^ ]/g,i,o=0,r,a=0,s=0,l="";i=n.exec(e);)s=i.index,s-o>t&&(r=a>o?a:s,l+=`
`+e.slice(o,r),o=r+1),a=s;return l+=`
`,e.length-o>t&&a>o?l+=e.slice(o,a)+`
`+e.slice(a+1):l+=e.slice(o),l.slice(1)}function As(e){for(var t="",n=0,i,o=0;o<e.length;n>=65536?o+=2:o++)n=We(e,o),i=J[n],!i&&Qe(n)?(t+=e[o],n>=65536&&(t+=e[o+1])):t+=i||gs(n);return t}function Ts(e,t,n){var i="",o=e.tag,r,a,s;for(r=0,a=n.length;r<a;r+=1)s=n[r],e.replacer&&(s=e.replacer.call(n,String(r),s)),(he(e,t,s,!1,!1)||typeof s>"u"&&he(e,t,null,!1,!1))&&(i!==""&&(i+=","+(e.condenseFlow?"":" ")),i+=e.dump);e.tag=o,e.dump="["+i+"]"}function Ti(e,t,n,i){var o="",r=e.tag,a,s,l;for(a=0,s=n.length;a<s;a+=1)l=n[a],e.replacer&&(l=e.replacer.call(n,String(a),l)),(he(e,t+1,l,!0,!0,!1,!0)||typeof l>"u"&&he(e,t+1,null,!0,!0,!1,!0))&&((!i||o!=="")&&(o+=zt(e,t)),e.dump&&Ge===e.dump.charCodeAt(0)?o+="-":o+="- ",o+=e.dump);e.tag=r,e.dump=o||"[]"}function Es(e,t,n){var i="",o=e.tag,r=Object.keys(n),a,s,l,u,p;for(a=0,s=r.length;a<s;a+=1)p="",i!==""&&(p+=", "),e.condenseFlow&&(p+='"'),l=r[a],u=n[l],e.replacer&&(u=e.replacer.call(n,l,u)),he(e,t,l,!1,!1)&&(e.dump.length>1024&&(p+="? "),p+=e.dump+(e.condenseFlow?'"':"")+":"+(e.condenseFlow?"":" "),he(e,t,u,!1,!1)&&(p+=e.dump,i+=p));e.tag=o,e.dump="{"+i+"}"}function Ls(e,t,n,i){var o="",r=e.tag,a=Object.keys(n),s,l,u,p,c,f;if(e.sortKeys===!0)a.sort();else if(typeof e.sortKeys=="function")a.sort(e.sortKeys);else if(e.sortKeys)throw new te("sortKeys must be a boolean or a function");for(s=0,l=a.length;s<l;s+=1)f="",(!i||o!=="")&&(f+=zt(e,t)),u=a[s],p=n[u],e.replacer&&(p=e.replacer.call(n,u,p)),he(e,t+1,u,!0,!0,!0)&&(c=e.tag!==null&&e.tag!=="?"||e.dump&&e.dump.length>1024,c&&(e.dump&&Ge===e.dump.charCodeAt(0)?f+="?":f+="? "),f+=e.dump,c&&(f+=zt(e,t)),he(e,t+1,p,!0,c)&&(e.dump&&Ge===e.dump.charCodeAt(0)?f+=":":f+=": ",f+=e.dump,o+=f));e.tag=r,e.dump=o||"{}"}function Ei(e,t,n){var i,o,r,a,s,l;for(o=n?e.explicitTypes:e.implicitTypes,r=0,a=o.length;r<a;r+=1)if(s=o[r],(s.instanceOf||s.predicate)&&(!s.instanceOf||typeof t=="object"&&t instanceof s.instanceOf)&&(!s.predicate||s.predicate(t))){if(n?s.multi&&s.representName?e.tag=s.representName(t):e.tag=s.tag:e.tag="?",s.represent){if(l=e.styleMap[s.tag]||s.defaultStyle,Yi.call(s.represent)==="[object Function]")i=s.represent(t,l);else if(Wi.call(s.represent,l))i=s.represent[l](t,l);else throw new te("!<"+s.tag+'> tag resolver accepts not "'+l+'" style');e.dump=i}return!0}return!1}function he(e,t,n,i,o,r,a){e.tag=null,e.dump=n,Ei(e,n,!1)||Ei(e,n,!0);var s=Yi.call(e.dump),l=i,u;i&&(i=e.flowLevel<0||e.flowLevel>t);var p=s==="[object Object]"||s==="[object Array]",c,f;if(p&&(c=e.duplicates.indexOf(n),f=c!==-1),(e.tag!==null&&e.tag!=="?"||f||e.indent!==2&&t>0)&&(o=!1),f&&e.usedDuplicates[c])e.dump="*ref_"+c;else{if(p&&f&&!e.usedDuplicates[c]&&(e.usedDuplicates[c]=!0),s==="[object Object]")i&&Object.keys(e.dump).length!==0?(Ls(e,t,e.dump,o),f&&(e.dump="&ref_"+c+e.dump)):(Es(e,t,e.dump),f&&(e.dump="&ref_"+c+" "+e.dump));else if(s==="[object Array]")i&&e.dump.length!==0?(e.noArrayIndent&&!a&&t>0?Ti(e,t-1,e.dump,o):Ti(e,t,e.dump,o),f&&(e.dump="&ref_"+c+e.dump)):(Ts(e,t,e.dump),f&&(e.dump="&ref_"+c+" "+e.dump));else if(s==="[object String]")e.tag!=="?"&&Cs(e,e.dump,t,r,l);else{if(s==="[object Undefined]")return!1;if(e.skipInvalid)return!1;throw new te("unacceptable kind of an object to dump "+s)}e.tag!==null&&e.tag!=="?"&&(u=encodeURI(e.tag[0]==="!"?e.tag.slice(1):e.tag).replace(/!/g,"%21"),e.tag[0]==="!"?u="!"+u:u.slice(0,18)==="tag:yaml.org,2002:"?u="!!"+u.slice(18):u="!<"+u+">",e.dump=u+" "+e.dump)}return!0}function Os(e,t){var n=[],i=[],o,r;for(Zt(e,n,i),o=0,r=i.length;o<r;o+=1)t.duplicates.push(n[i[o]]);t.usedDuplicates=new Array(r)}function Zt(e,t,n){var i,o,r;if(e!==null&&typeof e=="object")if(o=t.indexOf(e),o!==-1)n.indexOf(o)===-1&&n.push(o);else if(t.push(e),Array.isArray(e))for(o=0,r=e.length;o<r;o+=1)Zt(e[o],t,n);else for(i=Object.keys(e),o=0,r=i.length;o<r;o+=1)Zt(e[i[o]],t,n)}function Fs(e,t){t=t||{};var n=new bs(t);n.noRefs||Os(e,n);var i=e;return n.replacer&&(i=n.replacer.call({"":i},"",i)),he(n,0,i,!0,!0)?n.dump+`
`:""}var Is=Fs,Ns={dump:Is};function rn(e,t){return function(){throw new Error("Function yaml."+e+" is removed in js-yaml 4. Use yaml."+t+" instead, which is now safe by default.")}}var to=qi.load,xc=qi.loadAll,no=Ns.dump;var Cc=rn("safeLoad","load"),Sc=rn("safeLoadAll","loadAll"),Ac=rn("safeDump","dump");var ft;function ge(){let[e,t]=_([]);return W(()=>{ft=ft||B.list().catch(()=>(ft=void 0,[])),ft.then(t)},[]),e}var ae=e=>e?`${e.type}:${e.id}`:"",Ms=e=>{let[t,n]=e.split(":").map(Number);return{type:t,id:n}};function Z(e,t){if(!t)return"\u2014";let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n&&n.name?n.name:`${n?n.type_name:"type "+t.type} / 0x${t.id.toString(16).padStart(2,"0")}`}var Xe;function vt(){let[e,t]=_(new Map);return W(()=>{Xe=Xe||E.devices.list().then(n=>new Map(n.map(i=>[ae(i.device),i.features]))).catch(()=>(Xe=void 0,new Map)),Xe.then(t)},[]),e}var oo=()=>Xe=void 0,ro=[["extension","Extension board (buttons 4\u20137)"],["pir","Motion detector (PIR)"],["nightlight","Night light"],["veml7700","Brightness (VEML7700)"],["bme680","BME680"],["bme280","BME280"],["dht22","DHT22"],["scd30","SCD30 (CO\u2082)"]];function gt(e,t,n){let i=e.filter(o=>(t.get(ae({type:o.device_type,id:o.device_id}))||[]).includes(n));return i.length?i:e}var ao=(e,t,n)=>(e.get(ae(t))||[]).includes(n);function sn(e,t){let n=e.find(i=>i.device_type===t.type&&i.device_id===t.id);return n?n.name||n.key:"0x"+(268435456+(t.type<<16)+(t.id<<8)).toString(16)}function se({value:e,onChange:t,devices:n,types:i}){let o=n.filter(s=>!i||i.includes(s.device_type)),r=ae(e),a=o.some(s=>ae({type:s.device_type,id:s.device_id})===r);return d`<div class="device-select">
    <select value=${a?r:e?"manual":""} onChange=${s=>{let l=s.target.value;l==="manual"?t(e||{type:i&&i[0]||0,id:1}):l&&t(Ms(l))}}>
      <option value="" disabled>Choose a device…</option>
      ${o.map(s=>d`<option value=${ae({type:s.device_type,id:s.device_id})}>
          ${Z(n,{type:s.device_type,id:s.device_id})} (${s.type_name})
        </option>`)}
      <option value="manual">Other: type and id…</option>
    </select>
    ${e&&!a&&d`<span class="pair">
      <input type="number" min="0" max="63" title="Device type" value=${e.type} onInput=${s=>t({...e,type:+s.target.value})} />
      <input type="number" min="1" max="255" title="Device id" value=${e.id} onInput=${s=>t({...e,id:+s.target.value})} />
    </span>`}
  </div>`}var so=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]],Rs=e=>(so.find(([t])=>t===e)||[e,e])[1],mt=e=>String(e).padStart(2,"0");function Ie(e){if(!e)return"";if(e.clock)return`${mt(e.clock.hour)}:${mt(e.clock.minute)}`;let t=e.sun.offset_min||0;return Rs(e.sun.event)+(t?` ${t>0?"+":"\u2212"} ${Math.abs(t)} min`:"")}function Ne({value:e,onChange:t}){let n=!!e.sun;return d`<span class="time-edit">
    <select value=${n?"sun":"clock"} onChange=${i=>t(i.target.value==="sun"?{sun:{event:"sunset",offset_min:0}}:{clock:{hour:22,minute:0}})}>
      <option value="clock">Clock</option>
      <option value="sun">Sun</option>
    </select>
    ${n?d`<select value=${e.sun.event} onChange=${i=>t({sun:{...e.sun,event:i.target.value}})}>
            ${so.map(([i,o])=>d`<option value=${i}>${o}</option>`)}
          </select>
          <input type="number" class="short" min="-720" max="720" title="Offset in minutes (negative: before)" value=${e.sun.offset_min||0}
            onInput=${i=>t({sun:{...e.sun,offset_min:+i.target.value}})} /><small>min</small>`:d`<input type="time" value=${`${mt(e.clock.hour)}:${mt(e.clock.minute)}`} onInput=${i=>{let[o,r]=i.target.value.split(":").map(Number);isNaN(o)||t({clock:{hour:o,minute:r||0}})}} />`}
  </span>`}var Ds=[["dark","Darker than"],["bright","At least as bright as"],["between","Time between"],["sun_below","Sun lower than"],["sun_above","Sun at least"]],Ps=(e,t)=>{let n={type:0,id:1};switch(e){case"dark":case"bright":return{[e]:{sensor:n,lux:40}};case"between":return{between:{from:{clock:{hour:22,minute:0}},to:{clock:{hour:6,minute:0}}}};default:return{[e]:{degrees:-6}}}},lo=e=>Object.keys(e)[0];function ln(e,t){let n=lo(e),i=e[n];switch(n){case"dark":return`darker than ${i.lux} lx at ${Z(t,i.sensor)}`;case"bright":return`at least ${i.lux} lx at ${Z(t,i.sensor)}`;case"between":return`between ${Ie(i.from)} and ${Ie(i.to)}`;case"sun_below":return`sun below ${i.degrees}\xB0`;case"sun_above":return`sun at least ${i.degrees}\xB0`}return n}var ht;function Hs(){let[e,t]=_([]);return W(()=>{ht=ht||fe.list().then(n=>n.filter(i=>i.kind==="brightness")).catch(()=>(ht=void 0,[])),ht.then(t)},[]),e}function cn({value:e,onChange:t,devices:n}){let i=lo(e),o=e[i],r=Hs(),a=n.filter(l=>r.some(u=>u.device_key.toLowerCase()===l.key.toLowerCase())),s=l=>t({[i]:{...o,...l}});return d`<span class="condition">
    <select value=${i} onChange=${l=>t(Ps(l.target.value,n))}>
      ${Ds.map(([l,u])=>d`<option value=${l}>${u}</option>`)}
    </select>
    ${(i==="dark"||i==="bright")&&d`<input type="number" class="short" min="0" value=${o.lux} onInput=${l=>s({lux:+l.target.value})} /><small>lx at</small>
      <${se} value=${o.sensor.type?o.sensor:null} devices=${a.length?a:n} onChange=${l=>s({sensor:l})} />`}
    ${i==="between"&&d`<${Ne} value=${o.from} onChange=${l=>s({from:l})} /><small>and</small><${Ne} value=${o.to} onChange=${l=>s({to:l})} />`}
    ${(i==="sun_below"||i==="sun_above")&&d`<input type="number" class="short" min="-90" max="90" value=${o.degrees} onInput=${l=>s({degrees:+l.target.value})} /><small>° (−6: civil twilight ends)</small>`}
  </span>`}function le({items:e,onChange:t,max:n,make:i,render:o,addLabel:r}){return d`<div class="list-edit">
    ${e.map((a,s)=>d`<div class="list-row" key=${s}>
        <div class="list-body">${o(a,l=>t(e.map((u,p)=>p===s?l:u)),s)}</div>
        <button class="icon" title="Remove" onClick=${()=>t(e.filter((l,u)=>u!==s))}>×</button>
      </div>`)}
    ${e.length<n&&d`<button onClick=${()=>t([...e,i()])}>+ ${r}</button>`}
  </div>`}var un=[["light","Light (levels)"],["dimmer","Dimmer (0\u2013255)"],["relay","Relay"],["shutter","Roller shutter"],["group","Group"]],$t={light:[["toggle","Toggle"],["on","On (last level)"],["at_least","On, at least level",!0],["off","Off"],["set","Level",!0],["max","Brightest"],["inc","Brighter"],["dec","Darker"]],dimmer:[["toggle","Toggle"],["on","On (last value)"],["at_least","On, at least value",!0],["off","Off"],["set","Value",!0],["max","Full"],["inc","Brighter"],["dec","Darker"]],relay:[["toggle","Toggle"],["on","On"],["off","Off"],["on_for","On for (ms)",!0]],shutter:[["up","Up / stop"],["down","Down / stop"],["up_hold","Up (while held)"],["down_hold","Down (while held)"],["stop","Stop"]],group:[["toggle","Toggle"],["on","On"],["off","Off"],["up","Up / stop"],["down","Down / stop"],["stop","Stop"]]},co=e=>typeof e=="string"?[e,void 0]:[Object.keys(e)[0],Object.values(e)[0]],io=(e,t)=>t===void 0?e:{[e]:t};function uo(e,t){let[n,i]=co(e),o=($t[t]||Object.values($t).flat()).find(([a])=>a===n),r=o?o[1].replace(/ \(.*\)$/,""):n;return i===void 0?r:`${r} ${i}`}function po({value:e,onChange:t,kind:n}){let i=$t[n]||$t.light,[o,r]=co(e),a=s=>(i.find(([l])=>l===s)||[])[2];return d`<span class="op">
    <select value=${o} onChange=${s=>t(io(s.target.value,a(s.target.value)?s.target.value==="on_for"?6e4:1:void 0))}>
      ${i.map(([s,l])=>d`<option value=${s}>${l}</option>`)}
    </select>
    ${a(o)&&d`<input type="number" class="short" min="0" value=${r} onInput=${s=>t(io(o,+s.target.value))} />`}
  </span>`}var ze=e=>no(e,{flowLevel:0,lineWidth:-1}).trim(),dn=e=>e===null||typeof e!="object",Us=e=>(Array.isArray(e)?e:Object.values(e)).every(dn)&&ze(e).length<=60;function an(e,t){let n=[],i=Array.isArray(e)?e.map(o=>[null,o]):Object.entries(e);if(!i.length)return[t+ze(e)];for(let[o,r]of i){let a=o===null?"- ":`${ze(o)}: `;if(dn(r)||Us(r))n.push(t+a+ze(r));else if(o===null){let s=an(r,t+"  ");n.push(t+"- "+s[0].slice(t.length+2),...s.slice(1))}else n.push(t+a.trimEnd(),...an(r,t+"  "))}return n}var _t=e=>(dn(e)?ze(e):an(e,"").join(`
`))+`
`,bt=e=>to(e);function Me({title:e,intro:t,children:n,onSave:i,onCancel:o,error:r,value:a,onText:s}){let[l,u]=_(!1),[p,c]=_(null),[f,h]=_(""),v=()=>{try{let m=bt(p);if(!m||typeof m!="object")throw new Error("not an object");return h(""),m}catch(m){h(m.message);return}},y=()=>{if(p===null)return;let m=v();m!==void 0&&(s(m),c(null))},g=async()=>{let m;if(!(p!==null&&(m=v())===void 0)){u(!0);try{await i(m)}finally{u(!1)}}};return d`<section class="card editor">
    <header><h2>${e}</h2>
      ${a!==void 0&&d`<div class="seg" role="group" aria-label="Edit as">
        <button class=${p===null?"active":""} onClick=${y}>Form</button>
        <button class=${p!==null?"active":""} onClick=${()=>p===null&&c(_t(a))}>YAML</button>
      </div>`}
    </header>
    ${t&&d`<p class="muted intro">${t}</p>`}
    ${p===null?n:d`<textarea class="code" rows=${Math.min(30,Math.max(8,p.split(`
`).length+1))} spellcheck="false"
          value=${p} onInput=${m=>c(m.target.value)} />
          ${f&&d`<p class="error">${f}</p>`}
          <p class="muted">Back to the form with <em>Form</em>; <em>Save</em> saves the text as it is.</p>`}
    ${r&&d`<p class="error">${r}</p>`}
    <div class="buttons">
      <button class="primary" disabled=${l} onClick=${g}>Save</button>
      <button onClick=${o}>Cancel</button>
    </div>
  </section>`}var Re=e=>e.field?`${e.field}: ${e.message}`:e.message;var js=/^[A-Za-z0-9_-]{1,20}$/,fo=["Mo","Tu","We","Th","Fr","Sa","Su"],ho=e=>(e||[]).filter(t=>["light","dimmer","relay"].includes(t.kind));function mo({value:e,onChange:t,outputs:n}){return d`<select value=${e} onChange=${i=>t(i.target.value)}>
    ${!n.some(i=>i.name===e)&&d`<option value=${e}>${e||"Choose\u2026"}</option>`}
    ${n.map(i=>d`<option value=${i.name}>${i.name}</option>`)}
  </select>`}function Bs({title:e,intro:t,oldName:n,initial:i,api:o,done:r,children:a}){let[s,l]=_(n||""),[u,p]=_(i),[c,f]=_(""),h=async v=>{let y=v||u;if(!js.test(s))return f("Name: 1\u201320 letters, digits, - and _");if(JSON.stringify(y).includes('"sensor":{"type":0,'))return f("Choose the brightness sensor");let g=y.detectors?{...y,detectors:y.detectors.filter(Boolean)}:y;try{await o.put(s,g),n&&n!==s&&await o.remove(n),D(`${s} saved`),r(!0)}catch(m){f(Re(m))}};return d`<${Me} title=${n?`${e} ${n}`:`New ${e.toLowerCase()}`} onSave=${h} onCancel=${()=>r(!1)} error=${c}
    value=${u} onText=${p} intro=${t}>
    <div class="row">
      <${L} label="Name" hint="Letters, digits, - and _; also the MQTT topic and the switch in Home Assistant">
        <input value=${s} maxlength="20" onInput=${v=>l(v.target.value.trim())} />
      <//>
    </div>
    ${a(u,p)}
  <//>`}var qs=e=>({detectors:[],output:e[0]?e[0].name:"",timeout_s:180,lockout_s:60,levels:[],conditions:[]}),Ys="Motion switches the output on; it goes off again after a while without motion. Switched on by hand (a button, Home Assistant), it stays on until switched off. After it went off, motion is ignored for a moment, so it does not come straight back on for someone leaving.";function Ws({value:e,onChange:t}){let n=e.level!==void 0&&e.level!==null;return d`<span class="period">
    <small>From</small><${Ne} value=${e.from} onChange=${i=>t({...e,from:i})} />
    <select aria-label="Level" value=${n?"fixed":"last"} onChange=${i=>t(i.target.value==="fixed"?{from:e.from,level:1}:{from:e.from,min:1})}>
      <option value="fixed">always level</option>
      <option value="last">the last level, at least</option>
    </select>
    <input type="number" class="short" min="1" max="255" aria-label="Level" value=${n?e.level:e.min||0}
      onInput=${i=>t(n?{from:e.from,level:+i.target.value}:{from:e.from,min:+i.target.value})} />
  </span>`}function Ks({m:e,set:t,outputs:n,devices:i,features:o}){let r=a=>t({...e,...a});return d`
    <div class="row">
      <${L} label="Switches"><${mo} value=${e.output} outputs=${n} onChange=${a=>r({output:a})} /><//>
      <${L} label="Off after no motion for (min)">
        <input type="number" min="0.1" max="1440" step="0.5" value=${e.timeout_s/60} onInput=${a=>r({timeout_s:Math.max(1,Math.round(+a.target.value*60))})} />
      <//>
      <${L} label="Then ignore motion for (s)" hint="So it doesn't come straight back on for someone leaving">
        <input type="number" min="0" max="3600" value=${e.lockout_s} onInput=${a=>r({lockout_s:+a.target.value})} />
      <//>
    </div>
    <h3>Motion detectors</h3>
    <p class="muted">Switches with a PIR (marked on their device page).</p>
    <${le} items=${e.detectors} max=${4} addLabel="motion detector" onChange=${a=>r({detectors:a})}
      make=${()=>null}
      render=${(a,s)=>d`<${se} value=${a} devices=${gt(i,o,"pir")} onChange=${s} />`} />
    <h3>Level by the time of day</h3>
    <p class="muted">Without any: the level it had last. E.g. from 22:00 always level 1; from sunrise the last level, but at least 4.</p>
    <${le} items=${e.levels||[]} max=${4} addLabel="time of day" onChange=${a=>r({levels:a})}
      make=${()=>({from:{clock:{hour:22,minute:0}},level:1})}
      render=${(a,s)=>d`<${Ws} value=${a} onChange=${s} />`} />
    <h3>Only switches on if</h3>
    <p class="muted">All of these hold. One that can't be told (no reading, no clock) counts as holding. Switching it on by hand stops the timer until it is switched off.</p>
    <${le} items=${e.conditions||[]} max=${3} addLabel="condition" onChange=${a=>r({conditions:a})}
      make=${()=>({sun_below:{degrees:-6}})}
      render=${(a,s)=>d`<${cn} value=${a} devices=${i} onChange=${s} />`} />`}var Gs="Switches an output on and off in time windows: by the clock, relative to the sun, and off early when it gets bright. Only the start and the end switch, so switching it off by hand in between sticks. Sun times use the location on the Gateway page.",$o=()=>({start:{sun:{event:"civil_dusk",offset_min:-30}},end:[{at:{clock:{hour:23,minute:0}}}],days:127});function Vs({value:e,onChange:t,devices:n}){let i=!!e.bright;return d`<span class="end">
    <select value=${i?"bright":"at"} onChange=${o=>t(o.target.value==="bright"?{bright:{sensor:{type:0,id:1},lux:200,for_min:5}}:{at:{clock:{hour:8,minute:0}}})}>
      <option value="at">At</option>
      <option value="bright">When bright</option>
    </select>
    ${i?d`<input type="number" class="short" min="0" value=${e.bright.lux} onInput=${o=>t({bright:{...e.bright,lux:+o.target.value}})} /><small>lx for</small>
          <input type="number" class="short" min="0" max="600" value=${e.bright.for_min} onInput=${o=>t({bright:{...e.bright,for_min:+o.target.value}})} /><small>min at</small>
          <${se} value=${e.bright.sensor.type?e.bright.sensor:null} devices=${n} onChange=${o=>t({bright:{...e.bright,sensor:o}})} />`:d`<${Ne} value=${e.at} onChange=${o=>t({at:o})} />`}
  </span>`}function Qs({w:e,set:t,devices:n}){let i=o=>t({...e,...o});return d`<div class="window">
    <div class="row">
      <${L} label="On at"><${Ne} value=${e.start} onChange=${o=>i({start:o})} /><//>
      <div class="field"><span>Days</span>
        <div class="days">
          ${fo.map((o,r)=>d`<label class=${"lamp"+(e.days&1<<r?" on":"")} key=${o}>
              <input type="checkbox" checked=${!!(e.days&1<<r)} onChange=${()=>i({days:e.days^1<<r})} />${o}
            </label>`)}
        </div>
      </div>
    </div>
    <div class="row tight">
      <label class="check"><input type="checkbox" checked=${!!e.only_if} onChange=${o=>{let{only_if:r,...a}=e;t(o.target.checked?{...a,only_if:{sun_below:{degrees:-6}}}:a)}} /> Only if, at the start:</label>
      ${e.only_if&&d`<${cn} value=${e.only_if} devices=${n} onChange=${o=>i({only_if:o})} />`}
    </div>
    <span class="label">Off at the first of</span>
    <${le} items=${e.end} max=${3} addLabel="end" onChange=${o=>i({end:o})}
      make=${()=>({at:{clock:{hour:8,minute:0}}})}
      render=${(o,r)=>d`<${Vs} value=${o} devices=${n} onChange=${r} />`} />
  </div>`}function Xs({s:e,set:t,outputs:n,devices:i}){return d`
    <div class="row">
      <${L} label="Switches" hint="On at its last level"><${mo} value=${e.output} outputs=${n} onChange=${o=>t({...e,output:o})} /><//>
    </div>
    <h3>Time windows</h3>
    <p class="muted">Only the start and the end switch: switching it off by hand in between sticks. Nothing switches while the clock isn't set.</p>
    <${le} items=${e.windows} max=${4} addLabel="time window" onChange=${o=>t({...e,windows:o})}
      make=${$o}
      render=${(o,r)=>d`<${Qs} w=${o} set=${r} devices=${i} />`} />`}function zs(e,t){let n=e.days===127?"":` (${fo.filter((r,a)=>e.days&1<<a).join(" ")})`,i=e.only_if?` if ${ln(e.only_if,t)}`:"",o=e.end.map(r=>r.at?Ie(r.at):`\u2265 ${r.bright.lux} lx`).join(" / ");return`${Ie(e.start)}${i} \u2192 ${o}${n}`}var Js={idle:["Waiting","muted"],auto:["On by motion","ok"],manual:["On by hand","warn"],lockout:["Locked","muted"],running:["Running","ok"]};function vo({kind:e,title:t,items:n,outputs:i,reload:o,empty:r}){let a=ge(),s=vt(),[l,u]=_(null),p=e==="motion"?E.motion:E.schedules,[c,f]=_({}),h=async m=>{let $=m?await T(()=>p.get(m)):e==="motion"?qs(i):{output:i[0]?i[0].name:"",windows:[$o()]};$&&u({oldName:m,initial:$})},v=async m=>{await T(()=>p.setEnabled(m.name,!m.enabled),`${m.name} ${m.enabled?"disabled":"enabled"}`),setTimeout(o,300)},y=async m=>{confirm(`Delete ${m}?`)&&await T(()=>p.remove(m),`${m} deleted`)!==void 0&&setTimeout(o,300)},g=async m=>{if(c[m])return f({...c,[m]:void 0});let $=await T(()=>p.get(m));$&&f({...c,[m]:$})};return l?d`<${Bs} title=${t} ...${l} api=${p} intro=${e==="motion"?Ys:Gs}
      done=${m=>{u(null),m&&setTimeout(o,300)}}>
      ${(m,$)=>e==="motion"?d`<${Ks} m=${m} set=${$} outputs=${i} devices=${a} features=${s} />`:d`<${Xs} s=${m} set=${$} outputs=${i} devices=${a} />`}
    <//>`:d`<${O} title=${t+"s"} aside=${d`<button class="primary" onClick=${()=>h()}>+ New ${t.toLowerCase()}</button>`}>
    ${n?n.length===0?d`<p class="muted">${r}</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>State</th><th>Enabled</th><th></th></tr></thead>
            <tbody>
              ${n.map(m=>{let[$,R]=Js[m.state]||[m.state,"muted"],x=c[m.name];return d`<tr key=${m.name}>
                    <td><a href="#" onClick=${A=>(A.preventDefault(),g(m.name))}><strong>${m.name}</strong></a></td>
                    <td><span class=${"badge "+(m.enabled?R:"muted")}>${$}</span>${m.remaining_s!==void 0?d` <small class="muted">${Math.ceil(m.remaining_s/60)} min</small>`:""}</td>
                    <td><label class="switch"><input type="checkbox" checked=${m.enabled} onChange=${()=>v(m)} /><span></span></label></td>
                    <td class="actions">
                      <button onClick=${()=>h(m.name)}>Edit</button>
                      <button class="danger" onClick=${()=>y(m.name)}>Delete</button>
                    </td>
                  </tr>
                  ${x&&d`<tr class="details"><td colspan="4">
                    ${e==="motion"?`${x.output}${(x.levels||[]).length?" ("+x.levels.map(A=>`from ${Ie(A.from)} ${A.level?"level "+A.level:"at least "+A.min}`).join(", ")+")":""}; off ${x.timeout_s/60} min after the last motion at ${x.detectors.map(A=>Z(a,A)).join(", ")}; locked ${x.lockout_s} s${(x.conditions||[]).length?"; only if "+x.conditions.map(A=>ln(A,a)).join(" and "):""}`:d`${x.output}: ${x.windows.map(A=>d`<div>${zs(A,a)}</div>`)}`}
                  </td></tr>`}`})}
            </tbody>
          </table></div>`:d`<${j} />`}
  <//>`}var go=({motion:e,outputs:t,reload:n})=>d`<${vo} kind="motion" title="Motion light" items=${e} outputs=${ho(t)} reload=${n}
  empty="None yet. A motion light switches an output on by motion and off after a while without it; it can be bound to a button (three times down: off) and switched in Home Assistant." />`,_o=({schedules:e,outputs:t,reload:n})=>d`<${vo} kind="schedule" title="Schedule" items=${e} outputs=${ho(t)} reload=${n}
  empty="None yet. A schedule switches an output in time windows: by the clock, relative to the sun, and off when it gets bright." />`;var Zs=[3],el=8,bo=15,pn=e=>Object.keys(e)[0],tl=e=>(un.find(([t])=>t===e)||[e,e])[1],yo={light:()=>({light:{groups:[{device:{type:3,id:1},mask:1}],levels:[[40],[80],[127]],default_level:2}}),dimmer:()=>({dimmer:{lamps:{device:{type:3,id:1},mask:1},default_value:127}}),relay:()=>({relay:{device:{type:5,id:1},channel:0,bank:0}}),shutter:()=>({shutter:{device:{type:5,id:1},channel:0,bank:0,travel_ms:2e4,up:1}}),group:()=>({group:{members:[]}})};function nl(e,t){let n=pn(e),i=e[n];switch(n){case"light":return`${i.levels.length} levels, ${i.groups.length} lamp group${i.groups.length>1?"s":""} on ${[...new Set(i.groups.map(o=>Z(t,o.device)))].join(", ")}`;case"dimmer":return`${Z(t,i.lamps.device)}, mask 0x${i.lamps.mask.toString(16)}`;case"relay":return`${Z(t,i.device)}, channel ${i.channel}`;case"shutter":return`${Z(t,i.device)}, shutter ${i.channel}, ${i.travel_ms/1e3} s`;case"group":return i.members.join(", ")}return""}function il(e){let[t,n]=_([]),i=e?`${e.type}:${e.id}`:"",o=()=>e&&E.devices.get(e).then(r=>n(r.lamps||[]),()=>n([]));return W(()=>{o()},[i]),[t,o]}function ko({value:e,onChange:t,lit:n,onPick:i,names:o=[]}){return d`<div class="lamps named">
    ${Array.from({length:24},(r,a)=>23-a).map(r=>{let a=e>>>r&1,s=()=>i?i(r):t((e^1<<r)>>>0);return d`<label key=${r} title=${o[r]||`Lamp ${r}`} class=${"lamp"+(a?" on":"")+(r===n?" lit":"")}>
        <input type="checkbox" checked=${!!a} onChange=${s} /><b>${r}</b>${o[r]&&d`<small>${o[r]}</small>`}
      </label>`})}
  </div>`}var wo=127;function ol({group:e,onChange:t,devices:n,names:i,reloadNames:o}){let[r,a]=_(null),[s,l]=_(""),u=sn(n,e.device),p=e.bank??0,c=(m,$)=>T(()=>B.lamps(u,p,m,$)),f=async m=>{r!==null&&r!==m&&await c(0,1<<r),await c(wo,1<<m),a(m),l(i[m]||"")},h=async()=>{let m=await T(()=>E.devices.get(e.device));if(!m)return;let $=Array.from({length:24},(R,x)=>(m.lamps||[])[x]||"");for($[r]=s.trim().slice(0,16);$.length&&!$[$.length-1];)$.pop();await T(()=>E.devices.put(e.device,{...m,lamps:$}),`Lamp ${r} named`)!==void 0&&o()},v=async()=>{r!==null&&await c(0,1<<r),a(null)},y=()=>t({...e,mask:(e.mask^1<<r)>>>0}),g=r!==null&&e.mask>>>r&1;return d`<div class="explore">
    <p class="muted">Click a lamp: it lights up in the room (the one before goes off). The controller takes about one change per second. Give it a name while it's lit: the name is kept with the controller and shown everywhere.</p>
    <${ko} value=${e.mask} lit=${r} onPick=${f} names=${i} />
    ${r!==null&&d`<div class="row tight">
      <input aria-label=${`Name of lamp ${r}`} placeholder=${`Name of lamp ${r}, e.g. \u201Cliving white 2\u201D`} maxlength="16" value=${s} onInput=${m=>l(m.target.value)} />
      <button onClick=${h}>Save name</button>
    </div>`}
    <div class="buttons">
      <button class="primary" disabled=${r===null} onClick=${y}>
        ${r===null?"Click a lamp first":g?`Remove lamp ${r} from the group`:`Add lamp ${r} to the group`}
      </button>
      <button disabled=${!e.mask} onClick=${()=>c(wo,e.mask)}>Light the whole group</button>
      <button onClick=${v}>Done: switch off</button>
    </div>
  </div>`}function xo({value:e,onChange:t,devices:n}){let[i,o]=_(!1),[r,a]=il(e.device);return d`<div class="row">
    <${L} label="Lamp controller">
      <${se} value=${e.device} devices=${n} types=${Zs} onChange=${s=>t({...e,device:s})} />
    <//>
    <${L} label="Bank" hint="Empty: the controller's only one">
      <input type="number" min="0" max="255" value=${e.bank??""} onInput=${s=>{let{bank:l,...u}=e;t(s.target.value===""?u:{...u,bank:+s.target.value})}} />
    <//>
    <div class="field wide">
      <span>Lamps (mask 0x${e.mask.toString(16).padStart(6,"0")})
        <button class="link" onClick=${()=>o(!i)}>${i?"Close":"Find a lamp\u2026"}</button></span>
      ${i?d`<${ol} group=${e} devices=${n} onChange=${t} names=${r} reloadNames=${a} />`:d`<${ko} value=${e.mask} names=${r} onChange=${s=>t({...e,mask:s})} />`}
    </div>
  </div>`}function rl(e,t,n,i,o){return Array.from({length:e},(r,a)=>{let s=Math.round(n+(i-n)*Math.pow((a+1)/e,o));return Array(t).fill(Math.max(1,Math.min(255,s)))})}function al({value:e,onChange:t,devices:n}){let[i,o]=_(127),r=e.groups,a=p=>{let c=e.levels.map(f=>p.map((h,v)=>v<f.length?f[v]:f[f.length-1]??0));t({...e,groups:p,levels:c})},s=(p,c,f)=>t({...e,levels:e.levels.map((h,v)=>v===p?h.map((y,g)=>g===c?f:y):h)}),l=async p=>{for(let[c,f]of r.entries())await T(()=>B.lamps(sn(n,f.device),f.bank??0,p?p[c]:0,f.mask))},u=p=>{let c=e.levels.slice(0,p);for(;c.length<p;)c.push([...c[c.length-1]||r.map(()=>0)]);t({...e,levels:c,default_level:Math.min(e.default_level,p)})};return d`
    <h3>Lamp groups</h3>
    <p class="muted">Lamps that always have the same value in every level form a group. A light may span several controllers.</p>
    <${le} items=${r} max=${el} addLabel="lamp group" onChange=${a}
      make=${()=>({device:r.length?r[r.length-1].device:{type:3,id:1},mask:1})}
      render=${(p,c)=>d`<${xo} value=${p} devices=${n} onChange=${c} />`} />

    <h3>Levels</h3>
    <p class="muted">The value (0–255) of each lamp group per level; level 0 is off. The controllers fade by themselves and take one change per second.</p>
    <div class="row">
      <${L} label="Levels">
        <input type="number" min="1" max=${bo} value=${e.levels.length} onInput=${p=>p.target.value&&u(Math.max(1,Math.min(bo,+p.target.value)))} />
      <//>
      <${L} label="Default level" hint="What “on” switches to the first time">
        <select value=${e.default_level} onChange=${p=>t({...e,default_level:+p.target.value})}>
          ${e.levels.map((p,c)=>d`<option value=${c+1}>${c+1}</option>`)}
        </select>
      <//>
      <${L} label="Ramp up to" hint="Fills every level, all groups alike">
        <input type="number" min="1" max="255" value=${i} onInput=${p=>o(+p.target.value)} />
      <//>
      <button onClick=${()=>t({...e,levels:rl(e.levels.length,r.length,2,i,3)})}>Fill ramp</button>
    </div>
    <div class="table-wrap"><table class="levels">
      <thead><tr><th>Level</th>${r.map((p,c)=>d`<th>Group ${c+1}</th>`)}<th><button class="link" onClick=${()=>l(null)}>All off</button></th></tr></thead>
      <tbody>
        ${e.levels.map((p,c)=>d`<tr key=${c}>
            <td>${c+1}${c+1===e.default_level&&d` <span class="badge muted">default</span>`}</td>
            ${p.map((f,h)=>d`<td><input type="number" class="short" min="0" max="255" aria-label=${`Level ${c+1}, group ${h+1}`} value=${f} onInput=${v=>s(c,h,+v.target.value)} /></td>`)}
            <td><button onClick=${()=>l(p)} title="Show this level on the lamps">Try</button></td>
          </tr>`)}
      </tbody>
    </table></div>`}var De=(e,t,n,i={},o)=>d`<${L} label=${e} hint=${o}>
  <input type="number" value=${t} ...${i} onInput=${r=>n(+r.target.value)} />
<//>`;function sl({output:e,onChange:t,devices:n,names:i,kinds:o={}}){let r=pn(e),a=u=>o[u],s=e[r],l=u=>t({[r]:{...s,...u}});switch(r){case"light":return d`<${al} value=${s} devices=${n} onChange=${u=>t({light:u})} />`;case"dimmer":return d`<${xo} value=${s.lamps} devices=${n} onChange=${u=>l({lamps:u})} />
        <div class="row">${De("Default value",s.default_value,u=>l({default_value:u}),{min:1,max:255},"What \u201Con\u201D switches to the first time")}</div>`;case"relay":return d`<div class="row">
        <${L} label="Relay node"><${se} value=${s.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${De("Channel",s.channel,u=>l({channel:u}),{min:0,max:255})}
        ${De("Bank",s.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>`;case"shutter":return d`<div class="row">
        <${L} label="Shutter node"><${se} value=${s.device} devices=${n} onChange=${u=>l({device:u})} /><//>
        ${De("Shutter",s.channel,u=>l({channel:u}),{min:0,max:255})}
        ${De("Bank",s.bank,u=>l({bank:u}),{min:0,max:255})}
      </div>
      <div class="row">
        ${De("Travel time (s)",s.travel_ms/1e3,u=>l({travel_ms:Math.round(u*1e3)}),{min:1,max:600,step:.5},"A full move; sent with up and down")}
        <${L} label="Up is" hint="Depends on the wiring: swap it if up and down are the wrong way round">
          <select value=${s.up} onChange=${u=>l({up:+u.target.value})}>
            <option value="1">Direction 1</option>
            <option value="2">Direction 2</option>
          </select>
        <//>
      </div>`;case"group":return d`<p class="muted">Switched together, e.g. “all lights” for one button that switches everything off. Up to every other output; groups can't contain groups.</p>
        <div class="buttons">
          <button onClick=${()=>l({members:i})}>All</button>
          <button onClick=${()=>l({members:i.filter(u=>a(u)==="light"||a(u)==="dimmer")})}>All lights</button>
          <button onClick=${()=>l({members:[]})}>None</button>
        </div>
        <div class="checks">
          ${i.map(u=>d`<label class="check" key=${u}>
              <input type="checkbox" checked=${s.members.includes(u)} onChange=${p=>l({members:p.target.checked?[...s.members,u]:s.members.filter(c=>c!==u)})} /> ${u}
            </label>`)}
        </div>`}return null}var ll={light:"A room light in levels: lamp groups on one or more lamp controllers, and the value of each group per level. \u201COn\u201D goes back to the level it had last.",dimmer:"One lamp group switched with a value 0\u2013255, without a level table.",relay:"A relay channel of a relay node: on and off.",shutter:"A roller shutter on a relay node: up, down and stop. Pressing up while it moves up stops it.",group:"Outputs switched together: on, off, toggle, and up/down for the shutters in it."};function cl({original:e,name:t,outputs:n,devices:i,done:o}){let[r,a]=_(t||""),[s,l]=_(e||yo.light()),[u,p]=_(""),c=pn(s),f=n.filter(v=>v.kind!=="group"&&v.name!==t).map(v=>v.name),h=async v=>{if(!/^[A-Za-z0-9_-]{1,20}$/.test(r))return p("Name: 1\u201320 letters, digits, - and _");try{await E.outputs.put(r,v||s),t&&t!==r&&await E.outputs.remove(t),D(`${r} saved`),o(!0)}catch(y){p(Re(y))}};return d`<${Me} title=${t?`Output ${t}`:"New output"} onSave=${h} onCancel=${()=>o(!1)} error=${u}
    value=${s} onText=${l} intro=${ll[c]}>
    <div class="row">
      <${L} label="Name" hint=${t&&r!==t?"Renaming: bindings and automations that use the old name stop working":"Letters, digits, - and _"}>
        <input value=${r} maxlength="20" onInput=${v=>a(v.target.value.trim())} />
      <//>
      <${L} label="Kind">
        <select value=${c} disabled=${!!t} onChange=${v=>l(yo[v.target.value]())}>
          ${un.map(([v,y])=>d`<option value=${v}>${y}</option>`)}
        </select>
      <//>
    </div>
    <${sl} output=${s} onChange=${l} devices=${i} names=${f}
      kinds=${Object.fromEntries(n.map(v=>[v.name,v.kind]))} />
  <//>`}function Co({outputs:e,reload:t}){let n=ge(),[i,o]=_(null),[r,a]=_({}),[s,l]=_(0),u=(e||[]).map(f=>f.name).join(",");W(()=>{let f=!1;return(async()=>{let h={};for(let v of u?u.split(","):[]){try{h[v]=await E.outputs.get(v)}catch{}if(f)return}a(h)})(),()=>f=!0},[u,s]);let p=async f=>{let h=f?await T(()=>E.outputs.get(f)):void 0;f&&!h||o({name:f,original:h})},c=async f=>{confirm(`Delete the output ${f}? Bindings and automations that use it stop working.`)&&await T(()=>E.outputs.remove(f),`${f} deleted`)!==void 0&&t()};return i?d`<${cl} ...${i} outputs=${e||[]} devices=${n}
      done=${f=>{o(null),f&&(l(h=>h+1),setTimeout(t,300))}} />`:d`<${O} title="Outputs" aside=${d`<button class="primary" onClick=${()=>p()}>+ New output</button>`}>
    ${e?e.length===0?d`<p class="muted">Nothing yet. An output is what the automation switches: a room light with its levels, a dimmer, a relay, a roller shutter, or a group of them (“all lights”).</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Kind</th><th>What</th><th></th></tr></thead>
            <tbody>
              ${e.map(f=>d`<tr key=${f.name}>
                  <td><strong>${f.name}</strong></td>
                  <td>${tl(f.kind)}</td>
                  <td class="muted-cell">${r[f.name]?nl(r[f.name],n):""}</td>
                  <td class="actions">
                    <button onClick=${()=>p(f.name)}>Edit</button>
                    <button class="danger" onClick=${()=>c(f.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${j} />`}
  <//>`}var yt=[["single","Once","Pressed once"],["double","Twice","Pressed twice"],["triple","3 times","Pressed three times"],["hold","Held","Held: repeats every 0.5 s"],["released","Let go","Let go after holding"]],wt=e=>(yt.find(([t])=>t===e)||[e,e,e])[2],Pe=8,ul=4,So=8,dl=/^[A-Za-z0-9_-]{1,20}$/,Ao=[4],hn=()=>Array.from({length:Pe},()=>({})),pl=e=>Object.fromEntries((e||[]).map(t=>[t.event,t.actions])),fn=e=>({events:yt.map(([t])=>t).filter(t=>(e[t]||[]).length).map(t=>({event:t,actions:e[t]}))});function mn(e){let t={};return e.buttons.forEach((n,i)=>{let o=Object.fromEntries(Object.entries(n).filter(([,r])=>r&&r.length));Object.keys(o).length&&(t[i]=o)}),{switches:e.switches,buttons:t}}function kt(e){let t=hn();for(let[n,i]of Object.entries(e.buttons||{}))+n>=0&&+n<Pe&&(t[+n]={...i});return{switches:e.switches||[],buttons:t}}async function $n(e,t){let n=await E.switches.get(e),i=hn();for(let o=0;o<Pe;o++)t&1<<o&&(i[o]=pl((await E.switches.button(e,o)).events));return{switches:n.switches,buttons:i}}async function vn(e,t,n){await E.switches.put(e,{switches:t.switches});for(let i=0;i<Pe;i++){let o=JSON.stringify(fn(t.buttons[i])),r=n?JSON.stringify(fn(n.buttons[i])):'{"events":[]}';o!==r&&await E.switches.putButton(e,i,fn(t.buttons[i]))}}function fl(e,t,n){return e.output?`${e.output.name}: ${uo(e.output.op,n[e.output.name]).toLowerCase()}`:e.automation?`${e.automation.name}: ${e.automation.switch}`:e.nightlight?`night light ${Z(t,e.nightlight.device)}: ${e.nightlight.value}`:"?"}function hl({value:e,onChange:t,devices:n,features:i,outputs:o,automations:r}){let a=Object.keys(e)[0],s=e[a],l=Object.fromEntries(o.map(p=>[p.name,p.kind])),u=p=>{p==="output"&&t({output:{name:o[0]?o[0].name:"",op:"toggle"}}),p==="automation"&&t({automation:{name:r[0]||"",switch:"toggle"}}),p==="nightlight"&&t({nightlight:{device:{type:4,id:1},value:0}})};return d`<span class="action">
    <select value=${a} onChange=${p=>u(p.target.value)} aria-label="Kind of action">
      <option value="output">Output</option>
      <option value="automation">Motion light / schedule</option>
      <option value="nightlight">Night light</option>
    </select>
    ${a==="output"&&d`<select value=${s.name} aria-label="Output" onChange=${p=>t({output:{name:p.target.value,op:"toggle"}})}>
        ${!o.some(p=>p.name===s.name)&&d`<option value=${s.name}>${s.name||"Choose\u2026"}</option>`}
        ${o.map(p=>d`<option value=${p.name}>${p.name}</option>`)}
      </select>
      <${po} value=${s.op} kind=${l[s.name]} onChange=${p=>t({output:{...s,op:p}})} />`}
    ${a==="automation"&&d`<select value=${s.name} aria-label="Motion light or schedule" onChange=${p=>t({automation:{...s,name:p.target.value}})}>
        ${!r.includes(s.name)&&d`<option value=${s.name}>${s.name||"Choose\u2026"}</option>`}
        ${r.map(p=>d`<option value=${p}>${p}</option>`)}
      </select>
      <select value=${s.switch} aria-label="Switch it" onChange=${p=>t({automation:{...s,switch:p.target.value}})}>
        <option value="toggle">Toggle</option>
        <option value="enable">Enable</option>
        <option value="disable">Disable</option>
      </select>`}
    ${a==="nightlight"&&d`<${se} value=${s.device} devices=${gt(n,i,"nightlight")} types=${Ao}
        onChange=${p=>t({nightlight:{...s,device:p}})} />
      <input type="number" class="short" min="0" max="255" aria-label="Brightness 0–255" value=${s.value}
        onInput=${p=>t({nightlight:{...s,value:+p.target.value}})} />`}
  </span>`}function To({onLearn:e,label:t="Learn: press a button"}){let[n,i]=_(!1),o=re(!1);return W(()=>()=>o.current=!0,[]),n?d`<button class="learning" onClick=${()=>o.current=!0}>Press the button on the wall now… (cancel)</button>`:d`<button onClick=${async()=>{i(!0),o.current=!1;let a=Date.now();for(;!o.current&&Date.now()<a+3e4;){try{let s=await E.status();if(s.last_button&&s.last_button.age_s+1<=(Date.now()-a)/1e3){e(s.last_button.trigger);break}}catch{}await new Promise(s=>setTimeout(s,700))}i(!1)}}>${t}</button>`}function ml(e,t){let n=i=>[{output:{name:t,op:i}}];return e==="shutter"?[{single:n("up"),hold:n("up_hold"),released:n("stop")},{single:n("down"),hold:n("down_hold"),released:n("stop")}]:e==="relay"||e==="group"?[{single:n("on")},{single:n("off")}]:[{single:n("on"),double:n("max"),hold:n("inc")},{single:n("off"),hold:n("dec")}]}function $l({outputs:e,onApply:t,buttons:n}){let[i,o]=_(0),[r,a]=_(e[0]?e[0].name:""),s=(e.find(l=>l.name===r)||{}).kind;return d`<div class="template">
    <span class="label">Quick fill:</span>
    <select value=${i} aria-label="Buttons" onChange=${l=>o(+l.target.value)}>
      ${Array.from({length:n/2},(l,u)=>d`<option value=${u}>buttons ${2*u} (up) and ${2*u+1} (down)</option>`)}
    </select>
    <span class="label">as a rocker for</span>
    <select value=${r} aria-label="Output" onChange=${l=>a(l.target.value)}>
      ${e.map(l=>d`<option value=${l.name}>${l.name}</option>`)}
    </select>
    <button disabled=${!r} onClick=${()=>t(2*i,ml(s,r))}>Fill</button>
    <small class="muted">${s==="shutter"?"Up/down, held: moves, let go: stops":s==="light"||s==="dimmer"?"Up: on, twice: brightest, held: brighter; down: off, held: darker":"Up: on, down: off"}</small>
  </div>`}function vl({name:e,original:t,devices:n,features:i,outputs:o,automations:r,done:a,learned:s}){let[l,u]=_(e||""),[p,c]=_(t||{switches:s?[s.device]:[],buttons:hn()}),[f,h]=_(s?[s.button,s.event]:[0,"single"]),[v,y]=_(""),g=Object.fromEntries(o.map(k=>[k.name,k.kind])),m=p.switches.some(k=>ao(i,k,"extension"))||p.buttons.slice(4).some(k=>Object.keys(k).length),[$,R]=_(!1),x=m||$||f[0]>=4?Pe:4,[A,M]=f,w=p.buttons[A][M]||[],S=k=>c({...p,buttons:p.buttons.map((I,H)=>H===A?{...I,[M]:k}:I)}),b=k=>{!p.switches.some(H=>ae(H)===ae(k.device))&&p.switches.length<So&&c(H=>({...H,switches:[...H.switches,k.device]})),h([k.button,k.event]),D(`Button ${k.button}, ${wt(k.event).toLowerCase()}`)},N=async k=>{let I=k?kt(k):p;if(!dl.test(l))return y("Name: 1\u201320 letters, digits, - and _");if(!I.switches.length)return y("Add at least one switch, or learn it");try{let H=e&&e!==l;await vn(l,I,H?void 0:t),H&&await E.switches.remove(e),D(`${l} saved`),a(!0)}catch(H){y(Re(H))}};return d`<${Me} title=${e?`Switch ${e}`:"New switch configuration"} onSave=${N} onCancel=${()=>a(!1)} error=${v}
    value=${mn(p)} onText=${k=>c(kt(k))}
    intro="What each button does. Several switches can share one configuration (both bedroom switches): they all do the same.">
    <div class="row">
      <${L} label="Name" hint="Letters, digits, - and _">
        <input value=${l} maxlength="20" onInput=${k=>u(k.target.value.trim())} />
      <//>
      <div class="field grow"><span>Switches</span>
        <${le} items=${p.switches} max=${So} addLabel="switch" onChange=${k=>c({...p,switches:k})}
          make=${()=>null}
          render=${(k,I)=>d`<${se} value=${k} devices=${n} types=${Ao} onChange=${I} />`} />
      </div>
    </div>
    <div class="row tight">
      <${To} onLearn=${b} label="Learn: press a button on the wall" />
      <small class="muted">Adds the switch and picks the button and kind of press.</small>
    </div>

    <h3>Buttons</h3>
    <div class="table-wrap"><table class="grid">
      <thead><tr><th>Button</th>${yt.map(([k,I,H])=>d`<th title=${H}>${I}</th>`)}</tr></thead>
      <tbody>
        ${Array.from({length:x},(k,I)=>d`<tr key=${I}>
          <th scope="row">${I}${I>=4?d` <small class="muted">ext.</small>`:""}</th>
          ${yt.map(([H])=>{let _e=p.buttons[I][H]||[],Sn=A===I&&M===H;return d`<td key=${H}><button class=${"cell"+(Sn?" active":"")+(_e.length?" used":"")}
              aria-pressed=${Sn} onClick=${()=>h([I,H])}>
              ${_e.length?_e.map(Ko=>fl(Ko,n,g)).join(", "):"\u2014"}
            </button></td>`})}
        </tr>`)}
      </tbody>
    </table></div>
    ${!m&&x===4&&d`<button class="link" onClick=${()=>R(!0)}>Show buttons 4–7 (extension board)</button>`}

    <div class="cell-edit">
      <h3>Button ${A}, ${wt(M).toLowerCase()}</h3>
      <${le} items=${w} max=${ul} addLabel="action" onChange=${S}
        make=${()=>({output:{name:o[0]?o[0].name:"",op:"toggle"}})}
        render=${(k,I)=>d`<${hl} value=${k} onChange=${I} devices=${n} features=${i} outputs=${o} automations=${r} />`} />
      ${w.length===0&&d`<p class="muted">Does nothing. Add an action, or fill a rocker below.</p>`}
    </div>
    ${o.length>0&&d`<${$l} outputs=${o} buttons=${x}
      onApply=${(k,I)=>{c({...p,buttons:p.buttons.map((H,_e)=>_e===k||_e===k+1?{...H,...I[_e-k]}:H)}),h([k,"single"])}} />`}
  <//>`}function Eo({outputs:e,motion:t,schedules:n}){let i=ge(),o=vt(),[r,a]=_(),[s,l]=_(),[u,p]=_(null),c=async()=>{try{a(await E.switches.list())}catch(g){l(g)}};W(()=>{c()},[]);let f=[...t||[],...n||[]].map(g=>g.name),h=async g=>{let m=await T(()=>$n(g.name,g.buttons));m&&p({name:g.name,original:m})},v=g=>{let m=(r||[]).find($=>$.switches.some(R=>ae(R)===ae(g.device)));m?h(m):p({learned:g})},y=async g=>{confirm(`Delete the switch configuration ${g}? Its buttons stop doing anything.`)&&await T(()=>E.switches.remove(g),`${g} deleted`)!==void 0&&c()};return u?d`<${vl} ...${u} devices=${i} features=${o} outputs=${e||[]} automations=${f}
      done=${g=>{p(null),g&&c()}} />`:d`<${O} title="Switches" aside=${d`<div class="buttons">
      <${To} onLearn=${v} label="Which switch is this?" />
      <button class="primary" onClick=${()=>p({})}>+ New</button>
    </div>`}>
    <p class="muted">A configuration says what each button of a switch does when pressed once, twice, three times, held or let go. Switches that do the same share one.</p>
    ${r?r.length===0?d`<p>No switch does anything yet. Press <em>Which switch is this?</em> and a button on the wall to start with that switch.</p>`:d`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Switches</th><th>Buttons</th><th></th></tr></thead>
            <tbody>
              ${r.map(g=>d`<tr key=${g.name}>
                  <td><strong>${g.name}</strong></td>
                  <td class="wrap">${g.switches.map(m=>Z(i,m)).join(", ")}</td>
                  <td><span class="chips">${Array.from({length:Pe},(m,$)=>$).filter(m=>g.buttons&1<<m).map(m=>d`<span class="chip">${m}</span>`)}</span></td>
                  <td class="actions">
                    <button onClick=${()=>h(g)}>Edit</button>
                    <button class="danger" onClick=${()=>y(g.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:d`<${j} error=${s} />`}
  <//>`}var gl=[["","Overview"],["switches","Switches"],["outputs","Outputs"],["motion","Motion lights"],["schedules","Schedules"],["backup","Backup"]];async function _l(){let e=await E.status(),t=await E.outputs.list(),n=await E.motion.list(),i=await E.schedules.list();return{status:e,outputs:t,motion:n,schedules:i}}function _n({tab:e=""}){let{data:t,error:n,reload:i}=V(_l,e===""?2500:0),o=t||{};return d`
    <nav class="tabs">
      ${gl.map(([r,a])=>d`<${X} href=${"/automation"+(r?"/"+r:"")} class=${r===e?"active":""}>${a}<//>`)}
    </nav>
    ${!t&&d`<${j} error=${n} />`}
    ${t&&e===""&&d`<${wl} ...${o} reload=${i} />`}
    ${t&&e==="switches"&&d`<${Eo} outputs=${o.outputs} motion=${o.motion} schedules=${o.schedules} />`}
    ${t&&e==="outputs"&&d`<${Co} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="motion"&&d`<${go} motion=${o.motion} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="schedules"&&d`<${_o} schedules=${o.schedules} outputs=${o.outputs} reload=${i} />`}
    ${t&&e==="backup"&&d`<${xl} ...${o} reload=${i} />`}
    ${n&&t&&d`<p class="error">${n.message}</p>`}`}function Io(e,t){let[n,i]=_(null),o=async(r,a)=>{i(a),await T(()=>E.outputs.command(e.name,r)),setTimeout(async()=>{await t(),i(null)},600)};return[n===null?e.level:n,o]}function bl({o:e,reload:t}){let[n,i]=Io(e,t),o=e.kind==="light"?e.top:255,r=e.kind==="light"?1:25,a=s=>i({set:s},Math.max(0,Math.min(o,s)));return d`<div class="stepper">
      <button aria-label="Darker" disabled=${n<=0} onClick=${()=>i("dec",Math.max(0,n-r))}>−</button>
      ${e.kind==="light"?d`<select aria-label="Level" value=${n} onChange=${s=>a(+s.target.value)}>
            ${Array.from({length:o+1},(s,l)=>d`<option value=${l}>${l===0?"off":`level ${l}`}</option>`)}
          </select>`:d`<input type="number" aria-label="Value 0–255" min="0" max="255" value=${n} onChange=${s=>a(+s.target.value)} />`}
      <button aria-label="Brighter" disabled=${n>=o} onClick=${()=>i("inc",Math.min(o,n+r))}>+</button>
    </div>
    <div class="buttons fixed"><button onClick=${()=>i("on",n||1)}>On</button><button onClick=${()=>i("off",0)}>Off</button></div>`}function Lo({o:e,reload:t}){let[,n]=Io(e,t),i,o;switch(e.kind){case"light":case"dimmer":i=e.level>0?e.kind==="light"?`level ${e.level} of ${e.top}`:`${Math.round(e.level/255*100)} %`:"off",o=d`<${bl} o=${e} reload=${t} />`;break;case"relay":i=e.level>0?"on":"off",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",1)}>On</button><button onClick=${()=>n("off",0)}>Off</button></div>`;break;case"shutter":i={up:"moving up",down:"moving down",stopped:"stopped"}[e.movement],o=d`<div class="buttons fixed">
        <button aria-label="Up" onClick=${()=>n("up",e.level)}>▲</button>
        <button aria-label="Stop" onClick=${()=>n("stop",e.level)}>■</button>
        <button aria-label="Down" onClick=${()=>n("down",e.level)}>▼</button>
      </div>`;break;default:i="group",o=d`<div class="buttons fixed"><button onClick=${()=>n("on",0)}>All on</button><button onClick=${()=>n("off",0)}>All off</button></div>`}let r=e.level>0||e.kind==="shutter"&&e.movement!=="stopped";return d`<div class=${"tile"+(r?" lit":"")}>
    <div class="tile-head"><strong>${e.name}</strong></div>
    <div class="tile-state">${i}</div>
    ${o}
  </div>`}var yl={idle:"waiting",auto:"on by motion",manual:"on by hand",lockout:"locked",running:"in a time window"};function wl({status:e,outputs:t,motion:n,schedules:i,reload:o}){let r=ge(),a=async f=>{await T(()=>E.setEnabled(f),f?"Automation on":"Automation off"),o()},s=(f,h)=>async()=>{await T(()=>f.setEnabled(h.name,!h.enabled),`${h.name} ${h.enabled?"disabled":"enabled"}`),setTimeout(o,400)},l=e.last_button,u=!t.length&&!n.length&&!i.length,p=t.filter(f=>f.kind==="group"),c=t.filter(f=>f.kind!=="group");return d`
    <${O} title="Automation" aside=${d`<label class="switch big" title="The master switch">
      <input type="checkbox" checked=${e.enabled} onChange=${f=>a(f.target.checked)} /><span></span>
      ${e.enabled?"On":"Off"}
    </label>`}>
      <p class="muted">
        Switches, motion lights and schedules run on the gateway itself: they keep working without the network, MQTT or Home Assistant.
        This page is for testing and watching them.
        ${!e.enabled&&d` <strong>Switched off:</strong> nothing switches by itself; outputs can still be switched here.`}
      </p>
      <dl class="facts">
        <div><dt>Switch configurations</dt><dd><${X} href="/automation/switches">${e.switches}<//></dd></div>
        <div><dt>Outputs</dt><dd><${X} href="/automation/outputs">${e.outputs}<//></dd></div>
        <div><dt>Motion lights</dt><dd><${X} href="/automation/motion">${e.motion}<//></dd></div>
        <div><dt>Schedules</dt><dd><${X} href="/automation/schedules">${e.schedules}<//></dd></div>
        <div><dt>Last button pressed</dt>
        <dd>${l?`${Z(r,l.trigger.device)}, button ${l.trigger.button}, ${wt(l.trigger.event).toLowerCase()} (${l.age_s} s ago)`:"\u2014"}</dd></div>
      </dl>
      ${u&&d`<ol class="steps">
        <li>Create the <${X} href="/automation/outputs">outputs<//>: the lights, relays and shutters the automation switches.</li>
        <li>Tell the <${X} href="/automation/switches">switches<//> what their buttons do.</li>
        <li>Add <${X} href="/automation/motion">motion lights<//> and <${X} href="/automation/schedules">schedules<//>.</li>
        <li>Or restore a <${X} href="/automation/backup">backup<//>.</li>
      </ol>`}
    <//>
    ${p.length>0&&d`<${O} title="Groups">
      <div class="tiles">${p.map(f=>d`<${Lo} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${c.length>0&&d`<${O} title="Outputs">
      <div class="tiles">${c.map(f=>d`<${Lo} key=${f.name} o=${f} reload=${o} />`)}</div>
    <//>`}
    ${n.length+i.length>0&&d`<${O} title="Motion lights and schedules">
      <div class="tiles">
        ${[...n.map(f=>[f,E.motion]),...i.map(f=>[f,E.schedules])].map(([f,h])=>d`<div class=${"tile"+(f.enabled&&f.state!=="idle"?" lit":"")} key=${f.name}>
            <div class="tile-head"><strong>${f.name}</strong></div>
            <div class="tile-state">${f.enabled?yl[f.state]:"disabled"}${f.enabled&&f.remaining_s!==void 0?` \xB7 ${f.remaining_s} s`:""}</div>
            <label class="switch"><input type="checkbox" checked=${f.enabled} onChange=${s(h,f)} /><span></span>${f.enabled?"Enabled":"Disabled"}</label>
          </div>`)}
      </div>
    <//>`}`}var No="gateway-automation",gn=2,kl=e=>new Promise(t=>setTimeout(t,e));async function Oo(e,t,n,i){let o={format:No,version:gn,enabled:e.enabled,outputs:[],switches:[],motion:[],schedules:[],devices:[]};for(let r of t)o.outputs.push({name:r.name,output:await E.outputs.get(r.name)});for(let r of await E.switches.list())o.switches.push({name:r.name,...mn(await $n(r.name,r.buttons))});for(let r of n)o.motion.push({name:r.name,enabled:r.enabled,config:await E.motion.get(r.name)});for(let r of i)o.schedules.push({name:r.name,enabled:r.enabled,config:await E.schedules.get(r.name)});for(let r of await E.devices.list())o.devices.push({device:r.device,...await E.devices.get(r.device)});return o}function Fo(e,t,n){let i=document.createElement("a");i.href=URL.createObjectURL(new Blob([e],{type:n})),i.download=t,i.click(),URL.revokeObjectURL(i.href)}function xl({status:e,outputs:t,motion:n,schedules:i,reload:o}){let[r,a]=_([]),[s,l]=_(!1),[u,p]=_(!1),[c,f]=_(null),h=x=>a(A=>[...A,x]),v=async x=>{l(!0),a([]);try{let A=await Oo(e,t,n,i),M=new Date().toISOString().slice(0,10);x?Fo(_t(A),`automation-${M}.yaml`,"application/yaml"):Fo(JSON.stringify(A,null,2),`automation-${M}.json`,"application/json"),h(`Exported ${A.outputs.length} outputs, ${A.switches.length} switch configurations, ${A.motion.length} motion lights, ${A.schedules.length} schedules.`)}catch(A){h(`Failed: ${A.message}`)}l(!1)},y=async()=>{l(!0);try{f(_t(await Oo(e,t,n,i)))}catch(x){D(x.message,"error")}l(!1)},g=async(x,A)=>{try{await A(),h(`\u2713 ${x}`)}catch(M){h(`\u2717 ${x}: ${M.field?M.field+": ":""}${M.message}`)}},m=async x=>{if(!x||x.format!==No)return D("Not an automation backup","error");if(x.version!==gn)return D(`Version ${x.version} isn't supported (this page writes ${gn})`,"error");if(u&&!confirm("Delete every output, switch configuration, motion light and schedule on the gateway first?"))return;if(l(!0),a([]),u){for(let b of await E.switches.list())await g(`delete switch ${b.name}`,()=>E.switches.remove(b.name));for(let b of n)await g(`delete ${b.name}`,()=>E.motion.remove(b.name));for(let b of i)await g(`delete ${b.name}`,()=>E.schedules.remove(b.name));let S=[...t].sort((b,N)=>(N.kind==="group")-(b.kind==="group"));for(let b of S)await g(`delete ${b.name}`,()=>E.outputs.remove(b.name))}let A=S=>Object.keys(S.output)[0]==="group",M=x.outputs||[];for(let S of[...M.filter(b=>!A(b)),...M.filter(A)])await g(`output ${S.name}`,()=>E.outputs.put(S.name,S.output));for(let S of x.motion||[])await g(`motion light ${S.name}`,()=>E.motion.put(S.name,S.config));for(let S of x.schedules||[])await g(`schedule ${S.name}`,()=>E.schedules.put(S.name,S.config));for(let S of x.switches||[])await g(`switch ${S.name}`,()=>vn(S.name,kt(S)));for(let S of x.devices||[])await g(`device notes ${Z([],S.device)}`,()=>E.devices.put(S.device,{features:S.features||[],lamps:S.lamps||[]}));let w=[...(x.motion||[]).map(S=>[S,E.motion]),...(x.schedules||[]).map(S=>[S,E.schedules])].filter(([S])=>S.enabled===!1);w.length&&await kl(1e3);for(let[S,b]of w)await g(`disable ${S.name}`,()=>b.setEnabled(S.name,!1));typeof x.enabled=="boolean"&&x.enabled!==e.enabled&&await g(`master switch ${x.enabled?"on":"off"}`,()=>E.setEnabled(x.enabled)),h("Done."),l(!1),o()},$=async x=>{let A=x.target.files[0];if(x.target.value="",!!A)try{await m(bt(await A.text()))}catch(M){D(`${A.name}: ${M.message}`,"error")}},R=async()=>{let x;try{x=bt(c)}catch(A){return D(A.message,"error")}await m(x),f(null)};return d`<${O} title="Backup">
    <p class="muted">The whole configuration as one file (YAML or JSON): to keep, to edit, to write by hand, or to move to another gateway. Devices are stored by type and id.</p>
    <div class="buttons">
      <button class="primary" disabled=${s} onClick=${()=>v(!0)}>Export YAML</button>
      <button disabled=${s} onClick=${()=>v(!1)}>Export JSON</button>
      <label class=${"button"+(s?" disabled":"")}>Import…<input type="file" accept=".json,.yaml,.yml,application/json,application/yaml" hidden disabled=${s} onChange=${$} /></label>
      <button disabled=${s||c!==null} onClick=${y}>Edit everything as YAML</button>
      <label class="check"><input type="checkbox" checked=${u} onChange=${x=>p(x.target.checked)} /> Delete everything first</label>
    </div>
    ${c!==null&&d`<div class="text-all">
      <textarea class="code" rows="28" spellcheck="false" value=${c} onInput=${x=>f(x.target.value)} />
      <div class="buttons">
        <button class="primary" disabled=${s} onClick=${R}>Apply</button>
        <button onClick=${()=>f(null)}>Cancel</button>
        <small class="muted">Applying stores every item as written; with “Delete everything first”, what isn't in the text is removed.</small>
      </div>
    </div>`}
    ${r.length>0&&d`<pre class="log">${r.join(`
`)}</pre>`}
  <//>`}function xt({target:e,label:t,others:n=[],onDone:i}){let[o,r]=_(null),[a,s]=_(null),[l,u]=_(""),[p,c]=_(null),f=re(null);W(()=>()=>clearInterval(f.current),[]);let h=()=>{clearInterval(f.current),f.current=setInterval(async()=>{try{c(await Bt.job())}catch{}},1500)},v=async($,R)=>{u($),s(0),R!=="gateway"&&h();try{let x=await o.arrayBuffer();return await Bt.upload(R,x,s)||{}}finally{clearInterval(f.current),s(null)}},y=async $=>{if(!o)return;let R=0;for(let{name:x,target:A}of $)try{let M=await v(x,A);R+=1,M.restarting&&D("Firmware installed, the gateway restarts\u2026")}catch(M){D(`${x}: ${M.message}`,"error");break}R===$.length&&$[0].target!=="gateway"&&D(R===1?"Firmware sent; the device restarts into it":`Firmware sent to ${R} devices`),u(""),c(null),i&&i()},g=a!==null,m=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${$=>r($.target.files[0]||null)} />
      <${F} onClick=${()=>y([{name:t||"device",target:e}])} disabled=${!o||g}>${t||"Upload"}<//>
      ${n.length>0&&d`<${F} onClick=${()=>y([{name:"this device",target:e},...n])} disabled=${!o||g}>Send to all ${n.length+1} of this type<//>`}
      ${g&&d`<progress max="1" value=${a}></progress>`}
      ${g&&d`<p class="muted wide">${l}${m?" \u2014 "+m:""}</p>`}
    </div>`}var Cl={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},Mo={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},bn=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],Sl={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},He=e=>Sl[e]||e;function Ct(e,t=5e3){let n=V(()=>fe.list(e),t),i=[...new Set((n.data||[]).map(r=>r.device))];return{...n,ask:async()=>{for(let r of e?[e]:i)await T(()=>fe.refresh(r));setTimeout(n.reload,1500)}}}function Al({s:e,device:t,reload:n}){let[i,o]=_(!1),[r,a]=_(e.name||""),[s,l]=_(e.role||"none"),u=async()=>{let p={};if(r!==(e.name||"")&&(p.name=r),s!==(e.role||"none")&&(p.role=s),Object.keys(p).length===0)return o(!1);await T(()=>fe.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${X} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${i?d`<input class="inline" maxlength="7" placeholder="name" value=${r} onInput=${p=>a(p.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${Cl[e.kind]||e.kind}</td>
    <td>${i?d`<select value=${s} onChange=${p=>l(p.target.value)}>${bn.map(p=>d`<option value=${p}>${He(p)}</option>`)}</select>`:e.role&&e.role!=="none"?He(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind in Mo?e.value.toFixed(Mo[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:we(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":i?d`<${F} kind="primary" onClick=${u}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function yn({device:e}){let{data:t,error:n,reload:i,ask:o}=Ct(e);if(!t)return d`<${j} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let r=t.some(a=>a.named_by_node&&a.slot===null);return d`
    ${r&&d`<p class="muted">The names and roles of some sensors are not known yet. <${F} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(a=>d`<${Al} key=${a.device_key+a.kind+a.sensor_id} s=${a} device=${e} reload=${i} />`)}
      </tbody>
    </table></div>`}function Ro(){let{ask:e}=Ct(void 0,0);return d`<${O} title="Sensors" aside=${d`<${F} onClick=${e}>Reload names and roles<//>`}>
    <${yn} />
  <//>`}var Tl=[2,5,8,9],El=[7],Ll=[3],Ol=3,wn=[9],Fl=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],Il=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ho({device:e}){let{data:t,error:n,reload:i}=V(()=>B.get(e),5e3);return t?d`
    <${Rl} d=${t} reload=${i} />
    ${Tl.includes(t.device_type)&&d`<${Do} d=${t} kind="relay" />`}
    ${El.includes(t.device_type)&&d`<${Do} d=${t} kind="rollershutter" />`}
    ${Ll.includes(t.device_type)&&d`<${Po} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===Ol&&d`<${Po} d=${t} firstBank=${1} />`}
    ${wn.includes(t.device_type)&&d`<${Dl} d=${t} />`}
    ${wn.includes(t.device_type)&&d`<${Hl} d=${t} />`}
    ${wn.includes(t.device_type)&&d`<${Ul} d=${t} />`}
    <${O} title="Sensors"><${yn} device=${t.name||t.key} /><//>
    <${Nl} d=${t} />
    <${jl} d=${t} reload=${i} />
    <${Ml} d=${t} />`:d`<${j} error=${n} />`}function Nl({d:e}){let t={type:e.device_type,id:e.device_id},{data:n,error:i,reload:o}=V(()=>E.devices.get(t)),[r,a]=_(!1);if(!n)return d`<${O} title="On board"><${j} error=${i} /><//>`;let s=async l=>{let u=n.features.includes(l)?n.features.filter(p=>p!==l):[...n.features,l];a(!0),await T(()=>E.devices.put(t,{...n,features:u}),"Saved")!==void 0&&(oo(),await o()),a(!1)};return d`<${O} title="On board">
    <p class="muted">What this device has, for the automation: it offers motion detectors, brightness sensors and night lights only where they are.</p>
    <div class="checks">
      ${ro.map(([l,u])=>d`<label class="check" key=${l}>
          <input type="checkbox" disabled=${r} checked=${n.features.includes(l)} onChange=${()=>s(l)} /> ${u}
        </label>`)}
    </div>
  <//>`}function Ml({d:e}){let t=e.name||e.key,{data:n}=V(B.list),i=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${O} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${xt} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${i} />
    <//>`}function Rl({d:e,reload:t}){let n=e.name||e.key,i=(o,r)=>async()=>{await T(()=>B.action(n,o),r),setTimeout(t,1500)};return d`
    <${O} title=${n}
      aside=${d`<span class="buttons">
        <${F} onClick=${i("ping","Ping sent")}>Ping<//>
        <${F} onClick=${i("refresh","Refresh requested")}>Refresh<//>
        <${F} kind="danger" onClick=${i("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${we(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Do({d:e,kind:t}){let n=e.name||e.key,[i,o]=_(1),[r,a]=_(0),s=t==="rollershutter",l=u=>()=>T(()=>B[t](n,i,u,Math.round(r*1e3)),`${s?"Rollershutter":"Relay"} ${i}: ${u}`);return d`
    <${O} title=${s?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${L} label="Number"><input type="number" min="1" max="16" value=${i} onInput=${u=>o(+u.target.value)} /><//>
        <${L} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${r} onInput=${u=>a(+u.target.value)} /><//>
      </div>
      <div class="buttons">
        ${s?d`<${F} onClick=${l("up")}>Up<//><${F} onClick=${l("down")}>Down<//><${F} onClick=${l("off")}>Stop<//>`:d`<${F} kind="primary" onClick=${l("on")}>On<//><${F} onClick=${l("off")}>Off<//>`}
      </div>
    <//>`}function Po({d:e,firstBank:t=0}){let n=e.name||e.key,[i,o]=_(t),[r,a]=_(255),[s,l]=_(Array(24).fill(!1)),u=s.reduce((p,c,f)=>c?p|1<<23-f:p,0);return d`
    <${O} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${L} label="Bank"><input type="number" min=${t} max="255" value=${i} onInput=${p=>o(+p.target.value)} /><//>
        <${L} label="Value (0-255)"><input type="number" min="0" max="255" value=${r} onInput=${p=>a(+p.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((p,c)=>d`<label key=${c} class=${"lamp"+(p?" on":"")}>
            <input type="checkbox" checked=${p} onChange=${()=>l(s.map((f,h)=>h===c?!f:f))} />${23-c}
          </label>`)}
      </div>
      <${F} kind="primary" onClick=${()=>T(()=>B.lamps(n,i,r,u),"Lamps set")}>Send<//>
    <//>`}function Dl({d:e}){let t=e.name||e.key,[n,i]=_(45),[o,r]=_(!1),[a,s]=_(0),[l,u]=_(!1),[p,c]=_(0),[f,h]=_(55);return d`
    <${O} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${L} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${v=>i(+v.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${v=>r(v.target.checked)} /> from the tank</label>
        <${F} onClick=${()=>T(()=>B.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${L} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${a} onInput=${v=>s(+v.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${l} onChange=${v=>u(v.target.checked)} /> rod released</label>
        <${F} onClick=${()=>T(()=>B.heating(t,"energy",{power_w:a,rod_enabled:l}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${L} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${v=>c(+v.target.value)} /><//>
        <${L} label="Tank (°C)"><input type="number" step="0.5" value=${f} onInput=${v=>h(+v.target.value)} /><//>
        <${F} kind="danger" onClick=${()=>T(()=>B.heating(t,"emergency",{stage:p,tank_c:f}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var Pl=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function Hl({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o,ask:r}=Ct(t);if(!n)return d`<${O} title="Sensor assignment"><${j} error=${i} /><//>`;let a=n.filter(c=>c.kind==="temperature"),s=c=>a.find(f=>f.role===c),l=c=>c.name?`${c.name} (${c.sensor_id})`:c.sensor_id,u=a.every(c=>c.slot!==null),p=c=>async f=>{let h=f.target.value,v;if(h===""){let y=s(c);if(!y)return;v=await T(()=>fe.update(t,y.slot,{role:"none"}),`${He(c)} cleared`)}else{let y=a.find(g=>g.sensor_id===h);v=await T(()=>fe.update(t,y.slot,{role:c}),`${l(y)} is ${He(c)} now`)}v&&setTimeout(o,1500)};return d`
    <${O} title="Sensor assignment" aside=${d`<${F} onClick=${r}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!u&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${bn.filter(c=>c!=="none").map(c=>d`<label key=${c} class="field">
            <span>${He(c)}</span>
            <select value=${(s(c)||{}).sensor_id||""} onChange=${p(c)} disabled=${!u}>
              <option value="">(none)</option>
              ${a.map(f=>d`<option value=${f.sensor_id}>${l(f)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Ul({d:e}){let t=e.name||e.key,{data:n,error:i,reload:o}=V(()=>B.heatingManualState(t),3e3),r=!!(n&&n.enabled),a=p=>!!(n&&n.relays.includes(p)),s=async()=>{let p=!r;await T(()=>B.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},l=p=>async()=>{await T(()=>B.heatingManual(t,!0,p,!a(p)),`Relay ${p} ${a(p)?"off":"on"}`)&&setTimeout(o,800)},u=p=>p===8&&a(9)||p===9&&a(8);return d`
    <${O} title="Manual mode"
      aside=${d`<${F} kind=${r?"danger":""} disabled=${!n} onClick=${s}>${r?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${i&&d`<p class="error">The controller does not answer: ${i.message}</p>`}
      ${r&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${Pl.map(([p,c])=>d`<button key=${p} class=${a(p)?"primary":""} disabled=${!r||u(p)} onClick=${l(p)}>
            <span>${c}</span><small>relay ${p}: ${a(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function jl({d:e,reload:t}){let n=e.name||e.key,[i,o]=_({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[r,a]=_(!1),s=u=>p=>o({...i,[u]:p.target.value}),l=async()=>{let u={};if(i.custom_string!==e.name&&(u.custom_string=i.custom_string),+i.hwrev!==e.hwrev&&(u.hwrev=+i.hwrev),i.relais_mode&&(u.relais_mode=i.relais_mode),i.extension_mode&&(u.extension_mode=i.extension_mode),Object.keys(u).length===0)return D("Nothing changed");await T(()=>B.update(n,u),"Settings sent")&&setTimeout(t,1500)};return d`
    <${O} title="Settings">
      <div class="row">
        <${L} label="Name" hint="up to 8 characters"><input maxlength="8" value=${i.custom_string} onInput=${s("custom_string")} /><//>
        <${L} label="Hardware revision"><input type="number" min="0" max="255" value=${i.hwrev} onInput=${s("hwrev")} /><//>
        <${L} label="Relay mode"><select value=${i.relais_mode} onChange=${s("relais_mode")}>
          <option value="">(unchanged)</option>${Fl.map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${L} label="Extension mode"><select value=${i.extension_mode} onChange=${s("extension_mode")}>
          <option value="">(unchanged)</option>${Il.map(u=>d`<option>${u}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${F} kind="primary" onClick=${l}>Save<//>
        <${F} onClick=${async()=>{await T(()=>B.silence(n,!r),r?"Device may talk again":"Device silenced"),a(!r)}}>${r?"End silence":"Silence"}<//>
        <${F} onClick=${()=>T(()=>B.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Uo(){let{data:e,error:t,reload:n}=V(B.list,5e3),[i,o]=_(""),r=(u,p)=>async()=>{await T(u,p),setTimeout(n,1500)},a=async()=>{let u=i.trim();u&&await T(()=>B.action(u,"ping"),`Ping sent to ${u}`)},s=async()=>{confirm("Restart every device on the bus?")&&await r(()=>Te.action("restart"),"Restart sent to every device")()},l=r(()=>Te.action("discover"),"Scanning: every device was asked to announce itself");return d`
    <${O} title="Devices">
      <div class="toolbar">
        <${F} onClick=${n}>Refresh<//>
        <${F} onClick=${r(()=>Te.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${F} onClick=${r(()=>Te.silence(!0),"Every device is silenced")}>Silence on<//>
        <${F} onClick=${r(()=>Te.silence(!1),"Every device may talk again")}>Silence off<//>
        <${F} kind="danger" onClick=${s}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${i} onInput=${u=>o(u.target.value)} onKeyDown=${u=>u.key==="Enter"&&a()} />
        <${F} onClick=${a}>Ping<//>
        <${F} onClick=${l}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(u=>d`<tr key=${u.key}>
                    <td><${X} href=${"/devices/"+encodeURIComponent(u.name||u.key)}>${u.name||u.key}<//></td>
                    <td><code>${Wt(u.device_id)}</code></td>
                    <td>${u.type_name} <code>${Wt(u.device_type)}</code></td>
                    <td>${u.version}</td>
                    <td>${we(u.last_seen_minutes_ago)}</td>
                    <td>${u.uptime?we(Math.floor(u.uptime/60)):""}</td>
                    <td>${u.error?d`<span class="badge bad">error ${u.error}</span>`:u.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${j} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function jo(){let e=V(Ht.get,5e3);return d`<${Bl} ...${e} /><${ql} ...${e} /><${Yl} /><${Kl} /><${Gl} />`}function Bl({data:e,error:t}){return d`
    <${O} title="Gateway" aside=${d`<${F} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await T(Ht.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${hi(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${j} error=${t} />`}
    <//>`}function ql({data:e,error:t}){if(!e)return d`<${O} title="Network"><${j} error=${t} /><//>`;let n=e.network;if(!n)return d`<${O} title="Network"><p>No Ethernet.</p><//>`;let i=r=>r.map(a=>d`<div>${a.address} <span class="muted">(${a.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${O} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?i(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?i(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function Yl(){let{data:e,error:t,reload:n}=V(Ut.get),[i,o]=_({});if(!e)return d`<${j} error=${t} />`;let r=l=>l in i?i[l]:e[l],a=(l,u)=>p=>o({...i,[l]:u?+p.target.value:p.target.value}),s=async()=>{let l={...i};if(l.web_password||delete l.web_password,Object.keys(l).length===0)return D("Nothing changed");let u=await T(()=>Ut.update(l),"Saved");u&&(u.restart_required&&D("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${O} title="Settings">
      <div class="row">
        <${L} label="Hostname"><input value=${r("hostname")} onInput=${a("hostname")} /><//>
        <${L} label="CAN bitrate"><select value=${r("can_bitrate")} onChange=${a("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${L} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${r("update_delay_ms")} onInput=${a("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${L} label="User name"><input value=${r("web_username")} onInput=${a("web_username")} autocomplete="off" /><//>
        <${L} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${i.web_password||""} onInput=${a("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${F} kind="primary" onClick=${s}>Save<//></div>
    <//>`}var Wl=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function Kl(){let{data:e,error:t,reload:n}=V(jt.get),[i,o]=_({});if(!e)return d`<${O} title="Location and time"><${j} error=${t} /><//>`;let r=c=>c in i?i[c]:e[c]??"",a=c=>f=>o({...i,[c]:f.target.value}),s=async()=>{let c={};if(("latitude"in i||"longitude"in i)&&(c.latitude=parseFloat(r("latitude")),c.longitude=parseFloat(r("longitude")),Number.isNaN(c.latitude)||Number.isNaN(c.longitude)))return D("Latitude and longitude are numbers");if("timezone"in i&&(c.timezone=i.timezone.trim()),Object.keys(c).length===0)return D("Nothing changed");await T(()=>jt.update(c),"Saved")&&(o({}),n())},l=()=>{if(!navigator.geolocation)return D("This browser has no location","error");navigator.geolocation.getCurrentPosition(c=>o({...i,latitude:c.coords.latitude.toFixed(4),longitude:c.coords.longitude.toFixed(4)}),c=>D(`No location: ${c.message}`,"error"),{timeout:15e3})},u=e.utc_offset_minutes,p=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return d`
    <${O} title="Location and time">
      <p class="muted">
        For switching by local time and by the sun (schedules, motion light levels). Two decimals (about 1 km) are plenty.
        Take this browser's location, or look the place up on a map: in OpenStreetMap or Google Maps a right click on the house shows
        latitude and longitude. Save, then check today's sunrise and sunset below.
      </p>
      <div class="row">
        <${L} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${r("latitude")} onInput=${a("latitude")} /><//>
        <${L} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${r("longitude")} onInput=${a("longitude")} /><//>
        <${L} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${r("timezone")} onInput=${a("timezone")} /><//>
      </div>
      <div class="buttons"><${F} kind="primary" onClick=${s}>Save<//><button onClick=${l}>Use this browser's location</button></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${p})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?Wl.map(([c,f])=>d`<div><dt>${f}</dt><dd>${e.sun[c]||d`<span class="muted">not today</span>`}</dd></div>`):d`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function Gl(){return d`
    <${O} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${xt} target="gateway" label="Install and restart" />
    <//>`}var Vl=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],Ql={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Xl={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},me=async(e,t)=>await T(e,t)!==void 0,kn=e=>e?new Date(e).toLocaleString():"\u2014";function xn({label:e,accept:t,send:n,success:i,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async a=>{let s=a.target.files[0];if(a.target.value="",!s)return;let l=await s.text();await me(()=>n(l),i)&&o&&o()}} hidden /></label>`}function Bo(){let{data:e,error:t,reload:n}=V(ee.get,1e4);return e?d`
    <${zl} d=${e} />
    <${Jl} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${Zl} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${ec} reload=${n} />`}
    ${e.mode==="est"&&d`<${tc} d=${e} reload=${n} />`}
    <${nc} d=${e} reload=${n} />
    <${ic} d=${e} reload=${n} />`:d`<${j} error=${t} />`}function Cn({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${kn(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${kn(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function zl({d:e}){let t=e.certificate,[n,i]=t?Ql[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${O} title="Certificate" aside=${d`<span class=${"badge "+i}>${n}</span>`}>
      ${t?d`<${Cn} c=${t} />
            <p class="muted">Made: ${Xl[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&d`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Jl({d:e,reload:t}){let[n,i]=_(e.fqdn),[o,r]=_(e.mode),a=async()=>{let s={};if(n!==e.fqdn&&(s.fqdn=n.trim()),o!==e.mode&&(s.mode=o),Object.keys(s).length===0)return D("Nothing changed");await me(()=>ee.update(s),"Saved")&&t()};return d`
    <${O} title="HTTPS settings">
      <div class="row">
        <${L} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${s=>i(s.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${Vl.map(([s,l,u])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${s} checked=${o===s} onChange=${()=>r(s)} />
          <span><strong>${l}</strong><small class="muted">${u}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${F} kind="primary" onClick=${a}>Save<//></div>
    <//>`}function Zl({d:e,reload:t}){let[n,i]=_(e.validity_years);return d`
    <${O} title="Self-signed certificate">
      <div class="row">
        <${L} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${r=>i(+r.target.value)} /><//>
      </div>
      <div class="buttons"><${F} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await me(()=>ee.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function ec({reload:e}){return d`
    <${O} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${ee.csrUrl()} download="gateway.csr">Download CSR</a>
        <${xn} label="Upload certificate" send=${ee.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function tc({d:e,reload:t}){let n=e.est,[i,o]=_(n.url),[r,a]=_(n.auto_renew),s=async()=>{await me(()=>ee.update({est_url:i.trim(),est_auto_renew:r}),"Saved")&&t()},l=async()=>{await me(ee.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${O} title="EST">
      <div class="row">
        <${L} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${i} onInput=${u=>o(u.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${r} onChange=${u=>a(u.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${kn(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${Cn} c=${n.identity} />`}
      <div class="buttons">
        <${xn} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${ee.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${F} kind="danger" onClick=${async()=>await me(ee.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${F} kind="primary" onClick=${s}>Save<//>
        <${F} onClick=${l}>Enroll / renew now<//>
      </div>
    <//>`}function nc({d:e,reload:t}){let n=e.trust_anchor,i=async o=>{await me(()=>ee.update({built_in_roots:o}),o?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return d`
    <${O} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${o=>i(o.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?d`<${Cn} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${xn} label=${n?"Replace":"Upload"} send=${ee.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&d`<${F} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await me(ee.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function ic({d:e,reload:t}){let[n,i]=_(e.ntp_server),o=async()=>{await me(()=>ee.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${O} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${L} label="NTP server"><input value=${n} placeholder="automatic" onInput=${r=>i(r.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&d`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?d` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${F} onClick=${o}>Save<//></div>
    <//>`}var oc=2e3;function qo(){let[e,t]=_([]),[n,i]=_(null),[o,r]=_(!1),[a,s]=_(""),[l,u]=_(!1),p=re(0),c=re(null),f=re(!0),h=re(!1);h.current=o,W(()=>{let $=!1,R,x=async()=>{if(!h.current)try{for(let A=0;A<10;A++){let M=await qt.read(p.current);if(u(M.can_to_mqtt),i(null),M.from>p.current&&p.current>0&&t(w=>[...w,"\u2026 (older lines were overwritten)"]),p.current=M.next,M.text&&t(w=>[...w,...M.text.replace(/\n$/,"").split(`
`)].slice(-oc)),!M.text)break}}catch(A){i(A.message)}$||(R=setTimeout(x,2e3))};return x(),()=>{$=!0,clearTimeout(R)}},[]),W(()=>{let $=c.current;$&&f.current&&($.scrollTop=$.scrollHeight)},[e,a]);let v=()=>{let $=c.current;f.current=$.scrollHeight-$.scrollTop-$.clientHeight<30},y=a?e.filter($=>$.toLowerCase().includes(a.toLowerCase())):e,g=async $=>{let R=await T(()=>qt.setCanToMqtt($),$?"CAN frames go to MQTT":"CAN frames no longer go to MQTT");R&&u(R.can_to_mqtt)};return d`
    <${O} title="Log" aside=${d`<div class="buttons">
      <button onClick=${()=>r(!o)}>${o?"Resume":"Pause"}</button>
      <button onClick=${()=>t([])}>Clear view</button>
      <button onClick=${()=>{let $=document.createElement("a");$.href=URL.createObjectURL(new Blob([e.join(`
`)+`
`],{type:"text/plain"})),$.download=`gateway-log-${new Date().toISOString().slice(0,19).replace(/:/g,"")}.txt`,$.click(),URL.revokeObjectURL($.href)}} disabled=${!e.length}>Save as file</button>
    </div>`}>
      <p class="muted">What the gateway printed on its console, newest at the bottom; the gateway keeps the last few kilobytes. Times are seconds since the start.</p>
      <div class="row tight">
        <input type="search" placeholder="Filter, e.g. mqtt or automation" aria-label="Filter" value=${a} onInput=${$=>s($.target.value)} />
      </div>
      <pre class="log console" ref=${c} onScroll=${v}>${y.join(`
`)||(n?"":"Waiting for lines\u2026")}</pre>
      ${n&&d`<p class="error">${n}</p>`}
    <//>
    <${O} title="CAN traffic to MQTT">
      <p class="muted">Every CAN frame sent and received also goes to <code>${"canbus/log/0x<id>"}</code> (<code>0x</code> and the data bytes, <code>R…</code> for a request), as the old gateway did. For debugging: it is a lot of messages. Off again after a restart. Frames can be sent to the bus with <code>${"canbus/debug/<id>"}</code>.</p>
      <label class="switch"><input type="checkbox" checked=${l} onChange=${$=>g($.target.checked)} /><span></span>${l?"On":"Off"}</label>
    <//>`}var rc={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Wo(){let{data:e,error:t,reload:n}=V(ye.all,5e3);return e?d`
    <${Yo} slot="primary" b=${e.primary} reload=${n} />
    <${Yo} slot="secondary" b=${e.secondary} reload=${n} />
    <${ac} on=${e.home_assistant} reload=${n} />`:d`<${j} error=${t} />`}function ac({on:e,reload:t}){return d`
    <${O} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async i=>{let o=i.target.checked;await T(()=>ye.updateAll({home_assistant:o}),o?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}var sc={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function Yo({slot:e,b:t,reload:n}){let[i,o]=_({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[r,a]=_(null),s=i.uri.startsWith("mqtts://"),l=c=>f=>o({...i,[c]:f.target.type==="checkbox"?f.target.checked:f.target.value}),u=async()=>{let c={uri:i.uri,user:i.user,enabled:i.enabled,tls_insecure:i.tls_insecure};i.password&&(c.password=i.password),await T(()=>ye.update(e,c),`${e} broker saved, reconnecting`)&&(o({...i,password:""}),setTimeout(n,2500))},p=async()=>{let c=await T(()=>ye.certificate(e));c&&a(c)};return d`
    <${O}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${rc[e]}</p>
      <div class="row">
        <${L} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${i.uri} onInput=${l("uri")} /><//>
        <${L} label="User"><input value=${i.user} onInput=${l("user")} autocomplete="off" /><//>
        <${L} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${i.password} onInput=${l("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${i.enabled} onChange=${l("enabled")} /> Connect to this broker</label>
      ${s&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${sc[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${i.tls_insecure} onChange=${l("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${F} onClick=${async()=>{await T(()=>ye.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${F} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${F} kind="danger" onClick=${async()=>{await T(()=>ye.forget(e),"Certificate forgotten"),a(null),n()}}>Forget<//>`}
          </div>
          ${r&&d`<p>${r.pinned?d`SHA-256 <code>${r.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${F} kind="primary" onClick=${u}>Save<//></div>
    <//>`}var lc=[{path:"/",title:"Devices",page:Uo},{path:"/devices/:device",title:"Device",page:Ho},{path:"/sensors",title:"Sensors",page:Ro},{path:"/automation",title:"Automation",page:_n},{path:"/automation/:tab",title:"Automation",page:_n},{path:"/mqtt",title:"MQTT",page:Wo},{path:"/gateway",title:"Gateway",page:jo},{path:"/https",title:"HTTPS",page:Bo},{path:"/log",title:"Log",page:qo}],cc=[["/","Devices"],["/sensors","Sensors"],["/automation","Automation"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"],["/log","Log"]];function uc(){let e=li(),t=ci(lc,e),n=t?t.route.page:null,i=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${cc.map(([o,r])=>d`<${X} href=${o} class=${i(o)?"active":""}>${r}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${X} href="/">Devices<//></p>`}
    </main>
    <${fi} />`}qn(d`<${uc} />`,document.getElementById("app"));
