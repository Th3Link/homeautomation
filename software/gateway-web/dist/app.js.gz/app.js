var Ht=Object.create;var Ie=Object.defineProperty;var At=Object.getOwnPropertyDescriptor;var It=Object.getOwnPropertyNames;var Mt=Object.getPrototypeOf,Pt=Object.prototype.hasOwnProperty;var Ut=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Nt=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of It(t))!Pt.call(e,a)&&a!==n&&Ie(e,a,{get:()=>t[a],enumerable:!(o=At(t,a))||o.enumerable});return e};var Dt=(e,t,n)=>(n=e!=null?Ht(Mt(e)):{},Nt(t||!e||!e.__esModule?Ie(n,"default",{value:e,enumerable:!0}):n,e));var dt=Ut(Te=>{var _t;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Te=="object"?e(Te):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(_t={}):e(_t={})})(function(e){e.version="1.2.2";function t(){for(var d=0,L=new Array(256),f=0;f!=256;++f)d=f,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,d=d&1?-306674912^d>>>1:d>>>1,L[f]=d;return typeof Int32Array<"u"?new Int32Array(L):L}var n=t();function o(d){var L=0,f=0,g=0,v=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(g=0;g!=256;++g)v[g]=d[g];for(g=0;g!=256;++g)for(f=d[g],L=256+g;L<4096;L+=256)f=v[L]=f>>>8^d[f&255];var x=[];for(g=1;g!=16;++g)x[g-1]=typeof Int32Array<"u"?v.subarray(g*256,g*256+256):v.slice(g*256,g*256+256);return x}var a=o(n),r=a[0],s=a[1],u=a[2],l=a[3],i=a[4],p=a[5],c=a[6],m=a[7],h=a[8],y=a[9],I=a[10],F=a[11],w=a[12],k=a[13],W=a[14];function N(d,L){for(var f=L^-1,g=0,v=d.length;g<v;)f=f>>>8^n[(f^d.charCodeAt(g++))&255];return~f}function Q(d,L){for(var f=L^-1,g=d.length-15,v=0;v<g;)f=W[d[v++]^f&255]^k[d[v++]^f>>8&255]^w[d[v++]^f>>16&255]^F[d[v++]^f>>>24]^I[d[v++]]^y[d[v++]]^h[d[v++]]^m[d[v++]]^c[d[v++]]^p[d[v++]]^i[d[v++]]^l[d[v++]]^u[d[v++]]^s[d[v++]]^r[d[v++]]^n[d[v++]];for(g+=15;v<g;)f=f>>>8^n[(f^d[v++])&255];return~f}function V(d,L){for(var f=L^-1,g=0,v=d.length,x=0,ve=0;g<v;)x=d.charCodeAt(g++),x<128?f=f>>>8^n[(f^x)&255]:x<2048?(f=f>>>8^n[(f^(192|x>>6&31))&255],f=f>>>8^n[(f^(128|x&63))&255]):x>=55296&&x<57344?(x=(x&1023)+64,ve=d.charCodeAt(g++)&1023,f=f>>>8^n[(f^(240|x>>8&7))&255],f=f>>>8^n[(f^(128|x>>2&63))&255],f=f>>>8^n[(f^(128|ve>>6&15|(x&3)<<4))&255],f=f>>>8^n[(f^(128|ve&63))&255]):(f=f>>>8^n[(f^(224|x>>12&15))&255],f=f>>>8^n[(f^(128|x>>6&63))&255],f=f>>>8^n[(f^(128|x&63))&255]);return~f}e.table=n,e.bstr=N,e.buf=Q,e.str=V})});var _e,S,De,Ot,j,Me,Oe,qe,We,ye,$e,ge,qt,ee={},Ve=[],Wt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,de=Array.isArray;function O(e,t){for(var n in t)e[n]=t[n];return e}function be(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function te(e,t,n){var o,a,r,s={};for(r in t)r=="key"?o=t[r]:r=="ref"?a=t[r]:s[r]=t[r];if(arguments.length>2&&(s.children=arguments.length>3?_e.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)s[r]===void 0&&(s[r]=e.defaultProps[r]);return ce(e,s,o,a,null)}function ce(e,t,n,o,a){var r={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:a??++De,__i:-1,__u:0};return a==null&&S.vnode!=null&&S.vnode(r),r}function pe(e){return e.children}function le(e,t){this.props=e,this.context=t}function z(e,t){if(t==null)return e.__?z(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?z(e):null}function je(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return je(e)}}function Pe(e){(!e.__d&&(e.__d=!0)&&j.push(e)&&!ue.__r++||Me!=S.debounceRendering)&&((Me=S.debounceRendering)||Oe)(ue)}function ue(){for(var e,t,n,o,a,r,s,u=1;j.length;)j.length>u&&j.sort(qe),e=j.shift(),u=j.length,e.__d&&(n=void 0,a=(o=(t=e).__v).__e,r=[],s=[],t.__P&&((n=O({},o)).__v=o.__v+1,S.vnode&&S.vnode(n),we(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[a]:null,r,a??z(o),!!(32&o.__u),s),n.__v=o.__v,n.__.__k[n.__i]=n,Be(r,n,s),n.__e!=a&&je(n)));ue.__r=0}function Ge(e,t,n,o,a,r,s,u,l,i,p){var c,m,h,y,I,F,w=o&&o.__k||Ve,k=t.length;for(l=Vt(n,t,w,l,k),c=0;c<k;c++)(h=n.__k[c])!=null&&(m=h.__i==-1?ee:w[h.__i]||ee,h.__i=c,F=we(e,h,m,a,r,s,u,l,i,p),y=h.__e,h.ref&&m.ref!=h.ref&&(m.ref&&ke(m.ref,null,h),p.push(h.ref,h.__c||y,h)),I==null&&y!=null&&(I=y),4&h.__u||m.__k===h.__k?l=Ke(h,l,e):typeof h.type=="function"&&F!==void 0?l=F:y&&(l=y.nextSibling),h.__u&=-7);return n.__e=I,l}function Vt(e,t,n,o,a){var r,s,u,l,i,p=n.length,c=p,m=0;for(e.__k=new Array(a),r=0;r<a;r++)(s=t[r])!=null&&typeof s!="boolean"&&typeof s!="function"?(l=r+m,(s=e.__k[r]=typeof s=="string"||typeof s=="number"||typeof s=="bigint"||s.constructor==String?ce(null,s,null,null,null):de(s)?ce(pe,{children:s},null,null,null):s.constructor==null&&s.__b>0?ce(s.type,s.props,s.key,s.ref?s.ref:null,s.__v):s).__=e,s.__b=e.__b+1,u=null,(i=s.__i=jt(s,n,l,c))!=-1&&(c--,(u=n[i])&&(u.__u|=2)),u==null||u.__v==null?(i==-1&&(a>p?m--:a<p&&m++),typeof s.type!="function"&&(s.__u|=4)):i!=l&&(i==l-1?m--:i==l+1?m++:(i>l?m--:m++,s.__u|=4))):e.__k[r]=null;if(c)for(r=0;r<p;r++)(u=n[r])!=null&&(2&u.__u)==0&&(u.__e==o&&(o=z(u)),Qe(u,u));return o}function Ke(e,t,n){var o,a;if(typeof e.type=="function"){for(o=e.__k,a=0;o&&a<o.length;a++)o[a]&&(o[a].__=e,t=Ke(o[a],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=z(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function jt(e,t,n,o){var a,r,s=e.key,u=e.type,l=t[n];if(l===null&&e.key==null||l&&s==l.key&&u==l.type&&(2&l.__u)==0)return n;if(o>(l!=null&&(2&l.__u)==0?1:0))for(a=n-1,r=n+1;a>=0||r<t.length;){if(a>=0){if((l=t[a])&&(2&l.__u)==0&&s==l.key&&u==l.type)return a;a--}if(r<t.length){if((l=t[r])&&(2&l.__u)==0&&s==l.key&&u==l.type)return r;r++}}return-1}function Ue(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Wt.test(t)?n:n+"px"}function se(e,t,n,o,a){var r,s;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||Ue(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||Ue(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(We,"$1")),s=t.toLowerCase(),t=s in e||t=="onFocusOut"||t=="onFocusIn"?s.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?o?n.u=o.u:(n.u=ye,e.addEventListener(t,r?ge:$e,r)):e.removeEventListener(t,r?ge:$e,r);else{if(a=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ne(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=ye++;else if(t.t<n.u)return;return n(S.event?S.event(t):t)}}}function we(e,t,n,o,a,r,s,u,l,i){var p,c,m,h,y,I,F,w,k,W,N,Q,V,d,L,f,g,v=t.type;if(t.constructor!=null)return null;128&n.__u&&(l=!!(32&n.__u),r=[u=t.__e=n.__e]),(p=S.__b)&&p(t);e:if(typeof v=="function")try{if(w=t.props,k="prototype"in v&&v.prototype.render,W=(p=v.contextType)&&o[p.__c],N=p?W?W.props.value:p.__:o,n.__c?F=(c=t.__c=n.__c).__=c.__E:(k?t.__c=c=new v(w,N):(t.__c=c=new le(w,N),c.constructor=v,c.render=Kt),W&&W.sub(c),c.props=w,c.state||(c.state={}),c.context=N,c.__n=o,m=c.__d=!0,c.__h=[],c._sb=[]),k&&c.__s==null&&(c.__s=c.state),k&&v.getDerivedStateFromProps!=null&&(c.__s==c.state&&(c.__s=O({},c.__s)),O(c.__s,v.getDerivedStateFromProps(w,c.__s))),h=c.props,y=c.state,c.__v=t,m)k&&v.getDerivedStateFromProps==null&&c.componentWillMount!=null&&c.componentWillMount(),k&&c.componentDidMount!=null&&c.__h.push(c.componentDidMount);else{if(k&&v.getDerivedStateFromProps==null&&w!==h&&c.componentWillReceiveProps!=null&&c.componentWillReceiveProps(w,N),!c.__e&&c.shouldComponentUpdate!=null&&c.shouldComponentUpdate(w,c.__s,N)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(c.props=w,c.state=c.__s,c.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(x){x&&(x.__=t)}),Q=0;Q<c._sb.length;Q++)c.__h.push(c._sb[Q]);c._sb=[],c.__h.length&&s.push(c);break e}c.componentWillUpdate!=null&&c.componentWillUpdate(w,c.__s,N),k&&c.componentDidUpdate!=null&&c.__h.push(function(){c.componentDidUpdate(h,y,I)})}if(c.context=N,c.props=w,c.__P=e,c.__e=!1,V=S.__r,d=0,k){for(c.state=c.__s,c.__d=!1,V&&V(t),p=c.render(c.props,c.state,c.context),L=0;L<c._sb.length;L++)c.__h.push(c._sb[L]);c._sb=[]}else do c.__d=!1,V&&V(t),p=c.render(c.props,c.state,c.context),c.state=c.__s;while(c.__d&&++d<25);c.state=c.__s,c.getChildContext!=null&&(o=O(O({},o),c.getChildContext())),k&&!m&&c.getSnapshotBeforeUpdate!=null&&(I=c.getSnapshotBeforeUpdate(h,y)),f=p,p!=null&&p.type===pe&&p.key==null&&(f=Je(p.props.children)),u=Ge(e,de(f)?f:[f],t,n,o,a,r,s,u,l,i),c.base=t.__e,t.__u&=-161,c.__h.length&&s.push(c),F&&(c.__E=c.__=null)}catch(x){if(t.__v=null,l||r!=null)if(x.then){for(t.__u|=l?160:128;u&&u.nodeType==8&&u.nextSibling;)u=u.nextSibling;r[r.indexOf(u)]=null,t.__e=u}else for(g=r.length;g--;)be(r[g]);else t.__e=n.__e,t.__k=n.__k;S.__e(x,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):u=t.__e=Gt(n.__e,t,n,o,a,r,s,l,i);return(p=S.diffed)&&p(t),128&t.__u?void 0:u}function Be(e,t,n){for(var o=0;o<n.length;o++)ke(n[o],n[++o],n[++o]);S.__c&&S.__c(t,e),e.some(function(a){try{e=a.__h,a.__h=[],e.some(function(r){r.call(a)})}catch(r){S.__e(r,a.__v)}})}function Je(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:de(e)?e.map(Je):O({},e)}function Gt(e,t,n,o,a,r,s,u,l){var i,p,c,m,h,y,I,F=n.props,w=t.props,k=t.type;if(k=="svg"?a="http://www.w3.org/2000/svg":k=="math"?a="http://www.w3.org/1998/Math/MathML":a||(a="http://www.w3.org/1999/xhtml"),r!=null){for(i=0;i<r.length;i++)if((h=r[i])&&"setAttribute"in h==!!k&&(k?h.localName==k:h.nodeType==3)){e=h,r[i]=null;break}}if(e==null){if(k==null)return document.createTextNode(w);e=document.createElementNS(a,k,w.is&&w),u&&(S.__m&&S.__m(t,r),u=!1),r=null}if(k==null)F===w||u&&e.data==w||(e.data=w);else{if(r=r&&_e.call(e.childNodes),F=n.props||ee,!u&&r!=null)for(F={},i=0;i<e.attributes.length;i++)F[(h=e.attributes[i]).name]=h.value;for(i in F)if(h=F[i],i!="children"){if(i=="dangerouslySetInnerHTML")c=h;else if(!(i in w)){if(i=="value"&&"defaultValue"in w||i=="checked"&&"defaultChecked"in w)continue;se(e,i,null,h,a)}}for(i in w)h=w[i],i=="children"?m=h:i=="dangerouslySetInnerHTML"?p=h:i=="value"?y=h:i=="checked"?I=h:u&&typeof h!="function"||F[i]===h||se(e,i,h,F[i],a);if(p)u||c&&(p.__html==c.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(c&&(e.innerHTML=""),Ge(t.type=="template"?e.content:e,de(m)?m:[m],t,n,o,k=="foreignObject"?"http://www.w3.org/1999/xhtml":a,r,s,r?r[0]:n.__k&&z(n,0),u,l),r!=null)for(i=r.length;i--;)be(r[i]);u||(i="value",k=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[i]||k=="progress"&&!y||k=="option"&&y!=F[i])&&se(e,i,y,F[i],a),i="checked",I!=null&&I!=e[i]&&se(e,i,I,F[i],a))}return e}function ke(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(a){S.__e(a,n)}}function Qe(e,t,n){var o,a;if(S.unmount&&S.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||ke(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(r){S.__e(r,t)}o.base=o.__P=null}if(o=e.__k)for(a=0;a<o.length;a++)o[a]&&Qe(o[a],t,n||typeof e.type!="function");n||be(e.__e),e.__c=e.__=e.__e=void 0}function Kt(e,t,n){return this.constructor(e,n)}function ze(e,t,n){var o,a,r,s;t==document&&(t=document.documentElement),S.__&&S.__(e,t),a=(o=typeof n=="function")?null:n&&n.__k||t.__k,r=[],s=[],we(t,e=(!o&&n||t).__k=te(pe,null,[e]),a||ee,ee,t.namespaceURI,!o&&n?[n]:a?null:t.firstChild?_e.call(t.childNodes):null,r,!o&&n?n:a?a.__e:t.firstChild,o,s),Be(r,e,s)}_e=Ve.slice,S={__e:function(e,t,n,o){for(var a,r,s;t=t.__;)if((a=t.__c)&&!a.__)try{if((r=a.constructor)&&r.getDerivedStateFromError!=null&&(a.setState(r.getDerivedStateFromError(e)),s=a.__d),a.componentDidCatch!=null&&(a.componentDidCatch(e,o||{}),s=a.__d),s)return a.__E=a}catch(u){e=u}throw e}},De=0,Ot=function(e){return e!=null&&e.constructor==null},le.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=O({},this.state),typeof e=="function"&&(e=e(O({},n),this.props)),e&&O(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Pe(this))},le.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Pe(this))},le.prototype.render=pe,j=[],Oe=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,qe=function(e,t){return e.__v.__b-t.__v.__b},ue.__r=0,We=/(PointerCapture)$|Capture$/i,ye=0,$e=Ne(!1),ge=Ne(!0),qt=0;var ne,E,Se,Xe,oe=0,at=[],R=S,Ye=R.__b,Ze=R.__r,et=R.diffed,tt=R.__c,nt=R.unmount,ot=R.__;function Ce(e,t){R.__h&&R.__h(E,e,oe||t),oe=0;var n=E.__H||(E.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function b(e){return oe=1,Bt(ut,e)}function Bt(e,t,n){var o=Ce(ne++,2);if(o.t=e,!o.__c&&(o.__=[n?n(t):ut(void 0,t),function(u){var l=o.__N?o.__N[0]:o.__[0],i=o.t(l,u);l!==i&&(o.__N=[i,o.__[1]],o.__c.setState({}))}],o.__c=E,!E.__f)){var a=function(u,l,i){if(!o.__c.__H)return!0;var p=o.__c.__H.__.filter(function(m){return!!m.__c});if(p.every(function(m){return!m.__N}))return!r||r.call(this,u,l,i);var c=o.__c.props!==u;return p.forEach(function(m){if(m.__N){var h=m.__[0];m.__=m.__N,m.__N=void 0,h!==m.__[0]&&(c=!0)}}),r&&r.call(this,u,l,i)||c};E.__f=!0;var r=E.shouldComponentUpdate,s=E.componentWillUpdate;E.componentWillUpdate=function(u,l,i){if(this.__e){var p=r;r=void 0,a(u,l,i),r=p}s&&s.call(this,u,l,i)},E.shouldComponentUpdate=a}return o.__N||o.__}function re(e,t){var n=Ce(ne++,3);!R.__s&&lt(n.__H,t)&&(n.__=e,n.u=t,E.__H.__h.push(n))}function it(e){return oe=5,st(function(){return{current:e}},[])}function st(e,t){var n=Ce(ne++,7);return lt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function ct(e,t){return oe=8,st(function(){return e},t)}function Jt(){for(var e;e=at.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(fe),e.__H.__h.forEach(xe),e.__H.__h=[]}catch(t){e.__H.__h=[],R.__e(t,e.__v)}}R.__b=function(e){E=null,Ye&&Ye(e)},R.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),ot&&ot(e,t)},R.__r=function(e){Ze&&Ze(e),ne=0;var t=(E=e.__c).__H;t&&(Se===E?(t.__h=[],E.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(fe),t.__h.forEach(xe),t.__h=[],ne=0)),Se=E},R.diffed=function(e){et&&et(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(at.push(t)!==1&&Xe===R.requestAnimationFrame||((Xe=R.requestAnimationFrame)||Qt)(Jt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Se=E=null},R.__c=function(e,t){t.some(function(n){try{n.__h.forEach(fe),n.__h=n.__h.filter(function(o){return!o.__||xe(o)})}catch(o){t.some(function(a){a.__h&&(a.__h=[])}),t=[],R.__e(o,n.__v)}}),tt&&tt(e,t)},R.unmount=function(e){nt&&nt(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{fe(o)}catch(a){t=a}}),n.__H=void 0,t&&R.__e(t,n.__v))};var rt=typeof requestAnimationFrame=="function";function Qt(e){var t,n=function(){clearTimeout(o),rt&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);rt&&(t=requestAnimationFrame(n))}function fe(e){var t=E,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),E=t}function xe(e){var t=E;e.__c=e.__(),E=t}function lt(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function ut(e,t){return typeof t=="function"?t(e):t}var pt=Dt(dt()),ft="/api/v1",X=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},zt=e=>new Promise(t=>setTimeout(t,e));async function ie(e,t,n){for(let o=1;;o++){let a;try{a=await fetch(ft+t,{method:e,headers:n===void 0?{}:{"Content-Type":"application/json"},body:n===void 0?void 0:JSON.stringify(n)})}catch{if(o>=4)throw new X(0,{message:"gateway unreachable"});await zt(250*o);continue}let r=await a.text(),s=null;try{s=r?JSON.parse(r):null}catch{s={message:r}}if(!a.ok)throw new X(a.status,s);return s}}var q=e=>ie("GET",e),ae=(e,t)=>ie("POST",e,t),G=(e,t)=>ie("PUT",e,t),Ee=(e,t)=>ie("PATCH",e,t),Xt=e=>ie("DELETE",e),P=encodeURIComponent,Fe={get:()=>q("/system"),restart:()=>ae("/system/restart")},Re={get:()=>q("/config"),update:e=>Ee("/config",e)},Y={all:()=>q("/mqtt"),update:(e,t)=>Ee(`/mqtt/${e}`,t),trust:e=>ae(`/mqtt/${e}/trust`),certificate:e=>q(`/mqtt/${e}/certificate`),forget:e=>Xt(`/mqtt/${e}/certificate`)},A={async list(){let e=[];for(;;){let t=await q(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>q(`/devices/${P(e)}`),update:(e,t)=>Ee(`/devices/${P(e)}`,t),action:(e,t)=>ae(`/devices/${P(e)}/${t}`),silence:(e,t)=>G(`/devices/${P(e)}/silence`,{on:t}),relay:(e,t,n,o)=>G(`/devices/${P(e)}/relays/${t}`,{state:n,duration_ms:o}),rollershutter:(e,t,n,o)=>G(`/devices/${P(e)}/rollershutters/${t}`,{state:n,duration_ms:o}),lamps:(e,t,n,o)=>G(`/devices/${P(e)}/lamps/${t}`,{value:n,bitmask:o}),heating:(e,t,n)=>G(`/devices/${P(e)}/heating/${t}`,n),heatingManualState:e=>q(`/devices/${P(e)}/heating/manual`),heatingManual:(e,t,n,o)=>G(`/devices/${P(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:o})},mt={async list(e){let t=[];for(;;){let n=e?`&device=${P(e)}`:"",o=await q(`/sensors?offset=${t.length}${n}`);if(t.push(...o.sensors),o.sensors.length===0||t.length>=o.total)return t}}},K={action:e=>ae(`/bus/${e}`),silence:e=>G("/bus/silence",{on:e}),typeAction:(e,t)=>ae(`/device-types/${e}/${t}`)},ht={job:()=>q("/firmware/job"),upload(e,t,n){let o=pt.default.buf(new Uint8Array(t))>>>0,a=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((r,s)=>{let u=new XMLHttpRequest;u.open("PUT",`${ft}${a}?crc32=${o}`),u.setRequestHeader("Content-Type","application/octet-stream"),u.upload.onprogress=l=>l.lengthComputable&&n&&n(l.loaded/l.total),u.onload=()=>{let l=null;try{l=JSON.parse(u.responseText)}catch{}u.status>=200&&u.status<300?r(l):s(new X(u.status,l))},u.onerror=()=>s(new X(0,{message:"upload failed"})),u.send(t)})}};var $t=function(e,t,n,o){var a;t[0]=0;for(var r=1;r<t.length;r++){var s=t[r++],u=t[r]?(t[0]|=s?1:2,n[t[r++]]):t[++r];s===3?o[0]=u:s===4?o[1]=Object.assign(o[1]||{},u):s===5?(o[1]=o[1]||{})[t[++r]]=u:s===6?o[1][t[++r]]+=u+"":s?(a=e.apply(u,$t(e,u,n,["",null])),o.push(a),u[0]?t[0]|=2:(t[r-2]=0,t[r]=a)):o.push(u)}return o},vt=new Map;function gt(e){var t=vt.get(this);return t||(t=new Map,vt.set(this,t)),(t=$t(this,t.get(e)||(t.set(e,t=function(n){for(var o,a,r=1,s="",u="",l=[0],i=function(m){r===1&&(m||(s=s.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?l.push(0,m,s):r===3&&(m||s)?(l.push(3,m,s),r=2):r===2&&s==="..."&&m?l.push(4,m,0):r===2&&s&&!m?l.push(5,0,!0,s):r>=5&&((s||!m&&r===5)&&(l.push(r,0,s,a),r=6),m&&(l.push(r,m,0,a),r=6)),s=""},p=0;p<n.length;p++){p&&(r===1&&i(),i(p));for(var c=0;c<n[p].length;c++)o=n[p][c],r===1?o==="<"?(i(),l=[l],r=3):s+=o:r===4?s==="--"&&o===">"?(r=1,s=""):s=o+s[0]:u?o===u?u="":s+=o:o==='"'||o==="'"?u=o:o===">"?(i(),r=1):r&&(o==="="?(r=5,a=s,s=""):o==="/"&&(r<5||n[p][c+1]===">")?(i(),r===3&&(l=l[0]),r=l,(l=l[0]).push(2,0,r),r=0):o===" "||o==="	"||o===`
`||o==="\r"?(i(),r=2):s+=o),r===3&&s==="!--"&&(r=4,l=l[0])}return i(),l}(e)),t),arguments,[])).length>1?t:t[0]}var _=gt.bind(te),Le=()=>{};function D(e,t="ok"){Le(e,t)}function yt(){let[e,t]=b([]);return re(()=>{let n=0;return Le=(o,a)=>{let r={id:++n,message:o,kind:a};t(s=>[...s,r]),setTimeout(()=>t(s=>s.filter(u=>u!==r)),a==="error"?8e3:3e3)},()=>Le=()=>{}},[]),_`<div class="toasts">
    ${e.map(n=>_`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function C(e,t){try{let n=await e();return t&&D(t),n}catch(n){D(n.message,"error");return}}function M(e,t){let[n,o]=b({data:void 0,error:void 0}),a=it(e);a.current=e;let r=ct(async()=>{try{o({data:await a.current(),error:void 0})}catch(s){o(u=>({data:u.data,error:s}))}},[]);return re(()=>{let s=!1,u,l=async()=>{await r(),t&&!s&&(u=setTimeout(l,t))};return l(),()=>{s=!0,clearTimeout(u)}},[t,r]),{...n,reload:r}}var H=({title:e,children:t,aside:n})=>_`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,U=({error:e})=>e?_`<p class="error">${e.message}</p>`:_`<p class="muted">Loading…</p>`,T=({label:e,hint:t,children:n})=>_`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&_`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:o})=>{let[a,r]=b(!1);return _`<button class=${t||""} disabled=${o||a} onClick=${async u=>{r(!0);try{await n(u)}finally{r(!1)}}}>${e}</button>`},He=e=>"0x"+e.toString(16).padStart(2,"0");function B(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function bt(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),o=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${o} min`:`${o} min`}function me({target:e,label:t,onDone:n}){let[o,a]=b(null),[r,s]=b(null);return _`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${l=>a(l.target.files[0]||null)} />
      <${$} onClick=${async()=>{if(o){s(0);try{let l=await o.arrayBuffer(),i=await ht.upload(e,l,s);D(i&&i.restarting?"Firmware installed, the gateway restarts\u2026":"Firmware sent"),n&&n(i)}catch(l){D(l.message,"error")}s(null)}}} disabled=${!o||r!==null}>${t||"Upload"}<//>
      ${r!==null&&_`<progress max="1" value=${r}></progress>`}
    </div>`}var he=new Set;function Yt(e){e!==location.pathname&&history.pushState(null,"",e),he.forEach(t=>t())}addEventListener("popstate",()=>he.forEach(e=>e()));function wt(){let[e,t]=b(location.pathname);return re(()=>{let n=()=>t(location.pathname);return he.add(n),()=>he.delete(n)},[]),e}function kt(e,t){let n=t.split("/").filter(Boolean);for(let o of e){let a=o.path.split("/").filter(Boolean);if(a.length!==n.length)continue;let r={};if(a.every((u,l)=>u.startsWith(":")?(r[u.slice(1)]=decodeURIComponent(n[l]),!0):u===n[l]))return{route:o,params:r}}return null}function J({href:e,children:t,...n}){return te("a",{href:e,onClick:a=>{a.metaKey||a.ctrlKey||a.shiftKey||a.button!==0||(a.preventDefault(),Yt(e))},...n},t)}var Zt={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"};function Ae({device:e}){let{data:t,error:n}=M(()=>mt.list(e),5e3);return t?t.length===0?_`<p class="muted">No sensor reading seen yet.</p>`:_`<div class="table-wrap"><table>
    <thead><tr>${!e&&_`<th>Device</th>`}<th>Kind</th><th>Sensor</th><th>Value</th><th>Seen</th></tr></thead>
    <tbody>
      ${t.map(o=>_`<tr key=${o.device_key+o.kind+o.sensor_id}>
          ${!e&&_`<td><${J} href=${"/devices/"+encodeURIComponent(o.device)}>${o.device}<//></td>`}
          <td>${Zt[o.kind]||o.kind}</td>
          <td><code>${o.sensor_id}</code></td>
          <td>${o.kind==="temperature"?o.value.toFixed(2):o.value} ${o.unit}</td>
          <td>${o.age_s<60?`${o.age_s} s`:B(Math.floor(o.age_s/60))}</td>
        </tr>`)}
    </tbody>
  </table></div>`:_`<${U} error=${n} />`}function St(){return _`<${H} title="Sensors"><${Ae} /><//>`}var en=[2,5,8,9],tn=[7],nn=[3],xt=[9],on=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],rn=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Tt({device:e}){let{data:t,error:n,reload:o}=M(()=>A.get(e),5e3);return t?_`
    <${an} d=${t} reload=${o} />
    ${en.includes(t.device_type)&&_`<${Ct} d=${t} kind="relay" />`}
    ${tn.includes(t.device_type)&&_`<${Ct} d=${t} kind="rollershutter" />`}
    ${nn.includes(t.device_type)&&_`<${sn} d=${t} />`}
    ${xt.includes(t.device_type)&&_`<${cn} d=${t} />`}
    ${xt.includes(t.device_type)&&_`<${un} d=${t} />`}
    <${H} title="Sensors"><${Ae} device=${t.name||t.key} /><//>
    <${_n} d=${t} reload=${o} />
    <${H} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus. It takes a few minutes.</p>
      <${me} target=${"devices/"+encodeURIComponent(t.name||t.key)} label="Send to device" />
    <//>`:_`<${U} error=${n} />`}function an({d:e,reload:t}){let n=e.name||e.key,o=(a,r)=>async()=>{await C(()=>A.action(n,a),r),setTimeout(t,1500)};return _`
    <${H} title=${n}
      aside=${_`<span class="buttons">
        <${$} onClick=${o("ping","Ping sent")}>Ping<//>
        <${$} onClick=${o("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${o("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${B(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Ct({d:e,kind:t}){let n=e.name||e.key,[o,a]=b(1),[r,s]=b(0),u=t==="rollershutter",l=i=>()=>C(()=>A[t](n,o,i,Math.round(r*1e3)),`${u?"Rollershutter":"Relay"} ${o}: ${i}`);return _`
    <${H} title=${u?"Rollershutter":"Relays"}>
      ${e.device_type===9&&_`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${T} label="Number"><input type="number" min="1" max="16" value=${o} onInput=${i=>a(+i.target.value)} /><//>
        <${T} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${r} onInput=${i=>s(+i.target.value)} /><//>
      </div>
      <div class="buttons">
        ${u?_`<${$} onClick=${l("up")}>Up<//><${$} onClick=${l("down")}>Down<//><${$} onClick=${l("off")}>Stop<//>`:_`<${$} kind="primary" onClick=${l("on")}>On<//><${$} onClick=${l("off")}>Off<//>`}
      </div>
    <//>`}function sn({d:e}){let t=e.name||e.key,[n,o]=b(0),[a,r]=b(255),[s,u]=b(Array(24).fill(!1)),l=s.reduce((i,p,c)=>p?i|1<<23-c:i,0);return _`
    <${H} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${T} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${i=>o(+i.target.value)} /><//>
        <${T} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${i=>r(+i.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((i,p)=>_`<label key=${p} class=${"lamp"+(i?" on":"")}>
            <input type="checkbox" checked=${i} onChange=${()=>u(s.map((c,m)=>m===p?!c:c))} />${23-p}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>C(()=>A.lamps(t,n,a,l),"Lamps set")}>Send<//>
    <//>`}function cn({d:e}){let t=e.name||e.key,[n,o]=b(45),[a,r]=b(!1),[s,u]=b(0),[l,i]=b(!1),[p,c]=b(0),[m,h]=b(55);return _`
    <${H} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${T} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>o(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${a} onChange=${y=>r(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>C(()=>A.heating(t,"target",{flow_c:n,tank:a}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${T} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${s} onInput=${y=>u(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${l} onChange=${y=>i(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>C(()=>A.heating(t,"energy",{power_w:s,rod_enabled:l}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${T} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>c(+y.target.value)} /><//>
        <${T} label="Tank (°C)"><input type="number" step="0.5" value=${m} onInput=${y=>h(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>C(()=>A.heating(t,"emergency",{stage:p,tank_c:m}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var ln=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function un({d:e}){let t=e.name||e.key,{data:n,reload:o}=M(()=>A.heatingManualState(t),3e3),a=!!(n&&n.enabled),r=i=>!!(n&&n.relays.includes(i)),s=async()=>{let i=!a;await C(()=>A.heatingManual(t,i),i?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},u=i=>async()=>{await C(()=>A.heatingManual(t,!0,i,!r(i)),`Relay ${i} ${r(i)?"off":"on"}`)&&setTimeout(o,800)},l=i=>i===8&&r(9)||i===9&&r(8);return _`
    <${H} title="Manual mode"
      aside=${_`<${$} kind=${a?"danger":""} disabled=${!n} onClick=${s}>${a?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${a&&_`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${ln.map(([i,p])=>_`<button key=${i} class=${r(i)?"primary":""} disabled=${!a||l(i)} onClick=${u(i)}>
            <span>${p}</span><small>relay ${i}: ${r(i)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function _n({d:e,reload:t}){let n=e.name||e.key,[o,a]=b({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[r,s]=b(!1),u=i=>p=>a({...o,[i]:p.target.value}),l=async()=>{let i={};if(o.custom_string!==e.name&&(i.custom_string=o.custom_string),+o.hwrev!==e.hwrev&&(i.hwrev=+o.hwrev),o.relais_mode&&(i.relais_mode=o.relais_mode),o.extension_mode&&(i.extension_mode=o.extension_mode),Object.keys(i).length===0)return D("Nothing changed");await C(()=>A.update(n,i),"Settings sent")&&setTimeout(t,1500)};return _`
    <${H} title="Settings">
      <div class="row">
        <${T} label="Name" hint="up to 8 characters"><input maxlength="8" value=${o.custom_string} onInput=${u("custom_string")} /><//>
        <${T} label="Hardware revision"><input type="number" min="0" max="255" value=${o.hwrev} onInput=${u("hwrev")} /><//>
        <${T} label="Relay mode"><select value=${o.relais_mode} onChange=${u("relais_mode")}>
          <option value="">(unchanged)</option>${on.map(i=>_`<option>${i}</option>`)}
        </select><//>
        <${T} label="Extension mode"><select value=${o.extension_mode} onChange=${u("extension_mode")}>
          <option value="">(unchanged)</option>${rn.map(i=>_`<option>${i}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${l}>Save<//>
        <${$} onClick=${async()=>{await C(()=>A.silence(n,!r),r?"Device may talk again":"Device silenced"),s(!r)}}>${r?"End silence":"Silence"}<//>
        <${$} onClick=${()=>C(()=>A.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Et(){let{data:e,error:t,reload:n}=M(A.list,5e3),[o,a]=b(""),r=(i,p)=>async()=>{await C(i,p),setTimeout(n,1500)},s=async()=>{let i=o.trim();i&&await C(()=>A.action(i,"ping"),`Ping sent to ${i}`)},u=async()=>{confirm("Restart every device on the bus?")&&await r(()=>K.action("restart"),"Restart sent to every device")()},l=r(async()=>{await K.action("ping"),await K.action("refresh")},"Scanning: every device was asked to announce itself");return _`
    <${H} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${r(()=>K.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${r(()=>K.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${r(()=>K.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${u}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${o} onInput=${i=>a(i.target.value)} onKeyDown=${i=>i.key==="Enter"&&s()} />
        <${$} onClick=${s}>Ping<//>
        <${$} onClick=${l}>Scan<//>
      </div>
      ${e?e.length===0?_`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:_`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(i=>_`<tr key=${i.key}>
                    <td><${J} href=${"/devices/"+encodeURIComponent(i.name||i.key)}>${i.name||i.key}<//></td>
                    <td><code>${He(i.device_id)}</code></td>
                    <td>${i.type_name} <code>${He(i.device_type)}</code></td>
                    <td>${i.version}</td>
                    <td>${B(i.last_seen_minutes_ago)}</td>
                    <td>${i.uptime?B(Math.floor(i.uptime/60)):""}</td>
                    <td>${i.error?_`<span class="badge bad">error ${i.error}</span>`:i.last_seen_minutes_ago>10?_`<span class="badge warn">silent</span>`:_`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:_`<${U} error=${t} />`}
      ${t&&e&&_`<p class="error">${t.message}</p>`}
    <//>`}function Ft(){return _`<${dn} /><${pn} /><${fn} />`}function dn(){let{data:e,error:t}=M(Fe.get,5e3);return _`
    <${H} title="Gateway" aside=${_`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await C(Fe.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?_`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${bt(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:_`<${U} error=${t} />`}
    <//>`}function pn(){let{data:e,error:t,reload:n}=M(Re.get),[o,a]=b({});if(!e)return _`<${U} error=${t} />`;let r=l=>l in o?o[l]:e[l],s=(l,i)=>p=>a({...o,[l]:i?+p.target.value:p.target.value}),u=async()=>{let l={...o};if(l.web_password||delete l.web_password,Object.keys(l).length===0)return D("Nothing changed");let i=await C(()=>Re.update(l),"Saved");i&&(i.restart_required&&D("Restart the gateway to apply the hostname or bitrate."),a({}),n())};return _`
    <${H} title="Settings">
      <div class="row">
        <${T} label="Hostname"><input value=${r("hostname")} onInput=${s("hostname")} /><//>
        <${T} label="CAN bitrate"><select value=${r("can_bitrate")} onChange=${s("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(l=>_`<option>${l}</option>`)}
        </select><//>
        <${T} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${r("update_delay_ms")} onInput=${s("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${T} label="User name"><input value=${r("web_username")} onInput=${s("web_username")} autocomplete="off" /><//>
        <${T} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${o.web_password||""} onInput=${s("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${u}>Save<//></div>
    <//>`}function fn(){return _`
    <${H} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${me} target="gateway" label="Install and restart" />
    <//>`}var mn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Lt(){let{data:e,error:t,reload:n}=M(Y.all,5e3);return e?_`
    <${Rt} slot="primary" b=${e.primary} reload=${n} />
    <${Rt} slot="secondary" b=${e.secondary} reload=${n} />`:_`<${U} error=${t} />`}function Rt({slot:e,b:t,reload:n}){let[o,a]=b({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[r,s]=b(null),u=o.uri.startsWith("mqtts://"),l=c=>m=>a({...o,[c]:m.target.type==="checkbox"?m.target.checked:m.target.value}),i=async()=>{let c={uri:o.uri,user:o.user,enabled:o.enabled,tls_insecure:o.tls_insecure};o.password&&(c.password=o.password),await C(()=>Y.update(e,c),`${e} broker saved, reconnecting`)&&(a({...o,password:""}),setTimeout(n,2500))},p=async()=>{let c=await C(()=>Y.certificate(e));c&&s(c)};return _`
    <${H}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${_`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${mn[e]}</p>
      <div class="row">
        <${T} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${o.uri} onInput=${l("uri")} /><//>
        <${T} label="User"><input value=${o.user} onInput=${l("user")} autocomplete="off" /><//>
        <${T} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${o.password} onInput=${l("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${o.enabled} onChange=${l("enabled")} /> Connect to this broker</label>
      ${u&&_`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${o.tls_insecure} onChange=${l("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await C(()=>Y.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&_`<${$} kind="danger" onClick=${async()=>{await C(()=>Y.forget(e),"Certificate forgotten"),s(null),n()}}>Forget<//>`}
          </div>
          ${r&&_`<p>${r.pinned?_`SHA-256 <code>${r.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${i}>Save<//></div>
    <//>`}var hn=[{path:"/",title:"Devices",page:Et},{path:"/devices/:device",title:"Device",page:Tt},{path:"/sensors",title:"Sensors",page:St},{path:"/mqtt",title:"MQTT",page:Lt},{path:"/gateway",title:"Gateway",page:Ft}],vn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"]];function $n(){let e=wt(),t=kt(hn,e),n=t?t.route.page:null,o=a=>a==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(a);return _`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${vn.map(([a,r])=>_`<${J} href=${a} class=${o(a)?"active":""}>${r}<//>`)}</nav>
    </header>
    <main>
      ${n?_`<${n} key=${e} ...${t.params} />`:_`<p class="error">No such page. <${J} href="/">Devices<//></p>`}
    </main>
    <${yt} />`}ze(_`<${$n} />`,document.getElementById("app"));
