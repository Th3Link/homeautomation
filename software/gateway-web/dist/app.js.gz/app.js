var Mn=Object.create;var gt=Object.defineProperty;var Rn=Object.getOwnPropertyDescriptor;var Fn=Object.getOwnPropertyNames;var Pn=Object.getPrototypeOf,Hn=Object.prototype.hasOwnProperty;var Un=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var qn=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let s of Fn(t))!Hn.call(e,s)&&s!==n&&gt(e,s,{get:()=>t[s],enumerable:!(o=Rn(t,s))||o.enumerable});return e};var Bn=(e,t,n)=>(n=e!=null?Mn(Pn(e)):{},qn(t||!e||!e.__esModule?gt(n,"default",{value:e,enumerable:!0}):n,e));var Jt=Un(Je=>{var Qt;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Je=="object"?e(Je):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(Qt={}):e(Qt={})})(function(e){e.version="1.2.2";function t(){for(var b=0,q=new Array(256),y=0;y!=256;++y)b=y,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,b=b&1?-306674912^b>>>1:b>>>1,q[y]=b;return typeof Int32Array<"u"?new Int32Array(q):q}var n=t();function o(b){var q=0,y=0,A=0,E=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(A=0;A!=256;++A)E[A]=b[A];for(A=0;A!=256;++A)for(y=b[A],q=256+A;q<4096;q+=256)y=E[q]=y>>>8^b[y&255];var D=[];for(A=1;A!=16;++A)D[A-1]=typeof Int32Array<"u"?E.subarray(A*256,A*256+256):E.slice(A*256,A*256+256);return D}var s=o(n),a=s[0],r=s[1],l=s[2],u=s[3],c=s[4],d=s[5],p=s[6],m=s[7],$=s[8],_=s[9],v=s[10],h=s[11],g=s[12],w=s[13],O=s[14];function S(b,q){for(var y=q^-1,A=0,E=b.length;A<E;)y=y>>>8^n[(y^b.charCodeAt(A++))&255];return~y}function N(b,q){for(var y=q^-1,A=b.length-15,E=0;E<A;)y=O[b[E++]^y&255]^w[b[E++]^y>>8&255]^g[b[E++]^y>>16&255]^h[b[E++]^y>>>24]^v[b[E++]]^_[b[E++]]^$[b[E++]]^m[b[E++]]^p[b[E++]]^d[b[E++]]^c[b[E++]]^u[b[E++]]^l[b[E++]]^r[b[E++]]^a[b[E++]]^n[b[E++]];for(A+=15;E<A;)y=y>>>8^n[(y^b[E++])&255];return~y}function z(b,q){for(var y=q^-1,A=0,E=b.length,D=0,Ue=0;A<E;)D=b.charCodeAt(A++),D<128?y=y>>>8^n[(y^D)&255]:D<2048?(y=y>>>8^n[(y^(192|D>>6&31))&255],y=y>>>8^n[(y^(128|D&63))&255]):D>=55296&&D<57344?(D=(D&1023)+64,Ue=b.charCodeAt(A++)&1023,y=y>>>8^n[(y^(240|D>>8&7))&255],y=y>>>8^n[(y^(128|D>>2&63))&255],y=y>>>8^n[(y^(128|Ue>>6&15|(D&3)<<4))&255],y=y>>>8^n[(y^(128|Ue&63))&255]):(y=y>>>8^n[(y^(224|D>>12&15))&255],y=y>>>8^n[(y^(128|D>>6&63))&255],y=y>>>8^n[(y^(128|D&63))&255]);return~y}e.table=n,e.bstr=S,e.buf=N,e.str=z})});var Le,I,St,jn,se,bt,xt,Ct,Tt,je,qe,Be,Wn,ve={},Et=[],Vn=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,Ae=Array.isArray;function Z(e,t){for(var n in t)e[n]=t[n];return e}function We(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ge(e,t,n){var o,s,a,r={};for(a in t)a=="key"?o=t[a]:a=="ref"?s=t[a]:r[a]=t[a];if(arguments.length>2&&(r.children=arguments.length>3?Le.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(a in e.defaultProps)r[a]===void 0&&(r[a]=e.defaultProps[a]);return Ce(e,r,o,s,null)}function Ce(e,t,n,o,s){var a={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:s??++St,__i:-1,__u:0};return s==null&&I.vnode!=null&&I.vnode(a),a}function Oe(e){return e.children}function Te(e,t){this.props=e,this.context=t}function le(e,t){if(t==null)return e.__?le(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?le(e):null}function Lt(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Lt(e)}}function yt(e){(!e.__d&&(e.__d=!0)&&se.push(e)&&!Ee.__r++||bt!=I.debounceRendering)&&((bt=I.debounceRendering)||xt)(Ee)}function Ee(){for(var e,t,n,o,s,a,r,l=1;se.length;)se.length>l&&se.sort(Ct),e=se.shift(),l=se.length,e.__d&&(n=void 0,s=(o=(t=e).__v).__e,a=[],r=[],t.__P&&((n=Z({},o)).__v=o.__v+1,I.vnode&&I.vnode(n),Ve(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[s]:null,a,s??le(o),!!(32&o.__u),r),n.__v=o.__v,n.__.__k[n.__i]=n,Nt(a,n,r),n.__e!=s&&Lt(n)));Ee.__r=0}function At(e,t,n,o,s,a,r,l,u,c,d){var p,m,$,_,v,h,g=o&&o.__k||Et,w=t.length;for(u=Kn(n,t,g,u,w),p=0;p<w;p++)($=n.__k[p])!=null&&(m=$.__i==-1?ve:g[$.__i]||ve,$.__i=p,h=Ve(e,$,m,s,a,r,l,u,c,d),_=$.__e,$.ref&&m.ref!=$.ref&&(m.ref&&Ke(m.ref,null,$),d.push($.ref,$.__c||_,$)),v==null&&_!=null&&(v=_),4&$.__u||m.__k===$.__k?u=Ot($,u,e):typeof $.type=="function"&&h!==void 0?u=h:_&&(u=_.nextSibling),$.__u&=-7);return n.__e=v,u}function Kn(e,t,n,o,s){var a,r,l,u,c,d=n.length,p=d,m=0;for(e.__k=new Array(s),a=0;a<s;a++)(r=t[a])!=null&&typeof r!="boolean"&&typeof r!="function"?(u=a+m,(r=e.__k[a]=typeof r=="string"||typeof r=="number"||typeof r=="bigint"||r.constructor==String?Ce(null,r,null,null,null):Ae(r)?Ce(Oe,{children:r},null,null,null):r.constructor==null&&r.__b>0?Ce(r.type,r.props,r.key,r.ref?r.ref:null,r.__v):r).__=e,r.__b=e.__b+1,l=null,(c=r.__i=Gn(r,n,u,p))!=-1&&(p--,(l=n[c])&&(l.__u|=2)),l==null||l.__v==null?(c==-1&&(s>d?m--:s<d&&m++),typeof r.type!="function"&&(r.__u|=4)):c!=u&&(c==u-1?m--:c==u+1?m++:(c>u?m--:m++,r.__u|=4))):e.__k[a]=null;if(p)for(a=0;a<d;a++)(l=n[a])!=null&&(2&l.__u)==0&&(l.__e==o&&(o=le(l)),Dt(l,l));return o}function Ot(e,t,n){var o,s;if(typeof e.type=="function"){for(o=e.__k,s=0;o&&s<o.length;s++)o[s]&&(o[s].__=e,t=Ot(o[s],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=le(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function Gn(e,t,n,o){var s,a,r=e.key,l=e.type,u=t[n];if(u===null&&e.key==null||u&&r==u.key&&l==u.type&&(2&u.__u)==0)return n;if(o>(u!=null&&(2&u.__u)==0?1:0))for(s=n-1,a=n+1;s>=0||a<t.length;){if(s>=0){if((u=t[s])&&(2&u.__u)==0&&r==u.key&&l==u.type)return s;s--}if(a<t.length){if((u=t[a])&&(2&u.__u)==0&&r==u.key&&l==u.type)return a;a++}}return-1}function wt(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Vn.test(t)?n:n+"px"}function xe(e,t,n,o,s){var a,r;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||wt(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||wt(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")a=t!=(t=t.replace(Tt,"$1")),r=t.toLowerCase(),t=r in e||t=="onFocusOut"||t=="onFocusIn"?r.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+a]=n,n?o?n.u=o.u:(n.u=je,e.addEventListener(t,a?Be:qe,a)):e.removeEventListener(t,a?Be:qe,a);else{if(s=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function kt(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=je++;else if(t.t<n.u)return;return n(I.event?I.event(t):t)}}}function Ve(e,t,n,o,s,a,r,l,u,c){var d,p,m,$,_,v,h,g,w,O,S,N,z,b,q,y,A,E=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),a=[l=t.__e=n.__e]),(d=I.__b)&&d(t);e:if(typeof E=="function")try{if(g=t.props,w="prototype"in E&&E.prototype.render,O=(d=E.contextType)&&o[d.__c],S=d?O?O.props.value:d.__:o,n.__c?h=(p=t.__c=n.__c).__=p.__E:(w?t.__c=p=new E(g,S):(t.__c=p=new Te(g,S),p.constructor=E,p.render=Qn),O&&O.sub(p),p.props=g,p.state||(p.state={}),p.context=S,p.__n=o,m=p.__d=!0,p.__h=[],p._sb=[]),w&&p.__s==null&&(p.__s=p.state),w&&E.getDerivedStateFromProps!=null&&(p.__s==p.state&&(p.__s=Z({},p.__s)),Z(p.__s,E.getDerivedStateFromProps(g,p.__s))),$=p.props,_=p.state,p.__v=t,m)w&&E.getDerivedStateFromProps==null&&p.componentWillMount!=null&&p.componentWillMount(),w&&p.componentDidMount!=null&&p.__h.push(p.componentDidMount);else{if(w&&E.getDerivedStateFromProps==null&&g!==$&&p.componentWillReceiveProps!=null&&p.componentWillReceiveProps(g,S),!p.__e&&p.shouldComponentUpdate!=null&&p.shouldComponentUpdate(g,p.__s,S)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(p.props=g,p.state=p.__s,p.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(D){D&&(D.__=t)}),N=0;N<p._sb.length;N++)p.__h.push(p._sb[N]);p._sb=[],p.__h.length&&r.push(p);break e}p.componentWillUpdate!=null&&p.componentWillUpdate(g,p.__s,S),w&&p.componentDidUpdate!=null&&p.__h.push(function(){p.componentDidUpdate($,_,v)})}if(p.context=S,p.props=g,p.__P=e,p.__e=!1,z=I.__r,b=0,w){for(p.state=p.__s,p.__d=!1,z&&z(t),d=p.render(p.props,p.state,p.context),q=0;q<p._sb.length;q++)p.__h.push(p._sb[q]);p._sb=[]}else do p.__d=!1,z&&z(t),d=p.render(p.props,p.state,p.context),p.state=p.__s;while(p.__d&&++b<25);p.state=p.__s,p.getChildContext!=null&&(o=Z(Z({},o),p.getChildContext())),w&&!m&&p.getSnapshotBeforeUpdate!=null&&(v=p.getSnapshotBeforeUpdate($,_)),y=d,d!=null&&d.type===Oe&&d.key==null&&(y=It(d.props.children)),l=At(e,Ae(y)?y:[y],t,n,o,s,a,r,l,u,c),p.base=t.__e,t.__u&=-161,p.__h.length&&r.push(p),h&&(p.__E=p.__=null)}catch(D){if(t.__v=null,u||a!=null)if(D.then){for(t.__u|=u?160:128;l&&l.nodeType==8&&l.nextSibling;)l=l.nextSibling;a[a.indexOf(l)]=null,t.__e=l}else for(A=a.length;A--;)We(a[A]);else t.__e=n.__e,t.__k=n.__k;I.__e(D,t,n)}else a==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):l=t.__e=zn(n.__e,t,n,o,s,a,r,u,c);return(d=I.diffed)&&d(t),128&t.__u?void 0:l}function Nt(e,t,n){for(var o=0;o<n.length;o++)Ke(n[o],n[++o],n[++o]);I.__c&&I.__c(t,e),e.some(function(s){try{e=s.__h,s.__h=[],e.some(function(a){a.call(s)})}catch(a){I.__e(a,s.__v)}})}function It(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:Ae(e)?e.map(It):Z({},e)}function zn(e,t,n,o,s,a,r,l,u){var c,d,p,m,$,_,v,h=n.props,g=t.props,w=t.type;if(w=="svg"?s="http://www.w3.org/2000/svg":w=="math"?s="http://www.w3.org/1998/Math/MathML":s||(s="http://www.w3.org/1999/xhtml"),a!=null){for(c=0;c<a.length;c++)if(($=a[c])&&"setAttribute"in $==!!w&&(w?$.localName==w:$.nodeType==3)){e=$,a[c]=null;break}}if(e==null){if(w==null)return document.createTextNode(g);e=document.createElementNS(s,w,g.is&&g),l&&(I.__m&&I.__m(t,a),l=!1),a=null}if(w==null)h===g||l&&e.data==g||(e.data=g);else{if(a=a&&Le.call(e.childNodes),h=n.props||ve,!l&&a!=null)for(h={},c=0;c<e.attributes.length;c++)h[($=e.attributes[c]).name]=$.value;for(c in h)if($=h[c],c!="children"){if(c=="dangerouslySetInnerHTML")p=$;else if(!(c in g)){if(c=="value"&&"defaultValue"in g||c=="checked"&&"defaultChecked"in g)continue;xe(e,c,null,$,s)}}for(c in g)$=g[c],c=="children"?m=$:c=="dangerouslySetInnerHTML"?d=$:c=="value"?_=$:c=="checked"?v=$:l&&typeof $!="function"||h[c]===$||xe(e,c,$,h[c],s);if(d)l||p&&(d.__html==p.__html||d.__html==e.innerHTML)||(e.innerHTML=d.__html),t.__k=[];else if(p&&(e.innerHTML=""),At(t.type=="template"?e.content:e,Ae(m)?m:[m],t,n,o,w=="foreignObject"?"http://www.w3.org/1999/xhtml":s,a,r,a?a[0]:n.__k&&le(n,0),l,u),a!=null)for(c=a.length;c--;)We(a[c]);l||(c="value",w=="progress"&&_==null?e.removeAttribute("value"):_!=null&&(_!==e[c]||w=="progress"&&!_||w=="option"&&_!=h[c])&&xe(e,c,_,h[c],s),c="checked",v!=null&&v!=e[c]&&xe(e,c,v,h[c],s))}return e}function Ke(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(s){I.__e(s,n)}}function Dt(e,t,n){var o,s;if(I.unmount&&I.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||Ke(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(a){I.__e(a,t)}o.base=o.__P=null}if(o=e.__k)for(s=0;s<o.length;s++)o[s]&&Dt(o[s],t,n||typeof e.type!="function");n||We(e.__e),e.__c=e.__=e.__e=void 0}function Qn(e,t,n){return this.constructor(e,n)}function Mt(e,t,n){var o,s,a,r;t==document&&(t=document.documentElement),I.__&&I.__(e,t),s=(o=typeof n=="function")?null:n&&n.__k||t.__k,a=[],r=[],Ve(t,e=(!o&&n||t).__k=ge(Oe,null,[e]),s||ve,ve,t.namespaceURI,!o&&n?[n]:s?null:t.firstChild?Le.call(t.childNodes):null,a,!o&&n?n:s?s.__e:t.firstChild,o,r),Nt(a,e,r)}Le=Et.slice,I={__e:function(e,t,n,o){for(var s,a,r;t=t.__;)if((s=t.__c)&&!s.__)try{if((a=s.constructor)&&a.getDerivedStateFromError!=null&&(s.setState(a.getDerivedStateFromError(e)),r=s.__d),s.componentDidCatch!=null&&(s.componentDidCatch(e,o||{}),r=s.__d),r)return s.__E=s}catch(l){e=l}throw e}},St=0,jn=function(e){return e!=null&&e.constructor==null},Te.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=Z({},this.state),typeof e=="function"&&(e=e(Z({},n),this.props)),e&&Z(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),yt(this))},Te.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),yt(this))},Te.prototype.render=Oe,se=[],xt=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Ct=function(e,t){return e.__v.__b-t.__v.__b},Ee.__r=0,Tt=/(PointerCapture)$|Capture$/i,je=0,qe=kt(!1),Be=kt(!0),Wn=0;var be,F,Ge,Rt,ye=0,Wt=[],P=I,Ft=P.__b,Pt=P.__r,Ht=P.diffed,Ut=P.__c,qt=P.unmount,Bt=P.__;function Qe(e,t){P.__h&&P.__h(F,e,ye||t),ye=0;var n=F.__H||(F.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function f(e){return ye=1,Jn(zt,e)}function Jn(e,t,n){var o=Qe(be++,2);if(o.t=e,!o.__c&&(o.__=[n?n(t):zt(void 0,t),function(l){var u=o.__N?o.__N[0]:o.__[0],c=o.t(u,l);u!==c&&(o.__N=[c,o.__[1]],o.__c.setState({}))}],o.__c=F,!F.__f)){var s=function(l,u,c){if(!o.__c.__H)return!0;var d=o.__c.__H.__.filter(function(m){return!!m.__c});if(d.every(function(m){return!m.__N}))return!a||a.call(this,l,u,c);var p=o.__c.props!==l;return d.forEach(function(m){if(m.__N){var $=m.__[0];m.__=m.__N,m.__N=void 0,$!==m.__[0]&&(p=!0)}}),a&&a.call(this,l,u,c)||p};F.__f=!0;var a=F.shouldComponentUpdate,r=F.componentWillUpdate;F.componentWillUpdate=function(l,u,c){if(this.__e){var d=a;a=void 0,s(l,u,c),a=d}r&&r.call(this,l,u,c)},F.shouldComponentUpdate=s}return o.__N||o.__}function W(e,t){var n=Qe(be++,3);!P.__s&&Gt(n.__H,t)&&(n.__=e,n.u=t,F.__H.__h.push(n))}function ce(e){return ye=5,Vt(function(){return{current:e}},[])}function Vt(e,t){var n=Qe(be++,7);return Gt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function Kt(e,t){return ye=8,Vt(function(){return e},t)}function Xn(){for(var e;e=Wt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(Ne),e.__H.__h.forEach(ze),e.__H.__h=[]}catch(t){e.__H.__h=[],P.__e(t,e.__v)}}P.__b=function(e){F=null,Ft&&Ft(e)},P.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),Bt&&Bt(e,t)},P.__r=function(e){Pt&&Pt(e),be=0;var t=(F=e.__c).__H;t&&(Ge===F?(t.__h=[],F.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(Ne),t.__h.forEach(ze),t.__h=[],be=0)),Ge=F},P.diffed=function(e){Ht&&Ht(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(Wt.push(t)!==1&&Rt===P.requestAnimationFrame||((Rt=P.requestAnimationFrame)||Yn)(Xn)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ge=F=null},P.__c=function(e,t){t.some(function(n){try{n.__h.forEach(Ne),n.__h=n.__h.filter(function(o){return!o.__||ze(o)})}catch(o){t.some(function(s){s.__h&&(s.__h=[])}),t=[],P.__e(o,n.__v)}}),Ut&&Ut(e,t)},P.unmount=function(e){qt&&qt(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{Ne(o)}catch(s){t=s}}),n.__H=void 0,t&&P.__e(t,n.__v))};var jt=typeof requestAnimationFrame=="function";function Yn(e){var t,n=function(){clearTimeout(o),jt&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);jt&&(t=requestAnimationFrame(n))}function Ne(e){var t=F,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),F=t}function ze(e){var t=F;e.__c=e.__(),F=t}function Gt(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function zt(e,t){return typeof t=="function"?t(e):t}var Xt=Bn(Jt()),Ze="/api/v1",ue=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error,this.field=n&&n.field}},Zn=e=>new Promise(t=>setTimeout(t,e));async function de(e,t,n,o=!1){for(let s=1;;s++){let a;try{a=await fetch(Ze+t,{method:e,headers:n===void 0?{}:{"Content-Type":o?"application/x-pem-file":"application/json"},body:n===void 0?void 0:o?n:JSON.stringify(n)})}catch{if(s>=4)throw new ue(0,{message:"gateway unreachable"});await Zn(250*s);continue}let r=await a.text(),l=null;try{l=r?JSON.parse(r):null}catch{l={message:r}}if(!a.ok)throw new ue(a.status,l);return l}}var V=e=>de("GET",e),J=(e,t)=>de("POST",e,t),Y=(e,t)=>de("PUT",e,t),Xe=(e,t)=>de("PUT",e,t,!0),ee=(e,t)=>de("PATCH",e,t),we=e=>de("DELETE",e),H=encodeURIComponent,et={get:()=>V("/system"),restart:()=>J("/system/restart")},tt={get:()=>V("/config"),update:e=>ee("/config",e)},nt={get:()=>V("/location"),update:e=>ee("/location",e)},ie={all:()=>V("/mqtt"),updateAll:e=>ee("/mqtt",e),update:(e,t)=>ee(`/mqtt/${e}`,t),trust:e=>J(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>we(`/mqtt/${e}/certificate`)},G={get:()=>V("/tls"),update:e=>ee("/tls",e),selfSigned:e=>J("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Ze}/tls/csr`,installCertificate:e=>Xe("/tls/certificate",e),setTrustAnchor:e=>Xe("/tls/trust-anchor",e),removeTrustAnchor:()=>we("/tls/trust-anchor"),setIdentity:e=>Xe("/tls/est/identity",e),removeIdentity:()=>we("/tls/est/identity"),enroll:()=>J("/tls/est/enroll")},U={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${H(e)}`),update:(e,t)=>ee(`/devices/${H(e)}`,t),action:(e,t)=>J(`/devices/${H(e)}/${t}`),silence:(e,t)=>Y(`/devices/${H(e)}/silence`,{on:t}),relay:(e,t,n,o)=>Y(`/devices/${H(e)}/relays/${t}`,{state:n,duration_ms:o}),rollershutter:(e,t,n,o)=>Y(`/devices/${H(e)}/rollershutters/${t}`,{state:n,duration_ms:o}),lamps:(e,t,n,o)=>Y(`/devices/${H(e)}/lamps/${t}`,{value:n,bitmask:o}),heating:(e,t,n)=>Y(`/devices/${H(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${H(e)}/heating/manual`),heatingManual:(e,t,n,o)=>Y(`/devices/${H(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:o})},te={update:(e,t,n)=>Y(`/devices/${H(e)}/sensors/${t}`,n),refresh:e=>J(`/devices/${H(e)}/sensors/refresh`),forget:e=>J(`/devices/${H(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${H(e)}`:"",o=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...o.sensors),o.sensors.length===0||t.length>=o.total)return t}}},pe={action:e=>J(`/bus/${e}`),silence:e=>Y("/bus/silence",{on:e}),typeAction:(e,t)=>J(`/device-types/${e}/${t}`)},ot={job:()=>V("/firmware/job"),upload(e,t,n){let o=Xt.default.buf(new Uint8Array(t))>>>0,s=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((a,r)=>{let l=new XMLHttpRequest;l.open("PUT",`${Ze}${s}?crc32=${o}`),l.setRequestHeader("Content-Type","application/octet-stream"),l.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),l.onload=()=>{let u=null;try{u=JSON.parse(l.responseText)}catch{}l.status>=200&&l.status<300?a(u):r(new ue(l.status,u))},l.onerror=()=>r(new ue(0,{message:"upload failed"})),l.send(t)})}},Ye=e=>({list:()=>V(`/automation/${e}`).then(t=>t.items),get:t=>V(`/automation/${e}/${H(t)}`),put:(t,n)=>Y(`/automation/${e}/${H(t)}`,n),remove:t=>we(`/automation/${e}/${H(t)}`)}),L={status:()=>V("/automation"),setEnabled:e=>ee("/automation",{enabled:e}),outputs:{...Ye("outputs"),command:(e,t)=>J(`/automation/outputs/${H(e)}/command`,t)},bindings:{async list(){let e=[];for(;;){let t=await V(`/automation/bindings?offset=${e.length}`);if(e.push(...t.items),t.items.length===0||e.length>=t.total)return e}},add:e=>J("/automation/bindings",e),put:(e,t)=>Y(`/automation/bindings/${e}`,t),remove:e=>we(`/automation/bindings/${e}`)},motion:{...Ye("motion"),setEnabled:(e,t)=>ee(`/automation/motion/${H(e)}`,{enabled:t})},schedules:{...Ye("schedules"),setEnabled:(e,t)=>ee(`/automation/schedules/${H(e)}`,{enabled:t})}};var Ie=new Set;function eo(e){e!==location.pathname&&history.pushState(null,"",e),Ie.forEach(t=>t())}addEventListener("popstate",()=>Ie.forEach(e=>e()));function Yt(){let[e,t]=f(location.pathname);return W(()=>{let n=()=>t(location.pathname);return Ie.add(n),()=>Ie.delete(n)},[]),e}function Zt(e,t){let n=t.split("/").filter(Boolean);for(let o of e){let s=o.path.split("/").filter(Boolean);if(s.length!==n.length)continue;let a={};if(s.every((l,u)=>l.startsWith(":")?(a[l.slice(1)]=decodeURIComponent(n[u]),!0):l===n[u]))return{route:o,params:a}}return null}function K({href:e,children:t,...n}){return ge("a",{href:e,onClick:s=>{s.metaKey||s.ctrlKey||s.shiftKey||s.button!==0||(s.preventDefault(),eo(e))},...n},t)}var tn=function(e,t,n,o){var s;t[0]=0;for(var a=1;a<t.length;a++){var r=t[a++],l=t[a]?(t[0]|=r?1:2,n[t[a++]]):t[++a];r===3?o[0]=l:r===4?o[1]=Object.assign(o[1]||{},l):r===5?(o[1]=o[1]||{})[t[++a]]=l:r===6?o[1][t[++a]]+=l+"":r?(s=e.apply(l,tn(e,l,n,["",null])),o.push(s),l[0]?t[0]|=2:(t[a-2]=0,t[a]=s)):o.push(l)}return o},en=new Map;function nn(e){var t=en.get(this);return t||(t=new Map,en.set(this,t)),(t=tn(this,t.get(e)||(t.set(e,t=function(n){for(var o,s,a=1,r="",l="",u=[0],c=function(m){a===1&&(m||(r=r.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,m,r):a===3&&(m||r)?(u.push(3,m,r),a=2):a===2&&r==="..."&&m?u.push(4,m,0):a===2&&r&&!m?u.push(5,0,!0,r):a>=5&&((r||!m&&a===5)&&(u.push(a,0,r,s),a=6),m&&(u.push(a,m,0,s),a=6)),r=""},d=0;d<n.length;d++){d&&(a===1&&c(),c(d));for(var p=0;p<n[d].length;p++)o=n[d][p],a===1?o==="<"?(c(),u=[u],a=3):r+=o:a===4?r==="--"&&o===">"?(a=1,r=""):r=o+r[0]:l?o===l?l="":r+=o:o==='"'||o==="'"?l=o:o===">"?(c(),a=1):a&&(o==="="?(a=5,s=r,r=""):o==="/"&&(a<5||n[d][p+1]===">")?(c(),a===3&&(u=u[0]),a=u,(u=u[0]).push(2,0,a),a=0):o===" "||o==="	"||o===`
`||o==="\r"?(c(),a=2):r+=o),a===3&&r==="!--"&&(a=4,u=u[0])}return c(),u}(e)),t),arguments,[])).length>1?t:t[0]}var i=nn.bind(ge),at=()=>{};function M(e,t="ok"){at(e,t)}function on(){let[e,t]=f([]);return W(()=>{let n=0;return at=(o,s)=>{let a={id:++n,message:o,kind:s};t(r=>[...r,a]),setTimeout(()=>t(r=>r.filter(l=>l!==a)),s==="error"?8e3:3e3)},()=>at=()=>{}},[]),i`<div class="toasts">
    ${e.map(n=>i`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function C(e,t){try{let n=await e();return t&&M(t),n}catch(n){M(n.message,"error");return}}function B(e,t){let[n,o]=f({data:void 0,error:void 0}),s=ce(e);s.current=e;let a=Kt(async()=>{try{o({data:await s.current(),error:void 0})}catch(r){o(l=>({data:l.data,error:r}))}},[]);return W(()=>{let r=!1,l,u=async()=>{await a(),t&&!r&&(l=setTimeout(u,t))};return u(),()=>{r=!0,clearTimeout(l)}},[t,a]),{...n,reload:a}}var T=({title:e,children:t,aside:n})=>i`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,R=({error:e})=>e?i`<p class="error">${e.message}</p>`:i`<p class="muted">Loading…</p>`,k=({label:e,hint:t,children:n})=>i`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&i`<small>${t}</small>`}
  </label>`,x=({children:e,kind:t,onClick:n,disabled:o})=>{let[s,a]=f(!1);return i`<button class=${t||""} disabled=${o||s} onClick=${async l=>{a(!0);try{await n(l)}finally{a(!1)}}}>${e}</button>`},st=e=>"0x"+e.toString(16).padStart(2,"0");function re(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function an(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),o=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${o} min`:`${o} min`}var De;function ae(){let[e,t]=f([]);return W(()=>{De=De||U.list().catch(()=>(De=void 0,[])),De.then(t)},[]),e}var it=e=>e?`${e.type}:${e.id}`:"",to=e=>{let[t,n]=e.split(":").map(Number);return{type:t,id:n}};function j(e,t){if(!t)return"\u2014";let n=e.find(o=>o.device_type===t.type&&o.device_id===t.id);return n&&n.name?n.name:`${n?n.type_name:"type "+t.type} / 0x${t.id.toString(16).padStart(2,"0")}`}function X({value:e,onChange:t,devices:n,types:o}){let s=n.filter(l=>!o||o.includes(l.device_type)),a=it(e),r=s.some(l=>it({type:l.device_type,id:l.device_id})===a);return i`<div class="device-select">
    <select value=${r?a:e?"manual":""} onChange=${l=>{let u=l.target.value;u==="manual"?t(e||{type:o&&o[0]||0,id:1}):u&&t(to(u))}}>
      <option value="" disabled>Choose a device…</option>
      ${s.map(l=>i`<option value=${it({type:l.device_type,id:l.device_id})}>
          ${j(n,{type:l.device_type,id:l.device_id})} (${l.type_name})
        </option>`)}
      <option value="manual">Other: type and id…</option>
    </select>
    ${e&&!r&&i`<span class="pair">
      <input type="number" min="0" max="63" title="Device type" value=${e.type} onInput=${l=>t({...e,type:+l.target.value})} />
      <input type="number" min="1" max="255" title="Device id" value=${e.id} onInput=${l=>t({...e,id:+l.target.value})} />
    </span>`}
  </div>`}var rn=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]],no=e=>(rn.find(([t])=>t===e)||[e,e])[1],Re=e=>String(e).padStart(2,"0");function ke(e){if(!e)return"";if(e.clock)return`${Re(e.clock.hour)}:${Re(e.clock.minute)}`;let t=e.sun.offset_min||0;return no(e.sun.event)+(t?` ${t>0?"+":"\u2212"} ${Math.abs(t)} min`:"")}function Se({value:e,onChange:t}){let n=!!e.sun;return i`<span class="time-edit">
    <select value=${n?"sun":"clock"} onChange=${o=>t(o.target.value==="sun"?{sun:{event:"sunset",offset_min:0}}:{clock:{hour:22,minute:0}})}>
      <option value="clock">Clock</option>
      <option value="sun">Sun</option>
    </select>
    ${n?i`<select value=${e.sun.event} onChange=${o=>t({sun:{...e.sun,event:o.target.value}})}>
            ${rn.map(([o,s])=>i`<option value=${o}>${s}</option>`)}
          </select>
          <input type="number" class="short" min="-720" max="720" title="Offset in minutes (negative: before)" value=${e.sun.offset_min||0}
            onInput=${o=>t({sun:{...e.sun,offset_min:+o.target.value}})} /><small>min</small>`:i`<input type="time" value=${`${Re(e.clock.hour)}:${Re(e.clock.minute)}`} onInput=${o=>{let[s,a]=o.target.value.split(":").map(Number);isNaN(s)||t({clock:{hour:s,minute:a||0}})}} />`}
  </span>`}var oo=[["dark","Darker than"],["bright","At least as bright as"],["between","Time between"],["sun_below","Sun lower than"],["sun_above","Sun at least"]],ao=(e,t)=>{let n={type:0,id:1};switch(e){case"dark":case"bright":return{[e]:{sensor:n,lux:40}};case"between":return{between:{from:{clock:{hour:22,minute:0}},to:{clock:{hour:6,minute:0}}}};default:return{[e]:{degrees:-6}}}},ln=e=>Object.keys(e)[0];function rt(e,t){let n=ln(e),o=e[n];switch(n){case"dark":return`darker than ${o.lux} lx at ${j(t,o.sensor)}`;case"bright":return`at least ${o.lux} lx at ${j(t,o.sensor)}`;case"between":return`between ${ke(o.from)} and ${ke(o.to)}`;case"sun_below":return`sun below ${o.degrees}\xB0`;case"sun_above":return`sun at least ${o.degrees}\xB0`}return n}var Me;function so(){let[e,t]=f([]);return W(()=>{Me=Me||te.list().then(n=>n.filter(o=>o.kind==="brightness")).catch(()=>(Me=void 0,[])),Me.then(t)},[]),e}function lt({value:e,onChange:t,devices:n}){let o=ln(e),s=e[o],a=so(),r=n.filter(u=>a.some(c=>c.device_key.toLowerCase()===u.key.toLowerCase())),l=u=>t({[o]:{...s,...u}});return i`<span class="condition">
    <select value=${o} onChange=${u=>t(ao(u.target.value,n))}>
      ${oo.map(([u,c])=>i`<option value=${u}>${c}</option>`)}
    </select>
    ${(o==="dark"||o==="bright")&&i`<input type="number" class="short" min="0" value=${s.lux} onInput=${u=>l({lux:+u.target.value})} /><small>lx at</small>
      <${X} value=${s.sensor.type?s.sensor:null} devices=${r.length?r:n} onChange=${u=>l({sensor:u})} />`}
    ${o==="between"&&i`<${Se} value=${s.from} onChange=${u=>l({from:u})} /><small>and</small><${Se} value=${s.to} onChange=${u=>l({to:u})} />`}
    ${(o==="sun_below"||o==="sun_above")&&i`<input type="number" class="short" min="-90" max="90" value=${s.degrees} onInput=${u=>l({degrees:+u.target.value})} /><small>° (−6: civil twilight ends)</small>`}
  </span>`}function ne({items:e,onChange:t,max:n,make:o,render:s,addLabel:a}){return i`<div class="list-edit">
    ${e.map((r,l)=>i`<div class="list-row" key=${l}>
        <div class="list-body">${s(r,u=>t(e.map((c,d)=>d===l?u:c)),l)}</div>
        <button class="icon" title="Remove" onClick=${()=>t(e.filter((u,c)=>c!==l))}>×</button>
      </div>`)}
    ${e.length<n&&i`<button onClick=${()=>t([...e,o()])}>+ ${a}</button>`}
  </div>`}var ct=[["light","Light (levels)"],["dimmer","Dimmer (0\u2013255)"],["relay","Relay"],["shutter","Roller shutter"],["group","Group"]],Fe={light:[["toggle","Toggle"],["on","On (last level)"],["off","Off"],["set","Level",!0],["max","Brightest"],["inc","Brighter"],["dec","Darker"]],dimmer:[["toggle","Toggle"],["on","On (last value)"],["off","Off"],["set","Value",!0],["max","Full"],["inc","Brighter"],["dec","Darker"]],relay:[["toggle","Toggle"],["on","On"],["off","Off"],["on_for","On for (ms)",!0]],shutter:[["up","Up / stop"],["down","Down / stop"],["up_hold","Up (while held)"],["down_hold","Down (while held)"],["stop","Stop"]],group:[["toggle","Toggle"],["on","On"],["off","Off"],["up","Up / stop"],["down","Down / stop"],["stop","Stop"]]},cn=e=>typeof e=="string"?[e,void 0]:[Object.keys(e)[0],Object.values(e)[0]],sn=(e,t)=>t===void 0?e:{[e]:t};function un(e,t){let[n,o]=cn(e),s=(Fe[t]||Object.values(Fe).flat()).find(([r])=>r===n),a=s?s[1].replace(/ \(.*\)$/,""):n;return o===void 0?a:`${a} ${o}`}function dn({value:e,onChange:t,kind:n}){let o=Fe[n]||Fe.light,[s,a]=cn(e),r=l=>(o.find(([u])=>u===l)||[])[2];return i`<span class="op">
    <select value=${s} onChange=${l=>t(sn(l.target.value,r(l.target.value)?l.target.value==="on_for"?6e4:1:void 0))}>
      ${o.map(([l,u])=>i`<option value=${l}>${u}</option>`)}
    </select>
    ${r(s)&&i`<input type="number" class="short" min="0" value=${a} onInput=${l=>t(sn(s,+l.target.value))} />`}
  </span>`}function me({title:e,children:t,onSave:n,onCancel:o,error:s}){let[a,r]=f(!1),l=async()=>{r(!0);try{await n()}finally{r(!1)}};return i`<section class="card editor">
    <header><h2>${e}</h2></header>
    ${t}
    ${s&&i`<p class="error">${s}</p>`}
    <div class="buttons">
      <button class="primary" disabled=${a} onClick=${l}>Save</button>
      <button onClick=${o}>Cancel</button>
    </div>
  </section>`}var $e=e=>e.field?`${e.field}: ${e.message}`:e.message;var io=/^[A-Za-z0-9_-]{1,20}$/,pn=["Mo","Tu","We","Th","Fr","Sa","Su"],mn=e=>(e||[]).filter(t=>["light","dimmer","relay"].includes(t.kind));function $n({value:e,onChange:t,outputs:n}){return i`<select value=${e} onChange=${o=>t(o.target.value)}>
    ${!n.some(o=>o.name===e)&&i`<option value=${e}>${e||"Choose\u2026"}</option>`}
    ${n.map(o=>i`<option value=${o.name}>${o.name}</option>`)}
  </select>`}function ro({title:e,oldName:t,initial:n,api:o,done:s,children:a}){let[r,l]=f(t||""),[u,c]=f(n),[d,p]=f(""),m=async()=>{if(!io.test(r))return p("name: 1\u201320 letters, digits, - and _");if(JSON.stringify(u).includes('"sensor":{"type":0,'))return p("Choose the brightness sensor");let $=u.detectors?{...u,detectors:u.detectors.filter(Boolean)}:u;try{await o.put(r,$),t&&t!==r&&await o.remove(t),M(`${r} saved`),s(!0)}catch(_){p($e(_))}};return i`<${me} title=${t?`${e} ${t}`:`New ${e.toLowerCase()}`} onSave=${m} onCancel=${()=>s(!1)} error=${d}>
    <div class="row">
      <${k} label="Name" hint="Letters, digits, - and _; also the MQTT topic and the switch in Home Assistant">
        <input value=${r} maxlength="20" onInput=${$=>l($.target.value.trim())} />
      <//>
    </div>
    ${a(u,c)}
  <//>`}var lo=e=>({detectors:[],output:e[0]?e[0].name:"",timeout_s:180,lockout_s:60,conditions:[]});function co({m:e,set:t,outputs:n,devices:o}){let s=a=>t({...e,...a});return i`
    <div class="row">
      <${k} label="Switches"><${$n} value=${e.output} outputs=${n} onChange=${a=>s({output:a})} /><//>
      <${k} label="At level" hint="Empty: the level it had last">
        <input type="number" min="0" max="255" value=${e.level??""} onInput=${a=>{let{level:r,...l}=e;t(a.target.value===""?l:{...l,level:+a.target.value})}} />
      <//>
      <${k} label="Off after no motion for (min)">
        <input type="number" min="0.1" max="1440" step="0.5" value=${e.timeout_s/60} onInput=${a=>s({timeout_s:Math.max(1,Math.round(+a.target.value*60))})} />
      <//>
      <${k} label="Then ignore motion for (s)" hint="So it doesn't come straight back on for someone leaving">
        <input type="number" min="0" max="3600" value=${e.lockout_s} onInput=${a=>s({lockout_s:+a.target.value})} />
      <//>
    </div>
    <h3>Motion detectors</h3>
    <${ne} items=${e.detectors} max=${4} addLabel="motion detector" onChange=${a=>s({detectors:a})}
      make=${()=>null}
      render=${(a,r)=>i`<${X} value=${a} devices=${o} onChange=${r} />`} />
    <h3>Only switches on if</h3>
    <p class="muted">All of these hold. One that can't be told (no reading, no clock) counts as holding. Switching it on by hand stops the timer until it is switched off.</p>
    <${ne} items=${e.conditions||[]} max=${3} addLabel="condition" onChange=${a=>s({conditions:a})}
      make=${()=>({sun_below:{degrees:-6}})}
      render=${(a,r)=>i`<${lt} value=${a} devices=${o} onChange=${r} />`} />`}var hn=()=>({start:{sun:{event:"civil_dusk",offset_min:-30}},end:[{at:{clock:{hour:23,minute:0}}}],days:127});function uo({value:e,onChange:t,devices:n}){let o=!!e.bright;return i`<span class="end">
    <select value=${o?"bright":"at"} onChange=${s=>t(s.target.value==="bright"?{bright:{sensor:{type:0,id:1},lux:200,for_min:5}}:{at:{clock:{hour:8,minute:0}}})}>
      <option value="at">At</option>
      <option value="bright">When bright</option>
    </select>
    ${o?i`<input type="number" class="short" min="0" value=${e.bright.lux} onInput=${s=>t({bright:{...e.bright,lux:+s.target.value}})} /><small>lx for</small>
          <input type="number" class="short" min="0" max="600" value=${e.bright.for_min} onInput=${s=>t({bright:{...e.bright,for_min:+s.target.value}})} /><small>min at</small>
          <${X} value=${e.bright.sensor.type?e.bright.sensor:null} devices=${n} onChange=${s=>t({bright:{...e.bright,sensor:s}})} />`:i`<${Se} value=${e.at} onChange=${s=>t({at:s})} />`}
  </span>`}function po({w:e,set:t,devices:n}){let o=s=>t({...e,...s});return i`<div class="window">
    <div class="row">
      <${k} label="On at"><${Se} value=${e.start} onChange=${s=>o({start:s})} /><//>
      <div class="field"><span>Days</span>
        <div class="days">
          ${pn.map((s,a)=>i`<label class=${"lamp"+(e.days&1<<a?" on":"")} key=${s}>
              <input type="checkbox" checked=${!!(e.days&1<<a)} onChange=${()=>o({days:e.days^1<<a})} />${s}
            </label>`)}
        </div>
      </div>
    </div>
    <div class="row tight">
      <label class="check"><input type="checkbox" checked=${!!e.only_if} onChange=${s=>{let{only_if:a,...r}=e;t(s.target.checked?{...r,only_if:{sun_below:{degrees:-6}}}:r)}} /> Only if, at the start:</label>
      ${e.only_if&&i`<${lt} value=${e.only_if} devices=${n} onChange=${s=>o({only_if:s})} />`}
    </div>
    <span class="label">Off at the first of</span>
    <${ne} items=${e.end} max=${3} addLabel="end" onChange=${s=>o({end:s})}
      make=${()=>({at:{clock:{hour:8,minute:0}}})}
      render=${(s,a)=>i`<${uo} value=${s} devices=${n} onChange=${a} />`} />
  </div>`}function mo({s:e,set:t,outputs:n,devices:o}){return i`
    <div class="row">
      <${k} label="Switches" hint="On at its last level"><${$n} value=${e.output} outputs=${n} onChange=${s=>t({...e,output:s})} /><//>
    </div>
    <h3>Time windows</h3>
    <p class="muted">Only the start and the end switch: switching it off by hand in between sticks. Nothing switches while the clock isn't set.</p>
    <${ne} items=${e.windows} max=${4} addLabel="time window" onChange=${s=>t({...e,windows:s})}
      make=${hn}
      render=${(s,a)=>i`<${po} w=${s} set=${a} devices=${o} />`} />`}function $o(e,t){let n=e.days===127?"":` (${pn.filter((a,r)=>e.days&1<<r).join(" ")})`,o=e.only_if?` if ${rt(e.only_if,t)}`:"",s=e.end.map(a=>a.at?ke(a.at):`\u2265 ${a.bright.lux} lx`).join(" / ");return`${ke(e.start)}${o} \u2192 ${s}${n}`}var ho={idle:["Waiting","muted"],auto:["On by motion","ok"],manual:["On by hand","warn"],lockout:["Locked","muted"],running:["Running","ok"]};function fn({kind:e,title:t,items:n,outputs:o,reload:s,empty:a}){let r=ae(),[l,u]=f(null),c=e==="motion"?L.motion:L.schedules,[d,p]=f({}),m=async h=>{let g=h?await C(()=>c.get(h)):e==="motion"?lo(o):{output:o[0]?o[0].name:"",windows:[hn()]};g&&u({oldName:h,initial:g})},$=async h=>{await C(()=>c.setEnabled(h.name,!h.enabled),`${h.name} ${h.enabled?"disabled":"enabled"}`),setTimeout(s,300)},_=async h=>{confirm(`Delete ${h}?`)&&await C(()=>c.remove(h),`${h} deleted`)!==void 0&&setTimeout(s,300)},v=async h=>{if(d[h])return p({...d,[h]:void 0});let g=await C(()=>c.get(h));g&&p({...d,[h]:g})};return l?i`<${ro} title=${t} ...${l} api=${c}
      done=${h=>{u(null),h&&setTimeout(s,300)}}>
      ${(h,g)=>e==="motion"?i`<${co} m=${h} set=${g} outputs=${o} devices=${r} />`:i`<${mo} s=${h} set=${g} outputs=${o} devices=${r} />`}
    <//>`:i`<${T} title=${t+"s"} aside=${i`<button class="primary" onClick=${()=>m()}>+ New ${t.toLowerCase()}</button>`}>
    ${n?n.length===0?i`<p class="muted">${a}</p>`:i`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>State</th><th>Enabled</th><th></th></tr></thead>
            <tbody>
              ${n.map(h=>{let[g,w]=ho[h.state]||[h.state,"muted"],O=d[h.name];return i`<tr key=${h.name}>
                    <td><a href="#" onClick=${S=>(S.preventDefault(),v(h.name))}><strong>${h.name}</strong></a></td>
                    <td><span class=${"badge "+(h.enabled?w:"muted")}>${g}</span>${h.remaining_s!==void 0?i` <small class="muted">${Math.ceil(h.remaining_s/60)} min</small>`:""}</td>
                    <td><label class="switch"><input type="checkbox" checked=${h.enabled} onChange=${()=>$(h)} /><span></span></label></td>
                    <td class="actions">
                      <button onClick=${()=>m(h.name)}>Edit</button>
                      <button class="danger" onClick=${()=>_(h.name)}>Delete</button>
                    </td>
                  </tr>
                  ${O&&i`<tr class="details"><td colspan="4">
                    ${e==="motion"?`${O.output}${O.level!==void 0?" at "+O.level:""}; off ${O.timeout_s/60} min after the last motion at ${O.detectors.map(S=>j(r,S)).join(", ")}; locked ${O.lockout_s} s${(O.conditions||[]).length?"; only if "+O.conditions.map(S=>rt(S,r)).join(" and "):""}`:i`${O.output}: ${O.windows.map(S=>i`<div>${$o(S,r)}</div>`)}`}
                  </td></tr>`}`})}
            </tbody>
          </table></div>`:i`<${R} />`}
  <//>`}var _n=({motion:e,outputs:t,reload:n})=>i`<${fn} kind="motion" title="Motion light" items=${e} outputs=${mn(t)} reload=${n}
  empty="None yet. A motion light switches an output on by motion and off after a while without it; it can be bound to a button (three times down: off) and switched in Home Assistant." />`,vn=({schedules:e,outputs:t,reload:n})=>i`<${fn} kind="schedule" title="Schedule" items=${e} outputs=${mn(t)} reload=${n}
  empty="None yet. A schedule switches an output in time windows: by the clock, relative to the sun, and off when it gets bright." />`;var he=[["single","Pressed once"],["double","Pressed twice"],["triple","Pressed three times"],["hold","Held (every 0.5 s)"],["released","Let go after holding"]],fo=e=>(he.find(([t])=>t===e)||[e,e])[1],_o=4;function vo(e,t,n){return e.output?`${e.output.name}: ${un(e.output.op,n[e.output.name])}`:e.automation?`${e.automation.name}: ${e.automation.switch}`:e.nightlight?`night light of ${j(t,e.nightlight.device)}: ${e.nightlight.value}`:"?"}function go({value:e,onChange:t,devices:n,outputs:o,automations:s}){let a=Object.keys(e)[0],r=e[a],l=Object.fromEntries(o.map(c=>[c.name,c.kind])),u=c=>{c==="output"&&t({output:{name:o[0]?o[0].name:"",op:"toggle"}}),c==="automation"&&t({automation:{name:s[0]||"",switch:"toggle"}}),c==="nightlight"&&t({nightlight:{device:{type:4,id:1},value:0}})};return i`<span class="action">
    <select value=${a} onChange=${c=>u(c.target.value)}>
      <option value="output">Output</option>
      <option value="automation">Motion light / schedule</option>
      <option value="nightlight">Night light</option>
    </select>
    ${a==="output"&&i`<select value=${r.name} onChange=${c=>t({output:{name:c.target.value,op:"toggle"}})}>
        ${!o.some(c=>c.name===r.name)&&i`<option value=${r.name}>${r.name||"Choose\u2026"}</option>`}
        ${o.map(c=>i`<option value=${c.name}>${c.name}</option>`)}
      </select>
      <${dn} value=${r.op} kind=${l[r.name]} onChange=${c=>t({output:{...r,op:c}})} />`}
    ${a==="automation"&&i`<select value=${r.name} onChange=${c=>t({automation:{...r,name:c.target.value}})}>
        ${!s.includes(r.name)&&i`<option value=${r.name}>${r.name||"Choose\u2026"}</option>`}
        ${s.map(c=>i`<option value=${c}>${c}</option>`)}
      </select>
      <select value=${r.switch} onChange=${c=>t({automation:{...r,switch:c.target.value}})}>
        <option value="toggle">Toggle</option>
        <option value="enable">Enable</option>
        <option value="disable">Disable</option>
      </select>`}
    ${a==="nightlight"&&i`<${X} value=${r.device} devices=${n} types=${[4]} onChange=${c=>t({nightlight:{...r,device:c}})} />
      <input type="number" class="short" min="0" max="255" value=${r.value} onInput=${c=>t({nightlight:{...r,value:+c.target.value}})} />`}
  </span>`}function bo({onLearn:e}){let[t,n]=f(!1),o=ce(!1);return W(()=>()=>o.current=!0,[]),t?i`<button class="learning" onClick=${()=>o.current=!0}>Press the button now… (cancel)</button>`:i`<button onClick=${async()=>{n(!0),o.current=!1;let a=Date.now(),r=a+3e4;for(;!o.current&&Date.now()<r;){try{let l=await L.status();if(l.last_button&&l.last_button.age_s+1<=(Date.now()-a)/1e3){e(l.last_button.trigger),M("Button learned");break}}catch{}await new Promise(l=>setTimeout(l,700))}n(!1)}}>Learn: press the button</button>`}function yo({slot:e,original:t,devices:n,outputs:o,automations:s,done:a}){let[r,l]=f(t||{trigger:{device:null,button:0,event:"single"},actions:[{output:{name:o[0]?o[0].name:"",op:"toggle"}}]}),[u,c]=f(""),d=r.trigger,p=$=>l({...r,trigger:{...d,...$}});return i`<${me} title=${e===void 0?"New button binding":"Button binding"} onSave=${async()=>{if(!d.device)return c("Choose the switch, or learn it");try{e===void 0?await L.bindings.add(r):await L.bindings.put(e,r),M("Binding saved"),a(!0)}catch($){c($e($))}}} onCancel=${()=>a(!1)} error=${u}>
    <div class="row">
      <${k} label="Switch"><${X} value=${d.device} devices=${n} onChange=${$=>p({device:$})} /><//>
      <${k} label="Button" hint="0–7; 4–7 on an extension board">
        <input type="number" min="0" max="15" value=${d.button} onInput=${$=>p({button:+$.target.value})} />
      <//>
      <${k} label="When">
        <select value=${d.event} onChange=${$=>p({event:$.target.value})}>
          ${he.map(([$,_])=>i`<option value=${$}>${_}</option>`)}
        </select>
      <//>
      <${bo} onLearn=${$=>l(_=>({..._,trigger:$}))} />
    </div>
    <h3>Does</h3>
    <${ne} items=${r.actions} max=${_o} addLabel="action" onChange=${$=>l({...r,actions:$})}
      make=${()=>({output:{name:o[0]?o[0].name:"",op:"toggle"}})}
      render=${($,_)=>i`<${go} value=${$} onChange=${_} devices=${n} outputs=${o} automations=${s} />`} />
  <//>`}function gn({outputs:e,motion:t,schedules:n}){let o=ae(),[s,a]=f(),[r,l]=f(),[u,c]=f(null),d=async()=>{try{a(await L.bindings.list())}catch(v){l(v)}};W(()=>{d()},[]);let p=[...t||[],...n||[]].map(v=>v.name),m=Object.fromEntries((e||[]).map(v=>[v.name,v.kind]));if(u)return i`<${yo} ...${u} devices=${o} outputs=${e||[]} automations=${p}
      done=${v=>{c(null),v&&d()}} />`;let $=async v=>{confirm("Delete this binding?")&&await C(()=>L.bindings.remove(v),"Binding deleted")!==void 0&&d()},_=(s||[]).slice().sort((v,h)=>j(o,v.trigger.device).localeCompare(j(o,h.trigger.device))||v.trigger.button-h.trigger.button||he.findIndex(([g])=>g===v.trigger.event)-he.findIndex(([g])=>g===h.trigger.event));return i`<${T} title="Buttons" aside=${i`<button class="primary" onClick=${()=>c({})}>+ New binding</button>`}>
    ${s?s.length===0?i`<p class="muted">No button does anything yet. A binding ties a button event (pressed once, twice, held …) to up to four actions.</p>`:i`<div class="table-wrap"><table>
            <thead><tr><th>Switch</th><th>Button</th><th>When</th><th>Does</th><th></th></tr></thead>
            <tbody>
              ${_.map(({slot:v,trigger:h,actions:g})=>i`<tr key=${v}>
                  <td>${j(o,h.device)}</td>
                  <td>${h.button}</td>
                  <td>${fo(h.event)}</td>
                  <td class="wrap">${g.map(w=>vo(w,o,m)).join(" \xB7 ")}</td>
                  <td class="actions">
                    <button onClick=${()=>c({slot:v,original:{trigger:h,actions:g}})}>Edit</button>
                    <button class="danger" onClick=${()=>$(v)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:i`<${R} error=${r} />`}
  <//>`}var wo=[3],ko=8,bn=15,ut=e=>Object.keys(e)[0],So=e=>(ct.find(([t])=>t===e)||[e,e])[1],yn={light:()=>({light:{groups:[{device:{type:3,id:1},mask:1}],levels:[[40],[80],[127]],default_level:2}}),dimmer:()=>({dimmer:{lamps:{device:{type:3,id:1},mask:1},default_value:127}}),relay:()=>({relay:{device:{type:5,id:1},channel:0,bank:0}}),shutter:()=>({shutter:{device:{type:5,id:1},channel:0,bank:0,travel_ms:2e4,up:1}}),group:()=>({group:{members:[]}})};function xo(e,t){let n=ut(e),o=e[n];switch(n){case"light":return`${o.levels.length} levels, ${o.groups.length} lamp group${o.groups.length>1?"s":""} on ${[...new Set(o.groups.map(s=>j(t,s.device)))].join(", ")}`;case"dimmer":return`${j(t,o.lamps.device)}, mask 0x${o.lamps.mask.toString(16)}`;case"relay":return`${j(t,o.device)}, channel ${o.channel}`;case"shutter":return`${j(t,o.device)}, shutter ${o.channel}, ${o.travel_ms/1e3} s`;case"group":return o.members.join(", ")}return""}function Co({value:e,onChange:t}){return i`<div class="lamps compact">
    ${Array.from({length:24},(n,o)=>23-o).map(n=>{let o=e>>>n&1;return i`<label key=${n} class=${"lamp"+(o?" on":"")}>
        <input type="checkbox" checked=${!!o} onChange=${()=>t((e^1<<n)>>>0)} />${n}
      </label>`})}
  </div>`}function wn({value:e,onChange:t,devices:n}){return i`<div class="row">
    <${k} label="Lamp controller">
      <${X} value=${e.device} devices=${n} types=${wo} onChange=${o=>t({...e,device:o})} />
    <//>
    <${k} label="Bank" hint="Empty: the controller's only one">
      <input type="number" min="0" max="255" value=${e.bank??""} onInput=${o=>{let{bank:s,...a}=e;t(o.target.value===""?a:{...a,bank:+o.target.value})}} />
    <//>
    <div class="field wide"><span>Lamps (mask 0x${e.mask.toString(16).padStart(6,"0")})</span>
      <${Co} value=${e.mask} onChange=${o=>t({...e,mask:o})} />
    </div>
  </div>`}function To(e,t,n,o,s){return Array.from({length:e},(a,r)=>{let l=Math.round(n+(o-n)*Math.pow((r+1)/e,s));return Array(t).fill(Math.max(1,Math.min(255,l)))})}function Eo({value:e,onChange:t,devices:n}){let[o,s]=f(127),a=e.groups,r=c=>{let d=e.levels.map(p=>c.map((m,$)=>$<p.length?p[$]:p[p.length-1]??0));t({...e,groups:c,levels:d})},l=(c,d,p)=>t({...e,levels:e.levels.map((m,$)=>$===c?m.map((_,v)=>v===d?p:_):m)}),u=c=>{let d=e.levels.slice(0,c);for(;d.length<c;)d.push([...d[d.length-1]||a.map(()=>0)]);t({...e,levels:d,default_level:Math.min(e.default_level,c)})};return i`
    <h3>Lamp groups</h3>
    <p class="muted">Lamps that always have the same value in every level form a group. A light may span several controllers.</p>
    <${ne} items=${a} max=${ko} addLabel="lamp group" onChange=${r}
      make=${()=>({device:a.length?a[a.length-1].device:{type:3,id:1},mask:1})}
      render=${(c,d)=>i`<${wn} value=${c} devices=${n} onChange=${d} />`} />

    <h3>Levels</h3>
    <p class="muted">The value (0–255) of each lamp group per level; level 0 is off. The controllers fade by themselves and take one change per second.</p>
    <div class="table-wrap"><table class="levels">
      <thead><tr><th>Level</th>${a.map((c,d)=>i`<th>Group ${d+1}</th>`)}</tr></thead>
      <tbody>
        ${e.levels.map((c,d)=>i`<tr key=${d}>
            <td>${d+1}${d+1===e.default_level&&i` <span class="badge muted">default</span>`}</td>
            ${c.map((p,m)=>i`<td><input type="number" class="short" min="0" max="255" value=${p} onInput=${$=>l(d,m,+$.target.value)} /></td>`)}
          </tr>`)}
      </tbody>
    </table></div>
    <div class="row">
      <${k} label="Levels">
        <input type="number" min="1" max=${bn} value=${e.levels.length} onInput=${c=>c.target.value&&u(Math.max(1,Math.min(bn,+c.target.value)))} />
      <//>
      <${k} label="Default level" hint="What “on” switches to the first time">
        <select value=${e.default_level} onChange=${c=>t({...e,default_level:+c.target.value})}>
          ${e.levels.map((c,d)=>i`<option value=${d+1}>${d+1}</option>`)}
        </select>
      <//>
      <${k} label="Ramp up to" hint="Fills every level, all groups alike">
        <input type="number" min="1" max="255" value=${o} onInput=${c=>s(+c.target.value)} />
      <//>
      <button onClick=${()=>t({...e,levels:To(e.levels.length,a.length,2,o,3)})}>Fill ramp</button>
    </div>`}var fe=(e,t,n,o={},s)=>i`<${k} label=${e} hint=${s}>
  <input type="number" value=${t} ...${o} onInput=${a=>n(+a.target.value)} />
<//>`;function Lo({output:e,onChange:t,devices:n,names:o}){let s=ut(e),a=e[s],r=l=>t({[s]:{...a,...l}});switch(s){case"light":return i`<${Eo} value=${a} devices=${n} onChange=${l=>t({light:l})} />`;case"dimmer":return i`<${wn} value=${a.lamps} devices=${n} onChange=${l=>r({lamps:l})} />
        <div class="row">${fe("Default value",a.default_value,l=>r({default_value:l}),{min:1,max:255},"What \u201Con\u201D switches to the first time")}</div>`;case"relay":return i`<div class="row">
        <${k} label="Relay node"><${X} value=${a.device} devices=${n} onChange=${l=>r({device:l})} /><//>
        ${fe("Channel",a.channel,l=>r({channel:l}),{min:0,max:255})}
        ${fe("Bank",a.bank,l=>r({bank:l}),{min:0,max:255})}
      </div>`;case"shutter":return i`<div class="row">
        <${k} label="Shutter node"><${X} value=${a.device} devices=${n} onChange=${l=>r({device:l})} /><//>
        ${fe("Shutter",a.channel,l=>r({channel:l}),{min:0,max:255})}
        ${fe("Bank",a.bank,l=>r({bank:l}),{min:0,max:255})}
      </div>
      <div class="row">
        ${fe("Travel time (s)",a.travel_ms/1e3,l=>r({travel_ms:Math.round(l*1e3)}),{min:1,max:600,step:.5},"A full move; sent with up and down")}
        <${k} label="Up is" hint="Depends on the wiring: swap it if up and down are the wrong way round">
          <select value=${a.up} onChange=${l=>r({up:+l.target.value})}>
            <option value="1">Direction 1</option>
            <option value="2">Direction 2</option>
          </select>
        <//>
      </div>`;case"group":return i`<p class="muted">Switched together. Groups can't contain groups.</p>
        <div class="checks">
          ${o.map(l=>i`<label class="check" key=${l}>
              <input type="checkbox" checked=${a.members.includes(l)} onChange=${u=>r({members:u.target.checked?[...a.members,l]:a.members.filter(c=>c!==l)})} /> ${l}
            </label>`)}
        </div>`}return null}function Ao({original:e,name:t,outputs:n,devices:o,done:s}){let[a,r]=f(t||""),[l,u]=f(e||yn.light()),[c,d]=f(""),p=ut(l),m=n.filter(_=>_.kind!=="group"&&_.name!==t).map(_=>_.name),$=async()=>{if(!/^[A-Za-z0-9_-]{1,20}$/.test(a))return d("name: 1\u201320 letters, digits, - and _");try{await L.outputs.put(a,l),t&&t!==a&&await L.outputs.remove(t),M(`${a} saved`),s(!0)}catch(_){d($e(_))}};return i`<${me} title=${t?`Output ${t}`:"New output"} onSave=${$} onCancel=${()=>s(!1)} error=${c}>
    <div class="row">
      <${k} label="Name" hint=${t&&a!==t?"Renaming: bindings and automations that use the old name stop working":"Letters, digits, - and _"}>
        <input value=${a} maxlength="20" onInput=${_=>r(_.target.value.trim())} />
      <//>
      <${k} label="Kind">
        <select value=${p} disabled=${!!t} onChange=${_=>u(yn[_.target.value]())}>
          ${ct.map(([_,v])=>i`<option value=${_}>${v}</option>`)}
        </select>
      <//>
    </div>
    <${Lo} output=${l} onChange=${u} devices=${o} names=${m} />
  <//>`}function kn({outputs:e,reload:t}){let n=ae(),[o,s]=f(null),[a,r]=f({}),[l,u]=f(0),c=(e||[]).map(m=>m.name).join(",");W(()=>{let m=!1;return(async()=>{let $={};for(let _ of c?c.split(","):[]){try{$[_]=await L.outputs.get(_)}catch{}if(m)return}r($)})(),()=>m=!0},[c,l]);let d=async m=>{let $=m?await C(()=>L.outputs.get(m)):void 0;m&&!$||s({name:m,original:$})},p=async m=>{confirm(`Delete the output ${m}? Bindings and automations that use it stop working.`)&&await C(()=>L.outputs.remove(m),`${m} deleted`)!==void 0&&t()};return o?i`<${Ao} ...${o} outputs=${e||[]} devices=${n}
      done=${m=>{s(null),m&&(u($=>$+1),setTimeout(t,300))}} />`:i`<${T} title="Outputs" aside=${i`<button class="primary" onClick=${()=>d()}>+ New output</button>`}>
    ${e?e.length===0?i`<p class="muted">Nothing yet. An output is what the automation switches: a room light with its levels, a dimmer, a relay, a roller shutter, or a group of them.</p>`:i`<div class="table-wrap"><table>
            <thead><tr><th>Name</th><th>Kind</th><th>What</th><th></th></tr></thead>
            <tbody>
              ${e.map(m=>i`<tr key=${m.name}>
                  <td><strong>${m.name}</strong></td>
                  <td>${So(m.kind)}</td>
                  <td class="muted-cell">${a[m.name]?xo(a[m.name],n):""}</td>
                  <td class="actions">
                    <button onClick=${()=>d(m.name)}>Edit</button>
                    <button class="danger" onClick=${()=>p(m.name)}>Delete</button>
                  </td>
                </tr>`)}
            </tbody>
          </table></div>`:i`<${R} />`}
  <//>`}var Oo=[["","Overview"],["outputs","Outputs"],["buttons","Buttons"],["motion","Motion lights"],["schedules","Schedules"],["backup","Backup"]];async function No(){let e=await L.status(),t=await L.outputs.list(),n=await L.motion.list(),o=await L.schedules.list();return{status:e,outputs:t,motion:n,schedules:o}}function pt({tab:e=""}){let{data:t,error:n,reload:o}=B(No,e===""?2500:0),s=t||{};return i`
    <nav class="tabs">
      ${Oo.map(([a,r])=>i`<${K} href=${"/automation"+(a?"/"+a:"")} class=${a===e?"active":""}>${r}<//>`)}
    </nav>
    ${!t&&i`<${R} error=${n} />`}
    ${t&&e===""&&i`<${Do} ...${s} reload=${o} />`}
    ${t&&e==="outputs"&&i`<${kn} outputs=${s.outputs} reload=${o} />`}
    ${t&&e==="buttons"&&i`<${gn} outputs=${s.outputs} motion=${s.motion} schedules=${s.schedules} />`}
    ${t&&e==="motion"&&i`<${_n} motion=${s.motion} outputs=${s.outputs} reload=${o} />`}
    ${t&&e==="schedules"&&i`<${vn} schedules=${s.schedules} outputs=${s.outputs} reload=${o} />`}
    ${t&&e==="backup"&&i`<${Ro} ...${s} reload=${o} />`}
    ${n&&t&&i`<p class="error">${n.message}</p>`}`}var dt=(e,t,n)=>async()=>{await C(()=>L.outputs.command(e,t)),setTimeout(n,400)};function Io({o:e,reload:t}){let n=e.level>0,o=l=>dt(e.name,l,t),s,a;switch(e.kind){case"light":s=n?`level ${e.level} of ${e.top}`:"off",a=i`
        <input type="range" min="0" max=${e.top} value=${e.level} onChange=${l=>dt(e.name,{set:+l.target.value},t)()} />
        <div class="buttons"><button onClick=${o("dec")}>−</button><button onClick=${o("inc")}>+</button><button onClick=${o(n?"off":"on")}>${n?"Off":"On"}</button></div>`;break;case"dimmer":s=n?`${Math.round(e.level/255*100)} %`:"off",a=i`
        <input type="range" min="0" max="255" value=${e.level} onChange=${l=>dt(e.name,{set:+l.target.value},t)()} />
        <div class="buttons"><button onClick=${o(n?"off":"on")}>${n?"Off":"On"}</button></div>`;break;case"relay":s=n?"on":"off",a=i`<div class="buttons"><button onClick=${o(n?"off":"on")}>${n?"Off":"On"}</button></div>`;break;case"shutter":s={up:"moving up",down:"moving down",stopped:"stopped"}[e.movement],a=i`<div class="buttons"><button title="Up" onClick=${o("up")}>▲</button><button title="Stop" onClick=${o("stop")}>■</button><button title="Down" onClick=${o("down")}>▼</button></div>`;break;default:s="group",a=i`<div class="buttons"><button onClick=${o("on")}>On</button><button onClick=${o("off")}>Off</button></div>`}let r=n||e.kind==="shutter"&&e.movement!=="stopped";return i`<div class=${"tile"+(r?" lit":"")}>
    <div class="tile-head"><strong>${e.name}</strong><small>${s}</small></div>
    ${a}
  </div>`}function Do({status:e,outputs:t,motion:n,schedules:o,reload:s}){let a=ae(),r=async d=>{await C(()=>L.setEnabled(d),d?"Automation on":"Automation off"),s()},l=(d,p)=>async()=>{await C(()=>d.setEnabled(p.name,!p.enabled),`${p.name} ${p.enabled?"disabled":"enabled"}`),setTimeout(s,400)},u=e.last_button,c=!t.length&&!n.length&&!o.length;return i`
    <${T} title="Automation" aside=${i`<label class="switch big" title="The master switch">
      <input type="checkbox" checked=${e.enabled} onChange=${d=>r(d.target.checked)} /><span></span>
      ${e.enabled?"On":"Off"}
    </label>`}>
      <p class="muted">
        Buttons, motion lights and schedules run on the gateway itself: they keep working without the network, MQTT or Home Assistant.
        ${!e.enabled&&i` <strong>Switched off:</strong> nothing switches by itself, outputs can still be switched here.`}
      </p>
      <dl class="facts">
        <div><dt>Outputs</dt><dd><${K} href="/automation/outputs">${e.outputs}<//></dd></div>
        <div><dt>Button bindings</dt><dd><${K} href="/automation/buttons">${e.bindings}<//></dd></div>
        <div><dt>Motion lights</dt><dd><${K} href="/automation/motion">${e.motion}<//></dd></div>
        <div><dt>Schedules</dt><dd><${K} href="/automation/schedules">${e.schedules}<//></dd></div>
        <div><dt>Last button</dt>
        <dd>${u?`${j(a,u.trigger.device)}, button ${u.trigger.button}, ${(he.find(([d])=>d===u.trigger.event)||[,u.trigger.event])[1].toLowerCase()} (${u.age_s} s ago)`:"\u2014"}</dd></div>
      </dl>
      ${c&&i`<p>Start with the <${K} href="/automation/outputs">outputs<//>: what the automation switches. Or restore a <${K} href="/automation/backup">backup<//>.</p>`}
    <//>
    ${t.length>0&&i`<${T} title="Outputs">
      <div class="tiles">${t.map(d=>i`<${Io} key=${d.name} o=${d} reload=${s} />`)}</div>
    <//>`}
    ${n.length+o.length>0&&i`<${T} title="Motion lights and schedules">
      <div class="tiles">
        ${[...n.map(d=>[d,L.motion]),...o.map(d=>[d,L.schedules])].map(([d,p])=>i`<div class=${"tile"+(d.enabled&&d.state!=="idle"?" lit":"")} key=${d.name}>
            <div class="tile-head"><strong>${d.name}</strong>
              <small>${d.enabled?{idle:"waiting",auto:"on by motion",manual:"on by hand",lockout:"locked",running:"running"}[d.state]:"disabled"}
              ${d.enabled&&d.remaining_s!==void 0?` \xB7 ${d.remaining_s} s`:""}</small>
            </div>
            <label class="switch"><input type="checkbox" checked=${d.enabled} onChange=${l(p,d)} /><span></span>${d.enabled?"Enabled":"Disabled"}</label>
          </div>`)}
      </div>
    <//>`}`}var Sn="gateway-automation",Mo=e=>new Promise(t=>setTimeout(t,e));function Ro({status:e,outputs:t,motion:n,schedules:o,reload:s}){let[a,r]=f([]),[l,u]=f(!1),[c,d]=f(!1),p=v=>r(h=>[...h,v]),m=async()=>{u(!0),r([]);try{let v={format:Sn,version:1,enabled:e.enabled,outputs:[],bindings:[],motion:[],schedules:[]};for(let w of t)v.outputs.push({name:w.name,output:await L.outputs.get(w.name)});v.bindings=(await L.bindings.list()).map(({trigger:w,actions:O})=>({trigger:w,actions:O}));for(let w of n)v.motion.push({name:w.name,enabled:w.enabled,config:await L.motion.get(w.name)});for(let w of o)v.schedules.push({name:w.name,enabled:w.enabled,config:await L.schedules.get(w.name)});let h=new Blob([JSON.stringify(v,null,2)],{type:"application/json"}),g=document.createElement("a");g.href=URL.createObjectURL(h),g.download=`automation-${new Date().toISOString().slice(0,10)}.json`,g.click(),URL.revokeObjectURL(g.href),p(`Exported ${v.outputs.length} outputs, ${v.bindings.length} bindings, ${v.motion.length} motion lights, ${v.schedules.length} schedules.`)}catch(v){p(`Failed: ${v.message}`)}u(!1)},$=async(v,h)=>{try{return await h(),p(`\u2713 ${v}`),!0}catch(g){return p(`\u2717 ${v}: ${g.field?g.field+": ":""}${g.message}`),!1}},_=async v=>{let h=v.target.files[0];if(v.target.value="",!h)return;let g;try{if(g=JSON.parse(await h.text()),g.format!==Sn)throw new Error("not an automation backup")}catch(S){return M(`${h.name}: ${S.message}`,"error")}if(c&&!confirm("Delete every output, binding, motion light and schedule on the gateway first?"))return;if(u(!0),r([]),c){for(let N of await L.bindings.list())await $(`delete binding ${N.slot}`,()=>L.bindings.remove(N.slot));for(let N of n)await $(`delete ${N.name}`,()=>L.motion.remove(N.name));for(let N of o)await $(`delete ${N.name}`,()=>L.schedules.remove(N.name));let S=[...t].sort((N,z)=>(z.kind==="group")-(N.kind==="group"));for(let N of S)await $(`delete ${N.name}`,()=>L.outputs.remove(N.name))}let w=S=>Object.keys(S.output)[0]==="group";for(let S of[...(g.outputs||[]).filter(N=>!w(N)),...(g.outputs||[]).filter(w)])await $(`output ${S.name}`,()=>L.outputs.put(S.name,S.output));for(let S of g.motion||[])await $(`motion light ${S.name}`,()=>L.motion.put(S.name,S.config));for(let S of g.schedules||[])await $(`schedule ${S.name}`,()=>L.schedules.put(S.name,S.config));for(let[S,N]of(g.bindings||[]).entries())await $(`binding ${S+1}`,()=>L.bindings.add(N));let O=[...(g.motion||[]).map(S=>[S,L.motion]),...(g.schedules||[]).map(S=>[S,L.schedules])].filter(([S])=>S.enabled===!1);O.length&&await Mo(1e3);for(let[S,N]of O)await $(`disable ${S.name}`,()=>N.setEnabled(S.name,!1));p("Done."),u(!1),s()};return i`<${T} title="Backup">
    <p class="muted">The whole configuration as one JSON file: to keep, to edit, or to move to another gateway. Devices are stored by type and id.</p>
    <div class="buttons">
      <button class="primary" disabled=${l} onClick=${m}>Export</button>
      <label class=${"button"+(l?" disabled":"")}>Import…<input type="file" accept=".json,application/json" hidden disabled=${l} onChange=${_} /></label>
      <label class="check"><input type="checkbox" checked=${c} onChange=${v=>d(v.target.checked)} /> Delete everything first</label>
    </div>
    ${a.length>0&&i`<pre class="log">${a.join(`
`)}</pre>`}
  <//>`}function Pe({target:e,label:t,others:n=[],onDone:o}){let[s,a]=f(null),[r,l]=f(null),[u,c]=f(""),[d,p]=f(null),m=ce(null);W(()=>()=>clearInterval(m.current),[]);let $=()=>{clearInterval(m.current),m.current=setInterval(async()=>{try{p(await ot.job())}catch{}},1500)},_=async(w,O)=>{c(w),l(0),O!=="gateway"&&$();try{let S=await s.arrayBuffer();return await ot.upload(O,S,l)||{}}finally{clearInterval(m.current),l(null)}},v=async w=>{if(!s)return;let O=0;for(let{name:S,target:N}of w)try{let z=await _(S,N);O+=1,z.restarting&&M("Firmware installed, the gateway restarts\u2026")}catch(z){M(`${S}: ${z.message}`,"error");break}O===w.length&&w[0].target!=="gateway"&&M(O===1?"Firmware sent; the device restarts into it":`Firmware sent to ${O} devices`),c(""),p(null),o&&o()},h=r!==null,g=d&&d.state==="running"?`${d.sent} of ${d.total} bytes acknowledged${d.protocol?` (${d.protocol})`:""}${d.retries?`, ${d.retries} blocks repeated`:""}`:"";return i`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>a(w.target.files[0]||null)} />
      <${x} onClick=${()=>v([{name:t||"device",target:e}])} disabled=${!s||h}>${t||"Upload"}<//>
      ${n.length>0&&i`<${x} onClick=${()=>v([{name:"this device",target:e},...n])} disabled=${!s||h}>Send to all ${n.length+1} of this type<//>`}
      ${h&&i`<progress max="1" value=${r}></progress>`}
      ${h&&i`<p class="muted wide">${u}${g?" \u2014 "+g:""}</p>`}
    </div>`}var Fo={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},xn={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},mt=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],Po={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},_e=e=>Po[e]||e;function He(e,t=5e3){let n=B(()=>te.list(e),t),o=[...new Set((n.data||[]).map(a=>a.device))];return{...n,ask:async()=>{for(let a of e?[e]:o)await C(()=>te.refresh(a));setTimeout(n.reload,1500)}}}function Ho({s:e,device:t,reload:n}){let[o,s]=f(!1),[a,r]=f(e.name||""),[l,u]=f(e.role||"none"),c=async()=>{let d={};if(a!==(e.name||"")&&(d.name=a),l!==(e.role||"none")&&(d.role=l),Object.keys(d).length===0)return s(!1);await C(()=>te.update(e.device,e.slot,d),"Sent to the device")&&(s(!1),setTimeout(n,1500))};return i`<tr>
    ${!t&&i`<td><${K} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${o?i`<input class="inline" maxlength="7" placeholder="name" value=${a} onInput=${d=>r(d.target.value)} />`:e.name||i`<span class="muted">–</span>`}</td>
    <td>${Fo[e.kind]||e.kind}</td>
    <td>${o?i`<select value=${l} onChange=${d=>u(d.target.value)}>${mt.map(d=>i`<option value=${d}>${_e(d)}</option>`)}</select>`:e.role&&e.role!=="none"?_e(e.role):i`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&i` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?i`<span class="badge bad">lost</span>`:`${e.kind in xn?e.value.toFixed(xn[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:re(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":o?i`<${x} kind="primary" onClick=${c}>Save<//> <button onClick=${()=>s(!1)}>Cancel</button>`:i`<button onClick=${()=>s(!0)}>Edit</button>`}</td>
  </tr>`}function $t({device:e}){let{data:t,error:n,reload:o,ask:s}=He(e);if(!t)return i`<${R} error=${n} />`;if(t.length===0)return i`<p class="muted">No sensor reading seen yet.</p>`;let a=t.some(r=>r.named_by_node&&r.slot===null);return i`
    ${a&&i`<p class="muted">The names and roles of some sensors are not known yet. <${x} onClick=${s}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&i`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(r=>i`<${Ho} key=${r.device_key+r.kind+r.sensor_id} s=${r} device=${e} reload=${o} />`)}
      </tbody>
    </table></div>`}function Cn(){let{ask:e}=He(void 0,0);return i`<${T} title="Sensors" aside=${i`<${x} onClick=${e}>Reload names and roles<//>`}>
    <${$t} />
  <//>`}var Uo=[2,5,8,9],qo=[7],Bo=[3],jo=3,ht=[9],Wo=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],Vo=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ln({device:e}){let{data:t,error:n,reload:o}=B(()=>U.get(e),5e3);return t?i`
    <${Go} d=${t} reload=${o} />
    ${Uo.includes(t.device_type)&&i`<${Tn} d=${t} kind="relay" />`}
    ${qo.includes(t.device_type)&&i`<${Tn} d=${t} kind="rollershutter" />`}
    ${Bo.includes(t.device_type)&&i`<${En} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===jo&&i`<${En} d=${t} firstBank=${1} />`}
    ${ht.includes(t.device_type)&&i`<${zo} d=${t} />`}
    ${ht.includes(t.device_type)&&i`<${Jo} d=${t} />`}
    ${ht.includes(t.device_type)&&i`<${Xo} d=${t} />`}
    <${T} title="Sensors"><${$t} device=${t.name||t.key} /><//>
    <${Yo} d=${t} reload=${o} />
    <${Ko} d=${t} />`:i`<${R} error=${n} />`}function Ko({d:e}){let t=e.name||e.key,{data:n}=B(U.list),o=(n||[]).filter(s=>s.device_type===e.device_type&&s.key!==e.key).map(s=>({name:s.name||s.key,target:"devices/"+encodeURIComponent(s.name||s.key)}));return i`
    <${T} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${Pe} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${o} />
    <//>`}function Go({d:e,reload:t}){let n=e.name||e.key,o=(s,a)=>async()=>{await C(()=>U.action(n,s),a),setTimeout(t,1500)};return i`
    <${T} title=${n}
      aside=${i`<span class="buttons">
        <${x} onClick=${o("ping","Ping sent")}>Ping<//>
        <${x} onClick=${o("refresh","Refresh requested")}>Refresh<//>
        <${x} kind="danger" onClick=${o("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${re(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Tn({d:e,kind:t}){let n=e.name||e.key,[o,s]=f(1),[a,r]=f(0),l=t==="rollershutter",u=c=>()=>C(()=>U[t](n,o,c,Math.round(a*1e3)),`${l?"Rollershutter":"Relay"} ${o}: ${c}`);return i`
    <${T} title=${l?"Rollershutter":"Relays"}>
      ${e.device_type===9&&i`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${k} label="Number"><input type="number" min="1" max="16" value=${o} onInput=${c=>s(+c.target.value)} /><//>
        <${k} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${a} onInput=${c=>r(+c.target.value)} /><//>
      </div>
      <div class="buttons">
        ${l?i`<${x} onClick=${u("up")}>Up<//><${x} onClick=${u("down")}>Down<//><${x} onClick=${u("off")}>Stop<//>`:i`<${x} kind="primary" onClick=${u("on")}>On<//><${x} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function En({d:e,firstBank:t=0}){let n=e.name||e.key,[o,s]=f(t),[a,r]=f(255),[l,u]=f(Array(24).fill(!1)),c=l.reduce((d,p,m)=>p?d|1<<23-m:d,0);return i`
    <${T} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${k} label="Bank"><input type="number" min=${t} max="255" value=${o} onInput=${d=>s(+d.target.value)} /><//>
        <${k} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${d=>r(+d.target.value)} /><//>
      </div>
      <div class="lamps">
        ${l.map((d,p)=>i`<label key=${p} class=${"lamp"+(d?" on":"")}>
            <input type="checkbox" checked=${d} onChange=${()=>u(l.map((m,$)=>$===p?!m:m))} />${23-p}
          </label>`)}
      </div>
      <${x} kind="primary" onClick=${()=>C(()=>U.lamps(n,o,a,c),"Lamps set")}>Send<//>
    <//>`}function zo({d:e}){let t=e.name||e.key,[n,o]=f(45),[s,a]=f(!1),[r,l]=f(0),[u,c]=f(!1),[d,p]=f(0),[m,$]=f(55);return i`
    <${T} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${k} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${_=>o(+_.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${s} onChange=${_=>a(_.target.checked)} /> from the tank</label>
        <${x} onClick=${()=>C(()=>U.heating(t,"target",{flow_c:n,tank:s}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${k} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${r} onInput=${_=>l(+_.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${_=>c(_.target.checked)} /> rod released</label>
        <${x} onClick=${()=>C(()=>U.heating(t,"energy",{power_w:r,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${k} label="Stage (0-3)"><input type="number" min="0" max="3" value=${d} onInput=${_=>p(+_.target.value)} /><//>
        <${k} label="Tank (°C)"><input type="number" step="0.5" value=${m} onInput=${_=>$(+_.target.value)} /><//>
        <${x} kind="danger" onClick=${()=>C(()=>U.heating(t,"emergency",{stage:d,tank_c:m}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var Qo=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function Jo({d:e}){let t=e.name||e.key,{data:n,error:o,reload:s,ask:a}=He(t);if(!n)return i`<${T} title="Sensor assignment"><${R} error=${o} /><//>`;let r=n.filter(p=>p.kind==="temperature"),l=p=>r.find(m=>m.role===p),u=p=>p.name?`${p.name} (${p.sensor_id})`:p.sensor_id,c=r.every(p=>p.slot!==null),d=p=>async m=>{let $=m.target.value,_;if($===""){let v=l(p);if(!v)return;_=await C(()=>te.update(t,v.slot,{role:"none"}),`${_e(p)} cleared`)}else{let v=r.find(h=>h.sensor_id===$);_=await C(()=>te.update(t,v.slot,{role:p}),`${u(v)} is ${_e(p)} now`)}_&&setTimeout(s,1500)};return i`
    <${T} title="Sensor assignment" aside=${i`<${x} onClick=${a}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!c&&i`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${mt.filter(p=>p!=="none").map(p=>i`<label key=${p} class="field">
            <span>${_e(p)}</span>
            <select value=${(l(p)||{}).sensor_id||""} onChange=${d(p)} disabled=${!c}>
              <option value="">(none)</option>
              ${r.map(m=>i`<option value=${m.sensor_id}>${u(m)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Xo({d:e}){let t=e.name||e.key,{data:n,error:o,reload:s}=B(()=>U.heatingManualState(t),3e3),a=!!(n&&n.enabled),r=d=>!!(n&&n.relays.includes(d)),l=async()=>{let d=!a;await C(()=>U.heatingManual(t,d),d?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(s,800)},u=d=>async()=>{await C(()=>U.heatingManual(t,!0,d,!r(d)),`Relay ${d} ${r(d)?"off":"on"}`)&&setTimeout(s,800)},c=d=>d===8&&r(9)||d===9&&r(8);return i`
    <${T} title="Manual mode"
      aside=${i`<${x} kind=${a?"danger":""} disabled=${!n} onClick=${l}>${a?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${o&&i`<p class="error">The controller does not answer: ${o.message}</p>`}
      ${a&&i`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${Qo.map(([d,p])=>i`<button key=${d} class=${r(d)?"primary":""} disabled=${!a||c(d)} onClick=${u(d)}>
            <span>${p}</span><small>relay ${d}: ${r(d)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Yo({d:e,reload:t}){let n=e.name||e.key,[o,s]=f({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[a,r]=f(!1),l=c=>d=>s({...o,[c]:d.target.value}),u=async()=>{let c={};if(o.custom_string!==e.name&&(c.custom_string=o.custom_string),+o.hwrev!==e.hwrev&&(c.hwrev=+o.hwrev),o.relais_mode&&(c.relais_mode=o.relais_mode),o.extension_mode&&(c.extension_mode=o.extension_mode),Object.keys(c).length===0)return M("Nothing changed");await C(()=>U.update(n,c),"Settings sent")&&setTimeout(t,1500)};return i`
    <${T} title="Settings">
      <div class="row">
        <${k} label="Name" hint="up to 8 characters"><input maxlength="8" value=${o.custom_string} onInput=${l("custom_string")} /><//>
        <${k} label="Hardware revision"><input type="number" min="0" max="255" value=${o.hwrev} onInput=${l("hwrev")} /><//>
        <${k} label="Relay mode"><select value=${o.relais_mode} onChange=${l("relais_mode")}>
          <option value="">(unchanged)</option>${Wo.map(c=>i`<option>${c}</option>`)}
        </select><//>
        <${k} label="Extension mode"><select value=${o.extension_mode} onChange=${l("extension_mode")}>
          <option value="">(unchanged)</option>${Vo.map(c=>i`<option>${c}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${x} kind="primary" onClick=${u}>Save<//>
        <${x} onClick=${async()=>{await C(()=>U.silence(n,!a),a?"Device may talk again":"Device silenced"),r(!a)}}>${a?"End silence":"Silence"}<//>
        <${x} onClick=${()=>C(()=>U.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function An(){let{data:e,error:t,reload:n}=B(U.list,5e3),[o,s]=f(""),a=(c,d)=>async()=>{await C(c,d),setTimeout(n,1500)},r=async()=>{let c=o.trim();c&&await C(()=>U.action(c,"ping"),`Ping sent to ${c}`)},l=async()=>{confirm("Restart every device on the bus?")&&await a(()=>pe.action("restart"),"Restart sent to every device")()},u=a(()=>pe.action("discover"),"Scanning: every device was asked to announce itself");return i`
    <${T} title="Devices">
      <div class="toolbar">
        <${x} onClick=${n}>Refresh<//>
        <${x} onClick=${a(()=>pe.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${x} onClick=${a(()=>pe.silence(!0),"Every device is silenced")}>Silence on<//>
        <${x} onClick=${a(()=>pe.silence(!1),"Every device may talk again")}>Silence off<//>
        <${x} kind="danger" onClick=${l}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${o} onInput=${c=>s(c.target.value)} onKeyDown=${c=>c.key==="Enter"&&r()} />
        <${x} onClick=${r}>Ping<//>
        <${x} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?i`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:i`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(c=>i`<tr key=${c.key}>
                    <td><${K} href=${"/devices/"+encodeURIComponent(c.name||c.key)}>${c.name||c.key}<//></td>
                    <td><code>${st(c.device_id)}</code></td>
                    <td>${c.type_name} <code>${st(c.device_type)}</code></td>
                    <td>${c.version}</td>
                    <td>${re(c.last_seen_minutes_ago)}</td>
                    <td>${c.uptime?re(Math.floor(c.uptime/60)):""}</td>
                    <td>${c.error?i`<span class="badge bad">error ${c.error}</span>`:c.last_seen_minutes_ago>10?i`<span class="badge warn">silent</span>`:i`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:i`<${R} error=${t} />`}
      ${t&&e&&i`<p class="error">${t.message}</p>`}
    <//>`}function On(){let e=B(et.get,5e3);return i`<${Zo} ...${e} /><${ea} ...${e} /><${ta} /><${oa} /><${aa} />`}function Zo({data:e,error:t}){return i`
    <${T} title="Gateway" aside=${i`<${x} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await C(et.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?i`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${an(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:i`<${R} error=${t} />`}
    <//>`}function ea({data:e,error:t}){if(!e)return i`<${T} title="Network"><${R} error=${t} /><//>`;let n=e.network;if(!n)return i`<${T} title="Network"><p>No Ethernet.</p><//>`;let o=a=>a.map(r=>i`<div>${r.address} <span class="muted">(${r.origin})</span></div>`),s={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return i`
    <${T} title="Network" aside=${i`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?o(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${s}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?i`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?o(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function ta(){let{data:e,error:t,reload:n}=B(tt.get),[o,s]=f({});if(!e)return i`<${R} error=${t} />`;let a=u=>u in o?o[u]:e[u],r=(u,c)=>d=>s({...o,[u]:c?+d.target.value:d.target.value}),l=async()=>{let u={...o};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return M("Nothing changed");let c=await C(()=>tt.update(u),"Saved");c&&(c.restart_required&&M("Restart the gateway to apply the hostname or bitrate."),s({}),n())};return i`
    <${T} title="Settings">
      <div class="row">
        <${k} label="Hostname"><input value=${a("hostname")} onInput=${r("hostname")} /><//>
        <${k} label="CAN bitrate"><select value=${a("can_bitrate")} onChange=${r("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>i`<option>${u}</option>`)}
        </select><//>
        <${k} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${a("update_delay_ms")} onInput=${r("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${k} label="User name"><input value=${a("web_username")} onInput=${r("web_username")} autocomplete="off" /><//>
        <${k} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${o.web_password||""} onInput=${r("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${x} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var na=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function oa(){let{data:e,error:t,reload:n}=B(nt.get),[o,s]=f({});if(!e)return i`<${T} title="Location and time"><${R} error=${t} /><//>`;let a=d=>d in o?o[d]:e[d]??"",r=d=>p=>s({...o,[d]:p.target.value}),l=async()=>{let d={};if(("latitude"in o||"longitude"in o)&&(d.latitude=parseFloat(a("latitude")),d.longitude=parseFloat(a("longitude")),Number.isNaN(d.latitude)||Number.isNaN(d.longitude)))return M("Latitude and longitude are numbers");if("timezone"in o&&(d.timezone=o.timezone.trim()),Object.keys(d).length===0)return M("Nothing changed");await C(()=>nt.update(d),"Saved")&&(s({}),n())},u=e.utc_offset_minutes,c=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return i`
    <${T} title="Location and time">
      <p class="muted">For switching by local time and by the sun.</p>
      <div class="row">
        <${k} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${a("latitude")} onInput=${r("latitude")} /><//>
        <${k} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${a("longitude")} onInput=${r("longitude")} /><//>
        <${k} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${a("timezone")} onInput=${r("timezone")} /><//>
      </div>
      <div class="buttons"><${x} kind="primary" onClick=${l}>Save<//></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${c})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?na.map(([d,p])=>i`<div><dt>${p}</dt><dd>${e.sun[d]||i`<span class="muted">not today</span>`}</dd></div>`):i`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function aa(){return i`
    <${T} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${Pe} target="gateway" label="Install and restart" />
    <//>`}var sa=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],ia={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},ra={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},oe=async(e,t)=>await C(e,t)!==void 0,ft=e=>e?new Date(e).toLocaleString():"\u2014";function _t({label:e,accept:t,send:n,success:o,after:s}){return i`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async r=>{let l=r.target.files[0];if(r.target.value="",!l)return;let u=await l.text();await oe(()=>n(u),o)&&s&&s()}} hidden /></label>`}function Nn(){let{data:e,error:t,reload:n}=B(G.get,1e4);return e?i`
    <${la} d=${e} />
    <${ca} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&i`<${ua} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&i`<${da} reload=${n} />`}
    ${e.mode==="est"&&i`<${pa} d=${e} reload=${n} />`}
    <${ma} d=${e} reload=${n} />
    <${$a} d=${e} reload=${n} />`:i`<${R} error=${t} />`}function vt({c:e}){return i`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${ft(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${ft(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&i`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function la({d:e}){let t=e.certificate,[n,o]=t?ia[t.status]||[t.status,"muted"]:["none","bad"];return i`
    <${T} title="Certificate" aside=${i`<span class=${"badge "+o}>${n}</span>`}>
      ${t?i`<${vt} c=${t} />
            <p class="muted">Made: ${ra[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:i`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&i`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&i`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function ca({d:e,reload:t}){let[n,o]=f(e.fqdn),[s,a]=f(e.mode),r=async()=>{let l={};if(n!==e.fqdn&&(l.fqdn=n.trim()),s!==e.mode&&(l.mode=s),Object.keys(l).length===0)return M("Nothing changed");await oe(()=>G.update(l),"Saved")&&t()};return i`
    <${T} title="HTTPS settings">
      <div class="row">
        <${k} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${l=>o(l.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${sa.map(([l,u,c])=>i`
        <label class="choice">
          <input type="radio" name="mode" value=${l} checked=${s===l} onChange=${()=>a(l)} />
          <span><strong>${u}</strong><small class="muted">${c}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${x} kind="primary" onClick=${r}>Save<//></div>
    <//>`}function ua({d:e,reload:t}){let[n,o]=f(e.validity_years);return i`
    <${T} title="Self-signed certificate">
      <div class="row">
        <${k} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${a=>o(+a.target.value)} /><//>
      </div>
      <div class="buttons"><${x} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await oe(()=>G.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function da({reload:e}){return i`
    <${T} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${G.csrUrl()} download="gateway.csr">Download CSR</a>
        <${_t} label="Upload certificate" send=${G.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function pa({d:e,reload:t}){let n=e.est,[o,s]=f(n.url),[a,r]=f(n.auto_renew),l=async()=>{await oe(()=>G.update({est_url:o.trim(),est_auto_renew:a}),"Saved")&&t()},u=async()=>{await oe(G.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return i`
    <${T} title="EST">
      <div class="row">
        <${k} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${o} onInput=${c=>s(c.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a} onChange=${c=>r(c.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?i`<span class="badge ok">installed</span>`:i`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&i` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${ft(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&i`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&i`<${vt} c=${n.identity} />`}
      <div class="buttons">
        <${_t} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${G.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&i`<${x} kind="danger" onClick=${async()=>await oe(G.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${x} kind="primary" onClick=${l}>Save<//>
        <${x} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function ma({d:e,reload:t}){let n=e.trust_anchor,o=async s=>{await oe(()=>G.update({built_in_roots:s}),s?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return i`
    <${T} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${s=>o(s.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?i`<${vt} c=${n} />${n.count>1&&i`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:i`<p>None installed.</p>`}
      <div class="buttons">
        <${_t} label=${n?"Replace":"Upload"} send=${G.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&i`<${x} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await oe(G.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function $a({d:e,reload:t}){let[n,o]=f(e.ntp_server),s=async()=>{await oe(()=>G.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return i`
    <${T} title="Time" aside=${i`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${k} label="NTP server"><input value=${n} placeholder="automatic" onInput=${a=>o(a.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&i`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?i` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${x} onClick=${s}>Save<//></div>
    <//>`}var ha={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Dn(){let{data:e,error:t,reload:n}=B(ie.all,5e3);return e?i`
    <${In} slot="primary" b=${e.primary} reload=${n} />
    <${In} slot="secondary" b=${e.secondary} reload=${n} />
    <${fa} on=${e.home_assistant} reload=${n} />`:i`<${R} error=${t} />`}function fa({on:e,reload:t}){return i`
    <${T} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async o=>{let s=o.target.checked;await C(()=>ie.updateAll({home_assistant:s}),s?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}var _a={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function In({slot:e,b:t,reload:n}){let[o,s]=f({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[a,r]=f(null),l=o.uri.startsWith("mqtts://"),u=p=>m=>s({...o,[p]:m.target.type==="checkbox"?m.target.checked:m.target.value}),c=async()=>{let p={uri:o.uri,user:o.user,enabled:o.enabled,tls_insecure:o.tls_insecure};o.password&&(p.password=o.password),await C(()=>ie.update(e,p),`${e} broker saved, reconnecting`)&&(s({...o,password:""}),setTimeout(n,2500))},d=async()=>{let p=await C(()=>ie.certificate(e));p&&r(p)};return i`
    <${T}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${i`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${ha[e]}</p>
      <div class="row">
        <${k} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${o.uri} onInput=${u("uri")} /><//>
        <${k} label="User"><input value=${o.user} onInput=${u("user")} autocomplete="off" /><//>
        <${k} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${o.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${o.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${l&&i`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${_a[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${o.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${x} onClick=${async()=>{await C(()=>ie.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),d()},4e3)}}>Trust the broker's certificate now<//>
            <${x} onClick=${d}>Show pinned certificate<//>
            ${t.certificate_pinned&&i`<${x} kind="danger" onClick=${async()=>{await C(()=>ie.forget(e),"Certificate forgotten"),r(null),n()}}>Forget<//>`}
          </div>
          ${a&&i`<p>${a.pinned?i`SHA-256 <code>${a.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${x} kind="primary" onClick=${c}>Save<//></div>
    <//>`}var va=[{path:"/",title:"Devices",page:An},{path:"/devices/:device",title:"Device",page:Ln},{path:"/sensors",title:"Sensors",page:Cn},{path:"/automation",title:"Automation",page:pt},{path:"/automation/:tab",title:"Automation",page:pt},{path:"/mqtt",title:"MQTT",page:Dn},{path:"/gateway",title:"Gateway",page:On},{path:"/https",title:"HTTPS",page:Nn}],ga=[["/","Devices"],["/sensors","Sensors"],["/automation","Automation"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function ba(){let e=Yt(),t=Zt(va,e),n=t?t.route.page:null,o=s=>s==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(s);return i`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${ga.map(([s,a])=>i`<${K} href=${s} class=${o(s)?"active":""}>${a}<//>`)}</nav>
    </header>
    <main>
      ${n?i`<${n} key=${e} ...${t.params} />`:i`<p class="error">No such page. <${K} href="/">Devices<//></p>`}
    </main>
    <${on} />`}Mt(i`<${ba} />`,document.getElementById("app"));
