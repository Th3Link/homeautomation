var Vt=Object.create;var Qe=Object.defineProperty;var Gt=Object.getOwnPropertyDescriptor;var Kt=Object.getOwnPropertyNames;var zt=Object.getPrototypeOf,Qt=Object.prototype.hasOwnProperty;var Jt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Xt=(e,t,n,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Kt(t))!Qt.call(e,o)&&o!==n&&Qe(e,o,{get:()=>t[o],enumerable:!(a=Gt(t,o))||a.enumerable});return e};var Yt=(e,t,n)=>(n=e!=null?Vt(zt(e)):{},Xt(t||!e||!e.__esModule?Qe(n,"default",{value:e,enumerable:!0}):n,e));var Ct=Jt(Le=>{var Tt;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Le=="object"?e(Le):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(Tt={}):e(Tt={})})(function(e){e.version="1.2.2";function t(){for(var f=0,I=new Array(256),h=0;h!=256;++h)f=h,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,I[h]=f;return typeof Int32Array<"u"?new Int32Array(I):I}var n=t();function a(f){var I=0,h=0,k=0,g=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(k=0;k!=256;++k)g[k]=f[k];for(k=0;k!=256;++k)for(h=f[k],I=256+k;I<4096;I+=256)h=g[I]=h>>>8^f[h&255];var A=[];for(k=1;k!=16;++k)A[k-1]=typeof Int32Array<"u"?g.subarray(k*256,k*256+256):g.slice(k*256,k*256+256);return A}var o=a(n),s=o[0],i=o[1],l=o[2],u=o[3],d=o[4],p=o[5],r=o[6],_=o[7],m=o[8],y=o[9],R=o[10],x=o[11],T=o[12],w=o[13],P=o[14];function D(f,I){for(var h=I^-1,k=0,g=f.length;k<g;)h=h>>>8^n[(h^f.charCodeAt(k++))&255];return~h}function V(f,I){for(var h=I^-1,k=f.length-15,g=0;g<k;)h=P[f[g++]^h&255]^w[f[g++]^h>>8&255]^T[f[g++]^h>>16&255]^x[f[g++]^h>>>24]^R[f[g++]]^y[f[g++]]^m[f[g++]]^_[f[g++]]^r[f[g++]]^p[f[g++]]^d[f[g++]]^u[f[g++]]^l[f[g++]]^i[f[g++]]^s[f[g++]]^n[f[g++]];for(k+=15;g<k;)h=h>>>8^n[(h^f[g++])&255];return~h}function W(f,I){for(var h=I^-1,k=0,g=f.length,A=0,Se=0;k<g;)A=f.charCodeAt(k++),A<128?h=h>>>8^n[(h^A)&255]:A<2048?(h=h>>>8^n[(h^(192|A>>6&31))&255],h=h>>>8^n[(h^(128|A&63))&255]):A>=55296&&A<57344?(A=(A&1023)+64,Se=f.charCodeAt(k++)&1023,h=h>>>8^n[(h^(240|A>>8&7))&255],h=h>>>8^n[(h^(128|A>>2&63))&255],h=h>>>8^n[(h^(128|Se>>6&15|(A&3)<<4))&255],h=h>>>8^n[(h^(128|Se&63))&255]):(h=h>>>8^n[(h^(224|A>>12&15))&255],h=h>>>8^n[(h^(128|A>>6&63))&255],h=h>>>8^n[(h^(128|A&63))&255]);return~h}e.table=n,e.bstr=D,e.buf=V,e.str=W})});var me,E,et,Zt,Q,Je,tt,nt,at,xe,Te,Ce,en,re={},st=[],tn=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,$e=Array.isArray;function G(e,t){for(var n in t)e[n]=t[n];return e}function Ee(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function le(e,t,n){var a,o,s,i={};for(s in t)s=="key"?a=t[s]:s=="ref"?o=t[s]:i[s]=t[s];if(arguments.length>2&&(i.children=arguments.length>3?me.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(s in e.defaultProps)i[s]===void 0&&(i[s]=e.defaultProps[s]);return _e(e,i,a,o,null)}function _e(e,t,n,a,o){var s={type:e,props:t,key:n,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++et,__i:-1,__u:0};return o==null&&E.vnode!=null&&E.vnode(s),s}function ve(e){return e.children}function fe(e,t){this.props=e,this.context=t}function ne(e,t){if(t==null)return e.__?ne(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?ne(e):null}function ot(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return ot(e)}}function Xe(e){(!e.__d&&(e.__d=!0)&&Q.push(e)&&!he.__r++||Je!=E.debounceRendering)&&((Je=E.debounceRendering)||tt)(he)}function he(){for(var e,t,n,a,o,s,i,l=1;Q.length;)Q.length>l&&Q.sort(nt),e=Q.shift(),l=Q.length,e.__d&&(n=void 0,o=(a=(t=e).__v).__e,s=[],i=[],t.__P&&((n=G({},a)).__v=a.__v+1,E.vnode&&E.vnode(n),Ae(t.__P,n,a,t.__n,t.__P.namespaceURI,32&a.__u?[o]:null,s,o??ne(a),!!(32&a.__u),i),n.__v=a.__v,n.__.__k[n.__i]=n,lt(s,n,i),n.__e!=o&&ot(n)));he.__r=0}function it(e,t,n,a,o,s,i,l,u,d,p){var r,_,m,y,R,x,T=a&&a.__k||st,w=t.length;for(u=nn(n,t,T,u,w),r=0;r<w;r++)(m=n.__k[r])!=null&&(_=m.__i==-1?re:T[m.__i]||re,m.__i=r,x=Ae(e,m,_,o,s,i,l,u,d,p),y=m.__e,m.ref&&_.ref!=m.ref&&(_.ref&&Re(_.ref,null,m),p.push(m.ref,m.__c||y,m)),R==null&&y!=null&&(R=y),4&m.__u||_.__k===m.__k?u=rt(m,u,e):typeof m.type=="function"&&x!==void 0?u=x:y&&(u=y.nextSibling),m.__u&=-7);return n.__e=R,u}function nn(e,t,n,a,o){var s,i,l,u,d,p=n.length,r=p,_=0;for(e.__k=new Array(o),s=0;s<o;s++)(i=t[s])!=null&&typeof i!="boolean"&&typeof i!="function"?(u=s+_,(i=e.__k[s]=typeof i=="string"||typeof i=="number"||typeof i=="bigint"||i.constructor==String?_e(null,i,null,null,null):$e(i)?_e(ve,{children:i},null,null,null):i.constructor==null&&i.__b>0?_e(i.type,i.props,i.key,i.ref?i.ref:null,i.__v):i).__=e,i.__b=e.__b+1,l=null,(d=i.__i=an(i,n,u,r))!=-1&&(r--,(l=n[d])&&(l.__u|=2)),l==null||l.__v==null?(d==-1&&(o>p?_--:o<p&&_++),typeof i.type!="function"&&(i.__u|=4)):d!=u&&(d==u-1?_--:d==u+1?_++:(d>u?_--:_++,i.__u|=4))):e.__k[s]=null;if(r)for(s=0;s<p;s++)(l=n[s])!=null&&(2&l.__u)==0&&(l.__e==a&&(a=ne(l)),dt(l,l));return a}function rt(e,t,n){var a,o;if(typeof e.type=="function"){for(a=e.__k,o=0;a&&o<a.length;o++)a[o]&&(a[o].__=e,t=rt(a[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=ne(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function an(e,t,n,a){var o,s,i=e.key,l=e.type,u=t[n];if(u===null&&e.key==null||u&&i==u.key&&l==u.type&&(2&u.__u)==0)return n;if(a>(u!=null&&(2&u.__u)==0?1:0))for(o=n-1,s=n+1;o>=0||s<t.length;){if(o>=0){if((u=t[o])&&(2&u.__u)==0&&i==u.key&&l==u.type)return o;o--}if(s<t.length){if((u=t[s])&&(2&u.__u)==0&&i==u.key&&l==u.type)return s;s++}}return-1}function Ye(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||tn.test(t)?n:n+"px"}function pe(e,t,n,a,o){var s,i;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof a=="string"&&(e.style.cssText=a=""),a)for(t in a)n&&t in n||Ye(e.style,t,"");if(n)for(t in n)a&&n[t]==a[t]||Ye(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")s=t!=(t=t.replace(at,"$1")),i=t.toLowerCase(),t=i in e||t=="onFocusOut"||t=="onFocusIn"?i.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+s]=n,n?a?n.u=a.u:(n.u=xe,e.addEventListener(t,s?Ce:Te,s)):e.removeEventListener(t,s?Ce:Te,s);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Ze(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=xe++;else if(t.t<n.u)return;return n(E.event?E.event(t):t)}}}function Ae(e,t,n,a,o,s,i,l,u,d){var p,r,_,m,y,R,x,T,w,P,D,V,W,f,I,h,k,g=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),s=[l=t.__e=n.__e]),(p=E.__b)&&p(t);e:if(typeof g=="function")try{if(T=t.props,w="prototype"in g&&g.prototype.render,P=(p=g.contextType)&&a[p.__c],D=p?P?P.props.value:p.__:a,n.__c?x=(r=t.__c=n.__c).__=r.__E:(w?t.__c=r=new g(T,D):(t.__c=r=new fe(T,D),r.constructor=g,r.render=on),P&&P.sub(r),r.props=T,r.state||(r.state={}),r.context=D,r.__n=a,_=r.__d=!0,r.__h=[],r._sb=[]),w&&r.__s==null&&(r.__s=r.state),w&&g.getDerivedStateFromProps!=null&&(r.__s==r.state&&(r.__s=G({},r.__s)),G(r.__s,g.getDerivedStateFromProps(T,r.__s))),m=r.props,y=r.state,r.__v=t,_)w&&g.getDerivedStateFromProps==null&&r.componentWillMount!=null&&r.componentWillMount(),w&&r.componentDidMount!=null&&r.__h.push(r.componentDidMount);else{if(w&&g.getDerivedStateFromProps==null&&T!==m&&r.componentWillReceiveProps!=null&&r.componentWillReceiveProps(T,D),!r.__e&&r.shouldComponentUpdate!=null&&r.shouldComponentUpdate(T,r.__s,D)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(r.props=T,r.state=r.__s,r.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(A){A&&(A.__=t)}),V=0;V<r._sb.length;V++)r.__h.push(r._sb[V]);r._sb=[],r.__h.length&&i.push(r);break e}r.componentWillUpdate!=null&&r.componentWillUpdate(T,r.__s,D),w&&r.componentDidUpdate!=null&&r.__h.push(function(){r.componentDidUpdate(m,y,R)})}if(r.context=D,r.props=T,r.__P=e,r.__e=!1,W=E.__r,f=0,w){for(r.state=r.__s,r.__d=!1,W&&W(t),p=r.render(r.props,r.state,r.context),I=0;I<r._sb.length;I++)r.__h.push(r._sb[I]);r._sb=[]}else do r.__d=!1,W&&W(t),p=r.render(r.props,r.state,r.context),r.state=r.__s;while(r.__d&&++f<25);r.state=r.__s,r.getChildContext!=null&&(a=G(G({},a),r.getChildContext())),w&&!_&&r.getSnapshotBeforeUpdate!=null&&(R=r.getSnapshotBeforeUpdate(m,y)),h=p,p!=null&&p.type===ve&&p.key==null&&(h=ct(p.props.children)),l=it(e,$e(h)?h:[h],t,n,a,o,s,i,l,u,d),r.base=t.__e,t.__u&=-161,r.__h.length&&i.push(r),x&&(r.__E=r.__=null)}catch(A){if(t.__v=null,u||s!=null)if(A.then){for(t.__u|=u?160:128;l&&l.nodeType==8&&l.nextSibling;)l=l.nextSibling;s[s.indexOf(l)]=null,t.__e=l}else for(k=s.length;k--;)Ee(s[k]);else t.__e=n.__e,t.__k=n.__k;E.__e(A,t,n)}else s==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):l=t.__e=sn(n.__e,t,n,a,o,s,i,u,d);return(p=E.diffed)&&p(t),128&t.__u?void 0:l}function lt(e,t,n){for(var a=0;a<n.length;a++)Re(n[a],n[++a],n[++a]);E.__c&&E.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(s){s.call(o)})}catch(s){E.__e(s,o.__v)}})}function ct(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:$e(e)?e.map(ct):G({},e)}function sn(e,t,n,a,o,s,i,l,u){var d,p,r,_,m,y,R,x=n.props,T=t.props,w=t.type;if(w=="svg"?o="http://www.w3.org/2000/svg":w=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),s!=null){for(d=0;d<s.length;d++)if((m=s[d])&&"setAttribute"in m==!!w&&(w?m.localName==w:m.nodeType==3)){e=m,s[d]=null;break}}if(e==null){if(w==null)return document.createTextNode(T);e=document.createElementNS(o,w,T.is&&T),l&&(E.__m&&E.__m(t,s),l=!1),s=null}if(w==null)x===T||l&&e.data==T||(e.data=T);else{if(s=s&&me.call(e.childNodes),x=n.props||re,!l&&s!=null)for(x={},d=0;d<e.attributes.length;d++)x[(m=e.attributes[d]).name]=m.value;for(d in x)if(m=x[d],d!="children"){if(d=="dangerouslySetInnerHTML")r=m;else if(!(d in T)){if(d=="value"&&"defaultValue"in T||d=="checked"&&"defaultChecked"in T)continue;pe(e,d,null,m,o)}}for(d in T)m=T[d],d=="children"?_=m:d=="dangerouslySetInnerHTML"?p=m:d=="value"?y=m:d=="checked"?R=m:l&&typeof m!="function"||x[d]===m||pe(e,d,m,x[d],o);if(p)l||r&&(p.__html==r.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(r&&(e.innerHTML=""),it(t.type=="template"?e.content:e,$e(_)?_:[_],t,n,a,w=="foreignObject"?"http://www.w3.org/1999/xhtml":o,s,i,s?s[0]:n.__k&&ne(n,0),l,u),s!=null)for(d=s.length;d--;)Ee(s[d]);l||(d="value",w=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[d]||w=="progress"&&!y||w=="option"&&y!=x[d])&&pe(e,d,y,x[d],o),d="checked",R!=null&&R!=e[d]&&pe(e,d,R,x[d],o))}return e}function Re(e,t,n){try{if(typeof e=="function"){var a=typeof e.__u=="function";a&&e.__u(),a&&t==null||(e.__u=e(t))}else e.current=t}catch(o){E.__e(o,n)}}function dt(e,t,n){var a,o;if(E.unmount&&E.unmount(e),(a=e.ref)&&(a.current&&a.current!=e.__e||Re(a,null,t)),(a=e.__c)!=null){if(a.componentWillUnmount)try{a.componentWillUnmount()}catch(s){E.__e(s,t)}a.base=a.__P=null}if(a=e.__k)for(o=0;o<a.length;o++)a[o]&&dt(a[o],t,n||typeof e.type!="function");n||Ee(e.__e),e.__c=e.__=e.__e=void 0}function on(e,t,n){return this.constructor(e,n)}function ut(e,t,n){var a,o,s,i;t==document&&(t=document.documentElement),E.__&&E.__(e,t),o=(a=typeof n=="function")?null:n&&n.__k||t.__k,s=[],i=[],Ae(t,e=(!a&&n||t).__k=le(ve,null,[e]),o||re,re,t.namespaceURI,!a&&n?[n]:o?null:t.firstChild?me.call(t.childNodes):null,s,!a&&n?n:o?o.__e:t.firstChild,a,i),lt(s,e,i)}me=st.slice,E={__e:function(e,t,n,a){for(var o,s,i;t=t.__;)if((o=t.__c)&&!o.__)try{if((s=o.constructor)&&s.getDerivedStateFromError!=null&&(o.setState(s.getDerivedStateFromError(e)),i=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,a||{}),i=o.__d),i)return o.__E=o}catch(l){e=l}throw e}},et=0,Zt=function(e){return e!=null&&e.constructor==null},fe.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=G({},this.state),typeof e=="function"&&(e=e(G({},n),this.props)),e&&G(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),Xe(this))},fe.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),Xe(this))},fe.prototype.render=ve,Q=[],tt=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,nt=function(e,t){return e.__v.__b-t.__v.__b},he.__r=0,at=/(PointerCapture)$|Capture$/i,xe=0,Te=Ze(!1),Ce=Ze(!0),en=0;var ce,F,Fe,pt,de=0,yt=[],N=E,_t=N.__b,ft=N.__r,ht=N.diffed,mt=N.__c,$t=N.unmount,vt=N.__;function Ie(e,t){N.__h&&N.__h(F,e,de||t),de=0;var n=F.__H||(F.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function v(e){return de=1,rn(St,e)}function rn(e,t,n){var a=Ie(ce++,2);if(a.t=e,!a.__c&&(a.__=[n?n(t):St(void 0,t),function(l){var u=a.__N?a.__N[0]:a.__[0],d=a.t(u,l);u!==d&&(a.__N=[d,a.__[1]],a.__c.setState({}))}],a.__c=F,!F.__f)){var o=function(l,u,d){if(!a.__c.__H)return!0;var p=a.__c.__H.__.filter(function(_){return!!_.__c});if(p.every(function(_){return!_.__N}))return!s||s.call(this,l,u,d);var r=a.__c.props!==l;return p.forEach(function(_){if(_.__N){var m=_.__[0];_.__=_.__N,_.__N=void 0,m!==_.__[0]&&(r=!0)}}),s&&s.call(this,l,u,d)||r};F.__f=!0;var s=F.shouldComponentUpdate,i=F.componentWillUpdate;F.componentWillUpdate=function(l,u,d){if(this.__e){var p=s;s=void 0,o(l,u,d),s=p}i&&i.call(this,l,u,d)},F.shouldComponentUpdate=o}return a.__N||a.__}function J(e,t){var n=Ie(ce++,3);!N.__s&&kt(n.__H,t)&&(n.__=e,n.u=t,F.__H.__h.push(n))}function ye(e){return de=5,wt(function(){return{current:e}},[])}function wt(e,t){var n=Ie(ce++,7);return kt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function bt(e,t){return de=8,wt(function(){return e},t)}function ln(){for(var e;e=yt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ge),e.__H.__h.forEach(Ne),e.__H.__h=[]}catch(t){e.__H.__h=[],N.__e(t,e.__v)}}N.__b=function(e){F=null,_t&&_t(e)},N.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),vt&&vt(e,t)},N.__r=function(e){ft&&ft(e),ce=0;var t=(F=e.__c).__H;t&&(Fe===F?(t.__h=[],F.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ge),t.__h.forEach(Ne),t.__h=[],ce=0)),Fe=F},N.diffed=function(e){ht&&ht(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(yt.push(t)!==1&&pt===N.requestAnimationFrame||((pt=N.requestAnimationFrame)||cn)(ln)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Fe=F=null},N.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ge),n.__h=n.__h.filter(function(a){return!a.__||Ne(a)})}catch(a){t.some(function(o){o.__h&&(o.__h=[])}),t=[],N.__e(a,n.__v)}}),mt&&mt(e,t)},N.unmount=function(e){$t&&$t(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(a){try{ge(a)}catch(o){t=o}}),n.__H=void 0,t&&N.__e(t,n.__v))};var gt=typeof requestAnimationFrame=="function";function cn(e){var t,n=function(){clearTimeout(a),gt&&cancelAnimationFrame(t),setTimeout(e)},a=setTimeout(n,35);gt&&(t=requestAnimationFrame(n))}function ge(e){var t=F,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),F=t}function Ne(e){var t=F;e.__c=e.__(),F=t}function kt(e,t){return!e||e.length!==t.length||t.some(function(n,a){return n!==e[a]})}function St(e,t){return typeof t=="function"?t(e):t}var xt=Yt(Ct()),Me="/api/v1",ae=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},dn=e=>new Promise(t=>setTimeout(t,e));async function ue(e,t,n){let a=typeof n=="string";for(let o=1;;o++){let s;try{s=await fetch(Me+t,{method:e,headers:n===void 0?{}:{"Content-Type":a?"application/x-pem-file":"application/json"},body:n===void 0?void 0:a?n:JSON.stringify(n)})}catch{if(o>=4)throw new ae(0,{message:"gateway unreachable"});await dn(250*o);continue}let i=await s.text(),l=null;try{l=i?JSON.parse(i):null}catch{l={message:i}}if(!s.ok)throw new ae(s.status,l);return l}}var B=e=>ue("GET",e),K=(e,t)=>ue("POST",e,t),j=(e,t)=>ue("PUT",e,t),se=(e,t)=>ue("PATCH",e,t),He=e=>ue("DELETE",e),q=encodeURIComponent,Pe={get:()=>B("/system"),restart:()=>K("/system/restart")},De={get:()=>B("/config"),update:e=>se("/config",e)},Ue={get:()=>B("/location"),update:e=>se("/location",e)},X={all:()=>B("/mqtt"),updateAll:e=>se("/mqtt",e),update:(e,t)=>se(`/mqtt/${e}`,t),trust:e=>K(`/mqtt/${e}/trust`),certificate:e=>B(`/mqtt/${e}/certificate`),forget:e=>He(`/mqtt/${e}/certificate`)},O={get:()=>B("/tls"),update:e=>se("/tls",e),selfSigned:e=>K("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${Me}/tls/csr`,installCertificate:e=>j("/tls/certificate",e),setTrustAnchor:e=>j("/tls/trust-anchor",e),removeTrustAnchor:()=>He("/tls/trust-anchor"),setIdentity:e=>j("/tls/est/identity",e),removeIdentity:()=>He("/tls/est/identity"),enroll:()=>K("/tls/est/enroll")},L={async list(){let e=[];for(;;){let t=await B(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>B(`/devices/${q(e)}`),update:(e,t)=>se(`/devices/${q(e)}`,t),action:(e,t)=>K(`/devices/${q(e)}/${t}`),silence:(e,t)=>j(`/devices/${q(e)}/silence`,{on:t}),relay:(e,t,n,a)=>j(`/devices/${q(e)}/relays/${t}`,{state:n,duration_ms:a}),rollershutter:(e,t,n,a)=>j(`/devices/${q(e)}/rollershutters/${t}`,{state:n,duration_ms:a}),lamps:(e,t,n,a)=>j(`/devices/${q(e)}/lamps/${t}`,{value:n,bitmask:a}),heating:(e,t,n)=>j(`/devices/${q(e)}/heating/${t}`,n),heatingManualState:e=>B(`/devices/${q(e)}/heating/manual`),heatingManual:(e,t,n,a)=>j(`/devices/${q(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:a})},Y={update:(e,t,n)=>j(`/devices/${q(e)}/sensors/${t}`,n),refresh:e=>K(`/devices/${q(e)}/sensors/refresh`),forget:e=>K(`/devices/${q(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${q(e)}`:"",a=await B(`/sensors?offset=${t.length}${n}`);if(t.push(...a.sensors),a.sensors.length===0||t.length>=a.total)return t}}},oe={action:e=>K(`/bus/${e}`),silence:e=>j("/bus/silence",{on:e}),typeAction:(e,t)=>K(`/device-types/${e}/${t}`)},qe={job:()=>B("/firmware/job"),upload(e,t,n){let a=xt.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((s,i)=>{let l=new XMLHttpRequest;l.open("PUT",`${Me}${o}?crc32=${a}`),l.setRequestHeader("Content-Type","application/octet-stream"),l.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),l.onload=()=>{let u=null;try{u=JSON.parse(l.responseText)}catch{}l.status>=200&&l.status<300?s(u):i(new ae(l.status,u))},l.onerror=()=>i(new ae(0,{message:"upload failed"})),l.send(t)})}};var At=function(e,t,n,a){var o;t[0]=0;for(var s=1;s<t.length;s++){var i=t[s++],l=t[s]?(t[0]|=i?1:2,n[t[s++]]):t[++s];i===3?a[0]=l:i===4?a[1]=Object.assign(a[1]||{},l):i===5?(a[1]=a[1]||{})[t[++s]]=l:i===6?a[1][t[++s]]+=l+"":i?(o=e.apply(l,At(e,l,n,["",null])),a.push(o),l[0]?t[0]|=2:(t[s-2]=0,t[s]=o)):a.push(l)}return a},Et=new Map;function Rt(e){var t=Et.get(this);return t||(t=new Map,Et.set(this,t)),(t=At(this,t.get(e)||(t.set(e,t=function(n){for(var a,o,s=1,i="",l="",u=[0],d=function(_){s===1&&(_||(i=i.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,_,i):s===3&&(_||i)?(u.push(3,_,i),s=2):s===2&&i==="..."&&_?u.push(4,_,0):s===2&&i&&!_?u.push(5,0,!0,i):s>=5&&((i||!_&&s===5)&&(u.push(s,0,i,o),s=6),_&&(u.push(s,_,0,o),s=6)),i=""},p=0;p<n.length;p++){p&&(s===1&&d(),d(p));for(var r=0;r<n[p].length;r++)a=n[p][r],s===1?a==="<"?(d(),u=[u],s=3):i+=a:s===4?i==="--"&&a===">"?(s=1,i=""):i=a+i[0]:l?a===l?l="":i+=a:a==='"'||a==="'"?l=a:a===">"?(d(),s=1):s&&(a==="="?(s=5,o=i,i=""):a==="/"&&(s<5||n[p][r+1]===">")?(d(),s===3&&(u=u[0]),s=u,(u=u[0]).push(2,0,s),s=0):a===" "||a==="	"||a===`
`||a==="\r"?(d(),s=2):i+=a),s===3&&i==="!--"&&(s=4,u=u[0])}return d(),u}(e)),t),arguments,[])).length>1?t:t[0]}var c=Rt.bind(le),Oe=()=>{};function U(e,t="ok"){Oe(e,t)}function Ft(){let[e,t]=v([]);return J(()=>{let n=0;return Oe=(a,o)=>{let s={id:++n,message:a,kind:o};t(i=>[...i,s]),setTimeout(()=>t(i=>i.filter(l=>l!==s)),o==="error"?8e3:3e3)},()=>Oe=()=>{}},[]),c`<div class="toasts">
    ${e.map(n=>c`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function S(e,t){try{let n=await e();return t&&U(t),n}catch(n){U(n.message,"error");return}}function H(e,t){let[n,a]=v({data:void 0,error:void 0}),o=ye(e);o.current=e;let s=bt(async()=>{try{a({data:await o.current(),error:void 0})}catch(i){a(l=>({data:l.data,error:i}))}},[]);return J(()=>{let i=!1,l,u=async()=>{await s(),t&&!i&&(l=setTimeout(u,t))};return u(),()=>{i=!0,clearTimeout(l)}},[t,s]),{...n,reload:s}}var b=({title:e,children:t,aside:n})=>c`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,M=({error:e})=>e?c`<p class="error">${e.message}</p>`:c`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>c`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&c`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:a})=>{let[o,s]=v(!1);return c`<button class=${t||""} disabled=${a||o} onClick=${async l=>{s(!0);try{await n(l)}finally{s(!1)}}}>${e}</button>`},We=e=>"0x"+e.toString(16).padStart(2,"0");function ee(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function Nt(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),a=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${a} min`:`${a} min`}function we({target:e,label:t,others:n=[],onDone:a}){let[o,s]=v(null),[i,l]=v(null),[u,d]=v(""),[p,r]=v(null),_=ye(null);J(()=>()=>clearInterval(_.current),[]);let m=()=>{clearInterval(_.current),_.current=setInterval(async()=>{try{r(await qe.job())}catch{}},1500)},y=async(w,P)=>{d(w),l(0),P!=="gateway"&&m();try{let D=await o.arrayBuffer();return await qe.upload(P,D,l)||{}}finally{clearInterval(_.current),l(null)}},R=async w=>{if(!o)return;let P=0;for(let{name:D,target:V}of w)try{let W=await y(D,V);P+=1,W.restarting&&U("Firmware installed, the gateway restarts\u2026")}catch(W){U(`${D}: ${W.message}`,"error");break}P===w.length&&w[0].target!=="gateway"&&U(P===1?"Firmware sent; the device restarts into it":`Firmware sent to ${P} devices`),d(""),r(null),a&&a()},x=i!==null,T=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return c`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>s(w.target.files[0]||null)} />
      <${$} onClick=${()=>R([{name:t||"device",target:e}])} disabled=${!o||x}>${t||"Upload"}<//>
      ${n.length>0&&c`<${$} onClick=${()=>R([{name:"this device",target:e},...n])} disabled=${!o||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&c`<progress max="1" value=${i}></progress>`}
      ${x&&c`<p class="muted wide">${u}${T?" \u2014 "+T:""}</p>`}
    </div>`}var be=new Set;function un(e){e!==location.pathname&&history.pushState(null,"",e),be.forEach(t=>t())}addEventListener("popstate",()=>be.forEach(e=>e()));function It(){let[e,t]=v(location.pathname);return J(()=>{let n=()=>t(location.pathname);return be.add(n),()=>be.delete(n)},[]),e}function Lt(e,t){let n=t.split("/").filter(Boolean);for(let a of e){let o=a.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let s={};if(o.every((l,u)=>l.startsWith(":")?(s[l.slice(1)]=decodeURIComponent(n[u]),!0):l===n[u]))return{route:a,params:s}}return null}function te({href:e,children:t,...n}){return le("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),un(e))},...n},t)}var pn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082 equivalent",voc:"VOC",air_quality:"Air quality",co2_measured:"CO\u2082",gas_resistance:"Gas resistance",brightness:"Brightness"},Ht={temperature:2,humidity:1,pressure:1,co2:0,voc:2,air_quality:0,co2_measured:0,gas_resistance:1},je=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],_n={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},ie=e=>_n[e]||e;function ke(e,t=5e3){let n=H(()=>Y.list(e),t),a=[...new Set((n.data||[]).map(s=>s.device))];return{...n,ask:async()=>{for(let s of e?[e]:a)await S(()=>Y.refresh(s));setTimeout(n.reload,1500)}}}function fn({s:e,device:t,reload:n}){let[a,o]=v(!1),[s,i]=v(e.name||""),[l,u]=v(e.role||"none"),d=async()=>{let p={};if(s!==(e.name||"")&&(p.name=s),l!==(e.role||"none")&&(p.role=l),Object.keys(p).length===0)return o(!1);await S(()=>Y.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return c`<tr>
    ${!t&&c`<td><${te} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${a?c`<input class="inline" maxlength="7" placeholder="name" value=${s} onInput=${p=>i(p.target.value)} />`:e.name||c`<span class="muted">–</span>`}</td>
    <td>${pn[e.kind]||e.kind}</td>
    <td>${a?c`<select value=${l} onChange=${p=>u(p.target.value)}>${je.map(p=>c`<option value=${p}>${ie(p)}</option>`)}</select>`:e.role&&e.role!=="none"?ie(e.role):c`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&c` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?c`<span class="badge bad">lost</span>`:`${e.kind in Ht?e.value.toFixed(Ht[e.kind]):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ee(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":a?c`<${$} kind="primary" onClick=${d}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:c`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function Be({device:e}){let{data:t,error:n,reload:a,ask:o}=ke(e);if(!t)return c`<${M} error=${n} />`;if(t.length===0)return c`<p class="muted">No sensor reading seen yet.</p>`;let s=t.some(i=>i.named_by_node&&i.slot===null);return c`
    ${s&&c`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&c`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(i=>c`<${fn} key=${i.device_key+i.kind+i.sensor_id} s=${i} device=${e} reload=${a} />`)}
      </tbody>
    </table></div>`}function Mt(){let{ask:e}=ke(void 0,0);return c`<${b} title="Sensors" aside=${c`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${Be} />
  <//>`}var hn=[2,5,8,9],mn=[7],$n=[3],vn=3,Ve=[9],gn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],yn=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ut({device:e}){let{data:t,error:n,reload:a}=H(()=>L.get(e),5e3);return t?c`
    <${bn} d=${t} reload=${a} />
    ${hn.includes(t.device_type)&&c`<${Pt} d=${t} kind="relay" />`}
    ${mn.includes(t.device_type)&&c`<${Pt} d=${t} kind="rollershutter" />`}
    ${$n.includes(t.device_type)&&c`<${Dt} d=${t} />`}
    ${t.device_type===4&&t.extension_mode===vn&&c`<${Dt} d=${t} firstBank=${1} />`}
    ${Ve.includes(t.device_type)&&c`<${kn} d=${t} />`}
    ${Ve.includes(t.device_type)&&c`<${Tn} d=${t} />`}
    ${Ve.includes(t.device_type)&&c`<${Cn} d=${t} />`}
    <${b} title="Sensors"><${Be} device=${t.name||t.key} /><//>
    <${xn} d=${t} reload=${a} />
    <${wn} d=${t} />`:c`<${M} error=${n} />`}function wn({d:e}){let t=e.name||e.key,{data:n}=H(L.list),a=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return c`
    <${b} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${we} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${a} />
    <//>`}function bn({d:e,reload:t}){let n=e.name||e.key,a=(o,s)=>async()=>{await S(()=>L.action(n,o),s),setTimeout(t,1500)};return c`
    <${b} title=${n}
      aside=${c`<span class="buttons">
        <${$} onClick=${a("ping","Ping sent")}>Ping<//>
        <${$} onClick=${a("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${a("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ee(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Pt({d:e,kind:t}){let n=e.name||e.key,[a,o]=v(1),[s,i]=v(0),l=t==="rollershutter",u=d=>()=>S(()=>L[t](n,a,d,Math.round(s*1e3)),`${l?"Rollershutter":"Relay"} ${a}: ${d}`);return c`
    <${b} title=${l?"Rollershutter":"Relays"}>
      ${e.device_type===9&&c`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${a} onInput=${d=>o(+d.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${s} onInput=${d=>i(+d.target.value)} /><//>
      </div>
      <div class="buttons">
        ${l?c`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:c`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function Dt({d:e,firstBank:t=0}){let n=e.name||e.key,[a,o]=v(t),[s,i]=v(255),[l,u]=v(Array(24).fill(!1)),d=l.reduce((p,r,_)=>r?p|1<<23-_:p,0);return c`
    <${b} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min=${t} max="255" value=${a} onInput=${p=>o(+p.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${s} onInput=${p=>i(+p.target.value)} /><//>
      </div>
      <div class="lamps">
        ${l.map((p,r)=>c`<label key=${r} class=${"lamp"+(p?" on":"")}>
            <input type="checkbox" checked=${p} onChange=${()=>u(l.map((_,m)=>m===r?!_:_))} />${23-r}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>S(()=>L.lamps(n,a,s,d),"Lamps set")}>Send<//>
    <//>`}function kn({d:e}){let t=e.name||e.key,[n,a]=v(45),[o,s]=v(!1),[i,l]=v(0),[u,d]=v(!1),[p,r]=v(0),[_,m]=v(55);return c`
    <${b} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>a(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${y=>s(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>S(()=>L.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${i} onInput=${y=>l(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${y=>d(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>S(()=>L.heating(t,"energy",{power_w:i,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>r(+y.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${_} onInput=${y=>m(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>S(()=>L.heating(t,"emergency",{stage:p,tank_c:_}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var Sn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function Tn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o,ask:s}=ke(t);if(!n)return c`<${b} title="Sensor assignment"><${M} error=${a} /><//>`;let i=n.filter(r=>r.kind==="temperature"),l=r=>i.find(_=>_.role===r),u=r=>r.name?`${r.name} (${r.sensor_id})`:r.sensor_id,d=i.every(r=>r.slot!==null),p=r=>async _=>{let m=_.target.value,y;if(m===""){let R=l(r);if(!R)return;y=await S(()=>Y.update(t,R.slot,{role:"none"}),`${ie(r)} cleared`)}else{let R=i.find(x=>x.sensor_id===m);y=await S(()=>Y.update(t,R.slot,{role:r}),`${u(R)} is ${ie(r)} now`)}y&&setTimeout(o,1500)};return c`
    <${b} title="Sensor assignment" aside=${c`<${$} onClick=${s}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!d&&c`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${je.filter(r=>r!=="none").map(r=>c`<label key=${r} class="field">
            <span>${ie(r)}</span>
            <select value=${(l(r)||{}).sensor_id||""} onChange=${p(r)} disabled=${!d}>
              <option value="">(none)</option>
              ${i.map(_=>c`<option value=${_.sensor_id}>${u(_)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function Cn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o}=H(()=>L.heatingManualState(t),3e3),s=!!(n&&n.enabled),i=p=>!!(n&&n.relays.includes(p)),l=async()=>{let p=!s;await S(()=>L.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},u=p=>async()=>{await S(()=>L.heatingManual(t,!0,p,!i(p)),`Relay ${p} ${i(p)?"off":"on"}`)&&setTimeout(o,800)},d=p=>p===8&&i(9)||p===9&&i(8);return c`
    <${b} title="Manual mode"
      aside=${c`<${$} kind=${s?"danger":""} disabled=${!n} onClick=${l}>${s?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${a&&c`<p class="error">The controller does not answer: ${a.message}</p>`}
      ${s&&c`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${Sn.map(([p,r])=>c`<button key=${p} class=${i(p)?"primary":""} disabled=${!s||d(p)} onClick=${u(p)}>
            <span>${r}</span><small>relay ${p}: ${i(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function xn({d:e,reload:t}){let n=e.name||e.key,[a,o]=v({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[s,i]=v(!1),l=d=>p=>o({...a,[d]:p.target.value}),u=async()=>{let d={};if(a.custom_string!==e.name&&(d.custom_string=a.custom_string),+a.hwrev!==e.hwrev&&(d.hwrev=+a.hwrev),a.relais_mode&&(d.relais_mode=a.relais_mode),a.extension_mode&&(d.extension_mode=a.extension_mode),Object.keys(d).length===0)return U("Nothing changed");await S(()=>L.update(n,d),"Settings sent")&&setTimeout(t,1500)};return c`
    <${b} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${a.custom_string} onInput=${l("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${a.hwrev} onInput=${l("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${a.relais_mode} onChange=${l("relais_mode")}>
          <option value="">(unchanged)</option>${gn.map(d=>c`<option>${d}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${a.extension_mode} onChange=${l("extension_mode")}>
          <option value="">(unchanged)</option>${yn.map(d=>c`<option>${d}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await S(()=>L.silence(n,!s),s?"Device may talk again":"Device silenced"),i(!s)}}>${s?"End silence":"Silence"}<//>
        <${$} onClick=${()=>S(()=>L.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function qt(){let{data:e,error:t,reload:n}=H(L.list,5e3),[a,o]=v(""),s=(d,p)=>async()=>{await S(d,p),setTimeout(n,1500)},i=async()=>{let d=a.trim();d&&await S(()=>L.action(d,"ping"),`Ping sent to ${d}`)},l=async()=>{confirm("Restart every device on the bus?")&&await s(()=>oe.action("restart"),"Restart sent to every device")()},u=s(()=>oe.action("discover"),"Scanning: every device was asked to announce itself");return c`
    <${b} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${s(()=>oe.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${s(()=>oe.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${s(()=>oe.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${l}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${a} onInput=${d=>o(d.target.value)} onKeyDown=${d=>d.key==="Enter"&&i()} />
        <${$} onClick=${i}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?c`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:c`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(d=>c`<tr key=${d.key}>
                    <td><${te} href=${"/devices/"+encodeURIComponent(d.name||d.key)}>${d.name||d.key}<//></td>
                    <td><code>${We(d.device_id)}</code></td>
                    <td>${d.type_name} <code>${We(d.device_type)}</code></td>
                    <td>${d.version}</td>
                    <td>${ee(d.last_seen_minutes_ago)}</td>
                    <td>${d.uptime?ee(Math.floor(d.uptime/60)):""}</td>
                    <td>${d.error?c`<span class="badge bad">error ${d.error}</span>`:d.last_seen_minutes_ago>10?c`<span class="badge warn">silent</span>`:c`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:c`<${M} error=${t} />`}
      ${t&&e&&c`<p class="error">${t.message}</p>`}
    <//>`}function Ot(){let e=H(Pe.get,5e3);return c`<${En} ...${e} /><${An} ...${e} /><${Rn} /><${Nn} /><${In} />`}function En({data:e,error:t}){return c`
    <${b} title="Gateway" aside=${c`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await S(Pe.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?c`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${Nt(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:c`<${M} error=${t} />`}
    <//>`}function An({data:e,error:t}){if(!e)return c`<${b} title="Network"><${M} error=${t} /><//>`;let n=e.network;if(!n)return c`<${b} title="Network"><p>No Ethernet.</p><//>`;let a=s=>s.map(i=>c`<div>${i.address} <span class="muted">(${i.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return c`
    <${b} title="Network" aside=${c`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?a(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?c`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?a(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function Rn(){let{data:e,error:t,reload:n}=H(De.get),[a,o]=v({});if(!e)return c`<${M} error=${t} />`;let s=u=>u in a?a[u]:e[u],i=(u,d)=>p=>o({...a,[u]:d?+p.target.value:p.target.value}),l=async()=>{let u={...a};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return U("Nothing changed");let d=await S(()=>De.update(u),"Saved");d&&(d.restart_required&&U("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return c`
    <${b} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${s("hostname")} onInput=${i("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${s("can_bitrate")} onChange=${i("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>c`<option>${u}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${s("update_delay_ms")} onInput=${i("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${s("web_username")} onInput=${i("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${a.web_password||""} onInput=${i("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var Fn=[["astronomical_dawn","Astronomical dawn"],["nautical_dawn","Nautical dawn"],["civil_dawn","Civil dawn"],["sunrise","Sunrise"],["noon","Solar noon"],["sunset","Sunset"],["civil_dusk","Civil dusk"],["nautical_dusk","Nautical dusk"],["astronomical_dusk","Astronomical dusk"]];function Nn(){let{data:e,error:t,reload:n}=H(Ue.get),[a,o]=v({});if(!e)return c`<${b} title="Location and time"><${M} error=${t} /><//>`;let s=p=>p in a?a[p]:e[p]??"",i=p=>r=>o({...a,[p]:r.target.value}),l=async()=>{let p={};if(("latitude"in a||"longitude"in a)&&(p.latitude=parseFloat(s("latitude")),p.longitude=parseFloat(s("longitude")),Number.isNaN(p.latitude)||Number.isNaN(p.longitude)))return U("Latitude and longitude are numbers");if("timezone"in a&&(p.timezone=a.timezone.trim()),Object.keys(p).length===0)return U("Nothing changed");await S(()=>Ue.update(p),"Saved")&&(o({}),n())},u=e.utc_offset_minutes,d=u==null?"":`UTC${u<0?"\u2212":"+"}${Math.floor(Math.abs(u)/60)}${Math.abs(u)%60?":"+String(Math.abs(u)%60).padStart(2,"0"):""}`;return c`
    <${b} title="Location and time">
      <p class="muted">For switching by local time and by the sun.</p>
      <div class="row">
        <${C} label="Latitude" hint="degrees, north positive"><input inputmode="decimal" value=${s("latitude")} onInput=${i("latitude")} /><//>
        <${C} label="Longitude" hint="degrees, east positive"><input inputmode="decimal" value=${s("longitude")} onInput=${i("longitude")} /><//>
        <${C} label="Time zone" hint="POSIX TZ, e.g. CET-1CEST,M3.5.0,M10.5.0/3"><input value=${s("timezone")} onInput=${i("timezone")} /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
      <dl class="facts">
        <div><dt>Local time</dt><dd>${e.local_time?`${e.local_time.replace("T"," ")} (${d})`:"not known yet (no time server answer)"}</dd></div>
        ${e.sun?Fn.map(([p,r])=>c`<div><dt>${r}</dt><dd>${e.sun[p]||c`<span class="muted">not today</span>`}</dd></div>`):c`<div><dt>Sun times</dt><dd class="muted">${e.latitude==null?"set the location first":"once the time is known"}</dd></div>`}
      </dl>
    <//>`}function In(){return c`
    <${b} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${we} target="gateway" label="Install and restart" />
    <//>`}var Ln=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],Hn={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},Mn={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},z=async(e,t)=>await S(e,t)!==void 0,Ge=e=>e?new Date(e).toLocaleString():"\u2014";function Ke({label:e,accept:t,send:n,success:a,after:o}){return c`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async i=>{let l=i.target.files[0];if(i.target.value="",!l)return;let u=await l.text();await z(()=>n(u),a)&&o&&o()}} hidden /></label>`}function Wt(){let{data:e,error:t,reload:n}=H(O.get,1e4);return e?c`
    <${Pn} d=${e} />
    <${Dn} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&c`<${Un} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&c`<${qn} reload=${n} />`}
    ${e.mode==="est"&&c`<${On} d=${e} reload=${n} />`}
    <${Wn} d=${e} reload=${n} />
    <${jn} d=${e} reload=${n} />`:c`<${M} error=${t} />`}function ze({c:e}){return c`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Ge(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Ge(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&c`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function Pn({d:e}){let t=e.certificate,[n,a]=t?Hn[t.status]||[t.status,"muted"]:["none","bad"];return c`
    <${b} title="Certificate" aside=${c`<span class=${"badge "+a}>${n}</span>`}>
      ${t?c`<${ze} c=${t} />
            <p class="muted">Made: ${Mn[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:c`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${e.key_pin_sha256&&c`<dl class="facts">
        <div><dt>Key pin</dt><dd><code>${e.key_pin_sha256}</code></dd></div>
      </dl>
      <p class="muted">The pin-sha256 (RFC 7469) of the gateway's own key, the same for every certificate and CSR. An EST server that registers clients by their key wants this.</p>`}
      ${!e.https&&c`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function Dn({d:e,reload:t}){let[n,a]=v(e.fqdn),[o,s]=v(e.mode),i=async()=>{let l={};if(n!==e.fqdn&&(l.fqdn=n.trim()),o!==e.mode&&(l.mode=o),Object.keys(l).length===0)return U("Nothing changed");await z(()=>O.update(l),"Saved")&&t()};return c`
    <${b} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${l=>a(l.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${Ln.map(([l,u,d])=>c`
        <label class="choice">
          <input type="radio" name="mode" value=${l} checked=${o===l} onChange=${()=>s(l)} />
          <span><strong>${u}</strong><small class="muted">${d}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${$} kind="primary" onClick=${i}>Save<//></div>
    <//>`}function Un({d:e,reload:t}){let[n,a]=v(e.validity_years);return c`
    <${b} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${s=>a(+s.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await z(()=>O.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function qn({reload:e}){return c`
    <${b} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${O.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Ke} label="Upload certificate" send=${O.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function On({d:e,reload:t}){let n=e.est,[a,o]=v(n.url),[s,i]=v(n.auto_renew),l=async()=>{await z(()=>O.update({est_url:a.trim(),est_auto_renew:s}),"Saved")&&t()},u=async()=>{await z(O.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return c`
    <${b} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${a} onInput=${d=>o(d.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${s} onChange=${d=>i(d.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?c`<span class="badge ok">installed</span>`:c`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&c` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Ge(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&c`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&c`<${ze} c=${n.identity} />`}
      <div class="buttons">
        <${Ke} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${O.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&c`<${$} kind="danger" onClick=${async()=>await z(O.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${l}>Save<//>
        <${$} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function Wn({d:e,reload:t}){let n=e.trust_anchor,a=async o=>{await z(()=>O.update({built_in_roots:o}),o?"Built-in CAs trusted":"Built-in CAs no longer trusted")&&t()};return c`
    <${b} title="Trusted certificate authorities">
      <p class="muted">The EST server's certificate has to chain to one of these, and so has that of an MQTT broker (mqtts://) whose key isn't pinned.</p>
      <label class="check"><input type="checkbox" checked=${e.built_in_roots} onChange=${o=>a(o.target.checked)} /> Built in: Let's Encrypt (${e.built_in_root_names.join(", ")})</label>
      <h3>Installed</h3>
      ${n?c`<${ze} c=${n} />${n.count>1&&c`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:c`<p>None installed.</p>`}
      <div class="buttons">
        <${Ke} label=${n?"Replace":"Upload"} send=${O.setTrustAnchor} success="CA certificates installed" after=${t} />
        ${n&&c`<${$} kind="danger" onClick=${async()=>confirm("Remove the installed CA certificates?")&&await z(O.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function jn({d:e,reload:t}){let[n,a]=v(e.ntp_server),o=async()=>{await z(()=>O.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return c`
    <${b} title="Time" aside=${c`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?e.time_authenticated?"synchronised (NTS)":"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates, EST and MQTT brokers checked against a CA need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} placeholder="automatic" onInput=${s=>a(s.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. <code>nts://host</code> authenticates the time with NTS (e.g. <code>nts://ptbtime1.ptb.de</code>); its certificate is checked against the trusted CAs. In use: ${e.ntp_server_in_use}</p>
      ${e.nts&&c`<p class="muted">NTS: ${e.nts.cookies} cookies${e.nts.last_key_exchange?` \xB7 key exchange ${e.nts.last_key_exchange}`:""}${e.nts.last_answer?` \xB7 last answer ${e.nts.last_answer}`:""}${e.nts.error?c` · <span class="badge warn">${e.nts.error}</span>`:""}</p>`}
      <div class="buttons"><${$} onClick=${o}>Save<//></div>
    <//>`}var Bn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function Bt(){let{data:e,error:t,reload:n}=H(X.all,5e3);return e?c`
    <${jt} slot="primary" b=${e.primary} reload=${n} />
    <${jt} slot="secondary" b=${e.secondary} reload=${n} />
    <${Vn} on=${e.home_assistant} reload=${n} />`:c`<${M} error=${t} />`}function Vn({on:e,reload:t}){return c`
    <${b} title="Home Assistant">
      <label class="check"><input type="checkbox" checked=${e} onChange=${async a=>{let o=a.target.checked;await S(()=>X.updateAll({home_assistant:o}),o?"Home Assistant discovery on":"Home Assistant discovery off")&&t()}} /> Publish discovery configurations (homeassistant/…) on the primary broker</label>
      <p class="muted">Sensors, presence sensors and buttons of every device the gateway has seen then appear in Home Assistant by themselves; buttons as device triggers (single, double, triple, hold, release). Relays, rollershutters and lamps aren't described yet. Switching it off stops new configurations; what was published stays until removed in Home Assistant.</p>
    <//>`}var Gn={ca:`The broker's certificate has to come from a trusted CA (HTTPS page) and name the host in the address. For a self-signed certificate, pin it with "Trust".`,pinned:`The broker's key is pinned: only a broker with the same key is accepted. "Forget" goes back to checking it against the trusted CAs.`,insecure:"Any certificate is accepted."};function jt({slot:e,b:t,reload:n}){let[a,o]=v({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[s,i]=v(null),l=a.uri.startsWith("mqtts://"),u=r=>_=>o({...a,[r]:_.target.type==="checkbox"?_.target.checked:_.target.value}),d=async()=>{let r={uri:a.uri,user:a.user,enabled:a.enabled,tls_insecure:a.tls_insecure};a.password&&(r.password=a.password),await S(()=>X.update(e,r),`${e} broker saved, reconnecting`)&&(o({...a,password:""}),setTimeout(n,2500))},p=async()=>{let r=await S(()=>X.certificate(e));r&&i(r)};return c`
    <${b}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${c`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${Bn[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${a.uri} onInput=${u("uri")} /><//>
        <${C} label="User"><input value=${a.user} onInput=${u("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${a.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${l&&c`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">${Gn[t.tls_check]||""}</p>
          <label class="check"><input type="checkbox" checked=${a.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await S(()=>X.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&c`<${$} kind="danger" onClick=${async()=>{await S(()=>X.forget(e),"Certificate forgotten"),i(null),n()}}>Forget<//>`}
          </div>
          ${s&&c`<p>${s.pinned?c`SHA-256 <code>${s.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${d}>Save<//></div>
    <//>`}var Kn=[{path:"/",title:"Devices",page:qt},{path:"/devices/:device",title:"Device",page:Ut},{path:"/sensors",title:"Sensors",page:Mt},{path:"/mqtt",title:"MQTT",page:Bt},{path:"/gateway",title:"Gateway",page:Ot},{path:"/https",title:"HTTPS",page:Wt}],zn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function Qn(){let e=It(),t=Lt(Kn,e),n=t?t.route.page:null,a=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return c`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${zn.map(([o,s])=>c`<${te} href=${o} class=${a(o)?"active":""}>${s}<//>`)}</nav>
    </header>
    <main>
      ${n?c`<${n} key=${e} ...${t.params} />`:c`<p class="error">No such page. <${te} href="/">Devices<//></p>`}
    </main>
    <${Ft} />`}ut(c`<${Qn} />`,document.getElementById("app"));
