var Wt=Object.create;var Qe=Object.defineProperty;var jt=Object.getOwnPropertyDescriptor;var Vt=Object.getOwnPropertyNames;var Bt=Object.getPrototypeOf,Gt=Object.prototype.hasOwnProperty;var Kt=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Qt=(e,t,n,a)=>{if(t&&typeof t=="object"||typeof t=="function")for(let o of Vt(t))!Gt.call(e,o)&&o!==n&&Qe(e,o,{get:()=>t[o],enumerable:!(a=jt(t,o))||a.enumerable});return e};var Jt=(e,t,n)=>(n=e!=null?Wt(Bt(e)):{},Qt(t||!e||!e.__esModule?Qe(n,"default",{value:e,enumerable:!0}):n,e));var Tt=Kt(Le=>{var St;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Le=="object"?e(Le):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(St={}):e(St={})})(function(e){e.version="1.2.2";function t(){for(var f=0,A=new Array(256),m=0;m!=256;++m)f=m,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,f=f&1?-306674912^f>>>1:f>>>1,A[m]=f;return typeof Int32Array<"u"?new Int32Array(A):A}var n=t();function a(f){var A=0,m=0,b=0,g=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(b=0;b!=256;++b)g[b]=f[b];for(b=0;b!=256;++b)for(m=f[b],A=256+b;A<4096;A+=256)m=g[A]=m>>>8^f[m&255];var R=[];for(b=1;b!=16;++b)R[b-1]=typeof Int32Array<"u"?g.subarray(b*256,b*256+256):g.slice(b*256,b*256+256);return R}var o=a(n),s=o[0],r=o[1],c=o[2],u=o[3],l=o[4],p=o[5],i=o[6],_=o[7],h=o[8],y=o[9],F=o[10],x=o[11],S=o[12],w=o[13],P=o[14];function H(f,A){for(var m=A^-1,b=0,g=f.length;b<g;)m=m>>>8^n[(m^f.charCodeAt(b++))&255];return~m}function B(f,A){for(var m=A^-1,b=f.length-15,g=0;g<b;)m=P[f[g++]^m&255]^w[f[g++]^m>>8&255]^S[f[g++]^m>>16&255]^x[f[g++]^m>>>24]^F[f[g++]]^y[f[g++]]^h[f[g++]]^_[f[g++]]^i[f[g++]]^p[f[g++]]^l[f[g++]]^u[f[g++]]^c[f[g++]]^r[f[g++]]^s[f[g++]]^n[f[g++]];for(b+=15;g<b;)m=m>>>8^n[(m^f[g++])&255];return~m}function W(f,A){for(var m=A^-1,b=0,g=f.length,R=0,Se=0;b<g;)R=f.charCodeAt(b++),R<128?m=m>>>8^n[(m^R)&255]:R<2048?(m=m>>>8^n[(m^(192|R>>6&31))&255],m=m>>>8^n[(m^(128|R&63))&255]):R>=55296&&R<57344?(R=(R&1023)+64,Se=f.charCodeAt(b++)&1023,m=m>>>8^n[(m^(240|R>>8&7))&255],m=m>>>8^n[(m^(128|R>>2&63))&255],m=m>>>8^n[(m^(128|Se>>6&15|(R&3)<<4))&255],m=m>>>8^n[(m^(128|Se&63))&255]):(m=m>>>8^n[(m^(224|R>>12&15))&255],m=m>>>8^n[(m^(128|R>>6&63))&255],m=m>>>8^n[(m^(128|R&63))&255]);return~m}e.table=n,e.bstr=H,e.buf=B,e.str=W})});var me,E,Ze,zt,J,Je,et,tt,nt,xe,Te,Ce,Yt,re={},at=[],Xt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,he=Array.isArray;function G(e,t){for(var n in t)e[n]=t[n];return e}function Ee(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function ie(e,t,n){var a,o,s,r={};for(s in t)s=="key"?a=t[s]:s=="ref"?o=t[s]:r[s]=t[s];if(arguments.length>2&&(r.children=arguments.length>3?me.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(s in e.defaultProps)r[s]===void 0&&(r[s]=e.defaultProps[s]);return pe(e,r,a,o,null)}function pe(e,t,n,a,o){var s={type:e,props:t,key:n,ref:a,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o??++Ze,__i:-1,__u:0};return o==null&&E.vnode!=null&&E.vnode(s),s}function $e(e){return e.children}function _e(e,t){this.props=e,this.context=t}function ne(e,t){if(t==null)return e.__?ne(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?ne(e):null}function st(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return st(e)}}function ze(e){(!e.__d&&(e.__d=!0)&&J.push(e)&&!fe.__r++||Je!=E.debounceRendering)&&((Je=E.debounceRendering)||et)(fe)}function fe(){for(var e,t,n,a,o,s,r,c=1;J.length;)J.length>c&&J.sort(tt),e=J.shift(),c=J.length,e.__d&&(n=void 0,o=(a=(t=e).__v).__e,s=[],r=[],t.__P&&((n=G({},a)).__v=a.__v+1,E.vnode&&E.vnode(n),Re(t.__P,n,a,t.__n,t.__P.namespaceURI,32&a.__u?[o]:null,s,o??ne(a),!!(32&a.__u),r),n.__v=a.__v,n.__.__k[n.__i]=n,it(s,n,r),n.__e!=o&&st(n)));fe.__r=0}function ot(e,t,n,a,o,s,r,c,u,l,p){var i,_,h,y,F,x,S=a&&a.__k||at,w=t.length;for(u=Zt(n,t,S,u,w),i=0;i<w;i++)(h=n.__k[i])!=null&&(_=h.__i==-1?re:S[h.__i]||re,h.__i=i,x=Re(e,h,_,o,s,r,c,u,l,p),y=h.__e,h.ref&&_.ref!=h.ref&&(_.ref&&Fe(_.ref,null,h),p.push(h.ref,h.__c||y,h)),F==null&&y!=null&&(F=y),4&h.__u||_.__k===h.__k?u=rt(h,u,e):typeof h.type=="function"&&x!==void 0?u=x:y&&(u=y.nextSibling),h.__u&=-7);return n.__e=F,u}function Zt(e,t,n,a,o){var s,r,c,u,l,p=n.length,i=p,_=0;for(e.__k=new Array(o),s=0;s<o;s++)(r=t[s])!=null&&typeof r!="boolean"&&typeof r!="function"?(u=s+_,(r=e.__k[s]=typeof r=="string"||typeof r=="number"||typeof r=="bigint"||r.constructor==String?pe(null,r,null,null,null):he(r)?pe($e,{children:r},null,null,null):r.constructor==null&&r.__b>0?pe(r.type,r.props,r.key,r.ref?r.ref:null,r.__v):r).__=e,r.__b=e.__b+1,c=null,(l=r.__i=en(r,n,u,i))!=-1&&(i--,(c=n[l])&&(c.__u|=2)),c==null||c.__v==null?(l==-1&&(o>p?_--:o<p&&_++),typeof r.type!="function"&&(r.__u|=4)):l!=u&&(l==u-1?_--:l==u+1?_++:(l>u?_--:_++,r.__u|=4))):e.__k[s]=null;if(i)for(s=0;s<p;s++)(c=n[s])!=null&&(2&c.__u)==0&&(c.__e==a&&(a=ne(c)),ct(c,c));return a}function rt(e,t,n){var a,o;if(typeof e.type=="function"){for(a=e.__k,o=0;a&&o<a.length;o++)a[o]&&(a[o].__=e,t=rt(a[o],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=ne(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function en(e,t,n,a){var o,s,r=e.key,c=e.type,u=t[n];if(u===null&&e.key==null||u&&r==u.key&&c==u.type&&(2&u.__u)==0)return n;if(a>(u!=null&&(2&u.__u)==0?1:0))for(o=n-1,s=n+1;o>=0||s<t.length;){if(o>=0){if((u=t[o])&&(2&u.__u)==0&&r==u.key&&c==u.type)return o;o--}if(s<t.length){if((u=t[s])&&(2&u.__u)==0&&r==u.key&&c==u.type)return s;s++}}return-1}function Ye(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Xt.test(t)?n:n+"px"}function ue(e,t,n,a,o){var s,r;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof a=="string"&&(e.style.cssText=a=""),a)for(t in a)n&&t in n||Ye(e.style,t,"");if(n)for(t in n)a&&n[t]==a[t]||Ye(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")s=t!=(t=t.replace(nt,"$1")),r=t.toLowerCase(),t=r in e||t=="onFocusOut"||t=="onFocusIn"?r.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+s]=n,n?a?n.u=a.u:(n.u=xe,e.addEventListener(t,s?Ce:Te,s)):e.removeEventListener(t,s?Ce:Te,s);else{if(o=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function Xe(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=xe++;else if(t.t<n.u)return;return n(E.event?E.event(t):t)}}}function Re(e,t,n,a,o,s,r,c,u,l){var p,i,_,h,y,F,x,S,w,P,H,B,W,f,A,m,b,g=t.type;if(t.constructor!=null)return null;128&n.__u&&(u=!!(32&n.__u),s=[c=t.__e=n.__e]),(p=E.__b)&&p(t);e:if(typeof g=="function")try{if(S=t.props,w="prototype"in g&&g.prototype.render,P=(p=g.contextType)&&a[p.__c],H=p?P?P.props.value:p.__:a,n.__c?x=(i=t.__c=n.__c).__=i.__E:(w?t.__c=i=new g(S,H):(t.__c=i=new _e(S,H),i.constructor=g,i.render=nn),P&&P.sub(i),i.props=S,i.state||(i.state={}),i.context=H,i.__n=a,_=i.__d=!0,i.__h=[],i._sb=[]),w&&i.__s==null&&(i.__s=i.state),w&&g.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=G({},i.__s)),G(i.__s,g.getDerivedStateFromProps(S,i.__s))),h=i.props,y=i.state,i.__v=t,_)w&&g.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),w&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(w&&g.getDerivedStateFromProps==null&&S!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(S,H),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(S,i.__s,H)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=S,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(R){R&&(R.__=t)}),B=0;B<i._sb.length;B++)i.__h.push(i._sb[B]);i._sb=[],i.__h.length&&r.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(S,i.__s,H),w&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,y,F)})}if(i.context=H,i.props=S,i.__P=e,i.__e=!1,W=E.__r,f=0,w){for(i.state=i.__s,i.__d=!1,W&&W(t),p=i.render(i.props,i.state,i.context),A=0;A<i._sb.length;A++)i.__h.push(i._sb[A]);i._sb=[]}else do i.__d=!1,W&&W(t),p=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++f<25);i.state=i.__s,i.getChildContext!=null&&(a=G(G({},a),i.getChildContext())),w&&!_&&i.getSnapshotBeforeUpdate!=null&&(F=i.getSnapshotBeforeUpdate(h,y)),m=p,p!=null&&p.type===$e&&p.key==null&&(m=lt(p.props.children)),c=ot(e,he(m)?m:[m],t,n,a,o,s,r,c,u,l),i.base=t.__e,t.__u&=-161,i.__h.length&&r.push(i),x&&(i.__E=i.__=null)}catch(R){if(t.__v=null,u||s!=null)if(R.then){for(t.__u|=u?160:128;c&&c.nodeType==8&&c.nextSibling;)c=c.nextSibling;s[s.indexOf(c)]=null,t.__e=c}else for(b=s.length;b--;)Ee(s[b]);else t.__e=n.__e,t.__k=n.__k;E.__e(R,t,n)}else s==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):c=t.__e=tn(n.__e,t,n,a,o,s,r,u,l);return(p=E.diffed)&&p(t),128&t.__u?void 0:c}function it(e,t,n){for(var a=0;a<n.length;a++)Fe(n[a],n[++a],n[++a]);E.__c&&E.__c(t,e),e.some(function(o){try{e=o.__h,o.__h=[],e.some(function(s){s.call(o)})}catch(s){E.__e(s,o.__v)}})}function lt(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:he(e)?e.map(lt):G({},e)}function tn(e,t,n,a,o,s,r,c,u){var l,p,i,_,h,y,F,x=n.props,S=t.props,w=t.type;if(w=="svg"?o="http://www.w3.org/2000/svg":w=="math"?o="http://www.w3.org/1998/Math/MathML":o||(o="http://www.w3.org/1999/xhtml"),s!=null){for(l=0;l<s.length;l++)if((h=s[l])&&"setAttribute"in h==!!w&&(w?h.localName==w:h.nodeType==3)){e=h,s[l]=null;break}}if(e==null){if(w==null)return document.createTextNode(S);e=document.createElementNS(o,w,S.is&&S),c&&(E.__m&&E.__m(t,s),c=!1),s=null}if(w==null)x===S||c&&e.data==S||(e.data=S);else{if(s=s&&me.call(e.childNodes),x=n.props||re,!c&&s!=null)for(x={},l=0;l<e.attributes.length;l++)x[(h=e.attributes[l]).name]=h.value;for(l in x)if(h=x[l],l!="children"){if(l=="dangerouslySetInnerHTML")i=h;else if(!(l in S)){if(l=="value"&&"defaultValue"in S||l=="checked"&&"defaultChecked"in S)continue;ue(e,l,null,h,o)}}for(l in S)h=S[l],l=="children"?_=h:l=="dangerouslySetInnerHTML"?p=h:l=="value"?y=h:l=="checked"?F=h:c&&typeof h!="function"||x[l]===h||ue(e,l,h,x[l],o);if(p)c||i&&(p.__html==i.__html||p.__html==e.innerHTML)||(e.innerHTML=p.__html),t.__k=[];else if(i&&(e.innerHTML=""),ot(t.type=="template"?e.content:e,he(_)?_:[_],t,n,a,w=="foreignObject"?"http://www.w3.org/1999/xhtml":o,s,r,s?s[0]:n.__k&&ne(n,0),c,u),s!=null)for(l=s.length;l--;)Ee(s[l]);c||(l="value",w=="progress"&&y==null?e.removeAttribute("value"):y!=null&&(y!==e[l]||w=="progress"&&!y||w=="option"&&y!=x[l])&&ue(e,l,y,x[l],o),l="checked",F!=null&&F!=e[l]&&ue(e,l,F,x[l],o))}return e}function Fe(e,t,n){try{if(typeof e=="function"){var a=typeof e.__u=="function";a&&e.__u(),a&&t==null||(e.__u=e(t))}else e.current=t}catch(o){E.__e(o,n)}}function ct(e,t,n){var a,o;if(E.unmount&&E.unmount(e),(a=e.ref)&&(a.current&&a.current!=e.__e||Fe(a,null,t)),(a=e.__c)!=null){if(a.componentWillUnmount)try{a.componentWillUnmount()}catch(s){E.__e(s,t)}a.base=a.__P=null}if(a=e.__k)for(o=0;o<a.length;o++)a[o]&&ct(a[o],t,n||typeof e.type!="function");n||Ee(e.__e),e.__c=e.__=e.__e=void 0}function nn(e,t,n){return this.constructor(e,n)}function dt(e,t,n){var a,o,s,r;t==document&&(t=document.documentElement),E.__&&E.__(e,t),o=(a=typeof n=="function")?null:n&&n.__k||t.__k,s=[],r=[],Re(t,e=(!a&&n||t).__k=ie($e,null,[e]),o||re,re,t.namespaceURI,!a&&n?[n]:o?null:t.firstChild?me.call(t.childNodes):null,s,!a&&n?n:o?o.__e:t.firstChild,a,r),it(s,e,r)}me=at.slice,E={__e:function(e,t,n,a){for(var o,s,r;t=t.__;)if((o=t.__c)&&!o.__)try{if((s=o.constructor)&&s.getDerivedStateFromError!=null&&(o.setState(s.getDerivedStateFromError(e)),r=o.__d),o.componentDidCatch!=null&&(o.componentDidCatch(e,a||{}),r=o.__d),r)return o.__E=o}catch(c){e=c}throw e}},Ze=0,zt=function(e){return e!=null&&e.constructor==null},_e.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=G({},this.state),typeof e=="function"&&(e=e(G({},n),this.props)),e&&G(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),ze(this))},_e.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),ze(this))},_e.prototype.render=$e,J=[],et=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,tt=function(e,t){return e.__v.__b-t.__v.__b},fe.__r=0,nt=/(PointerCapture)$|Capture$/i,xe=0,Te=Xe(!1),Ce=Xe(!0),Yt=0;var le,I,Ie,ut,ce=0,gt=[],N=E,pt=N.__b,_t=N.__r,ft=N.diffed,mt=N.__c,ht=N.unmount,$t=N.__;function Ae(e,t){N.__h&&N.__h(I,e,ce||t),ce=0;var n=I.__H||(I.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function v(e){return ce=1,an(kt,e)}function an(e,t,n){var a=Ae(le++,2);if(a.t=e,!a.__c&&(a.__=[n?n(t):kt(void 0,t),function(c){var u=a.__N?a.__N[0]:a.__[0],l=a.t(u,c);u!==l&&(a.__N=[l,a.__[1]],a.__c.setState({}))}],a.__c=I,!I.__f)){var o=function(c,u,l){if(!a.__c.__H)return!0;var p=a.__c.__H.__.filter(function(_){return!!_.__c});if(p.every(function(_){return!_.__N}))return!s||s.call(this,c,u,l);var i=a.__c.props!==c;return p.forEach(function(_){if(_.__N){var h=_.__[0];_.__=_.__N,_.__N=void 0,h!==_.__[0]&&(i=!0)}}),s&&s.call(this,c,u,l)||i};I.__f=!0;var s=I.shouldComponentUpdate,r=I.componentWillUpdate;I.componentWillUpdate=function(c,u,l){if(this.__e){var p=s;s=void 0,o(c,u,l),s=p}r&&r.call(this,c,u,l)},I.shouldComponentUpdate=o}return a.__N||a.__}function z(e,t){var n=Ae(le++,3);!N.__s&&bt(n.__H,t)&&(n.__=e,n.u=t,I.__H.__h.push(n))}function ge(e){return ce=5,yt(function(){return{current:e}},[])}function yt(e,t){var n=Ae(le++,7);return bt(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function wt(e,t){return ce=8,yt(function(){return e},t)}function sn(){for(var e;e=gt.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(ve),e.__H.__h.forEach(Ne),e.__H.__h=[]}catch(t){e.__H.__h=[],N.__e(t,e.__v)}}N.__b=function(e){I=null,pt&&pt(e)},N.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),$t&&$t(e,t)},N.__r=function(e){_t&&_t(e),le=0;var t=(I=e.__c).__H;t&&(Ie===I?(t.__h=[],I.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(ve),t.__h.forEach(Ne),t.__h=[],le=0)),Ie=I},N.diffed=function(e){ft&&ft(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(gt.push(t)!==1&&ut===N.requestAnimationFrame||((ut=N.requestAnimationFrame)||on)(sn)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Ie=I=null},N.__c=function(e,t){t.some(function(n){try{n.__h.forEach(ve),n.__h=n.__h.filter(function(a){return!a.__||Ne(a)})}catch(a){t.some(function(o){o.__h&&(o.__h=[])}),t=[],N.__e(a,n.__v)}}),mt&&mt(e,t)},N.unmount=function(e){ht&&ht(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(a){try{ve(a)}catch(o){t=o}}),n.__H=void 0,t&&N.__e(t,n.__v))};var vt=typeof requestAnimationFrame=="function";function on(e){var t,n=function(){clearTimeout(a),vt&&cancelAnimationFrame(t),setTimeout(e)},a=setTimeout(n,35);vt&&(t=requestAnimationFrame(n))}function ve(e){var t=I,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),I=t}function Ne(e){var t=I;e.__c=e.__(),I=t}function bt(e,t){return!e||e.length!==t.length||t.some(function(n,a){return n!==e[a]})}function kt(e,t){return typeof t=="function"?t(e):t}var Ct=Jt(Tt()),He="/api/v1",ae=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},rn=e=>new Promise(t=>setTimeout(t,e));async function de(e,t,n){let a=typeof n=="string";for(let o=1;;o++){let s;try{s=await fetch(He+t,{method:e,headers:n===void 0?{}:{"Content-Type":a?"application/x-pem-file":"application/json"},body:n===void 0?void 0:a?n:JSON.stringify(n)})}catch{if(o>=4)throw new ae(0,{message:"gateway unreachable"});await rn(250*o);continue}let r=await s.text(),c=null;try{c=r?JSON.parse(r):null}catch{c={message:r}}if(!s.ok)throw new ae(s.status,c);return c}}var V=e=>de("GET",e),K=(e,t)=>de("POST",e,t),j=(e,t)=>de("PUT",e,t),ye=(e,t)=>de("PATCH",e,t),Pe=e=>de("DELETE",e),U=encodeURIComponent,Me={get:()=>V("/system"),restart:()=>K("/system/restart")},De={get:()=>V("/config"),update:e=>ye("/config",e)},se={all:()=>V("/mqtt"),update:(e,t)=>ye(`/mqtt/${e}`,t),trust:e=>K(`/mqtt/${e}/trust`),certificate:e=>V(`/mqtt/${e}/certificate`),forget:e=>Pe(`/mqtt/${e}/certificate`)},O={get:()=>V("/tls"),update:e=>ye("/tls",e),selfSigned:e=>K("/tls/self-signed",{validity_years:e}),csrUrl:()=>`${He}/tls/csr`,installCertificate:e=>j("/tls/certificate",e),setTrustAnchor:e=>j("/tls/trust-anchor",e),removeTrustAnchor:()=>Pe("/tls/trust-anchor"),setIdentity:e=>j("/tls/est/identity",e),removeIdentity:()=>Pe("/tls/est/identity"),enroll:()=>K("/tls/est/enroll")},L={async list(){let e=[];for(;;){let t=await V(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>V(`/devices/${U(e)}`),update:(e,t)=>ye(`/devices/${U(e)}`,t),action:(e,t)=>K(`/devices/${U(e)}/${t}`),silence:(e,t)=>j(`/devices/${U(e)}/silence`,{on:t}),relay:(e,t,n,a)=>j(`/devices/${U(e)}/relays/${t}`,{state:n,duration_ms:a}),rollershutter:(e,t,n,a)=>j(`/devices/${U(e)}/rollershutters/${t}`,{state:n,duration_ms:a}),lamps:(e,t,n,a)=>j(`/devices/${U(e)}/lamps/${t}`,{value:n,bitmask:a}),heating:(e,t,n)=>j(`/devices/${U(e)}/heating/${t}`,n),heatingManualState:e=>V(`/devices/${U(e)}/heating/manual`),heatingManual:(e,t,n,a)=>j(`/devices/${U(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:a})},Y={update:(e,t,n)=>j(`/devices/${U(e)}/sensors/${t}`,n),refresh:e=>K(`/devices/${U(e)}/sensors/refresh`),forget:e=>K(`/devices/${U(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${U(e)}`:"",a=await V(`/sensors?offset=${t.length}${n}`);if(t.push(...a.sensors),a.sensors.length===0||t.length>=a.total)return t}}},X={action:e=>K(`/bus/${e}`),silence:e=>j("/bus/silence",{on:e}),typeAction:(e,t)=>K(`/device-types/${e}/${t}`)},Ue={job:()=>V("/firmware/job"),upload(e,t,n){let a=Ct.default.buf(new Uint8Array(t))>>>0,o=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((s,r)=>{let c=new XMLHttpRequest;c.open("PUT",`${He}${o}?crc32=${a}`),c.setRequestHeader("Content-Type","application/octet-stream"),c.upload.onprogress=u=>u.lengthComputable&&n&&n(u.loaded/u.total),c.onload=()=>{let u=null;try{u=JSON.parse(c.responseText)}catch{}c.status>=200&&c.status<300?s(u):r(new ae(c.status,u))},c.onerror=()=>r(new ae(0,{message:"upload failed"})),c.send(t)})}};var Et=function(e,t,n,a){var o;t[0]=0;for(var s=1;s<t.length;s++){var r=t[s++],c=t[s]?(t[0]|=r?1:2,n[t[s++]]):t[++s];r===3?a[0]=c:r===4?a[1]=Object.assign(a[1]||{},c):r===5?(a[1]=a[1]||{})[t[++s]]=c:r===6?a[1][t[++s]]+=c+"":r?(o=e.apply(c,Et(e,c,n,["",null])),a.push(o),c[0]?t[0]|=2:(t[s-2]=0,t[s]=o)):a.push(c)}return a},xt=new Map;function Rt(e){var t=xt.get(this);return t||(t=new Map,xt.set(this,t)),(t=Et(this,t.get(e)||(t.set(e,t=function(n){for(var a,o,s=1,r="",c="",u=[0],l=function(_){s===1&&(_||(r=r.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?u.push(0,_,r):s===3&&(_||r)?(u.push(3,_,r),s=2):s===2&&r==="..."&&_?u.push(4,_,0):s===2&&r&&!_?u.push(5,0,!0,r):s>=5&&((r||!_&&s===5)&&(u.push(s,0,r,o),s=6),_&&(u.push(s,_,0,o),s=6)),r=""},p=0;p<n.length;p++){p&&(s===1&&l(),l(p));for(var i=0;i<n[p].length;i++)a=n[p][i],s===1?a==="<"?(l(),u=[u],s=3):r+=a:s===4?r==="--"&&a===">"?(s=1,r=""):r=a+r[0]:c?a===c?c="":r+=a:a==='"'||a==="'"?c=a:a===">"?(l(),s=1):s&&(a==="="?(s=5,o=r,r=""):a==="/"&&(s<5||n[p][i+1]===">")?(l(),s===3&&(u=u[0]),s=u,(u=u[0]).push(2,0,s),s=0):a===" "||a==="	"||a===`
`||a==="\r"?(l(),s=2):r+=a),s===3&&r==="!--"&&(s=4,u=u[0])}return l(),u}(e)),t),arguments,[])).length>1?t:t[0]}var d=Rt.bind(ie),Oe=()=>{};function q(e,t="ok"){Oe(e,t)}function Ft(){let[e,t]=v([]);return z(()=>{let n=0;return Oe=(a,o)=>{let s={id:++n,message:a,kind:o};t(r=>[...r,s]),setTimeout(()=>t(r=>r.filter(c=>c!==s)),o==="error"?8e3:3e3)},()=>Oe=()=>{}},[]),d`<div class="toasts">
    ${e.map(n=>d`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function T(e,t){try{let n=await e();return t&&q(t),n}catch(n){q(n.message,"error");return}}function M(e,t){let[n,a]=v({data:void 0,error:void 0}),o=ge(e);o.current=e;let s=wt(async()=>{try{a({data:await o.current(),error:void 0})}catch(r){a(c=>({data:c.data,error:r}))}},[]);return z(()=>{let r=!1,c,u=async()=>{await s(),t&&!r&&(c=setTimeout(u,t))};return u(),()=>{r=!0,clearTimeout(c)}},[t,s]),{...n,reload:s}}var k=({title:e,children:t,aside:n})=>d`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,D=({error:e})=>e?d`<p class="error">${e.message}</p>`:d`<p class="muted">Loading…</p>`,C=({label:e,hint:t,children:n})=>d`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&d`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:a})=>{let[o,s]=v(!1);return d`<button class=${t||""} disabled=${a||o} onClick=${async c=>{s(!0);try{await n(c)}finally{s(!1)}}}>${e}</button>`},qe=e=>"0x"+e.toString(16).padStart(2,"0");function ee(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function It(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),a=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${a} min`:`${a} min`}function we({target:e,label:t,others:n=[],onDone:a}){let[o,s]=v(null),[r,c]=v(null),[u,l]=v(""),[p,i]=v(null),_=ge(null);z(()=>()=>clearInterval(_.current),[]);let h=()=>{clearInterval(_.current),_.current=setInterval(async()=>{try{i(await Ue.job())}catch{}},1500)},y=async(w,P)=>{l(w),c(0),P!=="gateway"&&h();try{let H=await o.arrayBuffer();return await Ue.upload(P,H,c)||{}}finally{clearInterval(_.current),c(null)}},F=async w=>{if(!o)return;let P=0;for(let{name:H,target:B}of w)try{let W=await y(H,B);P+=1,W.restarting&&q("Firmware installed, the gateway restarts\u2026")}catch(W){q(`${H}: ${W.message}`,"error");break}P===w.length&&w[0].target!=="gateway"&&q(P===1?"Firmware sent; the device restarts into it":`Firmware sent to ${P} devices`),l(""),i(null),a&&a()},x=r!==null,S=p&&p.state==="running"?`${p.sent} of ${p.total} bytes acknowledged${p.protocol?` (${p.protocol})`:""}${p.retries?`, ${p.retries} blocks repeated`:""}`:"";return d`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${w=>s(w.target.files[0]||null)} />
      <${$} onClick=${()=>F([{name:t||"device",target:e}])} disabled=${!o||x}>${t||"Upload"}<//>
      ${n.length>0&&d`<${$} onClick=${()=>F([{name:"this device",target:e},...n])} disabled=${!o||x}>Send to all ${n.length+1} of this type<//>`}
      ${x&&d`<progress max="1" value=${r}></progress>`}
      ${x&&d`<p class="muted wide">${u}${S?" \u2014 "+S:""}</p>`}
    </div>`}var be=new Set;function ln(e){e!==location.pathname&&history.pushState(null,"",e),be.forEach(t=>t())}addEventListener("popstate",()=>be.forEach(e=>e()));function Nt(){let[e,t]=v(location.pathname);return z(()=>{let n=()=>t(location.pathname);return be.add(n),()=>be.delete(n)},[]),e}function At(e,t){let n=t.split("/").filter(Boolean);for(let a of e){let o=a.path.split("/").filter(Boolean);if(o.length!==n.length)continue;let s={};if(o.every((c,u)=>c.startsWith(":")?(s[c.slice(1)]=decodeURIComponent(n[u]),!0):c===n[u]))return{route:a,params:s}}return null}function te({href:e,children:t,...n}){return ie("a",{href:e,onClick:o=>{o.metaKey||o.ctrlKey||o.shiftKey||o.button!==0||(o.preventDefault(),ln(e))},...n},t)}var cn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"},We=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],dn={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},oe=e=>dn[e]||e;function ke(e,t=5e3){let n=M(()=>Y.list(e),t),a=[...new Set((n.data||[]).map(s=>s.device))];return{...n,ask:async()=>{for(let s of e?[e]:a)await T(()=>Y.refresh(s));setTimeout(n.reload,1500)}}}function un({s:e,device:t,reload:n}){let[a,o]=v(!1),[s,r]=v(e.name||""),[c,u]=v(e.role||"none"),l=async()=>{let p={};if(s!==(e.name||"")&&(p.name=s),c!==(e.role||"none")&&(p.role=c),Object.keys(p).length===0)return o(!1);await T(()=>Y.update(e.device,e.slot,p),"Sent to the device")&&(o(!1),setTimeout(n,1500))};return d`<tr>
    ${!t&&d`<td><${te} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${a?d`<input class="inline" maxlength="7" placeholder="name" value=${s} onInput=${p=>r(p.target.value)} />`:e.name||d`<span class="muted">–</span>`}</td>
    <td>${cn[e.kind]||e.kind}</td>
    <td>${a?d`<select value=${c} onChange=${p=>u(p.target.value)}>${We.map(p=>d`<option value=${p}>${oe(p)}</option>`)}</select>`:e.role&&e.role!=="none"?oe(e.role):d`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&d` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?d`<span class="badge bad">lost</span>`:`${e.kind==="temperature"?e.value.toFixed(2):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:ee(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":a?d`<${$} kind="primary" onClick=${l}>Save<//> <button onClick=${()=>o(!1)}>Cancel</button>`:d`<button onClick=${()=>o(!0)}>Edit</button>`}</td>
  </tr>`}function je({device:e}){let{data:t,error:n,reload:a,ask:o}=ke(e);if(!t)return d`<${D} error=${n} />`;if(t.length===0)return d`<p class="muted">No sensor reading seen yet.</p>`;let s=t.some(r=>r.slot===null);return d`
    ${s&&d`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${o}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&d`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(r=>d`<${un} key=${r.device_key+r.kind+r.sensor_id} s=${r} device=${e} reload=${a} />`)}
      </tbody>
    </table></div>`}function Lt(){let{ask:e}=ke(void 0,0);return d`<${k} title="Sensors" aside=${d`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${je} />
  <//>`}var pn=[2,5,8,9],_n=[7],fn=[3],Ve=[9],mn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],hn=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ht({device:e}){let{data:t,error:n,reload:a}=M(()=>L.get(e),5e3);return t?d`
    <${vn} d=${t} reload=${a} />
    ${pn.includes(t.device_type)&&d`<${Pt} d=${t} kind="relay" />`}
    ${_n.includes(t.device_type)&&d`<${Pt} d=${t} kind="rollershutter" />`}
    ${fn.includes(t.device_type)&&d`<${gn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${yn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${bn} d=${t} />`}
    ${Ve.includes(t.device_type)&&d`<${kn} d=${t} />`}
    <${k} title="Sensors"><${je} device=${t.name||t.key} /><//>
    <${Sn} d=${t} reload=${a} />
    <${$n} d=${t} />`:d`<${D} error=${n} />`}function $n({d:e}){let t=e.name||e.key,{data:n}=M(L.list),a=(n||[]).filter(o=>o.device_type===e.device_type&&o.key!==e.key).map(o=>({name:o.name||o.key,target:"devices/"+encodeURIComponent(o.name||o.key)}));return d`
    <${k} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus: in blocks that the device acknowledges and the gateway repeats if the bus lost frames, so it takes a few minutes and does not depend on timing. The device restarts into the new image and keeps it once it was heard on the bus; if it does not come back, it returns to the old one.</p>
      <${we} target=${"devices/"+encodeURIComponent(t)} label="Send to this device" others=${a} />
    <//>`}function vn({d:e,reload:t}){let n=e.name||e.key,a=(o,s)=>async()=>{await T(()=>L.action(n,o),s),setTimeout(t,1500)};return d`
    <${k} title=${n}
      aside=${d`<span class="buttons">
        <${$} onClick=${a("ping","Ping sent")}>Ping<//>
        <${$} onClick=${a("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${a("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${ee(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Pt({d:e,kind:t}){let n=e.name||e.key,[a,o]=v(1),[s,r]=v(0),c=t==="rollershutter",u=l=>()=>T(()=>L[t](n,a,l,Math.round(s*1e3)),`${c?"Rollershutter":"Relay"} ${a}: ${l}`);return d`
    <${k} title=${c?"Rollershutter":"Relays"}>
      ${e.device_type===9&&d`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${C} label="Number"><input type="number" min="1" max="16" value=${a} onInput=${l=>o(+l.target.value)} /><//>
        <${C} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${s} onInput=${l=>r(+l.target.value)} /><//>
      </div>
      <div class="buttons">
        ${c?d`<${$} onClick=${u("up")}>Up<//><${$} onClick=${u("down")}>Down<//><${$} onClick=${u("off")}>Stop<//>`:d`<${$} kind="primary" onClick=${u("on")}>On<//><${$} onClick=${u("off")}>Off<//>`}
      </div>
    <//>`}function gn({d:e}){let t=e.name||e.key,[n,a]=v(0),[o,s]=v(255),[r,c]=v(Array(24).fill(!1)),u=r.reduce((l,p,i)=>p?l|1<<23-i:l,0);return d`
    <${k} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${C} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${l=>a(+l.target.value)} /><//>
        <${C} label="Value (0-255)"><input type="number" min="0" max="255" value=${o} onInput=${l=>s(+l.target.value)} /><//>
      </div>
      <div class="lamps">
        ${r.map((l,p)=>d`<label key=${p} class=${"lamp"+(l?" on":"")}>
            <input type="checkbox" checked=${l} onChange=${()=>c(r.map((i,_)=>_===p?!i:i))} />${23-p}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>T(()=>L.lamps(t,n,o,u),"Lamps set")}>Send<//>
    <//>`}function yn({d:e}){let t=e.name||e.key,[n,a]=v(45),[o,s]=v(!1),[r,c]=v(0),[u,l]=v(!1),[p,i]=v(0),[_,h]=v(55);return d`
    <${k} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${C} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${y=>a(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${o} onChange=${y=>s(y.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>T(()=>L.heating(t,"target",{flow_c:n,tank:o}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${C} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${r} onInput=${y=>c(+y.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${u} onChange=${y=>l(y.target.checked)} /> rod released</label>
        <${$} onClick=${()=>T(()=>L.heating(t,"energy",{power_w:r,rod_enabled:u}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${C} label="Stage (0-3)"><input type="number" min="0" max="3" value=${p} onInput=${y=>i(+y.target.value)} /><//>
        <${C} label="Tank (°C)"><input type="number" step="0.5" value=${_} onInput=${y=>h(+y.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>T(()=>L.heating(t,"emergency",{stage:p,tank_c:_}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var wn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function bn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o,ask:s}=ke(t);if(!n)return d`<${k} title="Sensor assignment"><${D} error=${a} /><//>`;let r=n.filter(i=>i.kind==="temperature"),c=i=>r.find(_=>_.role===i),u=i=>i.name?`${i.name} (${i.sensor_id})`:i.sensor_id,l=r.every(i=>i.slot!==null),p=i=>async _=>{let h=_.target.value,y;if(h===""){let F=c(i);if(!F)return;y=await T(()=>Y.update(t,F.slot,{role:"none"}),`${oe(i)} cleared`)}else{let F=r.find(x=>x.sensor_id===h);y=await T(()=>Y.update(t,F.slot,{role:i}),`${u(F)} is ${oe(i)} now`)}y&&setTimeout(o,1500)};return d`
    <${k} title="Sensor assignment" aside=${d`<${$} onClick=${s}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!l&&d`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${We.filter(i=>i!=="none").map(i=>d`<label key=${i} class="field">
            <span>${oe(i)}</span>
            <select value=${(c(i)||{}).sensor_id||""} onChange=${p(i)} disabled=${!l}>
              <option value="">(none)</option>
              ${r.map(_=>d`<option value=${_.sensor_id}>${u(_)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function kn({d:e}){let t=e.name||e.key,{data:n,error:a,reload:o}=M(()=>L.heatingManualState(t),3e3),s=!!(n&&n.enabled),r=p=>!!(n&&n.relays.includes(p)),c=async()=>{let p=!s;await T(()=>L.heatingManual(t,p),p?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(o,800)},u=p=>async()=>{await T(()=>L.heatingManual(t,!0,p,!r(p)),`Relay ${p} ${r(p)?"off":"on"}`)&&setTimeout(o,800)},l=p=>p===8&&r(9)||p===9&&r(8);return d`
    <${k} title="Manual mode"
      aside=${d`<${$} kind=${s?"danger":""} disabled=${!n} onClick=${c}>${s?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${a&&d`<p class="error">The controller does not answer: ${a.message}</p>`}
      ${s&&d`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${wn.map(([p,i])=>d`<button key=${p} class=${r(p)?"primary":""} disabled=${!s||l(p)} onClick=${u(p)}>
            <span>${i}</span><small>relay ${p}: ${r(p)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function Sn({d:e,reload:t}){let n=e.name||e.key,[a,o]=v({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[s,r]=v(!1),c=l=>p=>o({...a,[l]:p.target.value}),u=async()=>{let l={};if(a.custom_string!==e.name&&(l.custom_string=a.custom_string),+a.hwrev!==e.hwrev&&(l.hwrev=+a.hwrev),a.relais_mode&&(l.relais_mode=a.relais_mode),a.extension_mode&&(l.extension_mode=a.extension_mode),Object.keys(l).length===0)return q("Nothing changed");await T(()=>L.update(n,l),"Settings sent")&&setTimeout(t,1500)};return d`
    <${k} title="Settings">
      <div class="row">
        <${C} label="Name" hint="up to 8 characters"><input maxlength="8" value=${a.custom_string} onInput=${c("custom_string")} /><//>
        <${C} label="Hardware revision"><input type="number" min="0" max="255" value=${a.hwrev} onInput=${c("hwrev")} /><//>
        <${C} label="Relay mode"><select value=${a.relais_mode} onChange=${c("relais_mode")}>
          <option value="">(unchanged)</option>${mn.map(l=>d`<option>${l}</option>`)}
        </select><//>
        <${C} label="Extension mode"><select value=${a.extension_mode} onChange=${c("extension_mode")}>
          <option value="">(unchanged)</option>${hn.map(l=>d`<option>${l}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${u}>Save<//>
        <${$} onClick=${async()=>{await T(()=>L.silence(n,!s),s?"Device may talk again":"Device silenced"),r(!s)}}>${s?"End silence":"Silence"}<//>
        <${$} onClick=${()=>T(()=>L.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Mt(){let{data:e,error:t,reload:n}=M(L.list,5e3),[a,o]=v(""),s=(l,p)=>async()=>{await T(l,p),setTimeout(n,1500)},r=async()=>{let l=a.trim();l&&await T(()=>L.action(l,"ping"),`Ping sent to ${l}`)},c=async()=>{confirm("Restart every device on the bus?")&&await s(()=>X.action("restart"),"Restart sent to every device")()},u=s(async()=>{await X.action("ping"),await X.action("refresh")},"Scanning: every device was asked to announce itself");return d`
    <${k} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${s(()=>X.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${s(()=>X.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${s(()=>X.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${c}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${a} onInput=${l=>o(l.target.value)} onKeyDown=${l=>l.key==="Enter"&&r()} />
        <${$} onClick=${r}>Ping<//>
        <${$} onClick=${u}>Scan<//>
      </div>
      ${e?e.length===0?d`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:d`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(l=>d`<tr key=${l.key}>
                    <td><${te} href=${"/devices/"+encodeURIComponent(l.name||l.key)}>${l.name||l.key}<//></td>
                    <td><code>${qe(l.device_id)}</code></td>
                    <td>${l.type_name} <code>${qe(l.device_type)}</code></td>
                    <td>${l.version}</td>
                    <td>${ee(l.last_seen_minutes_ago)}</td>
                    <td>${l.uptime?ee(Math.floor(l.uptime/60)):""}</td>
                    <td>${l.error?d`<span class="badge bad">error ${l.error}</span>`:l.last_seen_minutes_ago>10?d`<span class="badge warn">silent</span>`:d`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:d`<${D} error=${t} />`}
      ${t&&e&&d`<p class="error">${t.message}</p>`}
    <//>`}function Dt(){let e=M(Me.get,5e3);return d`<${Tn} ...${e} /><${Cn} ...${e} /><${xn} /><${En} />`}function Tn({data:e,error:t}){return d`
    <${k} title="Gateway" aside=${d`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await T(Me.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?d`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${It(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
            <div><dt>Stack</dt><dd>${Math.round(e.stack_untouched/1024)} of ${Math.round(e.stack_size/1024)} KiB never used</dd></div>
          </dl>`:d`<${D} error=${t} />`}
    <//>`}function Cn({data:e,error:t}){if(!e)return d`<${k} title="Network"><${D} error=${t} /><//>`;let n=e.network;if(!n)return d`<${k} title="Network"><p>No Ethernet.</p><//>`;let a=s=>s.map(r=>d`<div>${r.address} <span class="muted">(${r.origin})</span></div>`),o={off:"not offered by the routers",stateless:"configuration only (O)",stateful:"addresses and configuration (M)"}[n.dhcpv6_mode];return d`
    <${k} title="Network" aside=${d`<span class=${"badge "+(n.link_up?"ok":"warn")}>${n.link_up?"link up":"link down"}</span>`}>
      <dl class="facts">
        <div><dt>IPv6</dt><dd>${n.ipv6.length?a(n.ipv6):"none"}</dd></div>
        <div><dt>IPv6 gateway</dt><dd>${n.ipv6_gateway||"none"}</dd></div>
        <div><dt>DHCPv6</dt><dd>${o}</dd></div>
        <div><dt>IPv4</dt><dd>${n.ipv4?d`${n.ipv4} <span class="muted">(DHCP)</span>`:"no DHCP lease"}</dd></div>
        <div><dt>IPv4 gateway</dt><dd>${n.ipv4_gateway||"none"}</dd></div>
        <div><dt>DNS servers</dt><dd>${n.dns_servers.length?a(n.dns_servers):"none"}</dd></div>
        <div><dt>MAC</dt><dd>${n.mac}</dd></div>
      </dl>
    <//>`}function xn(){let{data:e,error:t,reload:n}=M(De.get),[a,o]=v({});if(!e)return d`<${D} error=${t} />`;let s=u=>u in a?a[u]:e[u],r=(u,l)=>p=>o({...a,[u]:l?+p.target.value:p.target.value}),c=async()=>{let u={...a};if(u.web_password||delete u.web_password,Object.keys(u).length===0)return q("Nothing changed");let l=await T(()=>De.update(u),"Saved");l&&(l.restart_required&&q("Restart the gateway to apply the hostname or bitrate."),o({}),n())};return d`
    <${k} title="Settings">
      <div class="row">
        <${C} label="Hostname"><input value=${s("hostname")} onInput=${r("hostname")} /><//>
        <${C} label="CAN bitrate"><select value=${s("can_bitrate")} onChange=${r("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(u=>d`<option>${u}</option>`)}
        </select><//>
        <${C} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${s("update_delay_ms")} onInput=${r("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${C} label="User name"><input value=${s("web_username")} onInput=${r("web_username")} autocomplete="off" /><//>
        <${C} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${a.web_password||""} onInput=${r("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${c}>Save<//></div>
    <//>`}function En(){return d`
    <${k} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${we} target="gateway" label="Install and restart" />
    <//>`}var Rn=[["self_signed","Self-signed","The gateway signs its own certificate. Needs nothing else; browsers warn until you trust it."],["manual","Manual certificate","Download the CSR, have it signed by your CA, upload the certificate."],["est","EST automatic","The gateway enrolls and renews over EST (RFC 7030) with your CA."]],Fn={valid:["Valid","ok"],expires_soon:["Expires soon","warn"],expired:["Expired","bad"],not_yet_valid:["Not yet valid","bad"],fqdn_mismatch:["Not for this FQDN","warn"],time_unknown:["Valid (time not synchronised yet)","muted"]},In={self_signed:"self-signed",self_signed_fallback:"self-signed (fallback: there was no usable certificate)",manual:"uploaded",est:"EST"},Q=async(e,t)=>await T(e,t)!==void 0,Be=e=>e?new Date(e).toLocaleString():"\u2014";function Ge({label:e,accept:t,send:n,success:a,after:o}){return d`<label class="button file">${e}<input type="file" accept=${t||".pem,.crt,.cer"} onChange=${async r=>{let c=r.target.files[0];if(r.target.value="",!c)return;let u=await c.text();await Q(()=>n(u),a)&&o&&o()}} hidden /></label>`}function Ut(){let{data:e,error:t,reload:n}=M(O.get,1e4);return e?d`
    <${Nn} d=${e} />
    <${An} d=${e} reload=${n} />
    ${e.mode==="self_signed"&&d`<${Ln} d=${e} reload=${n} />`}
    ${e.mode==="manual"&&d`<${Pn} reload=${n} />`}
    ${e.mode==="est"&&d`<${Hn} d=${e} reload=${n} />`}
    <${Mn} d=${e} reload=${n} />
    <${Dn} d=${e} reload=${n} />`:d`<${D} error=${t} />`}function Ke({c:e}){return d`<dl class="facts">
    <div><dt>Subject</dt><dd>${e.subject||"\u2014"}</dd></div>
    <div><dt>Issuer</dt><dd>${e.issuer||"\u2014"}</dd></div>
    <div><dt>Valid from</dt><dd>${Be(e.not_before)}</dd></div>
    <div><dt>Valid until</dt><dd>${Be(e.not_after)}</dd></div>
    ${e.dns_names&&e.dns_names.length>0&&d`<div><dt>SAN</dt><dd>${e.dns_names.map(t=>"DNS:"+t).join(", ")}</dd></div>`}
    <div><dt>SHA-256</dt><dd><code>${e.fingerprint_sha256}</code></dd></div>
  </dl>`}function Nn({d:e}){let t=e.certificate,[n,a]=t?Fn[t.status]||[t.status,"muted"]:["none","bad"];return d`
    <${k} title="Certificate" aside=${d`<span class=${"badge "+a}>${n}</span>`}>
      ${t?d`<${Ke} c=${t} />
            <p class="muted">Made: ${In[t.origin]||t.origin}; ${t.count} certificate${t.count===1?"":"s"} in the chain.</p>`:d`<p class="error">No certificate. The gateway makes a self-signed one at the next start.</p>`}
      ${!e.https&&d`<p class="error">HTTPS is switched off (console: web-https on, then restart).</p>`}
    <//>`}function An({d:e,reload:t}){let[n,a]=v(e.fqdn),[o,s]=v(e.mode),r=async()=>{let c={};if(n!==e.fqdn&&(c.fqdn=n.trim()),o!==e.mode&&(c.mode=o),Object.keys(c).length===0)return q("Nothing changed");await Q(()=>O.update(c),"Saved")&&t()};return d`
    <${k} title="HTTPS settings">
      <div class="row">
        <${C} label="FQDN" hint=${"the name the gateway is reached by; empty: "+e.effective_fqdn}>
          <input value=${n} placeholder=${e.effective_fqdn} onInput=${c=>a(c.target.value)} />
        <//>
      </div>
      <h3>Certificate mode</h3>
      ${Rn.map(([c,u,l])=>d`
        <label class="choice">
          <input type="radio" name="mode" value=${c} checked=${o===c} onChange=${()=>s(c)} />
          <span><strong>${u}</strong><small class="muted">${l}</small></span>
        </label>`)}
      <p class="muted">Changing the FQDN in self-signed mode makes a new certificate right away; in the other modes the current one stays until the new one is there.</p>
      <div class="buttons"><${$} kind="primary" onClick=${r}>Save<//></div>
    <//>`}function Ln({d:e,reload:t}){let[n,a]=v(e.validity_years);return d`
    <${k} title="Self-signed certificate">
      <div class="row">
        <${C} label="Validity (years)" hint="1-30"><input type="number" min="1" max="30" value=${n} onInput=${s=>a(+s.target.value)} /><//>
      </div>
      <div class="buttons"><${$} onClick=${async()=>{confirm("Make a new self-signed certificate? Browsers that trusted the old one will warn again.")&&await Q(()=>O.selfSigned(n),"New certificate made; reload the page to use it")&&t()}}>Generate / regenerate<//></div>
    <//>`}function Pn({reload:e}){return d`
    <${k} title="Manual certificate">
      <p class="muted">The request is for the gateway's own key, which never leaves it. Upload the issued certificate with its chain (PEM); it replaces the current one only if it is for this key and FQDN.</p>
      <div class="buttons">
        <a class="button" href=${O.csrUrl()} download="gateway.csr">Download CSR</a>
        <${Ge} label="Upload certificate" send=${O.installCertificate} success="Certificate installed; reload the page to use it" after=${e} />
      </div>
    <//>`}function Hn({d:e,reload:t}){let n=e.est,[a,o]=v(n.url),[s,r]=v(n.auto_renew),c=async()=>{await Q(()=>O.update({est_url:a.trim(),est_auto_renew:s}),"Saved")&&t()},u=async()=>{await Q(O.enroll,"Enrollment requested")&&setTimeout(t,3e3)};return d`
    <${k} title="EST">
      <div class="row">
        <${C} label="EST server" hint="https://host[:port][/.well-known/est/label]; an IPv6 address in brackets: https://[fd00::1]"><input value=${a} onInput=${l=>o(l.target.value)} /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${s} onChange=${l=>r(l.target.checked)} /> Renew automatically (30 days before expiry)</label>
      <p>Trust anchor: ${e.trust_anchor?d`<span class="badge ok">installed</span>`:d`<span class="badge bad">missing</span> (below)`}
        ${!e.time_known&&d` · <span class="badge warn">waiting for the time (NTP)</span>`}</p>
      <dl class="facts">
        <div><dt>Last attempt</dt><dd>${Be(n.last_attempt)}</dd></div>
        <div><dt>Result</dt><dd>${n.last_result||"\u2014"}${n.last_status?` (HTTP ${n.last_status})`:""}</dd></div>
        ${n.next_attempt_in_s!=null&&d`<div><dt>Next attempt</dt><dd>in ${n.next_attempt_in_s} s</dd></div>`}
      </dl>
      <h3>Device identity (mTLS)</h3>
      <p class="muted">If the EST server wants a client certificate for the first enrollment: one PEM file with the certificate and its private key. The key can't be read back. Renewals authenticate with the current certificate.</p>
      ${n.identity&&d`<${Ke} c=${n.identity} />`}
      <div class="buttons">
        <${Ge} label=${n.identity?"Replace identity":"Install identity"} accept=".pem" send=${O.setIdentity} success="Identity installed" after=${t} />
        ${n.identity&&d`<${$} kind="danger" onClick=${async()=>await Q(O.removeIdentity,"Identity removed")&&t()}>Remove<//>`}
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${c}>Save<//>
        <${$} onClick=${u}>Enroll / renew now<//>
      </div>
    <//>`}function Mn({d:e,reload:t}){let n=e.trust_anchor;return d`
    <${k} title="Trust anchor (CA)">
      <p class="muted">The CA the EST server's certificate has to chain to. TLS to the EST server is always verified against it.</p>
      ${n?d`<${Ke} c=${n} />${n.count>1&&d`<p class="muted">${n.count} CA certificates installed; the first is shown.</p>`}`:d`<p>None installed.</p>`}
      <div class="buttons">
        <${Ge} label=${n?"Replace":"Upload"} send=${O.setTrustAnchor} success="Trust anchor installed" after=${t} />
        ${n&&d`<${$} kind="danger" onClick=${async()=>confirm("Remove the trust anchor?")&&await Q(O.removeTrustAnchor,"Removed")&&t()}>Remove<//>`}
      </div>
    <//>`}function Dn({d:e,reload:t}){let[n,a]=v(e.ntp_server),o=async()=>{await Q(()=>O.update({ntp_server:n.trim()}),"Saved; used at the next synchronisation")&&t()};return d`
    <${k} title="Time" aside=${d`<span class=${"badge "+(e.time_known?"ok":"warn")}>${e.time_known?"synchronised":"not synchronised"}</span>`}>
      <p class="muted">Certificate dates and EST need the time; the gateway has no clock of its own.</p>
      <div class="row">
        <${C} label="NTP server"><input value=${n} placeholder="automatic" onInput=${s=>a(s.target.value)} /><//>
      </div>
      <p class="muted">Empty: the server DHCPv6 names, else pool.ntp.org. In use: ${e.ntp_server_in_use}</p>
      <div class="buttons"><${$} onClick=${o}>Save<//></div>
    <//>`}var Un={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function qt(){let{data:e,error:t,reload:n}=M(se.all,5e3);return e?d`
    <${Ot} slot="primary" b=${e.primary} reload=${n} />
    <${Ot} slot="secondary" b=${e.secondary} reload=${n} />`:d`<${D} error=${t} />`}function Ot({slot:e,b:t,reload:n}){let[a,o]=v({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[s,r]=v(null),c=a.uri.startsWith("mqtts://"),u=i=>_=>o({...a,[i]:_.target.type==="checkbox"?_.target.checked:_.target.value}),l=async()=>{let i={uri:a.uri,user:a.user,enabled:a.enabled,tls_insecure:a.tls_insecure};a.password&&(i.password=a.password),await T(()=>se.update(e,i),`${e} broker saved, reconnecting`)&&(o({...a,password:""}),setTimeout(n,2500))},p=async()=>{let i=await T(()=>se.certificate(e));i&&r(i)};return d`
    <${k}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${d`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${Un[e]}</p>
      <div class="row">
        <${C} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${a.uri} onInput=${u("uri")} /><//>
        <${C} label="User"><input value=${a.user} onInput=${u("user")} autocomplete="off" /><//>
        <${C} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${a.password} onInput=${u("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${a.enabled} onChange=${u("enabled")} /> Connect to this broker</label>
      ${c&&d`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${a.tls_insecure} onChange=${u("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await T(()=>se.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),p()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${p}>Show pinned certificate<//>
            ${t.certificate_pinned&&d`<${$} kind="danger" onClick=${async()=>{await T(()=>se.forget(e),"Certificate forgotten"),r(null),n()}}>Forget<//>`}
          </div>
          ${s&&d`<p>${s.pinned?d`SHA-256 <code>${s.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var On=[{path:"/",title:"Devices",page:Mt},{path:"/devices/:device",title:"Device",page:Ht},{path:"/sensors",title:"Sensors",page:Lt},{path:"/mqtt",title:"MQTT",page:qt},{path:"/gateway",title:"Gateway",page:Dt},{path:"/https",title:"HTTPS",page:Ut}],qn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"],["/https","HTTPS"]];function Wn(){let e=Nt(),t=At(On,e),n=t?t.route.page:null,a=o=>o==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(o);return d`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${qn.map(([o,s])=>d`<${te} href=${o} class=${a(o)?"active":""}>${s}<//>`)}</nav>
    </header>
    <main>
      ${n?d`<${n} key=${e} ...${t.params} />`:d`<p class="error">No such page. <${te} href="/">Devices<//></p>`}
    </main>
    <${Ft} />`}dt(d`<${Wn} />`,document.getElementById("app"));
