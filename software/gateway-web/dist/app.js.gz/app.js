var Mt=Object.create;var De=Object.defineProperty;var Nt=Object.getOwnPropertyDescriptor;var Pt=Object.getOwnPropertyNames;var Ut=Object.getPrototypeOf,Dt=Object.prototype.hasOwnProperty;var Ot=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var qt=(e,t,n,o)=>{if(t&&typeof t=="object"||typeof t=="function")for(let a of Pt(t))!Dt.call(e,a)&&a!==n&&De(e,a,{get:()=>t[a],enumerable:!(o=Nt(t,a))||o.enumerable});return e};var Wt=(e,t,n)=>(n=e!=null?Mt(Ut(e)):{},qt(t||!e||!e.__esModule?De(n,"default",{value:e,enumerable:!0}):n,e));var $t=Ot(Fe=>{var ht;(function(e){typeof DO_NOT_EXPORT_CRC>"u"?typeof Fe=="object"?e(Fe):typeof define=="function"&&define.amd?define(function(){var t={};return e(t),t}):e(ht={}):e(ht={})})(function(e){e.version="1.2.2";function t(){for(var p=0,H=new Array(256),m=0;m!=256;++m)p=m,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,p=p&1?-306674912^p>>>1:p>>>1,H[m]=p;return typeof Int32Array<"u"?new Int32Array(H):H}var n=t();function o(p){var H=0,m=0,b=0,v=typeof Int32Array<"u"?new Int32Array(4096):new Array(4096);for(b=0;b!=256;++b)v[b]=p[b];for(b=0;b!=256;++b)for(m=p[b],H=256+b;H<4096;H+=256)m=v[H]=m>>>8^p[m&255];var C=[];for(b=1;b!=16;++b)C[b-1]=typeof Int32Array<"u"?v.subarray(b*256,b*256+256):v.slice(b*256,b*256+256);return C}var a=o(n),r=a[0],s=a[1],u=a[2],c=a[3],l=a[4],d=a[5],i=a[6],f=a[7],h=a[8],g=a[9],A=a[10],E=a[11],k=a[12],w=a[13],j=a[14];function U(p,H){for(var m=H^-1,b=0,v=p.length;b<v;)m=m>>>8^n[(m^p.charCodeAt(b++))&255];return~m}function X(p,H){for(var m=H^-1,b=p.length-15,v=0;v<b;)m=j[p[v++]^m&255]^w[p[v++]^m>>8&255]^k[p[v++]^m>>16&255]^E[p[v++]^m>>>24]^A[p[v++]]^g[p[v++]]^h[p[v++]]^f[p[v++]]^i[p[v++]]^d[p[v++]]^l[p[v++]]^c[p[v++]]^u[p[v++]]^s[p[v++]]^r[p[v++]]^n[p[v++]];for(b+=15;v<b;)m=m>>>8^n[(m^p[v++])&255];return~m}function V(p,H){for(var m=H^-1,b=0,v=p.length,C=0,ye=0;b<v;)C=p.charCodeAt(b++),C<128?m=m>>>8^n[(m^C)&255]:C<2048?(m=m>>>8^n[(m^(192|C>>6&31))&255],m=m>>>8^n[(m^(128|C&63))&255]):C>=55296&&C<57344?(C=(C&1023)+64,ye=p.charCodeAt(b++)&1023,m=m>>>8^n[(m^(240|C>>8&7))&255],m=m>>>8^n[(m^(128|C>>2&63))&255],m=m>>>8^n[(m^(128|ye>>6&15|(C&3)<<4))&255],m=m>>>8^n[(m^(128|ye&63))&255]):(m=m>>>8^n[(m^(224|C>>12&15))&255],m=m>>>8^n[(m^(128|C>>6&63))&255],m=m>>>8^n[(m^(128|C&63))&255]);return~m}e.table=n,e.bstr=U,e.buf=X,e.str=V})});var pe,x,Ve,jt,B,Oe,Be,Ge,Ke,we,be,ke,Vt,oe={},Je=[],Bt=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,fe=Array.isArray;function O(e,t){for(var n in t)e[n]=t[n];return e}function Se(e){e&&e.parentNode&&e.parentNode.removeChild(e)}function re(e,t,n){var o,a,r,s={};for(r in t)r=="key"?o=t[r]:r=="ref"?a=t[r]:s[r]=t[r];if(arguments.length>2&&(s.children=arguments.length>3?pe.call(arguments,2):n),typeof e=="function"&&e.defaultProps!=null)for(r in e.defaultProps)s[r]===void 0&&(s[r]=e.defaultProps[r]);return ue(e,s,o,a,null)}function ue(e,t,n,o,a){var r={type:e,props:t,key:n,ref:o,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:a??++Ve,__i:-1,__u:0};return a==null&&x.vnode!=null&&x.vnode(r),r}function me(e){return e.children}function _e(e,t){this.props=e,this.context=t}function Y(e,t){if(t==null)return e.__?Y(e.__,e.__i+1):null;for(var n;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null)return n.__e;return typeof e.type=="function"?Y(e):null}function Qe(e){var t,n;if((e=e.__)!=null&&e.__c!=null){for(e.__e=e.__c.base=null,t=0;t<e.__k.length;t++)if((n=e.__k[t])!=null&&n.__e!=null){e.__e=e.__c.base=n.__e;break}return Qe(e)}}function qe(e){(!e.__d&&(e.__d=!0)&&B.push(e)&&!de.__r++||Oe!=x.debounceRendering)&&((Oe=x.debounceRendering)||Be)(de)}function de(){for(var e,t,n,o,a,r,s,u=1;B.length;)B.length>u&&B.sort(Ge),e=B.shift(),u=B.length,e.__d&&(n=void 0,a=(o=(t=e).__v).__e,r=[],s=[],t.__P&&((n=O({},o)).__v=o.__v+1,x.vnode&&x.vnode(n),xe(t.__P,n,o,t.__n,t.__P.namespaceURI,32&o.__u?[a]:null,r,a??Y(o),!!(32&o.__u),s),n.__v=o.__v,n.__.__k[n.__i]=n,Ye(r,n,s),n.__e!=a&&Qe(n)));de.__r=0}function ze(e,t,n,o,a,r,s,u,c,l,d){var i,f,h,g,A,E,k=o&&o.__k||Je,w=t.length;for(c=Gt(n,t,k,c,w),i=0;i<w;i++)(h=n.__k[i])!=null&&(f=h.__i==-1?oe:k[h.__i]||oe,h.__i=i,E=xe(e,h,f,a,r,s,u,c,l,d),g=h.__e,h.ref&&f.ref!=h.ref&&(f.ref&&Ce(f.ref,null,h),d.push(h.ref,h.__c||g,h)),A==null&&g!=null&&(A=g),4&h.__u||f.__k===h.__k?c=Xe(h,c,e):typeof h.type=="function"&&E!==void 0?c=E:g&&(c=g.nextSibling),h.__u&=-7);return n.__e=A,c}function Gt(e,t,n,o,a){var r,s,u,c,l,d=n.length,i=d,f=0;for(e.__k=new Array(a),r=0;r<a;r++)(s=t[r])!=null&&typeof s!="boolean"&&typeof s!="function"?(c=r+f,(s=e.__k[r]=typeof s=="string"||typeof s=="number"||typeof s=="bigint"||s.constructor==String?ue(null,s,null,null,null):fe(s)?ue(me,{children:s},null,null,null):s.constructor==null&&s.__b>0?ue(s.type,s.props,s.key,s.ref?s.ref:null,s.__v):s).__=e,s.__b=e.__b+1,u=null,(l=s.__i=Kt(s,n,c,i))!=-1&&(i--,(u=n[l])&&(u.__u|=2)),u==null||u.__v==null?(l==-1&&(a>d?f--:a<d&&f++),typeof s.type!="function"&&(s.__u|=4)):l!=c&&(l==c-1?f--:l==c+1?f++:(l>c?f--:f++,s.__u|=4))):e.__k[r]=null;if(i)for(r=0;r<d;r++)(u=n[r])!=null&&(2&u.__u)==0&&(u.__e==o&&(o=Y(u)),et(u,u));return o}function Xe(e,t,n){var o,a;if(typeof e.type=="function"){for(o=e.__k,a=0;o&&a<o.length;a++)o[a]&&(o[a].__=e,t=Xe(o[a],t,n));return t}e.__e!=t&&(t&&e.type&&!n.contains(t)&&(t=Y(e)),n.insertBefore(e.__e,t||null),t=e.__e);do t=t&&t.nextSibling;while(t!=null&&t.nodeType==8);return t}function Kt(e,t,n,o){var a,r,s=e.key,u=e.type,c=t[n];if(c===null&&e.key==null||c&&s==c.key&&u==c.type&&(2&c.__u)==0)return n;if(o>(c!=null&&(2&c.__u)==0?1:0))for(a=n-1,r=n+1;a>=0||r<t.length;){if(a>=0){if((c=t[a])&&(2&c.__u)==0&&s==c.key&&u==c.type)return a;a--}if(r<t.length){if((c=t[r])&&(2&c.__u)==0&&s==c.key&&u==c.type)return r;r++}}return-1}function We(e,t,n){t[0]=="-"?e.setProperty(t,n??""):e[t]=n==null?"":typeof n!="number"||Bt.test(t)?n:n+"px"}function ce(e,t,n,o,a){var r,s;e:if(t=="style")if(typeof n=="string")e.style.cssText=n;else{if(typeof o=="string"&&(e.style.cssText=o=""),o)for(t in o)n&&t in n||We(e.style,t,"");if(n)for(t in n)o&&n[t]==o[t]||We(e.style,t,n[t])}else if(t[0]=="o"&&t[1]=="n")r=t!=(t=t.replace(Ke,"$1")),s=t.toLowerCase(),t=s in e||t=="onFocusOut"||t=="onFocusIn"?s.slice(2):t.slice(2),e.l||(e.l={}),e.l[t+r]=n,n?o?n.u=o.u:(n.u=we,e.addEventListener(t,r?ke:be,r)):e.removeEventListener(t,r?ke:be,r);else{if(a=="http://www.w3.org/2000/svg")t=t.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(t!="width"&&t!="height"&&t!="href"&&t!="list"&&t!="form"&&t!="tabIndex"&&t!="download"&&t!="rowSpan"&&t!="colSpan"&&t!="role"&&t!="popover"&&t in e)try{e[t]=n??"";break e}catch{}typeof n=="function"||(n==null||n===!1&&t[4]!="-"?e.removeAttribute(t):e.setAttribute(t,t=="popover"&&n==1?"":n))}}function je(e){return function(t){if(this.l){var n=this.l[t.type+e];if(t.t==null)t.t=we++;else if(t.t<n.u)return;return n(x.event?x.event(t):t)}}}function xe(e,t,n,o,a,r,s,u,c,l){var d,i,f,h,g,A,E,k,w,j,U,X,V,p,H,m,b,v=t.type;if(t.constructor!=null)return null;128&n.__u&&(c=!!(32&n.__u),r=[u=t.__e=n.__e]),(d=x.__b)&&d(t);e:if(typeof v=="function")try{if(k=t.props,w="prototype"in v&&v.prototype.render,j=(d=v.contextType)&&o[d.__c],U=d?j?j.props.value:d.__:o,n.__c?E=(i=t.__c=n.__c).__=i.__E:(w?t.__c=i=new v(k,U):(t.__c=i=new _e(k,U),i.constructor=v,i.render=Qt),j&&j.sub(i),i.props=k,i.state||(i.state={}),i.context=U,i.__n=o,f=i.__d=!0,i.__h=[],i._sb=[]),w&&i.__s==null&&(i.__s=i.state),w&&v.getDerivedStateFromProps!=null&&(i.__s==i.state&&(i.__s=O({},i.__s)),O(i.__s,v.getDerivedStateFromProps(k,i.__s))),h=i.props,g=i.state,i.__v=t,f)w&&v.getDerivedStateFromProps==null&&i.componentWillMount!=null&&i.componentWillMount(),w&&i.componentDidMount!=null&&i.__h.push(i.componentDidMount);else{if(w&&v.getDerivedStateFromProps==null&&k!==h&&i.componentWillReceiveProps!=null&&i.componentWillReceiveProps(k,U),!i.__e&&i.shouldComponentUpdate!=null&&i.shouldComponentUpdate(k,i.__s,U)===!1||t.__v==n.__v){for(t.__v!=n.__v&&(i.props=k,i.state=i.__s,i.__d=!1),t.__e=n.__e,t.__k=n.__k,t.__k.some(function(C){C&&(C.__=t)}),X=0;X<i._sb.length;X++)i.__h.push(i._sb[X]);i._sb=[],i.__h.length&&s.push(i);break e}i.componentWillUpdate!=null&&i.componentWillUpdate(k,i.__s,U),w&&i.componentDidUpdate!=null&&i.__h.push(function(){i.componentDidUpdate(h,g,A)})}if(i.context=U,i.props=k,i.__P=e,i.__e=!1,V=x.__r,p=0,w){for(i.state=i.__s,i.__d=!1,V&&V(t),d=i.render(i.props,i.state,i.context),H=0;H<i._sb.length;H++)i.__h.push(i._sb[H]);i._sb=[]}else do i.__d=!1,V&&V(t),d=i.render(i.props,i.state,i.context),i.state=i.__s;while(i.__d&&++p<25);i.state=i.__s,i.getChildContext!=null&&(o=O(O({},o),i.getChildContext())),w&&!f&&i.getSnapshotBeforeUpdate!=null&&(A=i.getSnapshotBeforeUpdate(h,g)),m=d,d!=null&&d.type===me&&d.key==null&&(m=Ze(d.props.children)),u=ze(e,fe(m)?m:[m],t,n,o,a,r,s,u,c,l),i.base=t.__e,t.__u&=-161,i.__h.length&&s.push(i),E&&(i.__E=i.__=null)}catch(C){if(t.__v=null,c||r!=null)if(C.then){for(t.__u|=c?160:128;u&&u.nodeType==8&&u.nextSibling;)u=u.nextSibling;r[r.indexOf(u)]=null,t.__e=u}else for(b=r.length;b--;)Se(r[b]);else t.__e=n.__e,t.__k=n.__k;x.__e(C,t,n)}else r==null&&t.__v==n.__v?(t.__k=n.__k,t.__e=n.__e):u=t.__e=Jt(n.__e,t,n,o,a,r,s,c,l);return(d=x.diffed)&&d(t),128&t.__u?void 0:u}function Ye(e,t,n){for(var o=0;o<n.length;o++)Ce(n[o],n[++o],n[++o]);x.__c&&x.__c(t,e),e.some(function(a){try{e=a.__h,a.__h=[],e.some(function(r){r.call(a)})}catch(r){x.__e(r,a.__v)}})}function Ze(e){return typeof e!="object"||e==null||e.__b&&e.__b>0?e:fe(e)?e.map(Ze):O({},e)}function Jt(e,t,n,o,a,r,s,u,c){var l,d,i,f,h,g,A,E=n.props,k=t.props,w=t.type;if(w=="svg"?a="http://www.w3.org/2000/svg":w=="math"?a="http://www.w3.org/1998/Math/MathML":a||(a="http://www.w3.org/1999/xhtml"),r!=null){for(l=0;l<r.length;l++)if((h=r[l])&&"setAttribute"in h==!!w&&(w?h.localName==w:h.nodeType==3)){e=h,r[l]=null;break}}if(e==null){if(w==null)return document.createTextNode(k);e=document.createElementNS(a,w,k.is&&k),u&&(x.__m&&x.__m(t,r),u=!1),r=null}if(w==null)E===k||u&&e.data==k||(e.data=k);else{if(r=r&&pe.call(e.childNodes),E=n.props||oe,!u&&r!=null)for(E={},l=0;l<e.attributes.length;l++)E[(h=e.attributes[l]).name]=h.value;for(l in E)if(h=E[l],l!="children"){if(l=="dangerouslySetInnerHTML")i=h;else if(!(l in k)){if(l=="value"&&"defaultValue"in k||l=="checked"&&"defaultChecked"in k)continue;ce(e,l,null,h,a)}}for(l in k)h=k[l],l=="children"?f=h:l=="dangerouslySetInnerHTML"?d=h:l=="value"?g=h:l=="checked"?A=h:u&&typeof h!="function"||E[l]===h||ce(e,l,h,E[l],a);if(d)u||i&&(d.__html==i.__html||d.__html==e.innerHTML)||(e.innerHTML=d.__html),t.__k=[];else if(i&&(e.innerHTML=""),ze(t.type=="template"?e.content:e,fe(f)?f:[f],t,n,o,w=="foreignObject"?"http://www.w3.org/1999/xhtml":a,r,s,r?r[0]:n.__k&&Y(n,0),u,c),r!=null)for(l=r.length;l--;)Se(r[l]);u||(l="value",w=="progress"&&g==null?e.removeAttribute("value"):g!=null&&(g!==e[l]||w=="progress"&&!g||w=="option"&&g!=E[l])&&ce(e,l,g,E[l],a),l="checked",A!=null&&A!=e[l]&&ce(e,l,A,E[l],a))}return e}function Ce(e,t,n){try{if(typeof e=="function"){var o=typeof e.__u=="function";o&&e.__u(),o&&t==null||(e.__u=e(t))}else e.current=t}catch(a){x.__e(a,n)}}function et(e,t,n){var o,a;if(x.unmount&&x.unmount(e),(o=e.ref)&&(o.current&&o.current!=e.__e||Ce(o,null,t)),(o=e.__c)!=null){if(o.componentWillUnmount)try{o.componentWillUnmount()}catch(r){x.__e(r,t)}o.base=o.__P=null}if(o=e.__k)for(a=0;a<o.length;a++)o[a]&&et(o[a],t,n||typeof e.type!="function");n||Se(e.__e),e.__c=e.__=e.__e=void 0}function Qt(e,t,n){return this.constructor(e,n)}function tt(e,t,n){var o,a,r,s;t==document&&(t=document.documentElement),x.__&&x.__(e,t),a=(o=typeof n=="function")?null:n&&n.__k||t.__k,r=[],s=[],xe(t,e=(!o&&n||t).__k=re(me,null,[e]),a||oe,oe,t.namespaceURI,!o&&n?[n]:a?null:t.firstChild?pe.call(t.childNodes):null,r,!o&&n?n:a?a.__e:t.firstChild,o,s),Ye(r,e,s)}pe=Je.slice,x={__e:function(e,t,n,o){for(var a,r,s;t=t.__;)if((a=t.__c)&&!a.__)try{if((r=a.constructor)&&r.getDerivedStateFromError!=null&&(a.setState(r.getDerivedStateFromError(e)),s=a.__d),a.componentDidCatch!=null&&(a.componentDidCatch(e,o||{}),s=a.__d),s)return a.__E=a}catch(u){e=u}throw e}},Ve=0,jt=function(e){return e!=null&&e.constructor==null},_e.prototype.setState=function(e,t){var n;n=this.__s!=null&&this.__s!=this.state?this.__s:this.__s=O({},this.state),typeof e=="function"&&(e=e(O({},n),this.props)),e&&O(n,e),e!=null&&this.__v&&(t&&this._sb.push(t),qe(this))},_e.prototype.forceUpdate=function(e){this.__v&&(this.__e=!0,e&&this.__h.push(e),qe(this))},_e.prototype.render=me,B=[],Be=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,Ge=function(e,t){return e.__v.__b-t.__v.__b},de.__r=0,Ke=/(PointerCapture)$|Capture$/i,we=0,be=je(!1),ke=je(!0),Vt=0;var ae,R,Te,nt,se=0,ut=[],L=x,ot=L.__b,rt=L.__r,at=L.diffed,st=L.__c,it=L.unmount,lt=L.__;function Re(e,t){L.__h&&L.__h(R,e,se||t),se=0;var n=R.__H||(R.__H={__:[],__h:[]});return e>=n.__.length&&n.__.push({}),n.__[e]}function y(e){return se=1,zt(mt,e)}function zt(e,t,n){var o=Re(ae++,2);if(o.t=e,!o.__c&&(o.__=[n?n(t):mt(void 0,t),function(u){var c=o.__N?o.__N[0]:o.__[0],l=o.t(c,u);c!==l&&(o.__N=[l,o.__[1]],o.__c.setState({}))}],o.__c=R,!R.__f)){var a=function(u,c,l){if(!o.__c.__H)return!0;var d=o.__c.__H.__.filter(function(f){return!!f.__c});if(d.every(function(f){return!f.__N}))return!r||r.call(this,u,c,l);var i=o.__c.props!==u;return d.forEach(function(f){if(f.__N){var h=f.__[0];f.__=f.__N,f.__N=void 0,h!==f.__[0]&&(i=!0)}}),r&&r.call(this,u,c,l)||i};R.__f=!0;var r=R.shouldComponentUpdate,s=R.componentWillUpdate;R.componentWillUpdate=function(u,c,l){if(this.__e){var d=r;r=void 0,a(u,c,l),r=d}s&&s.call(this,u,c,l)},R.shouldComponentUpdate=a}return o.__N||o.__}function ie(e,t){var n=Re(ae++,3);!L.__s&&ft(n.__H,t)&&(n.__=e,n.u=t,R.__H.__h.push(n))}function _t(e){return se=5,dt(function(){return{current:e}},[])}function dt(e,t){var n=Re(ae++,7);return ft(n.__H,t)&&(n.__=e(),n.__H=t,n.__h=e),n.__}function pt(e,t){return se=8,dt(function(){return e},t)}function Xt(){for(var e;e=ut.shift();)if(e.__P&&e.__H)try{e.__H.__h.forEach(he),e.__H.__h.forEach(Ee),e.__H.__h=[]}catch(t){e.__H.__h=[],L.__e(t,e.__v)}}L.__b=function(e){R=null,ot&&ot(e)},L.__=function(e,t){e&&t.__k&&t.__k.__m&&(e.__m=t.__k.__m),lt&&lt(e,t)},L.__r=function(e){rt&&rt(e),ae=0;var t=(R=e.__c).__H;t&&(Te===R?(t.__h=[],R.__h=[],t.__.forEach(function(n){n.__N&&(n.__=n.__N),n.u=n.__N=void 0})):(t.__h.forEach(he),t.__h.forEach(Ee),t.__h=[],ae=0)),Te=R},L.diffed=function(e){at&&at(e);var t=e.__c;t&&t.__H&&(t.__H.__h.length&&(ut.push(t)!==1&&nt===L.requestAnimationFrame||((nt=L.requestAnimationFrame)||Yt)(Xt)),t.__H.__.forEach(function(n){n.u&&(n.__H=n.u),n.u=void 0})),Te=R=null},L.__c=function(e,t){t.some(function(n){try{n.__h.forEach(he),n.__h=n.__h.filter(function(o){return!o.__||Ee(o)})}catch(o){t.some(function(a){a.__h&&(a.__h=[])}),t=[],L.__e(o,n.__v)}}),st&&st(e,t)},L.unmount=function(e){it&&it(e);var t,n=e.__c;n&&n.__H&&(n.__H.__.forEach(function(o){try{he(o)}catch(a){t=a}}),n.__H=void 0,t&&L.__e(t,n.__v))};var ct=typeof requestAnimationFrame=="function";function Yt(e){var t,n=function(){clearTimeout(o),ct&&cancelAnimationFrame(t),setTimeout(e)},o=setTimeout(n,35);ct&&(t=requestAnimationFrame(n))}function he(e){var t=R,n=e.__c;typeof n=="function"&&(e.__c=void 0,n()),R=t}function Ee(e){var t=R;e.__c=e.__(),R=t}function ft(e,t){return!e||e.length!==t.length||t.some(function(n,o){return n!==e[o]})}function mt(e,t){return typeof t=="function"?t(e):t}var vt=Wt($t()),gt="/api/v1",Z=class extends Error{constructor(t,n){super(n&&n.message?n.message:`HTTP ${t}`),this.status=t,this.code=n&&n.error}},Zt=e=>new Promise(t=>setTimeout(t,e));async function le(e,t,n){for(let o=1;;o++){let a;try{a=await fetch(gt+t,{method:e,headers:n===void 0?{}:{"Content-Type":"application/json"},body:n===void 0?void 0:JSON.stringify(n)})}catch{if(o>=4)throw new Z(0,{message:"gateway unreachable"});await Zt(250*o);continue}let r=await a.text(),s=null;try{s=r?JSON.parse(r):null}catch{s={message:r}}if(!a.ok)throw new Z(a.status,s);return s}}var q=e=>le("GET",e),G=(e,t)=>le("POST",e,t),W=(e,t)=>le("PUT",e,t),Le=(e,t)=>le("PATCH",e,t),en=e=>le("DELETE",e),M=encodeURIComponent,Ae={get:()=>q("/system"),restart:()=>G("/system/restart")},He={get:()=>q("/config"),update:e=>Le("/config",e)},ee={all:()=>q("/mqtt"),update:(e,t)=>Le(`/mqtt/${e}`,t),trust:e=>G(`/mqtt/${e}/trust`),certificate:e=>q(`/mqtt/${e}/certificate`),forget:e=>en(`/mqtt/${e}/certificate`)},I={async list(){let e=[];for(;;){let t=await q(`/devices?offset=${e.length}`);if(e.push(...t.devices),t.devices.length===0||e.length>=t.total)return e}},get:e=>q(`/devices/${M(e)}`),update:(e,t)=>Le(`/devices/${M(e)}`,t),action:(e,t)=>G(`/devices/${M(e)}/${t}`),silence:(e,t)=>W(`/devices/${M(e)}/silence`,{on:t}),relay:(e,t,n,o)=>W(`/devices/${M(e)}/relays/${t}`,{state:n,duration_ms:o}),rollershutter:(e,t,n,o)=>W(`/devices/${M(e)}/rollershutters/${t}`,{state:n,duration_ms:o}),lamps:(e,t,n,o)=>W(`/devices/${M(e)}/lamps/${t}`,{value:n,bitmask:o}),heating:(e,t,n)=>W(`/devices/${M(e)}/heating/${t}`,n),heatingManualState:e=>q(`/devices/${M(e)}/heating/manual`),heatingManual:(e,t,n,o)=>W(`/devices/${M(e)}/heating/manual`,n===void 0?{enabled:t}:{enabled:t,relay:n,on:o})},K={update:(e,t,n)=>W(`/devices/${M(e)}/sensors/${t}`,n),refresh:e=>G(`/devices/${M(e)}/sensors/refresh`),forget:e=>G(`/devices/${M(e)}/sensors/forget`),async list(e){let t=[];for(;;){let n=e?`&device=${M(e)}`:"",o=await q(`/sensors?offset=${t.length}${n}`);if(t.push(...o.sensors),o.sensors.length===0||t.length>=o.total)return t}}},J={action:e=>G(`/bus/${e}`),silence:e=>W("/bus/silence",{on:e}),typeAction:(e,t)=>G(`/device-types/${e}/${t}`)},yt={job:()=>q("/firmware/job"),upload(e,t,n){let o=vt.default.buf(new Uint8Array(t))>>>0,a=e==="gateway"?"/firmware/gateway":`/${e}/firmware`;return new Promise((r,s)=>{let u=new XMLHttpRequest;u.open("PUT",`${gt}${a}?crc32=${o}`),u.setRequestHeader("Content-Type","application/octet-stream"),u.upload.onprogress=c=>c.lengthComputable&&n&&n(c.loaded/c.total),u.onload=()=>{let c=null;try{c=JSON.parse(u.responseText)}catch{}u.status>=200&&u.status<300?r(c):s(new Z(u.status,c))},u.onerror=()=>s(new Z(0,{message:"upload failed"})),u.send(t)})}};var kt=function(e,t,n,o){var a;t[0]=0;for(var r=1;r<t.length;r++){var s=t[r++],u=t[r]?(t[0]|=s?1:2,n[t[r++]]):t[++r];s===3?o[0]=u:s===4?o[1]=Object.assign(o[1]||{},u):s===5?(o[1]=o[1]||{})[t[++r]]=u:s===6?o[1][t[++r]]+=u+"":s?(a=e.apply(u,kt(e,u,n,["",null])),o.push(a),u[0]?t[0]|=2:(t[r-2]=0,t[r]=a)):o.push(u)}return o},bt=new Map;function wt(e){var t=bt.get(this);return t||(t=new Map,bt.set(this,t)),(t=kt(this,t.get(e)||(t.set(e,t=function(n){for(var o,a,r=1,s="",u="",c=[0],l=function(f){r===1&&(f||(s=s.replace(/^\s*\n\s*|\s*\n\s*$/g,"")))?c.push(0,f,s):r===3&&(f||s)?(c.push(3,f,s),r=2):r===2&&s==="..."&&f?c.push(4,f,0):r===2&&s&&!f?c.push(5,0,!0,s):r>=5&&((s||!f&&r===5)&&(c.push(r,0,s,a),r=6),f&&(c.push(r,f,0,a),r=6)),s=""},d=0;d<n.length;d++){d&&(r===1&&l(),l(d));for(var i=0;i<n[d].length;i++)o=n[d][i],r===1?o==="<"?(l(),c=[c],r=3):s+=o:r===4?s==="--"&&o===">"?(r=1,s=""):s=o+s[0]:u?o===u?u="":s+=o:o==='"'||o==="'"?u=o:o===">"?(l(),r=1):r&&(o==="="?(r=5,a=s,s=""):o==="/"&&(r<5||n[d][i+1]===">")?(l(),r===3&&(c=c[0]),r=c,(c=c[0]).push(2,0,r),r=0):o===" "||o==="	"||o===`
`||o==="\r"?(l(),r=2):s+=o),r===3&&s==="!--"&&(r=4,c=c[0])}return l(),c}(e)),t),arguments,[])).length>1?t:t[0]}var _=wt.bind(re),Ie=()=>{};function D(e,t="ok"){Ie(e,t)}function St(){let[e,t]=y([]);return ie(()=>{let n=0;return Ie=(o,a)=>{let r={id:++n,message:o,kind:a};t(s=>[...s,r]),setTimeout(()=>t(s=>s.filter(u=>u!==r)),a==="error"?8e3:3e3)},()=>Ie=()=>{}},[]),_`<div class="toasts">
    ${e.map(n=>_`<div key=${n.id} class=${"toast "+n.kind}>${n.message}</div>`)}
  </div>`}async function S(e,t){try{let n=await e();return t&&D(t),n}catch(n){D(n.message,"error");return}}function N(e,t){let[n,o]=y({data:void 0,error:void 0}),a=_t(e);a.current=e;let r=pt(async()=>{try{o({data:await a.current(),error:void 0})}catch(s){o(u=>({data:u.data,error:s}))}},[]);return ie(()=>{let s=!1,u,c=async()=>{await r(),t&&!s&&(u=setTimeout(c,t))};return c(),()=>{s=!0,clearTimeout(u)}},[t,r]),{...n,reload:r}}var F=({title:e,children:t,aside:n})=>_`
  <section class="card">
    <header><h2>${e}</h2>${n}</header>
    ${t}
  </section>`,P=({error:e})=>e?_`<p class="error">${e.message}</p>`:_`<p class="muted">Loading…</p>`,T=({label:e,hint:t,children:n})=>_`
  <label class="field">
    <span>${e}</span>
    ${n}
    ${t&&_`<small>${t}</small>`}
  </label>`,$=({children:e,kind:t,onClick:n,disabled:o})=>{let[a,r]=y(!1);return _`<button class=${t||""} disabled=${o||a} onClick=${async u=>{r(!0);try{await n(u)}finally{r(!1)}}}>${e}</button>`},Me=e=>"0x"+e.toString(16).padStart(2,"0");function Q(e){return e<1?"now":e<60?`${e} min`:e<1440?`${Math.floor(e/60)} h`:`${Math.floor(e/1440)} d`}function xt(e){let t=Math.floor(e/86400),n=Math.floor(e%86400/3600),o=Math.floor(e%3600/60);return t?`${t} d ${n} h`:n?`${n} h ${o} min`:`${o} min`}function $e({target:e,label:t,onDone:n}){let[o,a]=y(null),[r,s]=y(null);return _`
    <div class="upload">
      <input type="file" accept=".bin" onChange=${c=>a(c.target.files[0]||null)} />
      <${$} onClick=${async()=>{if(o){s(0);try{let c=await o.arrayBuffer(),l=await yt.upload(e,c,s);D(l&&l.restarting?"Firmware installed, the gateway restarts\u2026":"Firmware sent"),n&&n(l)}catch(c){D(c.message,"error")}s(null)}}} disabled=${!o||r!==null}>${t||"Upload"}<//>
      ${r!==null&&_`<progress max="1" value=${r}></progress>`}
    </div>`}var ve=new Set;function tn(e){e!==location.pathname&&history.pushState(null,"",e),ve.forEach(t=>t())}addEventListener("popstate",()=>ve.forEach(e=>e()));function Ct(){let[e,t]=y(location.pathname);return ie(()=>{let n=()=>t(location.pathname);return ve.add(n),()=>ve.delete(n)},[]),e}function Tt(e,t){let n=t.split("/").filter(Boolean);for(let o of e){let a=o.path.split("/").filter(Boolean);if(a.length!==n.length)continue;let r={};if(a.every((u,c)=>u.startsWith(":")?(r[u.slice(1)]=decodeURIComponent(n[c]),!0):u===n[c]))return{route:o,params:r}}return null}function z({href:e,children:t,...n}){return re("a",{href:e,onClick:a=>{a.metaKey||a.ctrlKey||a.shiftKey||a.button!==0||(a.preventDefault(),tn(e))},...n},t)}var nn={temperature:"Temperature",humidity:"Humidity",pressure:"Pressure",co2:"CO\u2082",voc:"VOC",air_quality:"Air quality"},Ne=["none","tank0","tank1","tank2","tank3","tank4","tank5","tank6","flow"],on={none:"\u2013",flow:"Flow",...Object.fromEntries([0,1,2,3,4,5,6].map(e=>[`tank${e}`,`Tank ${e}${e===0?" (top)":e===6?" (bottom)":""}`]))},ne=e=>on[e]||e;function ge(e,t=5e3){let n=N(()=>K.list(e),t),o=[...new Set((n.data||[]).map(r=>r.device))];return{...n,ask:async()=>{for(let r of e?[e]:o)await S(()=>K.refresh(r));setTimeout(n.reload,1500)}}}function rn({s:e,device:t,reload:n}){let[o,a]=y(!1),[r,s]=y(e.name||""),[u,c]=y(e.role||"none"),l=async()=>{let d={};if(r!==(e.name||"")&&(d.name=r),u!==(e.role||"none")&&(d.role=u),Object.keys(d).length===0)return a(!1);await S(()=>K.update(e.device,e.slot,d),"Sent to the device")&&(a(!1),setTimeout(n,1500))};return _`<tr>
    ${!t&&_`<td><${z} href=${"/devices/"+encodeURIComponent(e.device)}>${e.device}<//></td>`}
    <td>${o?_`<input class="inline" maxlength="7" placeholder="name" value=${r} onInput=${d=>s(d.target.value)} />`:e.name||_`<span class="muted">–</span>`}</td>
    <td>${nn[e.kind]||e.kind}</td>
    <td>${o?_`<select value=${u} onChange=${d=>c(d.target.value)}>${Ne.map(d=>_`<option value=${d}>${ne(d)}</option>`)}</select>`:e.role&&e.role!=="none"?ne(e.role):_`<span class="muted">–</span>`}</td>
    <td><code>${e.sensor_id}</code>${e.slot!==null&&_` <small class="muted">slot ${e.slot}</small>`}</td>
    <td>${e.lost?_`<span class="badge bad">lost</span>`:`${e.kind==="temperature"?e.value.toFixed(2):e.value} ${e.unit}`}</td>
    <td>${e.age_s<60?`${e.age_s} s`:Q(Math.floor(e.age_s/60))}</td>
    <td class="actions">${e.slot===null?"":o?_`<${$} kind="primary" onClick=${l}>Save<//> <button onClick=${()=>a(!1)}>Cancel</button>`:_`<button onClick=${()=>a(!0)}>Edit</button>`}</td>
  </tr>`}function Pe({device:e}){let{data:t,error:n,reload:o,ask:a}=ge(e);if(!t)return _`<${P} error=${n} />`;if(t.length===0)return _`<p class="muted">No sensor reading seen yet.</p>`;let r=t.some(s=>s.slot===null);return _`
    ${r&&_`<p class="muted">The names and roles of some sensors are not known yet. <${$} onClick=${a}>Ask the device<//></p>`}
    <div class="table-wrap"><table>
      <thead><tr>${!e&&_`<th>Device</th>`}<th>Name</th><th>Kind</th><th>Role</th><th>Sensor</th><th>Value</th><th>Seen</th><th></th></tr></thead>
      <tbody>
        ${t.map(s=>_`<${rn} key=${s.device_key+s.kind+s.sensor_id} s=${s} device=${e} reload=${o} />`)}
      </tbody>
    </table></div>`}function Et(){let{ask:e}=ge(void 0,0);return _`<${F} title="Sensors" aside=${_`<${$} onClick=${e}>Reload names and roles<//>`}>
    <${Pe} />
  <//>`}var an=[2,5,8,9],sn=[7],ln=[3],Ue=[9],cn=["OFF","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER"],un=["OFF","BUTTONS","RELAIS","SWROLLERSHUTTER","HWROLLERSHUTTER","PWM","SENSORS","LEGACY_SENSORS"];function Ft({device:e}){let{data:t,error:n,reload:o}=N(()=>I.get(e),5e3);return t?_`
    <${_n} d=${t} reload=${o} />
    ${an.includes(t.device_type)&&_`<${Rt} d=${t} kind="relay" />`}
    ${sn.includes(t.device_type)&&_`<${Rt} d=${t} kind="rollershutter" />`}
    ${ln.includes(t.device_type)&&_`<${dn} d=${t} />`}
    ${Ue.includes(t.device_type)&&_`<${pn} d=${t} />`}
    ${Ue.includes(t.device_type)&&_`<${mn} d=${t} />`}
    ${Ue.includes(t.device_type)&&_`<${hn} d=${t} />`}
    <${F} title="Sensors"><${Pe} device=${t.name||t.key} /><//>
    <${$n} d=${t} reload=${o} />
    <${F} title="Firmware">
      <p class="muted">Sends a firmware image to this device over the CAN bus. It takes a few minutes.</p>
      <${$e} target=${"devices/"+encodeURIComponent(t.name||t.key)} label="Send to device" />
    <//>`:_`<${P} error=${n} />`}function _n({d:e,reload:t}){let n=e.name||e.key,o=(a,r)=>async()=>{await S(()=>I.action(n,a),r),setTimeout(t,1500)};return _`
    <${F} title=${n}
      aside=${_`<span class="buttons">
        <${$} onClick=${o("ping","Ping sent")}>Ping<//>
        <${$} onClick=${o("refresh","Refresh requested")}>Refresh<//>
        <${$} kind="danger" onClick=${o("restart","Restart sent")}>Restart<//>
      </span>`}>
      <dl class="facts">
        <div><dt>Type</dt><dd>${e.type_name} (${e.device_type})</dd></div>
        <div><dt>Key</dt><dd>${e.key}</dd></div>
        <div><dt>Device ID</dt><dd>${e.device_id}</dd></div>
        <div><dt>Version</dt><dd>${e.version}</dd></div>
        <div><dt>Last seen</dt><dd>${Q(e.last_seen_minutes_ago)}</dd></div>
        <div><dt>Hardware rev.</dt><dd>${e.hwrev}</dd></div>
        <div><dt>UID</dt><dd>${e.uid0} / ${e.uid1}</dd></div>
        <div><dt>State / error</dt><dd>${e.state} / ${e.error}</dd></div>
      </dl>
    <//>`}function Rt({d:e,kind:t}){let n=e.name||e.key,[o,a]=y(1),[r,s]=y(0),u=t==="rollershutter",c=l=>()=>S(()=>I[t](n,o,l,Math.round(r*1e3)),`${u?"Rollershutter":"Relay"} ${o}: ${l}`);return _`
    <${F} title=${u?"Rollershutter":"Relays"}>
      ${e.device_type===9&&_`<p class="muted">The heating controller drives relays 0-10 itself and ignores commands for them; only relay 11 can be switched here. For relays 6-10 see manual mode below.</p>`}
      <div class="row">
        <${T} label="Number"><input type="number" min="1" max="16" value=${o} onInput=${l=>a(+l.target.value)} /><//>
        <${T} label="Switch back after (s)" hint="0 = stay"><input type="number" min="0" step="0.1" value=${r} onInput=${l=>s(+l.target.value)} /><//>
      </div>
      <div class="buttons">
        ${u?_`<${$} onClick=${c("up")}>Up<//><${$} onClick=${c("down")}>Down<//><${$} onClick=${c("off")}>Stop<//>`:_`<${$} kind="primary" onClick=${c("on")}>On<//><${$} onClick=${c("off")}>Off<//>`}
      </div>
    <//>`}function dn({d:e}){let t=e.name||e.key,[n,o]=y(0),[a,r]=y(255),[s,u]=y(Array(24).fill(!1)),c=s.reduce((l,d,i)=>d?l|1<<23-i:l,0);return _`
    <${F} title="Lamps">
      <p class="muted">The numbers are the bits of the bank's lamp mask.</p>
      <div class="row">
        <${T} label="Bank"><input type="number" min="0" max="255" value=${n} onInput=${l=>o(+l.target.value)} /><//>
        <${T} label="Value (0-255)"><input type="number" min="0" max="255" value=${a} onInput=${l=>r(+l.target.value)} /><//>
      </div>
      <div class="lamps">
        ${s.map((l,d)=>_`<label key=${d} class=${"lamp"+(l?" on":"")}>
            <input type="checkbox" checked=${l} onChange=${()=>u(s.map((i,f)=>f===d?!i:i))} />${23-d}
          </label>`)}
      </div>
      <${$} kind="primary" onClick=${()=>S(()=>I.lamps(t,n,a,c),"Lamps set")}>Send<//>
    <//>`}function pn({d:e}){let t=e.name||e.key,[n,o]=y(45),[a,r]=y(!1),[s,u]=y(0),[c,l]=y(!1),[d,i]=y(0),[f,h]=y(55);return _`
    <${F} title="Heating control">
      <p class="muted">The controller switches the rod off again when these stop coming (after 30 s).</p>
      <h3>Target</h3>
      <div class="row">
        <${T} label="Flow (°C)"><input type="number" step="0.5" value=${n} onInput=${g=>o(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${a} onChange=${g=>r(g.target.checked)} /> from the tank</label>
        <${$} onClick=${()=>S(()=>I.heating(t,"target",{flow_c:n,tank:a}),"Target sent")}>Send<//>
      </div>
      <h3>Energy</h3>
      <div class="row">
        <${T} label="Power (W)" hint="negative while importing"><input type="number" step="100" value=${s} onInput=${g=>u(+g.target.value)} /><//>
        <label class="check"><input type="checkbox" checked=${c} onChange=${g=>l(g.target.checked)} /> rod released</label>
        <${$} onClick=${()=>S(()=>I.heating(t,"energy",{power_w:s,rod_enabled:c}),"Energy sent")}>Send<//>
      </div>
      <h3>Emergency</h3>
      <div class="row">
        <${T} label="Stage (0-3)"><input type="number" min="0" max="3" value=${d} onInput=${g=>i(+g.target.value)} /><//>
        <${T} label="Tank (°C)"><input type="number" step="0.5" value=${f} onInput=${g=>h(+g.target.value)} /><//>
        <${$} kind="danger" onClick=${()=>S(()=>I.heating(t,"emergency",{stage:d,tank_c:f}),"Emergency sent")}>Send<//>
      </div>
    <//>`}var fn=[[6,"Flow valve"],[7,"Return valve"],[8,"Mixer towards hot"],[9,"Mixer towards cold"],[10,"Circuit pump"]];function mn({d:e}){let t=e.name||e.key,{data:n,error:o,reload:a,ask:r}=ge(t);if(!n)return _`<${F} title="Sensor assignment"><${P} error=${o} /><//>`;let s=n.filter(i=>i.kind==="temperature"),u=i=>s.find(f=>f.role===i),c=i=>i.name?`${i.name} (${i.sensor_id})`:i.sensor_id,l=s.every(i=>i.slot!==null),d=i=>async f=>{let h=f.target.value,g;if(h===""){let A=u(i);if(!A)return;g=await S(()=>K.update(t,A.slot,{role:"none"}),`${ne(i)} cleared`)}else{let A=s.find(E=>E.sensor_id===h);g=await S(()=>K.update(t,A.slot,{role:i}),`${c(A)} is ${ne(i)} now`)}g&&setTimeout(a,1500)};return _`
    <${F} title="Sensor assignment" aside=${_`<${$} onClick=${r}>Reload from the device<//>`}>
      <p class="muted">Which temperature sensor is the tank at each height, and which one measures the flow. The heating needs them to run the rod and the circuit.</p>
      ${!l&&_`<p class="muted">Some sensors have not reported their slot yet; "Reload from the device" asks for it.</p>`}
      <div class="roles">
        ${Ne.filter(i=>i!=="none").map(i=>_`<label key=${i} class="field">
            <span>${ne(i)}</span>
            <select value=${(u(i)||{}).sensor_id||""} onChange=${d(i)} disabled=${!l}>
              <option value="">(none)</option>
              ${s.map(f=>_`<option value=${f.sensor_id}>${c(f)}</option>`)}
            </select>
          </label>`)}
      </div>
    <//>`}function hn({d:e}){let t=e.name||e.key,{data:n,error:o,reload:a}=N(()=>I.heatingManualState(t),3e3),r=!!(n&&n.enabled),s=d=>!!(n&&n.relays.includes(d)),u=async()=>{let d=!r;await S(()=>I.heatingManual(t,d),d?"Manual mode on: valves, mixer and pump are off":"Manual mode off: the controller has them back")&&setTimeout(a,800)},c=d=>async()=>{await S(()=>I.heatingManual(t,!0,d,!s(d)),`Relay ${d} ${s(d)?"off":"on"}`)&&setTimeout(a,800)},l=d=>d===8&&s(9)||d===9&&s(8);return _`
    <${F} title="Manual mode"
      aside=${_`<${$} kind=${r?"danger":""} disabled=${!n} onClick=${u}>${r?"End manual mode":"Start manual mode"}<//>`}>
      <p class="muted">For commissioning, venting and the like: the controller leaves valves, mixer and pump alone (they all go off when this starts) and you switch them one by one. It stays on until you end it, however long that takes — only a restart of the controller ends it too. While it is on, commands for the heating (from MQTT, too) are dropped, so the heating rod goes off. The rod is never switchable here.</p>
      ${o&&_`<p class="error">The controller does not answer: ${o.message}</p>`}
      ${r&&_`<p class="badge warn">Manual mode is on</p>`}
      <div class="manual">
        ${fn.map(([d,i])=>_`<button key=${d} class=${s(d)?"primary":""} disabled=${!r||l(d)} onClick=${c(d)}>
            <span>${i}</span><small>relay ${d}: ${s(d)?"on":"off"}</small>
          </button>`)}
      </div>
    <//>`}function $n({d:e,reload:t}){let n=e.name||e.key,[o,a]=y({custom_string:e.name,hwrev:e.hwrev,relais_mode:"",extension_mode:""}),[r,s]=y(!1),u=l=>d=>a({...o,[l]:d.target.value}),c=async()=>{let l={};if(o.custom_string!==e.name&&(l.custom_string=o.custom_string),+o.hwrev!==e.hwrev&&(l.hwrev=+o.hwrev),o.relais_mode&&(l.relais_mode=o.relais_mode),o.extension_mode&&(l.extension_mode=o.extension_mode),Object.keys(l).length===0)return D("Nothing changed");await S(()=>I.update(n,l),"Settings sent")&&setTimeout(t,1500)};return _`
    <${F} title="Settings">
      <div class="row">
        <${T} label="Name" hint="up to 8 characters"><input maxlength="8" value=${o.custom_string} onInput=${u("custom_string")} /><//>
        <${T} label="Hardware revision"><input type="number" min="0" max="255" value=${o.hwrev} onInput=${u("hwrev")} /><//>
        <${T} label="Relay mode"><select value=${o.relais_mode} onChange=${u("relais_mode")}>
          <option value="">(unchanged)</option>${cn.map(l=>_`<option>${l}</option>`)}
        </select><//>
        <${T} label="Extension mode"><select value=${o.extension_mode} onChange=${u("extension_mode")}>
          <option value="">(unchanged)</option>${un.map(l=>_`<option>${l}</option>`)}
        </select><//>
      </div>
      <div class="buttons">
        <${$} kind="primary" onClick=${c}>Save<//>
        <${$} onClick=${async()=>{await S(()=>I.silence(n,!r),r?"Device may talk again":"Device silenced"),s(!r)}}>${r?"End silence":"Silence"}<//>
        <${$} onClick=${()=>S(()=>I.action(n,"legacy-mode"),"Update mode requested")}>Legacy update mode<//>
      </div>
    <//>`}function Lt(){let{data:e,error:t,reload:n}=N(I.list,5e3),[o,a]=y(""),r=(l,d)=>async()=>{await S(l,d),setTimeout(n,1500)},s=async()=>{let l=o.trim();l&&await S(()=>I.action(l,"ping"),`Ping sent to ${l}`)},u=async()=>{confirm("Restart every device on the bus?")&&await r(()=>J.action("restart"),"Restart sent to every device")()},c=r(async()=>{await J.action("ping"),await J.action("refresh")},"Scanning: every device was asked to announce itself");return _`
    <${F} title="Devices">
      <div class="toolbar">
        <${$} onClick=${n}>Refresh<//>
        <${$} onClick=${r(()=>J.action("ping"),"Ping sent to every device")}>Broadcast ping<//>
        <${$} onClick=${r(()=>J.silence(!0),"Every device is silenced")}>Silence on<//>
        <${$} onClick=${r(()=>J.silence(!1),"Every device may talk again")}>Silence off<//>
        <${$} kind="danger" onClick=${u}>Restart all<//>
        <input class="uid" placeholder="Name or 0x… key" value=${o} onInput=${l=>a(l.target.value)} onKeyDown=${l=>l.key==="Enter"&&s()} />
        <${$} onClick=${s}>Ping<//>
        <${$} onClick=${c}>Scan<//>
      </div>
      ${e?e.length===0?_`<p class="muted">No device seen on the bus yet. Try a scan.</p>`:_`<div class="table-wrap"><table>
              <thead><tr><th>Name</th><th>ID</th><th>Type</th><th>Version</th><th>Seen</th><th>Uptime</th><th>State</th></tr></thead>
              <tbody>
                ${e.map(l=>_`<tr key=${l.key}>
                    <td><${z} href=${"/devices/"+encodeURIComponent(l.name||l.key)}>${l.name||l.key}<//></td>
                    <td><code>${Me(l.device_id)}</code></td>
                    <td>${l.type_name} <code>${Me(l.device_type)}</code></td>
                    <td>${l.version}</td>
                    <td>${Q(l.last_seen_minutes_ago)}</td>
                    <td>${l.uptime?Q(Math.floor(l.uptime/60)):""}</td>
                    <td>${l.error?_`<span class="badge bad">error ${l.error}</span>`:l.last_seen_minutes_ago>10?_`<span class="badge warn">silent</span>`:_`<span class="badge ok">ok</span>`}</td>
                  </tr>`)}
              </tbody>
            </table></div>`:_`<${P} error=${t} />`}
      ${t&&e&&_`<p class="error">${t.message}</p>`}
    <//>`}function At(){return _`<${vn} /><${gn} /><${yn} />`}function vn(){let{data:e,error:t}=N(Ae.get,5e3);return _`
    <${F} title="Gateway" aside=${_`<${$} kind="danger" onClick=${async()=>{confirm("Restart the gateway?")&&await S(Ae.restart,"Restarting\u2026")}}>Restart<//>`}>
      ${e?_`<dl class="facts">
            <div><dt>Firmware</dt><dd>${e.firmware_version}</dd></div>
            <div><dt>Uptime</dt><dd>${xt(e.uptime_s)}</dd></div>
            <div><dt>Heap</dt><dd>${Math.round(e.heap_used/1024)} KiB used, ${Math.round(e.heap_free/1024)} KiB free</dd></div>
          </dl>`:_`<${P} error=${t} />`}
    <//>`}function gn(){let{data:e,error:t,reload:n}=N(He.get),[o,a]=y({});if(!e)return _`<${P} error=${t} />`;let r=c=>c in o?o[c]:e[c],s=(c,l)=>d=>a({...o,[c]:l?+d.target.value:d.target.value}),u=async()=>{let c={...o};if(c.web_password||delete c.web_password,Object.keys(c).length===0)return D("Nothing changed");let l=await S(()=>He.update(c),"Saved");l&&(l.restart_required&&D("Restart the gateway to apply the hostname or bitrate."),a({}),n())};return _`
    <${F} title="Settings">
      <div class="row">
        <${T} label="Hostname"><input value=${r("hostname")} onInput=${s("hostname")} /><//>
        <${T} label="CAN bitrate"><select value=${r("can_bitrate")} onChange=${s("can_bitrate")}>
          ${["b22_222","b25","b50","b100"].map(c=>_`<option>${c}</option>`)}
        </select><//>
        <${T} label="CAN update delay (ms)" hint="between frames while updating a device"><input type="number" min="1" max="10000" value=${r("update_delay_ms")} onInput=${s("update_delay_ms",!0)} /><//>
      </div>
      <h3>Web access</h3>
      <div class="row">
        <${T} label="User name"><input value=${r("web_username")} onInput=${s("web_username")} autocomplete="off" /><//>
        <${T} label="New password" hint="at least 8 characters; empty keeps it"><input type="password" value=${o.web_password||""} onInput=${s("web_password")} autocomplete="new-password" /><//>
      </div>
      <div class="buttons"><${$} kind="primary" onClick=${u}>Save<//></div>
    <//>`}function yn(){return _`
    <${F} title="Gateway firmware">
      <p class="muted">Installs a new firmware image (the .bin of gateway-hardware) and restarts into it.</p>
      <${$e} target="gateway" label="Install and restart" />
    <//>`}var bn={primary:"Everything the gateway publishes goes here.",secondary:"Only listens (commands come in); the gateway publishes nothing to it."};function It(){let{data:e,error:t,reload:n}=N(ee.all,5e3);return e?_`
    <${Ht} slot="primary" b=${e.primary} reload=${n} />
    <${Ht} slot="secondary" b=${e.secondary} reload=${n} />`:_`<${P} error=${t} />`}function Ht({slot:e,b:t,reload:n}){let[o,a]=y({uri:t.uri,user:t.user,password:"",enabled:t.enabled,tls_insecure:t.tls_insecure}),[r,s]=y(null),u=o.uri.startsWith("mqtts://"),c=i=>f=>a({...o,[i]:f.target.type==="checkbox"?f.target.checked:f.target.value}),l=async()=>{let i={uri:o.uri,user:o.user,enabled:o.enabled,tls_insecure:o.tls_insecure};o.password&&(i.password=o.password),await S(()=>ee.update(e,i),`${e} broker saved, reconnecting`)&&(a({...o,password:""}),setTimeout(n,2500))},d=async()=>{let i=await S(()=>ee.certificate(e));i&&s(i)};return _`
    <${F}
      title=${e[0].toUpperCase()+e.slice(1)+" broker"}
      aside=${_`<span class=${"badge "+(t.connected?"ok":t.enabled?"warn":"muted")}>${t.connected?"connected":t.enabled?"not connected":"off"}</span>`}>
      <p class="muted">${bn[e]}</p>
      <div class="row">
        <${T} label="Address" hint="mqtt://host[:1883] or mqtts://host[:8883]"><input value=${o.uri} onInput=${c("uri")} /><//>
        <${T} label="User"><input value=${o.user} onInput=${c("user")} autocomplete="off" /><//>
        <${T} label="Password" hint=${t.password_set?"set; empty keeps it":"none set"}><input type="password" value=${o.password} onInput=${c("password")} autocomplete="new-password" /><//>
      </div>
      <label class="check"><input type="checkbox" checked=${o.enabled} onChange=${c("enabled")} /> Connect to this broker</label>
      ${u&&_`
        <div class="tls">
          <h3>Encryption</h3>
          <p class="muted">The broker's certificate is pinned: after "Trust", only a broker with the same key is accepted.</p>
          <label class="check"><input type="checkbox" checked=${o.tls_insecure} onChange=${c("tls_insecure")} /> Accept any certificate (encrypted, but not authenticated)</label>
          <div class="buttons">
            <${$} onClick=${async()=>{await S(()=>ee.trust(e),"The next connection pins the broker's certificate"),setTimeout(()=>{n(),d()},4e3)}}>Trust the broker's certificate now<//>
            <${$} onClick=${d}>Show pinned certificate<//>
            ${t.certificate_pinned&&_`<${$} kind="danger" onClick=${async()=>{await S(()=>ee.forget(e),"Certificate forgotten"),s(null),n()}}>Forget<//>`}
          </div>
          ${r&&_`<p>${r.pinned?_`SHA-256 <code>${r.sha256}</code>`:"No certificate pinned."}</p>`}
        </div>`}
      <div class="buttons"><${$} kind="primary" onClick=${l}>Save<//></div>
    <//>`}var kn=[{path:"/",title:"Devices",page:Lt},{path:"/devices/:device",title:"Device",page:Ft},{path:"/sensors",title:"Sensors",page:Et},{path:"/mqtt",title:"MQTT",page:It},{path:"/gateway",title:"Gateway",page:At}],wn=[["/","Devices"],["/sensors","Sensors"],["/mqtt","MQTT"],["/gateway","Gateway"]];function Sn(){let e=Ct(),t=Tt(kn,e),n=t?t.route.page:null,o=a=>a==="/"?e==="/"||e.startsWith("/devices"):e.startsWith(a);return _`
    <header class="top">
      <strong>CAN2MQTT</strong>
      <nav>${wn.map(([a,r])=>_`<${z} href=${a} class=${o(a)?"active":""}>${r}<//>`)}</nav>
    </header>
    <main>
      ${n?_`<${n} key=${e} ...${t.params} />`:_`<p class="error">No such page. <${z} href="/">Devices<//></p>`}
    </main>
    <${St} />`}tt(_`<${Sn} />`,document.getElementById("app"));
